--[[
  PulseFlash - ComboBar.lua  (WoW 3.3.5a)
  Barra de puntos de combo (5 segmentos) para el PÍCARO y el DRUIDA feral.

  Todo es personalizable desde el menú (/pf config -> Combos) y se guarda en el perfil activo
  (PF.db.combo, que Profiles.lua guarda por personaje y rama):
    enabled ... barra activada
    scale ..... escala de toda la barra (0.5 - 2.5)
    w, h ...... ancho y alto de cada segmento en píxeles (10-60 / 6-40)
    gap ....... separación entre segmentos (0-12)
    alpha ..... opacidad (0.1 - 1)
    show ...... "always" siempre | "target" con objetivo hostil | "points" solo con puntos de combo
    palette ... "gradient" | "yellow" | "red" | "green" | "white"
    number .... muestra el número de puntos sobre la barra
    x, y ...... posición (se mueve arrastrando cuando está desbloqueada)
    locked .... estado de sesión: desbloqueada = se puede arrastrar

  Solo LEE los puntos de combo: no toca la rotación ni el resplandor de las barras.
  El Druida solo ve la barra en forma de gato (o si aún conserva puntos).
]]
local PF = PulseFlash
-- Memoria: este archivo solo se carga para ROGUE/DRUID (en las demás clases se descarta al instante)
do local c = select(2, UnitClass("player")); if c and c ~= "ROGUE" and c ~= "DRUID" then return end end

local WHITE = "Interface\\Buttons\\WHITE8X8"
local MAX_CP = 5

PF.COMBO_DEFAULT = {
  enabled = true, locked = true, x = 0, y = -60, scale = 1.0,
  w = 36, h = 14, gap = 4, alpha = 1.0,
  show = "target", palette = "gradient", number = true,
}
PF.COMBO_SCALE_MIN, PF.COMBO_SCALE_MAX = 0.5, 2.5

local PALETTES = {
  gradient = { { 1.00, 0.90, 0.10 }, { 1.00, 0.78, 0.10 }, { 1.00, 0.60, 0.10 },
               { 1.00, 0.42, 0.10 }, { 1.00, 0.20, 0.10 } },
  yellow   = { { 1.00, 0.85, 0.10 }, { 1.00, 0.85, 0.10 }, { 1.00, 0.85, 0.10 },
               { 1.00, 0.85, 0.10 }, { 1.00, 0.85, 0.10 } },
  red      = { { 0.95, 0.15, 0.12 }, { 0.95, 0.15, 0.12 }, { 0.95, 0.15, 0.12 },
               { 0.95, 0.15, 0.12 }, { 0.95, 0.15, 0.12 } },
  green    = { { 0.25, 0.95, 0.30 }, { 0.25, 0.95, 0.30 }, { 0.25, 0.95, 0.30 },
               { 0.25, 0.95, 0.30 }, { 0.25, 0.95, 0.30 } },
  white    = { { 0.95, 0.95, 0.95 }, { 0.95, 0.95, 0.95 }, { 0.95, 0.95, 0.95 },
               { 0.95, 0.95, 0.95 }, { 0.95, 0.95, 0.95 } },
}
-- Orden y nombre de cada paleta en el menú
PF.COMBO_PALETTE_LIST = {
  { "gradient" }, { "yellow" }, { "red" }, { "green" }, { "white" },   -- nombre: PF.T("pal_<id>")
}
local SHOW = { always = true, target = true, points = true }

local function Clamp(v, lo, hi, default)
  v = tonumber(v)
  if not v then return default end
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

-- Deja la configuración de la barra con valores válidos (la llama Profiles.lua)
function PF.ComboSanitize(c)
  local D = PF.COMBO_DEFAULT
  c.scale = Clamp(c.scale, PF.COMBO_SCALE_MIN, PF.COMBO_SCALE_MAX, D.scale)
  c.w = math.floor(Clamp(c.w, 10, 60, D.w) + 0.5)
  c.h = Clamp(c.h, 6, 40, D.h)
  c.gap = Clamp(c.gap, 0, 12, D.gap)
  c.alpha = Clamp(c.alpha, 0.1, 1, D.alpha)
  c.x = tonumber(c.x) or D.x
  c.y = tonumber(c.y) or D.y
  if not SHOW[c.show] then c.show = D.show end
  if not PALETTES[c.palette] then c.palette = D.palette end
  c.enabled = c.enabled and true or false
  c.number = c.number and true or false
end

local bar
local class

local function Cfg() return PF.db and PF.db.combo end

----------------------------------------------------------------------
-- Posición y tamaño
----------------------------------------------------------------------
local function Layout()
  local c = Cfg()
  if not (bar and c) then return end
  local w, h, gap = c.w, c.h, c.gap
  bar:SetWidth(w * MAX_CP + gap * (MAX_CP - 1))
  bar:SetHeight(h)
  for i = 1, MAX_CP do
    local f = bar.seg[i]
    f:SetWidth(w); f:SetHeight(h)
    f:ClearAllPoints()
    f:SetPoint("LEFT", bar, "LEFT", (i - 1) * (w + gap), 0)
  end
  bar:SetScale(c.scale)
  bar:ClearAllPoints()
  bar:SetPoint("CENTER", UIParent, "CENTER", c.x / c.scale, c.y / c.scale)
  bar.cacheKey = nil              -- fuerza repintar colores
end

local function SavePos()
  local c = Cfg()
  local cx, cy = bar:GetCenter()
  local ucx, ucy = UIParent:GetCenter()
  if not (c and cx and ucx) then return end
  local s = bar:GetScale()
  c.x = math.floor(cx * s - ucx + 0.5)
  c.y = math.floor(cy * s - ucy + 0.5)
end

function PF.ComboBarApplyLock()
  if not bar then return end
  local c = Cfg()
  if not c or c.locked then
    bar:EnableMouse(false)
    bar.drag:Hide()
  else
    bar:EnableMouse(true)
    bar.drag:Show()
  end
end

-- Reaplica tamaño / posición / bloqueo del perfil activo (lo usan Profiles.lua y Config.lua)
function PF.ComboBarApply()
  if not bar or not Cfg() then return end
  Layout()
  PF.ComboBarApplyLock()
end

----------------------------------------------------------------------
-- Construcción
----------------------------------------------------------------------
local function Build()
  bar = CreateFrame("Frame", "PulseFlashComboBar", UIParent)
  bar:SetFrameStrata("MEDIUM")
  bar:SetClampedToScreen(true)
  bar:SetMovable(true)
  bar:SetUserPlaced(false)
  bar:RegisterForDrag("LeftButton")

  bar.seg = {}
  for i = 1, MAX_CP do
    local f = CreateFrame("Frame", nil, bar)
    f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1,
                    insets = { left = 1, right = 1, top = 1, bottom = 1 } })
    f:SetBackdropColor(0.03, 0.03, 0.04, 0.85)
    f:SetBackdropBorderColor(0.02, 0.02, 0.02, 1)
    f.fill = f:CreateTexture(nil, "ARTWORK")
    f.fill:SetTexture(WHITE)
    f.fill:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1)
    f.fill:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 1)
    bar.seg[i] = f
  end

  bar.num = bar:CreateFontString(nil, "OVERLAY")
  bar.num:SetFont("Fonts\\FRIZQT__.TTF", 16, "OUTLINE")
  bar.num:SetPoint("BOTTOM", bar, "TOP", 0, 3)

  -- Marco de arrastre visual (solo desbloqueada)
  bar.drag = CreateFrame("Frame", nil, bar)
  bar.drag:SetPoint("TOPLEFT", bar, "TOPLEFT", -4, 4)
  bar.drag:SetPoint("BOTTOMRIGHT", bar, "BOTTOMRIGHT", 4, -4)
  bar.drag:SetFrameLevel(bar:GetFrameLevel() + 10)
  bar.drag:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 2,
                         insets = { left = 2, right = 2, top = 2, bottom = 2 } })
  bar.drag:SetBackdropColor(1.00, 0.82, 0.00, 0.20)
  bar.drag:SetBackdropBorderColor(1.00, 0.82, 0.00, 1)
  bar.drag.text = bar.drag:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  bar.drag.text:SetPoint("TOP", bar.drag, "BOTTOM", 0, -4)
  bar.drag.text:SetText(PF.T("comboDrag"))
  PF.OnLangChange(function() bar.drag.text:SetText(PF.T("comboDrag")) end)
  bar.drag:Hide()

  bar:SetScript("OnDragStart", function(self)
    local c = Cfg()
    if c and not c.locked then self:StartMoving() end
  end)
  bar:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    SavePos()
    Layout()
  end)
  bar:Hide()
end

----------------------------------------------------------------------
-- Actualización (solo lectura de los puntos de combo)
----------------------------------------------------------------------
local function Paint(cp, c)
  local pal = PALETTES[c.palette] or PALETTES.gradient
  local key = cp .. "|" .. c.palette .. "|" .. (c.number and 1 or 0)
  if bar.cacheKey == key then return end
  bar.cacheKey = key
  for i = 1, MAX_CP do
    local f = bar.seg[i]
    local col = pal[i]
    if i <= cp then
      f.fill:SetVertexColor(col[1], col[2], col[3], 1)
      f.fill:SetAlpha(1)
    else
      f.fill:SetVertexColor(col[1], col[2], col[3], 1)
      f.fill:SetAlpha(0.14)           -- segmento vacío: tenue
    end
    -- con los 5 puntos, borde dorado: "listo para el remate"
    if cp >= MAX_CP then f:SetBackdropBorderColor(1, 0.82, 0, 1)
    else f:SetBackdropBorderColor(0.02, 0.02, 0.02, 1) end
  end
  if c.number and cp > 0 then
    local col = pal[cp]
    bar.num:SetTextColor(col[1], col[2], col[3])
    bar.num:SetText(cp)
  else
    bar.num:SetText("")
  end
end

local function Update()
  local c = Cfg()
  if not (bar and c) then return end
  local preview = PF.comboTest
  local unlocked = not c.locked

  if not (preview or unlocked) then
    if not c.enabled or not PF.db.enabled then bar:Hide(); return end
  end

  local cp = preview and MAX_CP or (GetComboPoints("player", "target") or 0)
  if not (preview or unlocked) then
    -- Druida: solo se ve en forma de gato (o con puntos que aún conserva)
    if class == "DRUID" and cp == 0 and not PF.Aura("player", PF.N.CatForm) then bar:Hide(); return end
    local show = c.show
    local ok
    if show == "always" then
      ok = true
    elseif show == "points" then
      ok = cp > 0
    else
      ok = (UnitExists("target") and UnitCanAttack("player", "target") and not UnitIsDead("target")) and true or false
    end
    if not ok then bar:Hide(); return end
  end
  if unlocked and not preview then cp = cp > 0 and cp or 3 end   -- desbloqueada: muestra algo para colocarla

  bar:SetAlpha(c.alpha)
  Paint(cp, c)
  bar:Show()
end

----------------------------------------------------------------------
-- API pública (menú, minimapa y comandos)
----------------------------------------------------------------------
function PF.ToggleComboLock()
  local c = Cfg()
  if not c then return end
  c.locked = not c.locked
  if not c.locked then c.enabled = true end
  PF.ComboBarApplyLock()
  PF.Msg(c.locked and PF.T("comboLockedMsg") or PF.T("comboUnlockedMsg"))
  if PF.RefreshConfig then PF.RefreshConfig() end
end

function PF.ToggleComboTest()
  PF.comboTest = not PF.comboTest
  PF.Msg(PF.T("comboPreview", PF.comboTest and PF.T("ON_F") or PF.T("OFF_F")))
  if PF.RefreshConfig then PF.RefreshConfig() end
end

function PF.ToggleComboBar()
  local c = Cfg()
  if not (c and bar) then PF.Msg(PF.T("comboOnly")); return end
  c.enabled = not c.enabled
  PF.Msg(PF.T("comboIs", c.enabled and PF.T("ON_F") or PF.T("OFF_F")))
  if PF.RefreshConfig then PF.RefreshConfig() end
end

-- Para el menú: ¿esta clase tiene barra de combos?
function PF.HasComboBar() return bar ~= nil end

-- La llama Core.lua en PLAYER_LOGIN (después de crear el perfil activo y rellenar PF.N)
function PF.ComboBar_Init(cls)
  if cls ~= "ROGUE" and cls ~= "DRUID" then return end
  class = cls
  Build()
  PF.ComboBarApply()
  local driver = CreateFrame("Frame")
  local acc = 0
  driver:SetScript("OnUpdate", function(_, dt)
    acc = acc + dt
    if acc < 0.05 then return end
    acc = 0
    Update()
  end)
end
