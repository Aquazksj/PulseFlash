-- PulseFlash: Chamán (Elemental / Mejora; Restauración como daño) - 3.3.5a
--
-- Mejora, por orden: Arma Vorágine de maná con 5 cargas (Descarga / Cadena de relámpagos) >
--   Choque de llamas (siempre activo) > Golpe de tormenta > Latigazo de lava > Choque de tierra (solo si
--   el Choque de llamas aguanta más de 6,5 s: comparten enfriamiento) > Descarga de relámpagos (relleno).
-- Elemental: Choque de llamas (se renueva con 3 s) > Ráfaga de lava (solo con el choque aguantando el
--   lanzamiento) > Cadena de relámpagos (con maná) > Descarga de relámpagos (relleno). Maestría
--   elemental, Tótem de elemental de fuego y Tormenta de truenos para el maná.
-- Escudos, encantamientos de arma y TÓTEMS: los recomienda el HUD de buffos (BuffHUD.lua).
local CF = PulseFlash
-- Memoria: este archivo solo se carga para SHAMAN (en las demás clases se descarta al instante)
do local c = select(2, UnitClass("player")); if c and c ~= "SHAMAN" then return end end
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

local MAELSTROM_STACKS = 5       -- cargas de Arma Vorágine de maná para el hechizo instantáneo
local ELE_FS_REFRESH = 3.0        -- Elemental: renueva Choque de llamas con <= 3 s (Ráfaga de lava necesita 2 s de lanzamiento)
local LAVA_BURST_MIN_FS = 2.5     -- Ráfaga de lava solo si el Choque de llamas aguantará el lanzamiento (crítico asegurado)
local EARTH_SHOCK_MIN_FS = 6.5    -- Mejora: Choque de tierra comparte enfriamiento con el de llamas; solo si no lo retrasa
local ELE_CHAIN_MIN_MANA = 0.25   -- Elemental: Cadena de relámpagos (cara) solo con más maná que esto (salvo ejecución/área)

-- DoT con umbral propio de renovación (PF.Dot usa un umbral fijo de 2 s)
local function DotAt(add, c, spell, left, thr)
  if not spell then return end
  if left and left > thr then return end
  if CF.IsCasting(spell) or c.casting == spell or CF.Pending(spell) then return end
  add(spell, 1)
end

local function evaluate(c, add, N)
  local spec = c.spec
  local fs = Aura("target", N.FlameShock, true, true)

  if spec == 2 then
    -- Mejora (cuerpo a cuerpo)
    Proc(add, N.MaelstromWeapon, CF.db.aoe and N.ChainLightning or N.LightningBolt, MAELSTROM_STACKS)
    if c.worth then Dot(add, c, N.FlameShock, fs) end
    add(N.Stormstrike, 1)
    add(N.LavaLash, 1)
    -- Choque de tierra: comparte enfriamiento con Choque de llamas, así que solo si éste aguanta
    if not c.worth or (fs and fs > EARTH_SHOCK_MIN_FS) then add(N.EarthShock, 1) end
    if CF.db.aoe then add(N.ChainLightning, 1) end
    if c.combat and c.bigCD then                       -- cooldowns largos: solo contra jefes
      add(N.FeralSpirit, 2)
      add(N.FireElementalTotem, 2)
    end
  else
    -- Elemental / Restauración / sin especialización (leveling): a distancia
    if c.worth then DotAt(add, c, N.FlameShock, fs, spec == 1 and ELE_FS_REFRESH or 2.0) end
    if fs and fs > LAVA_BURST_MIN_FS and c.casting ~= N.LavaBurst then add(N.LavaBurst, 1) end
    if (spec == 1 and (c.manaPct > ELE_CHAIN_MIN_MANA or c.burn)) or CF.db.aoe then
      add(N.ChainLightning, 1)
    end
    if c.combat and c.bigCD then
      add(N.ElementalMastery, 2)
      add(N.FireElementalTotem, 2)
    end
  end

  -- Interrupción / defensivos / utilidad (verde)
  if UnitCastingInfo("target") or UnitChannelInfo("target") then
    local kick = Known(N.WindShear) and N.WindShear or N.EarthShock
    if IsSpellInRange(kick, "target") == 1 then add(kick, 3) end
  end
  if c.combat then
    if c.php < 0.50 or c.manaPct < 0.25 then add(N.ShamanisticRage, 3) end
    if c.manaPct < 0.25 then add(N.Thunderstorm, 3) end
  end
end

-- Relleno infinito: Descarga de relámpagos
local function filler(c, N)
  return First(N.LightningBolt)
end

CF.Register("SHAMAN", {
  ids = {
    LightningBolt = 403,     ChainLightning = 421,     FlameShock = 8050,
    EarthShock = 8042,       LavaBurst = 51505,        Stormstrike = 17364,
    LavaLash = 60103,        LightningShield = 324,    WaterShield = 52127,
    WindShear = 57994,       ShamanisticRage = 30823,  FeralSpirit = 51533,
    ElementalMastery = 16166, Thunderstorm = 51490,    FireElementalTotem = 2894,
    MaelstromWeapon = 53817,   -- buff (proc)
    WindfuryWeapon = 8232, FlametongueWeapon = 8024, RockbiterWeapon = 8017,
  },
  multidot = { [0] = { "FlameShock" }, [1] = { "FlameShock" }, [2] = { "FlameShock" } },
  evaluate = evaluate,
  filler = filler,
})
