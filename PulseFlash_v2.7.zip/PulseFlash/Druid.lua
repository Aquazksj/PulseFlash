-- PulseFlash: Druida (Equilibrio / Feral gato; Ira como relleno al subir) - 3.3.5
local CF = PulseFlash
-- Memoria: este archivo solo se carga para DRUID (en las demás clases se descarta al instante)
do local c = select(2, UnitClass("player")); if c and c ~= "DRUID" then return end end
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

-- Feral (gato): prioridades según Icy Veins (WotLK Classic, Feral Druid DPS Rotation).
--
-- MODO DE ROTACIÓN (menú -> Rotación, o /pf modo):
--   NORMAL ....... siempre se recomienda la primera habilidad que puedas lanzar YA.
--   MÁXIMO DAÑO .. (prueba) dos cambios, ambos con cuenta atrás en el HUD. Salen de la propia guía
--     de Icy Veins / Warcraft Tavern ("Destrozar o acumular energía para lo anterior"; "Destrozar
--     para generar PC si no te impide tener energía para refrescar los DoT o el debuff de Mutilar"):
--     1) ACUMULAR ENERGÍA PARA REFRESCAR: si Rugido salvaje, Desgarrar (con 5 PC), Rastrillar o el
--        debuff de Mutilar vencen en pocos segundos y gastar ahora la energía en un generador te
--        dejaría sin la necesaria para refrescarlo en cuanto expire, se espera.
--     2) DESTROZAR EN VEZ DE MUTILAR: con el debuff de Mutilar ya activo, Mutilar es solo un
--        generador más débil. Si estás detrás y faltan <= 2 s de energía para Destrozar, se espera
--        en vez de gastar esa energía en Mutilar (no se espera durante Berserk).
local BERSERK_POOL = 85       -- energía a acumular antes de Berserk (la guía dice ~90)
local TF_ENERGY = 40          -- Tiger's Fury solo con menos de esta energía
local BERSERK_TF_CD = 15      -- Berserk solo si a Tiger's Fury le quedan >= 15 s de cooldown
local RIP_DYING_HP = 0.05     -- jefe casi muerto: Mordedura feroz en vez de Desgarrar

-- ECLIPSE (Equilibrio), flujo completo:
--   1) Sin Eclipse: Cólera hasta que salte Eclipse lunar.
--   2) Eclipse lunar activo: Fuego estelar.
--   3) Al acabarse el lunar se SIGUE con Fuego estelar (un crítico suyo da Eclipse solar) durante
--      ECLIPSE_SOLAR_WAIT segundos; si el solar no sale en ese tiempo, se vuelve a Cólera (paso 1).
--   4) Eclipse solar activo: Cólera; al acabarse, vuelta al paso 1.
--   Los DoTs (Enjambre de insectos / Fuego lunar) van SIEMPRE antes: son instantáneos y se renuevan sin
--   perder el Eclipse. Se reinicia al salir de combate.
local ECLIPSE_SOLAR_WAIT = 15    -- s insistiendo con Fuego estelar tras el lunar, esperando el solar (= duración del lunar)
local lunarWas, lunarEndedAt = false, nil

local function TrackEclipse(c, N)
  if not c.combat then lunarWas, lunarEndedAt = false, nil; return end
  if Aura("player", N.EclipseLunar) then
    lunarWas, lunarEndedAt = true, nil
  elseif lunarWas then                                    -- el lunar acaba de terminar
    lunarWas, lunarEndedAt = false, GetTime()
  end
  if Aura("player", N.EclipseSolar) then lunarEndedAt = nil end   -- ya salió el solar: fin de la espera
end

-- Seguimiento del Eclipse en cada pulso (también sin objetivo): solo Equilibrio / lanzador a distancia
local function upkeep(c, add, N)
  if c.spec ~= 2 then TrackEclipse(c, N) end
end

local function IsCat(c, N)
  return c.spec == 2 and Known(N.CatForm)
end

-- Segundos que le faltan a un cooldown (0 si está listo o solo tiene el GCD)
local function CDLeft(spell)
  if not spell then return 0 end
  local s, d = GetSpellCooldown(spell)
  if s and s > 0 and d and d > 1.6 then return math.max(0, s + d - GetTime()) end
  return 0
end

-- Feral: un DoT/buff propio se vuelve a aplicar SOLO cuando ya expiró (refrescarlo antes pierde
-- el último tick / duración). Si se acaba de lanzar (latencia) se da por cubierto.
local function Reapply(add, spell, left)
  if not spell or left then return end
  if CF.IsCasting(spell) or CF.Pending(spell) then return end
  add(spell, 1)
end

local function evaluate(c, add, N)
  local spec = c.spec
  local cp = c.cp

  if IsCat(c, N) then
    ----------------------------------------------------------------
    -- Feral (gato)
    ----------------------------------------------------------------
    if not Aura("player", N.CatForm) then add(N.CatForm, 1) end

    -- Apertura desde sigilo (Rondar): Devastar (detrás) o Abalanzarse
    if Aura("player", N.Prowl) then
      if c.behind then add(N.Ravage, 1) end
      add(N.Pounce, 1)
    end

    local energy = c.energy
    local maxMode = CF.db and CF.db.rot and CF.db.rot.max
    local sr = Aura("player", N.SavageRoar)
    local cc = Aura("player", N.Clearcasting)
    local ripLeft = Aura("target", N.Rip, true, true)
    local rakeLeft = Aura("target", N.Rake, true, true)
    -- Debuff de Mutilar: se llama "Mutilar" (sin "(Gato)"); Trauma del guerrero lo sustituye
    local mangleName = N.Mangle and (N.Mangle:gsub("%s*%b()", "")) or nil
    local mangleUp = Aura("target", mangleName, true) or Aura("target", N.Trauma, true)

    if c.combat then
      -- 1) Tiger's Fury con poca energía
      if energy < TF_ENERGY then add(N.TigersFury, 1) end
      -- 2) Berserk: acumular ~90 de energía y solo si a Tiger's Fury le quedan >= 15 s
      local tfLeft = CDLeft(N.TigersFury)
      local bsOk = (not Known(N.TigersFury)) or tfLeft >= BERSERK_TF_CD
      if c.bigCD then                                  -- Berserk (3 min): solo contra jefes
        if bsOk and energy >= BERSERK_POOL then add(N.Berserk, 1) else add(N.Berserk, 2) end
      end
    end

    -- 3) Rugido salvaje (se reaplica al expirar)
    if cp >= 1 then Reapply(add, N.SavageRoar, sr) end

    -- 4) Faerie Fire (Feral) para provocar Omen of Clarity (si no estás ya bajo Clearcasting)
    if c.combat and not cc then add(N.FaerieFire, 1) end

    if CF.db.aoe then
      -- Varios objetivos: Rastrillar genera el PC del Rugido; el resto es Azote (gato)
      if cp == 0 and not sr then add(N.Rake, 1) end
      add(N.Swipe, 1)
    else
      -- 5) Clearcasting: Destrozar (o Mutilar si no estás detrás) sale gratis
      if cc and cp < 5 then
        if c.behind then add(N.Shred, 1) end
        add(N.Mangle, 1)
      end

      -- 6) Desgarrar con 5 PC. Si el objetivo va a morir ya, Mordedura feroz (Rip necesita tiempo)
      local dying = (not c.worth) or (c.boss and c.hp <= RIP_DYING_HP)
      if cp >= 5 then
        if dying or not Known(N.Rip) then
          add(N.FerociousBite, 1)
        else
          Reapply(add, N.Rip, ripLeft)
        end
      end

      -- 7) Rastrillar (se reaplica al expirar)
      if c.worth then Reapply(add, N.Rake, rakeLeft) end

      -- 8) Debuff de Mutilar (+30% al daño de sangrado) si nadie más lo aporta
      if c.hostile and Known(N.Mangle) and not mangleUp then add(N.Mangle, 1) end

      -- MÁXIMO DAÑO: acumular energía para el próximo refresco (Rugido / Desgarrar / Rastrillar /
      -- debuff de Mutilar). Lo que se gastaría ahora es el generador que se lanzaría (gratis con
      -- Clearcasting). Se espera por el refresco que antes venza si no llegaría a tiempo.
      local berserk = Aura("player", N.Berserk)
      if maxMode and not cc then
        local gen = (c.behind and Known(N.Shred) and N.Shred) or (Known(N.Mangle) and N.Mangle) or N.Claw
        local spendCost = CF.Cost(gen)
        local best, bestT
        local function Cand(spell, left, ok)
          if not (spell and left and ok) or not Known(spell) then return end
          if left <= 0 or left > CF.POOL_MAX_T then return end
          if CF.CanSpend(spendCost, CF.Cost(spell), left, 10) then return end
          if not bestT or left < bestT then best, bestT = spell, left end
        end
        Cand(N.SavageRoar, sr, cp >= 1)
        Cand(N.Rip, ripLeft, cp >= 5 and not dying and Known(N.Rip))
        Cand(N.Rake, rakeLeft, c.worth)
        Cand(N.Mangle, (type(mangleUp) == "number") and mangleUp or nil, c.hostile)
        if best then add(best, 1, bestT) end
      end

      -- 9) Generador: Destrozar (solo detrás) -> Mutilar -> Garra
      -- Máximo daño: con el debuff de Mutilar activo, si solo falta energía para Destrozar se espera
      if c.behind then
        local hold = (maxMode and mangleUp and not berserk) and CF.HoldEta(N.Shred, 10) or nil
        add(N.Shred, 1, hold)
      end
      add(N.Mangle, 1)
      add(N.Claw, 1)
    end
  else
    ----------------------------------------------------------------
    -- Equilibrio / leveling a distancia
    ----------------------------------------------------------------
    -- Forma de lechúcico lunar: recomendada (cola), no prioridad 1
    if spec == 1 and Known(N.MoonkinForm) and not Aura("player", N.MoonkinForm) then
      add(N.MoonkinForm, 2)
    end
    -- 1) DoTs primero (instantáneos: no cuestan el Eclipse)
    if c.worth then
      Dot(add, c, N.InsectSwarm, Aura("target", N.InsectSwarm, true, true))
      Dot(add, c, N.Moonfire, Aura("target", N.Moonfire, true, true))
    end
    -- 2) Eclipse: lunar -> Fuego estelar; solar -> Cólera; tras el lunar, Fuego estelar hasta que
    --    salga el solar (máx. ECLIPSE_SOLAR_WAIT s); si no sale, Cólera (relleno) para volver al lunar
    if Aura("player", N.EclipseLunar) then
      add(N.Starfire, 1)
    elseif Aura("player", N.EclipseSolar) then
      add(N.Wrath, 1)
    elseif lunarEndedAt and (GetTime() - lunarEndedAt) <= ECLIPSE_SOLAR_WAIT then
      add(N.Starfire, 1)
    end
    if c.combat and c.bigCD then                       -- Lluvia de estrellas / Fuerza de la naturaleza
      add(N.Starfall, 2)
      add(N.ForceOfNature, 2)
    end
  end

  -- Defensivo (verde)
  if c.combat and c.php < 0.50 then add(N.Barkskin, 3) end
end

-- Relleno infinito: Cólera (Pollo); en gato, Destrozar si estás detrás, si no Mutilar / Garra
local function filler(c, N)
  if IsCat(c, N) then
    if CF.db.aoe and Known(N.Swipe) then return N.Swipe end
    if c.behind and Known(N.Shred) then return N.Shred end
    return First(N.Mangle, N.Claw)
  end
  return First(N.Wrath, N.Starfire)
end

CF.Register("DRUID", {
  ids = {
    Wrath = 5176,        Starfire = 2912,      Moonfire = 8921,
    InsectSwarm = 5570,  Starfall = 48505,     ForceOfNature = 33831,
    MoonkinForm = 24858, CatForm = 768,        Shred = 5221,
    Mangle = 33876,      Rake = 1822,          Rip = 1079,
    FerociousBite = 22568, SavageRoar = 52610, TigersFury = 5217,
    Berserk = 50334,     Claw = 1082,          Barkskin = 22812,
    -- feral: sigilo, AoE, Faerie Fire (Feral) y Omen of Clarity
    Prowl = 5215,        Ravage = 6785,        Pounce = 9005,
    Swipe = 62078,       FaerieFire = 16857,   Clearcasting = 16870,
    Trauma = 46855,
    -- procs (buffs)
    EclipseLunar = 48518, EclipseSolar = 48517,
  },
  -- Habilidades que exigen estar DETRÁS del objetivo (3.3.5): no se recomiendan de frente
  positional = { "Shred", "Ravage" },
  multidot = { [0] = { "InsectSwarm", "Moonfire" }, [1] = { "InsectSwarm", "Moonfire" } },   -- Equilibrio
  upkeep = upkeep,
  evaluate = evaluate,
  filler = filler,
})
