--[[
  PulseFlash - Keys.lua  (WoW 3.3.5a)

  Elección de la TECLA que se muestra en la esquina de cada icono del HUD.

  Por qué se veía "c-6" en vez de "Q":
    GetBindingKey("ACTIONBUTTON6") solo devuelve los atajos NORMALES del juego. La tecla Q de un botón
    puede estar asignada de otras formas que ese comando no ve:
      * como atajo "override" (lo usan Bartender, Dominos, Macaroon, Clique, macros SetBinding...),
      * en un botón cuya barra está oculta / en otra página,
      * y la pantalla de la propia barra sí la muestra (texto de la esquina del botón).
    Entonces solo quedaba el atajo por defecto del juego (CTRL-6) y se mostraba "c-6".

  Ahora se reúnen TODAS las teclas posibles de cada botón:
    1) GetBindingKey(comando)                          -> atajos normales
    2) escaneo inverso GetBindingAction(tecla, true)   -> atajos normales + override (se cachea unos segundos)
    3) el texto de tecla que dibuja la propia barra    -> lo que tú ves en el botón
  y se elige la MÁS SIMPLE (menos modificadores ALT/CTRL/MAYÚS y, a igualdad, la más corta):
  "Q" gana a "CTRL-6"; "6" gana a "CTRL-6".

  Además existe /pf alias para el caso de teclas remapeadas FUERA del juego (software del teclado o ratón
  que envía CTRL+6 al pulsar Q): el juego solo ve CTRL-6, así que ahí hay que decirle al addon qué mostrar.
]]
local PF = PulseFlash

local MODS = { "ALT-", "CTRL-", "SHIFT-" }

-- Coste de una tecla: modificadores primero (cada uno pesa 100) y luego su longitud
function PF.KeyCost(key)
  local cost = #key
  for i = 1, #MODS do
    if key:find(MODS[i], 1, true) then cost = cost + 100 end
  end
  return cost
end

-- La mejor de las teclas pasadas (varargs de GetBindingKey). Devuelve la tecla y su coste, o nil.
function PF.BestKey(...)
  local best, bestCost
  for i = 1, select("#", ...) do
    local k = select(i, ...)
    if type(k) == "string" and k ~= "" then
      local c = PF.KeyCost(k)
      if not bestCost or c < bestCost then best, bestCost = k, c end
    end
  end
  return best, bestCost
end

-- Coste de un texto YA abreviado, tal como lo dibuja la barra ("Q", "c-6", "s-Q"): cada prefijo "x-" = modificador
function PF.TextCost(text)
  local cost, s = #text, text
  while s:match("^%a%-.") do cost = cost + 100; s = s:sub(3) end
  return cost
end

-- "c-6" / "ctrl-6" / "s-q" -> "CTRL-6" / "SHIFT-Q" (formato que devuelve GetBindingKey). Para /pf alias.
function PF.NormKey(s)
  s = tostring(s or ""):upper()
  local out = ""
  while true do
    local m = s:match("^([ACS])%-.")
    if not m then break end
    out = out .. (m == "A" and "ALT-" or m == "C" and "CTRL-" or "SHIFT-")
    s = s:sub(3)
  end
  return out .. s
end

----------------------------------------------------------------------
-- Escaneo inverso: tecla -> comando. Es la única forma de ver los atajos "override" (no hay API que los liste).
-- Se prueban las teclas habituales con las 8 combinaciones de modificadores (~850 llamadas, solo al reconstruir).
----------------------------------------------------------------------
local BASE = {}
for c = 65, 90 do BASE[#BASE + 1] = string.char(c) end                      -- A-Z
for i = 0, 9 do BASE[#BASE + 1] = tostring(i) end                           -- 0-9
for i = 1, 12 do BASE[#BASE + 1] = "F" .. i end                             -- F1-F12
for i = 0, 9 do BASE[#BASE + 1] = "NUMPAD" .. i end                         -- teclado numérico
for _, k in ipairs({ "NUMPADDECIMAL", "NUMPADPLUS", "NUMPADMINUS", "NUMPADMULTIPLY", "NUMPADDIVIDE",
                     "-", "=", "[", "]", "\\", ";", "'", ",", ".", "/", "`",
                     "SPACE", "TAB", "BACKSPACE", "INSERT", "DELETE", "HOME", "END", "PAGEUP", "PAGEDOWN",
                     "UP", "DOWN", "LEFT", "RIGHT",
                     "BUTTON3", "BUTTON4", "BUTTON5", "MOUSEWHEELUP", "MOUSEWHEELDOWN" }) do
  BASE[#BASE + 1] = k
end
local PREFIX = { "", "ALT-", "CTRL-", "SHIFT-", "ALT-CTRL-", "ALT-SHIFT-", "CTRL-SHIFT-", "ALT-CTRL-SHIFT-" }

local byCmd = {}                   -- [comando] = { teclas }   p. ej. ["ACTIONBUTTON6"] = { "Q", "CTRL-6" }
local mapAt, mapEpoch = -100, -1
local MAP_TTL = 8                  -- segundos: los override de otros addons cambian sin avisar con ningún evento

local function RebuildMap()
  for _, list in pairs(byCmd) do wipe(list) end       -- se reutilizan las tablas (sin basura)
  for p = 1, #PREFIX do
    local pre = PREFIX[p]
    for i = 1, #BASE do
      local key = pre .. BASE[i]
      local act = GetBindingAction(key, true)         -- true: también atajos override (si el cliente no lo admite, se ignora)
      if act and act ~= "" then
        local list = byCmd[act]
        if not list then list = {}; byCmd[act] = list end
        list[#list + 1] = key
      end
    end
  end
end

local function KeyMap(epoch)
  local now = GetTime()
  if epoch ~= mapEpoch or now - mapAt > MAP_TTL then
    mapEpoch, mapAt = epoch, now
    RebuildMap()
  end
  return byCmd
end
PF.KeyMap = KeyMap

local function Add(out, k)
  if type(k) ~= "string" or k == "" then return end
  for i = 1, #out do if out[i] == k then return end end
  out[#out + 1] = k
end

local function AddAll(out, ...)
  for i = 1, select("#", ...) do Add(out, (select(i, ...))) end
end

-- Rellena "out" con TODAS las teclas del botón: por comando de barra (ACTIONBUTTON6...) y por clic directo
-- ("CLICK ActionButton6:LeftButton", lo que usan las barras de otros addons).
function PF.ButtonKeys(out, name, cmd, epoch)
  wipe(out)
  local map = KeyMap(epoch)
  local click = "CLICK " .. name .. ":LeftButton"
  local l
  if cmd then
    AddAll(out, GetBindingKey(cmd))
    l = map[cmd]
    if l then for i = 1, #l do Add(out, l[i]) end end
  end
  AddAll(out, GetBindingKey(click))
  l = map[click]
  if l then for i = 1, #l do Add(out, l[i]) end end
  return out
end

-- Texto de tecla que la propia barra dibuja en el botón (ya abreviado), o nil si no hay ninguno
function PF.ScreenHotkey(btn)
  local name = btn.GetName and btn:GetName()
  local fs = btn.HotKey or btn.hotkey or (name and _G[name .. "HotKey"])
  local t = fs and fs.GetText and fs:GetText()
  if type(t) ~= "string" then return nil end
  t = strtrim(t)
  if t == "" or t == RANGE_INDICATOR then return nil end    -- RANGE_INDICATOR ("●"): botón sin tecla
  return t
end
