-- PulseFlash: Paladín (Reprensión / Protección / Sagrado como daño; leveling) - 3.3.5a
--
-- Reprensión (3.3.5), por orden: Juicio (a cada enfriamiento) > Martillo de ira (<20 %) >
--   Golpe del cruzado > Tormenta divina > El arte de la guerra (Exorcismo instantáneo) >
--   Consagración (si el maná lo permite). Si todo está en enfriamiento, el relleno.
-- Protección: Escudo sagrado siempre activo > Escudo de rectitud > Martillo del honrado >
--   Escudo del vengador > Juicio > Consagración.
-- Sagrado (daño): Juicio > Choque sagrado > Martillo de ira > Consagración.
-- Sellos, auras y bendiciones: los recomienda el HUD de buffos (BuffHUD.lua).
local CF = PulseFlash
-- Memoria: este archivo solo se carga para PALADIN (en las demás clases se descarta al instante)
do local c = select(2, UnitClass("player")); if c and c ~= "PALADIN" then return end end
local Aura, Known, Proc, First = CF.Aura, CF.Known, CF.Proc, CF.First

local CONSECRATION_MIN_MANA = 0.30    -- Consagración solo con más maná que esto (Reprensión)
local HOLY_SHIELD_REFRESH = 1.5       -- Escudo sagrado se renueva si le quedan <= 1.5 s

local function evaluate(c, add, N)
  local spec = c.spec
  local judgement = First(N.JudgementOfWisdom, N.JudgementOfLight)

  if spec == 2 then
    -- Protección
    local hs = Aura("player", N.HolyShield)
    if (not hs or hs <= HOLY_SHIELD_REFRESH) and not CF.Pending(N.HolyShield) then add(N.HolyShield, 1) end
    add(N.ShieldOfRighteousness, 1)
    add(N.HammerOfTheRighteous, 1)
    add(N.AvengersShield, 1)
    add(judgement, 1)
    add(N.Consecration, 1)
  elseif spec == 1 then
    -- Sagrado (daño)
    Proc(add, N.ArtOfWar, N.Exorcism)
    add(judgement, 1)
    add(N.HolyShock, 1)
    if c.hp < 0.20 then add(N.HammerOfWrath, 1) end
    add(N.Exorcism, 1)
    add(N.Consecration, 1)
  else
    -- Reprensión / sin rama (leveling)
    add(judgement, 1)
    if c.hp < 0.20 then add(N.HammerOfWrath, 1) end
    add(N.CrusaderStrike, 1)
    add(N.DivineStorm, 1)
    Proc(add, N.ArtOfWar, N.Exorcism)                 -- El arte de la guerra: Exorcismo instantáneo
    if c.manaPct > CONSECRATION_MIN_MANA or spec == 0 or c.burn then add(N.Consecration, 1) end
    if not Known(N.CrusaderStrike) then add(N.Exorcism, 1) end
  end

  -- Cooldowns / maná (cola)
  if c.combat then
    if spec ~= 2 and c.bigCD then add(N.AvengingWrath, 2) end     -- 3 min: solo contra jefes
    if c.manaPct < 0.50 and spec ~= 2 then add(N.DivinePlea, 2) end
  end

  -- Interrupción / defensivos (verde)
  if (UnitCastingInfo("target") or UnitChannelInfo("target"))
     and IsSpellInRange(N.HammerOfJustice, "target") == 1 then
    add(N.HammerOfJustice, 3)
  end
  if c.combat then
    if c.php < 0.40 then add(N.DivineProtection, 3) end
    if c.php < 0.15 then add(N.DivineShield, 3) end
  end
end

-- Relleno infinito según la rama
local function filler(c, N)
  if c.spec == 2 then
    return First(N.HammerOfTheRighteous, N.ShieldOfRighteousness, N.Consecration, N.JudgementOfWisdom, N.JudgementOfLight)
  elseif c.spec == 1 then
    return First(N.HolyShock, N.Consecration, N.JudgementOfWisdom, N.JudgementOfLight, N.Exorcism)
  end
  return First(N.CrusaderStrike, N.JudgementOfWisdom, N.JudgementOfLight,
               N.Consecration, N.SealOfRighteousness)
end

CF.Register("PALADIN", {
  ids = {
    CrusaderStrike = 35395, DivineStorm = 53385,     JudgementOfWisdom = 53408,
    JudgementOfLight = 20271, Consecration = 26573,  Exorcism = 879,
    HammerOfWrath = 24275,  AvengingWrath = 31884,   DivinePlea = 54428,
    HammerOfJustice = 853,  DivineProtection = 498,  DivineShield = 642,
    HolyShock = 20473,      HolyShield = 20925,      ShieldOfRighteousness = 53600,
    HammerOfTheRighteous = 53595, AvengersShield = 31935,
    SealOfCommand = 20375,  SealOfVengeance = 31801, SealOfCorruption = 53736,
    SealOfRighteousness = 21084, SealOfWisdom = 20166, SealOfLight = 20165,
    SealOfJustice = 20164,
    SanctityAura = 20218, RetributionAura = 7294, DevotionAura = 465,
    ConcentrationAura = 19746, FireResistanceAura = 19891,
    FrostResistanceAura = 19888, ShadowResistanceAura = 19876,
    -- proc (buff)
    ArtOfWar = 59578,
  },
  evaluate = evaluate,
  filler = filler,
})
