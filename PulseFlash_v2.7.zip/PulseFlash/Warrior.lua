-- PulseFlash: Guerrero (Armas / Furia; Protección con lo básico) - 3.3.5a
-- Las posturas, el Grito de batalla y las demás mejoras personales las recomienda el HUD de
-- buffos (BuffHUD.lua); aquí solo hay habilidades de daño. IsUsableSpell devuelve falso en la
-- postura o con la ira equivocadas y esa habilidad se salta sola.
--
-- Armas, por orden: Ejecutar (<20 % o Muerte súbita) > Rasgadura (siempre activa; no en ejecución) >
--   Sobrepotencia con Sabor a sangre > Golpe mortal > Sobrepotencia > Torbellino > Empalar (Oleada de
--   sangre) > Golpe heroico (volcado). Imprudencia solo en la fase de ejecución del jefe.
-- Furia, por orden: Sed de sangre > Torbellino > Empalar con Oleada de sangre > Victoria rápida >
--   Ejecutar (<20 %) > Golpe heroico (volcado de ira). Mientras no tengas Sed de sangre (nivel < 40) se
--   usa la rotación general de arriba (con Rasgadura): una Furia sin sus habilidades solo daría Golpe heroico.
-- Modo área (/pf aoe): Golpes de barrido, Torbellino, Hendedura en lugar de Golpe heroico.
local CF = PulseFlash
-- Memoria: este archivo solo se carga para WARRIOR (en las demás clases se descarta al instante)
do local c = select(2, UnitClass("player")); if c and c ~= "WARRIOR" then return end end
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

local DUMP_RAGE_ARMS = 50        -- Golpe heroico / Hendedura solo con esta ira o más
local DUMP_RAGE_BURN = 40        -- fase de ejecución del jefe: ya no se ahorra ira
local DUMP_RAGE_FURY = 60        -- Furia gasta ira en Sed de sangre y Torbellino: se vuelca más tarde
local DUMP_RAGE_LOW = 25         -- sin habilidades de rama (nivel bajo): Golpe heroico en cuanto compense

local function evaluate(c, add, N)
  local spec = c.spec
  -- Furia sin Sed de sangre (se aprende con 31 puntos, nivel 40+): aún no tiene su rotación (Sed de sangre y
  -- Torbellino no existen), así que solo quedaría el Golpe heroico. Se usa la rotación general (Rasgadura,
  -- Sobrepotencia, Golpe heroico...), la misma que sin especialización.
  if spec == 2 and not Known(N.Bloodthirst) then spec = 0 end
  local executing = (c.hp < 0.20)
  local dump = CF.db.aoe and N.Cleave or N.HeroicStrike
  -- Con pocas habilidades (aún sin Golpe mortal, Sed de sangre ni Torbellino) la ira se gasta antes: no hay
  -- nada más en lo que gastarla y ahorrar hasta 50 solo desperdicia daño
  local lowLevel = not (Known(N.MortalStrike) or Known(N.Bloodthirst) or Known(N.Whirlwind))

  if spec == 2 then
    -- Furia
    if CF.db.aoe then add(N.Whirlwind, 1) end
    add(N.Bloodthirst, 1)
    add(N.Whirlwind, 1)
    Proc(add, N.Bloodsurge, N.Slam)                -- ¡Empalar! instantáneo (Oleada de sangre)
    add(N.VictoryRush, 1)                           -- solo es usable tras una muerte
    Proc(add, N.SuddenDeath, N.Execute)
    if executing then add(N.Execute, 1) end
    if c.rage >= (c.burn and DUMP_RAGE_BURN or DUMP_RAGE_FURY) then add(dump, 1) end
  elseif spec == 3 then
    -- Protección (daño básico)
    add(N.ShieldSlam, 1)
    add(N.Revenge, 1)
    add(N.Devastate, 1)
    if c.rage >= DUMP_RAGE_ARMS then add(dump, 1) end
  else
    -- Armas / sin especialización
    Proc(add, N.SuddenDeath, N.Execute)             -- Muerte súbita: Ejecutar aunque no estés en <20 %
    if executing then add(N.Execute, 1) end
    add(N.VictoryRush, 1)
    if c.worth and not executing then Dot(add, c, N.Rend, Aura("target", N.Rend, true, true)) end
    if CF.db.aoe then
      add(N.SweepingStrikes, 1)
      add(N.ThunderClap, 1)                          -- Atronar: daño en área y ralentiza (rotación de leveling)
    end
    Proc(add, N.TasteForBlood, N.Overpower)          -- Sabor a sangre: ventana corta, va antes del Golpe mortal
    add(N.MortalStrike, 1)
    add(N.Overpower, 1)
    add(N.Whirlwind, 1)
    Proc(add, N.Bloodsurge, N.Slam)
    if c.rage >= (lowLevel and DUMP_RAGE_LOW or (c.burn and DUMP_RAGE_BURN or DUMP_RAGE_ARMS)) then add(dump, 1) end
  end

  -- Cooldowns y generación de ira (cola)
  if c.combat then
    if c.rage < 20 then add(N.Bloodrage, 2) end
    if c.bigCD then                                -- más de 1 min de enfriamiento: solo contra jefes
      -- Imprudencia (5 min): en la fase de ejecución del jefe (o siempre con /pf cds)
      if c.burn or CF.db.cdAlways then add(N.Recklessness, 2) end
      add(N.DeathWish, 2)
      add(N.Bladestorm, 2)
    end
  end

  -- Interrupción / defensivos (verde)
  if (UnitCastingInfo("target") or UnitChannelInfo("target"))
     and IsSpellInRange(N.Pummel, "target") == 1 then
    add(N.Pummel, 3)
  end
  if c.combat and c.php < 0.35 then add(N.EnragedRegeneration, 3) end
end

-- Relleno infinito: Empalar (Armas) / Golpe heroico (Furia y leveling)
local function filler(c, N)
  if c.spec == 1 then return First(N.Slam, N.HeroicStrike) end
  if c.spec == 3 then return First(N.Devastate, N.HeroicStrike) end
  return First(N.HeroicStrike, N.Slam)
end

CF.Register("WARRIOR", {
  ids = {
    HeroicStrike = 78,   MortalStrike = 12294,  Bloodthirst = 23881,
    Whirlwind = 1680,    Slam = 1464,           Execute = 5308,
    Rend = 772,          Overpower = 7384,      VictoryRush = 34428,
    Bloodrage = 2687,    Recklessness = 1719,   DeathWish = 12292,
    Bladestorm = 46924,  Pummel = 6552,         EnragedRegeneration = 55694,
    Cleave = 845,        SweepingStrikes = 12328,  ThunderClap = 6343,
    ShieldSlam = 23922,  Revenge = 6572,        Devastate = 20243,
    BattleStance = 2457, DefensiveStance = 71,  BerserkerStance = 2458,
    BattleShout = 6673,  CommandingShout = 469,
    -- procs (buffs)
    TasteForBlood = 60503, SuddenDeath = 52437, Bloodsurge = 46916,
  },
  multidot = { [0] = { "Rend" }, [1] = { "Rend" } },                                      -- Armas
  evaluate = evaluate,
  filler = filler,
})
