--[[
  PulseFlash - Healer.lua  (WoW 3.3.5a)
  ASESOR DE SANACIONES para el rol de sanador (Sacerdote Disciplina / Sagrado, Paladín Sagrado,
  Chamán Restauración, Druida Restauración). Core.lua lo llama en lugar de la rotación de daño.

  QUÉ MIDE (todo con la API de 3.3.5, sin librerías):
    * Vida, vida perdida (déficit) y % de cada miembro del grupo / banda y del objetivo.
    * Ritmo de daño recibido (vida perdida por segundo, suavizado) y, con él, cuánto tarda en
      morir ("tiempo hasta morir") para saber si da tiempo a un hechizo lento.
    * Cuántos aliados están heridos a la vez (para recomendar sanación en área).
    * Potencia real de cada sanación: se lee del tooltip del hechizo (ya incluye tu +sanación).

  A QUIÉN SANA: al objetivo actual si es un aliado herido; si no, al aliado más herido del grupo
  (en rango). El HUD muestra debajo su nombre, % y vida que le falta; hay que seleccionarlo.

  QUÉ RECOMIENDA, por orden (todo comparando la vida QUE FALTA con lo que cura cada hechizo):
    0. Solo se sana a quien lo necesita de verdad: debe faltarle al menos la mitad de lo que cura tu
       sanación MÁS PEQUEÑA y un 6 % de su vida máxima (a quien le faltan 500 no se le lanza una de 20k),
       salvo emergencia.
    1. Sanación en área si hay 3+ aliados con déficit real por debajo del 80 %.
    2. Emergencia (< 30 % o a punto de morir con déficit real): la sanación instantánea / rápida;
       defensivo de cooldown en la ranura 3 (Espíritu guardián, Imposición de manos, Rapidez de la
       naturaleza).
    3. Sanación del tamaño justo: la MAYOR que quepa casi entera en la vida que falta (sumando el daño
       que recibirá mientras se lanza) y que dé tiempo a lanzarla; si ninguna cabe, la más pequeña con
       al menos la mitad de su cura aprovechada.
    4. Sanación en el tiempo (HoT) si no hay directa que valga la pena y sigue recibiendo daño.
  La potencia de cada sanación se aprende de tus curaciones reales (media móvil, sin críticos); mientras
  no hay muestras suficientes se usa el tooltip.

  LO QUE NO PUEDE SABER: las sanaciones entrantes de otros sanadores (3.3.5 no tiene esa API) ni
  el daño que va a venir. Es un asesor heurístico: la decisión final es del jugador.
]]
local PF = PulseFlash
-- Memoria: este archivo solo se carga para PRIEST/PALADIN/SHAMAN/DRUID (en las demás clases se descarta al instante)
do local c = select(2, UnitClass("player")); if c and c ~= "PRIEST" and c ~= "PALADIN" and c ~= "SHAMAN" and c ~= "DRUID" then return end end

----------------------------------------------------------------------
-- Ajustes (puedes cambiarlos)
----------------------------------------------------------------------
local NEED_PCT         = 0.95    -- por encima de este % de vida nadie necesita sanación (el déficit mínimo manda)
local INJURED_PCT      = 0.80    -- "herido" a efectos de sanación en área
local AOE_COUNT        = 3       -- heridos necesarios para recomendar sanación en área
local EMERGENCY_PCT    = 0.30    -- por debajo: emergencia
local EMERGENCY_TTD    = 3.0     -- o muriendo en menos de estos segundos
local COOLDOWN_PCT     = 0.20    -- por debajo: defensivo de cooldown (ranura 3)
local LOW_MANA         = 0.25    -- con menos maná se prefiere la sanación grande (eficiente)
local BIG_FRACTION     = 0.80    -- una sanación "cabe" si la vida que falta es >= 80 % de lo que cura (poco exceso)
local FAST_FRACTION    = 0.50    -- si ninguna cabe entera, la más pequeña se usa con >= 50 % de lo que cura
local HOT_MIN_DEFICIT  = 0.10    -- déficit mínimo (fracción de la vida máxima) para un HoT
local MIN_DEFICIT_FRAC = 0.50    -- no se sana si la vida que falta no llega a esta fracción de la sanación MÁS PEQUEÑA
local MIN_DEFICIT_MAXHP = 0.06    -- ni si es menos de este % de la vida máxima del aliado (salvo emergencia)
local SCAN_INTERVAL    = 0.20    -- segundos entre lecturas de la vida del grupo
local AMOUNT_TTL       = 45      -- segundos de validez de la potencia leída del tooltip

----------------------------------------------------------------------
-- Hechizos por clase (nombres localizados vía GetSpellInfo). Listas: se usa el primero que tengas.
--   big = lenta y grande | fast = rápida | inst = instantánea | hot = en el tiempo
--   aoe = en área | shield = escudo | emergency = defensivos de cooldown (ranura 3)
----------------------------------------------------------------------
local DEF = {
  PRIEST = {
    big = { 2060, 2054 },          -- Sanación superior, Sanar
    fast = { 2061 },               -- Sanación relámpago
    inst = { 47540 },              -- Penitencia
    hot = { 139 },                 -- Renovar
    aoe = { 34861, 596 },          -- Círculo de sanación, Rezo de sanación
    shield = { 17 },               -- Palabra de poder: Escudo
    emergency = { 47788 },         -- Espíritu guardián
  },
  PALADIN = {
    big = { 635 },                 -- Luz sagrada
    fast = { 19750 },              -- Destello de luz
    inst = { 20473 },              -- Choque sagrado
    emergency = { 633 },           -- Imposición de manos
  },
  SHAMAN = {
    big = { 331 },                 -- Ola de sanación
    fast = { 8004 },               -- Ola de sanación menor
    inst = { 61295 },              -- Torrente
    hot = { 61295 },
    aoe = { 1064 },                -- Sanación en cadena
    emergency = { 16188 },         -- Rapidez de la naturaleza
  },
  DRUID = {
    big = { 5185 },                -- Toque de sanación
    fast = { 50464, 8936 },        -- Nutrir, Recrecimiento
    inst = { 18562 },              -- Alimento voraz (necesita Rejuvenecimiento / Recrecimiento)
    hot = { 774, 33763 },          -- Rejuvenecimiento, Florecer de vida
    aoe = { 48438 },               -- Crecimiento salvaje
    emergency = { 17116 },         -- Rapidez de la naturaleza
  },
}
local SWIFTMEND_REQ = { 774, 8936 }   -- Alimento voraz exige uno de estos HoTs en el aliado

local S = {}                 -- nombres resueltos de tu clase: S.big, S.fast, ... (primer hechizo conocido)
local class
local DB

----------------------------------------------------------------------
-- Potencia de cada sanación (tooltip del hechizo, ya con tu +sanación)
----------------------------------------------------------------------
local tip
local bookIndex = {}         -- [nombre] = índice en el libro de hechizos (el rango más alto)
local amounts = {}           -- [nombre] = { v = potencia | false, t = instante }

local function BuildBook()
  wipe(bookIndex)
  for i = 1, 400 do
    local name = GetSpellName(i, BOOKTYPE_SPELL)
    if not name then break end
    bookIndex[name] = i         -- el último gana: rango más alto
  end
end

local function ParseTooltip(name)
  local idx = bookIndex[name]
  if not idx then return nil end
  if not tip then
    tip = CreateFrame("GameTooltip", "PulseFlashHealScan", nil, "GameTooltipTemplate")
    tip:SetOwner(UIParent, "ANCHOR_NONE")
  end
  tip:ClearLines()
  tip:SetSpell(idx, BOOKTYPE_SPELL)
  -- La descripción son las últimas líneas; se buscan cifras de 3+ dígitos (evita tiempos y rangos)
  for i = tip:NumLines(), 2, -1 do
    local fs = _G["PulseFlashHealScanTextLeft" .. i]
    local line = fs and fs:GetText()
    if line then
      local nums = {}
      for n in line:gmatch("%d+") do
        local v = tonumber(n)
        if v >= 100 then nums[#nums + 1] = v end
      end
      if #nums >= 2 and nums[2] >= nums[1] and nums[2] <= nums[1] * 2.5 then
        return (nums[1] + nums[2]) / 2                  -- "de X a Y"
      elseif #nums >= 1 then
        return nums[1]                                  -- cifra única (HoT, escudo)
      end
    end
  end
  return nil
end

-- Potencia REAL observada: media móvil de tus sanaciones sin crítico (SPELL_HEAL). Es más fiable que el
-- tooltip (incluye talentos, glifos y equipo) y no depende del idioma. Hacen falta 3+ muestras.
local observed = {}
local playerGUID

local function Amount(spell)
  if not spell then return nil end
  local o = observed[spell]
  if o and o.n >= 3 then return o.v end
  local e = amounts[spell]
  local now = GetTime()
  if e and now - e.t < AMOUNT_TTL then return e.v or nil end
  local v = ParseTooltip(spell)
  amounts[spell] = { v = v or false, t = now }
  return v
end
PF.HealAmount = Amount

local function CastTime(spell)                          -- segundos (2.5 si no se conoce)
  local _, _, _, _, _, _, ms = GetSpellInfo(spell)
  return (ms and ms > 0) and ms / 1000 or (ms == 0 and 0 or 2.5)
end

----------------------------------------------------------------------
-- Lectura del grupo
----------------------------------------------------------------------
local hist = {}              -- [unidad] = { guid, hp, t, rate }
local units = {}
local nextScan = 0
local cache = { list = {}, injured = 0 }

local function GroupUnits()
  wipe(units)
  local raid = GetNumRaidMembers and GetNumRaidMembers() or 0
  if raid > 0 then
    for i = 1, raid do units[#units + 1] = "raid" .. i end
  else
    units[1] = "player"
    for i = 1, (GetNumPartyMembers and GetNumPartyMembers() or 0) do units[#units + 1] = "party" .. i end
  end
  return units
end

local function InRange(unit, probe)
  if probe then
    local r = IsSpellInRange(probe, unit)
    if r ~= nil then return r == 1 end
  end
  if UnitInRange and unit ~= "player" then
    local ir = UnitInRange(unit)
    if ir ~= nil then return ir and true or false end
  end
  return true
end

-- Ritmo de daño (vida perdida por segundo, suavizado). Las sanaciones recibidas no cuentan como daño.
local function Track(unit, hp, now)
  local guid = UnitGUID(unit)
  local h = hist[unit]
  if not h or h.guid ~= guid then
    hist[unit] = { guid = guid, hp = hp, t = now, rate = 0 }
    return 0
  end
  local dt = now - h.t
  if dt < 0.1 then return h.rate end
  local inst = (h.hp - hp) / dt
  if inst < 0 then inst = 0 end
  local k = math.min(1, dt / 2.0)                       -- ventana de ~2 s
  h.rate = h.rate * (1 - k) + inst * k
  h.hp, h.t = hp, now
  return h.rate
end

local function Info(unit, now, probe)
  if not UnitExists(unit) or UnitIsDeadOrGhost(unit) or not UnitIsConnected(unit)
     or not UnitCanAssist("player", unit) then
    return nil
  end
  local hp, max = UnitHealth(unit), UnitHealthMax(unit)
  if not max or max <= 0 then return nil end
  local rate = Track(unit, hp, now)
  return {
    unit = unit, name = UnitName(unit), hp = hp, max = max,
    deficit = max - hp, pct = hp / max, rate = rate,
    ttd = (rate > 0) and (hp / rate) or 999,
    inRange = InRange(unit, probe),
  }
end

-- Vida que debe faltar para que merezca la pena sanar a alguien: la mitad de la sanación más pequeña que
-- tienes (si no, se sanaría con un hechizo de 20k a quien le faltan 500) y un mínimo del % de su vida máxima.
local function Threshold(max, minAmt)
  return math.max((minAmt or 0) * MIN_DEFICIT_FRAC, max * MIN_DEFICIT_MAXHP)
end

-- ¿Necesita sanación? (por debajo de NEED_PCT con déficit suficiente, o en emergencia)
local function Needs(i, minAmt)
  if not i or not i.inRange or i.pct > NEED_PCT then return false end
  return i.pct < EMERGENCY_PCT or i.deficit >= Threshold(i.max, minAmt)
end

-- Lee el grupo cada SCAN_INTERVAL: lista de aliados que necesitan sanación y cuántos están heridos
local function Scan(now, probe, minAmt)
  if now < nextScan then return end
  nextScan = now + SCAN_INTERVAL
  local list, injured = {}, 0
  for _, unit in ipairs(GroupUnits()) do
    local i = Info(unit, now, probe)
    if Needs(i, minAmt) then
      list[#list + 1] = i
      if i.pct <= INJURED_PCT then injured = injured + 1 end
    end
  end
  table.sort(list, function(a, b)
    if a.pct ~= b.pct then return a.pct < b.pct end
    return a.deficit > b.deficit
  end)
  cache.list, cache.injured = list, injured
end

----------------------------------------------------------------------
-- Cifras para el HUD
----------------------------------------------------------------------
local function Short(n)
  if n >= 1000 then return string.format("%.1fk", n / 1000) end
  return tostring(math.floor(n + 0.5))
end

----------------------------------------------------------------------
-- Rotación de sanación (la llama Core.lua con el mismo add() de siempre)
----------------------------------------------------------------------
local function HasAnyAura(unit, ids)
  for i = 1, #ids do
    local n = GetSpellInfo(ids[i])
    if n and PF.Aura(unit, n, false, true) then return true end
  end
  return false
end

function PF.HealerEval(c, add)
  PF.healInfo, c.healUnit = nil, nil
  if not class or not S.any then return end
  local now = GetTime()
  local probe = S.fast or S.big or S.inst

  -- Potencia de tus sanaciones directas (la más pequeña fija el déficit mínimo para sanar)
  local bigAmt, fastAmt, instAmt = Amount(S.big), Amount(S.fast), Amount(S.inst)
  local minAmt
  for _, a in ipairs({ bigAmt or 0, fastAmt or 0, instAmt or 0 }) do
    if a > 0 and (not minAmt or a < minAmt) then minAmt = a end
  end
  Scan(now, probe, minAmt)

  -- Objetivo de la sanación: tu objetivo si es un aliado que lo necesita; si no, el más necesitado
  local u
  local t = Info("target", now, probe)
  if Needs(t, minAmt) then
    u = t
  else
    u = cache.list[1]
    if u then u = Info(u.unit, now, probe) end            -- datos frescos del elegido
    if not Needs(u, minAmt) then u = nil end
  end
  if not u then return end

  c.healUnit = u.unit
  local isTarget = UnitIsUnit and UnitIsUnit(u.unit, "target")
  PF.healInfo = string.format("%s%s  %d%%  -%s%s", isTarget and "" or "> ", u.name or "?",
    math.floor(u.pct * 100 + 0.5), Short(u.deficit),
    u.rate > 0 and (" (" .. Short(u.rate) .. "/s)") or "")

  local mana = c.manaPct or 1
  local thr = Threshold(u.max, minAmt)
  local emergency = (u.pct < EMERGENCY_PCT) or (u.ttd < EMERGENCY_TTD and u.deficit >= thr)
  local hasHot = S.hot and PF.Aura(u.unit, S.hot, false, true) and true or false
  local swiftOK = S.inst and (class ~= "DRUID" or HasAnyAura(u.unit, SWIFTMEND_REQ))
  local inst = swiftOK and S.inst or nil

  -- 1) Sanación en área (solo con 3+ aliados con déficit real)
  if cache.injured >= AOE_COUNT and S.aoe then add(S.aoe, 1) end

  if emergency then
    -- 2) Emergencia: lo más rápido primero
    add(inst, 1)
    add(S.fast, 1)
    -- Escudo: no si ya lo tiene ni si tiene Alma debilitada (6788)
    local weak = GetSpellInfo(6788)
    if S.shield and not PF.Aura(u.unit, S.shield, false) and not (weak and PF.Aura(u.unit, weak, true)) then
      add(S.shield, 1)
    end
    add(S.big, 2)
  else
    -- 3) Sanación del tamaño justo: la MAYOR que quepa casi entera en la vida que falta (la vida que
    --    falta cuenta también el daño que recibirá durante el lanzamiento) y que dé tiempo a lanzar.
    --    Si ninguna cabe entera, la más pequeña, con al menos la mitad de su cura aprovechada.
    local cands = {}
    local function Cand(spell, amt, defaultFrac)
      if not spell then return end
      for i = 1, #cands do if cands[i].spell == spell then return end end
      cands[#cands + 1] = { spell = spell, amt = amt or (u.max * defaultFrac), cast = CastTime(spell) }
    end
    Cand(S.big, bigAmt, 0.45); Cand(S.fast, fastAmt, 0.25); Cand(inst, instAmt, 0.25)
    table.sort(cands, function(a, b) return a.amt > b.amt end)

    local fits = {}
    for _, cd in ipairs(cands) do
      local need = u.deficit + u.rate * cd.cast
      if need >= cd.amt * BIG_FRACTION and u.ttd > cd.cast + 0.5 then fits[#fits + 1] = cd end
    end
    local pick = fits[1]
    -- con poco maná se prefiere la eficiente (la mayor que quepa); con maná normal también es la mayor
    if not pick and #cands > 0 then
      local sm = cands[#cands]
      if u.deficit + u.rate * sm.cast >= sm.amt * FAST_FRACTION and u.ttd > sm.cast + 0.5 then pick = sm end
    end
    if pick then
      add(pick.spell, 1)
      for _, cd in ipairs(cands) do if cd ~= pick then add(cd.spell, 2) end end
    end
    -- 4) En el tiempo: si no hay sanación directa que merezca la pena pero sigue recibiendo daño
    --    (o el déficit ya es apreciable) y no tiene tu HoT
    if S.hot and not hasHot and not pick
       and (u.deficit >= u.max * HOT_MIN_DEFICIT or (u.rate > 0 and u.deficit >= thr)) then
      add(S.hot, 1)
    elseif S.hot and not hasHot then
      add(S.hot, 2)
    end
  end

  -- Defensivos de cooldown sobre el aliado en peligro (ranura 3)
  if u.pct < COOLDOWN_PCT and S.emergency then
    for i = 1, #S.emergency do add(S.emergency[i], 3) end
  end
end

----------------------------------------------------------------------
-- Inicialización (la llama Core.lua en PLAYER_LOGIN)
----------------------------------------------------------------------
local function Resolve()
  wipe(S)
  local def = DEF[class]
  if not def then return end
  local function first(ids)
    for i = 1, #ids do
      local n = GetSpellInfo(ids[i])
      if n and PF.Known(n) then return n end
    end
  end
  S.big, S.fast, S.inst = first(def.big or {}), first(def.fast or {}), first(def.inst or {})
  S.hot, S.aoe, S.shield = first(def.hot or {}), first(def.aoe or {}), first(def.shield or {})
  S.emergency = {}
  for _, id in ipairs(def.emergency or {}) do
    local n = GetSpellInfo(id)
    if n and PF.Known(n) then S.emergency[#S.emergency + 1] = n end
  end
  S.any = (S.big or S.fast or S.inst) and true or false
  BuildBook()
  wipe(amounts)
  wipe(observed)
end

function PF.Healer_Init(cls)
  DB = PF.db
  class = cls
  playerGUID = UnitGUID("player")
  Resolve()
  -- Potencia real de tus sanaciones (SPELL_HEAL sin crítico): media móvil por hechizo
  local lf = CreateFrame("Frame")
  lf:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
  lf:SetScript("OnEvent", function(_, _, _, sub, sGUID, _, _, _, _, _, _, spellName, _, amount, _, _, critical)
    if sub ~= "SPELL_HEAL" or sGUID ~= playerGUID or not spellName or not amount or amount <= 0 or critical then
      return
    end
    local o = observed[spellName]
    if not o then observed[spellName] = { v = amount, n = 1 }
    else o.v = o.v * 0.8 + amount * 0.2; o.n = o.n + 1 end
  end)
  local f = CreateFrame("Frame")
  f:RegisterEvent("SPELLS_CHANGED")
  f:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
  f:RegisterEvent("PLAYER_TALENT_UPDATE")
  f:SetScript("OnEvent", function() Resolve() end)
end
