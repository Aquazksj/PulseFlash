--[[
  PulseFlash - Sounds.lua  (WoW 3.3.5a)
  Alertas audibles configurables para los procs que alteran la rotación
  (Núcleo de magma, Arte de la guerra, Racha ardiente, Máquina de matar...).

  FUNCIONAMIENTO
    * Se vigilan los buffs propios con UNIT_AURA ("player"). Cuando un proc pasa de INACTIVO
      a ACTIVO se reproduce el sonido asignado a ese proc (flanco de subida: no se repite
      mientras el buff siga activo). Al entrar al mundo o cambiar de perfil el estado se
      reinicia en silencio, para no sonar por un proc que ya estaba activo.
    * Cada perfil (personaje + rama) guarda su propia asignación en DB.sound:
        DB.sound.enabled          -> interruptor global del audio
        DB.sound.procs[clave]     -> id del sonido elegido para ese proc ("none" = silencio)
    * PF.SOUNDS es el catálogo. Para añadir un sonido basta con una línea nueva:
        { id = "x", name = "Mi sonido", sound = "NombreDePlaySound" }     -> PlaySound(nombre)
        { id = "x", name = "Mi sonido", file  = "Sound\\ruta\\fichero.wav" } -> PlaySoundFile(ruta)
]]
local PF = PulseFlash

----------------------------------------------------------------------
-- Catálogo de sonidos limpios (efectos de interfaz incluidos en el cliente 3.3.5a)
----------------------------------------------------------------------
PF.SOUNDS = {
  { id = "none",    name = "Ninguno" },
  { id = "raid",    name = "Alerta de banda",   sound = "RaidWarning" },
  { id = "boss",    name = "Aviso de jefe",     sound = "RaidBossEmoteWarning" },
  { id = "ping",    name = "Ping de mapa",      sound = "MapPing" },
  { id = "ready",   name = "Control de listos", sound = "ReadyCheck" },
  { id = "auction", name = "Campanilla",        sound = "AuctionWindowOpen" },
  { id = "alarm2",  name = "Alarma suave",      sound = "AlarmClockWarning2" },
  { id = "alarm3",  name = "Alarma",            sound = "AlarmClockWarning3" },
  { id = "tell",    name = "Susurro",           sound = "TellMessage" },
  { id = "level",   name = "Nivel",             sound = "LevelUp" },
  { id = "pvp",     name = "Aviso JcJ",         sound = "PVPWarningHorde" },
  { id = "bell",    name = "Campana",           file = "Sound\\Doodad\\BellTollAlliance.wav" },
}
local byId, indexOf = {}, {}
for i, s in ipairs(PF.SOUNDS) do byId[s.id] = s; indexOf[s.id] = i end

-- Sonidos por defecto (se reparten por orden entre los procs de la clase)
local DEFAULT_ORDER = { "raid", "ping", "ready", "alarm2", "auction", "tell" }

-- Reproduce una entrada del catálogo (pcall: un nombre inválido nunca debe dar error)
function PF.PlaySoundEntry(id)
  local s = byId[id]
  if not s or id == "none" then return end
  if s.file then pcall(PlaySoundFile, s.file)
  elseif s.sound then pcall(PlaySound, s.sound) end
end

function PF.SoundName(id)
  local s = byId[id] or byId.none
  local key = "snd_" .. s.id
  local t = PF.T(key)
  return (t ~= key) and t or s.name
end

-- Índice siguiente / anterior en el catálogo (para el selector del panel)
function PF.SoundCycle(id, step)
  local n = #PF.SOUNDS
  local i = ((indexOf[id] or 1) - 1 + step) % n + 1
  return PF.SOUNDS[i].id
end

----------------------------------------------------------------------
-- Procs por clase: "key" = clave en module.ids (de ahí sale el nombre localizado del buff)
-- "stacks" = cargas mínimas para considerar el proc activo.
----------------------------------------------------------------------
local PROCS = {
  DEATHKNIGHT = { { key = "KillingMachine" }, { key = "Rime" } },
  DRUID       = { { key = "EclipseLunar" }, { key = "EclipseSolar" }, { key = "Clearcasting" } },
  HUNTER      = { { key = "LockAndLoad" } },
  MAGE        = { { key = "HotStreak" }, { key = "MissileBarrage" }, { key = "BrainFreeze" },
                  { key = "FingersOfFrost" } },
  PALADIN     = { { key = "ArtOfWar" } },
  SHAMAN      = { { key = "MaelstromWeapon", stacks = 5 } },
  WARLOCK     = { { key = "ShadowTrance" }, { key = "Backlash" }, { key = "Decimation" },
                  { key = "MoltenCore" }, { key = "Eradication" } },
  WARRIOR     = { { key = "TasteForBlood" }, { key = "SuddenDeath" }, { key = "Bloodsurge" } },
  -- Pícaro y Sacerdote no tienen procs que cambien su rotación
}

PF.procList = {}        -- procs de ESTA clase: { key=, name=, stacks=, default= }

-- Sonido asignado a un proc en el perfil activo (o el de por defecto)
function PF.GetProcSound(proc)
  local S = PF.db and PF.db.sound
  local v = S and S.procs and S.procs[proc.key]
  if v and byId[v] then return v end
  return proc.default
end

function PF.SetProcSound(proc, id)
  local S = PF.db and PF.db.sound
  if S and byId[id] then S.procs[proc.key] = id end
end

----------------------------------------------------------------------
-- Vigilancia de buffs
----------------------------------------------------------------------
local state = {}                 -- [clave] = true si el proc estaba activo en el último escaneo
local lastPlayed = 0
local MIN_GAP = 0.4              -- segundos entre sonidos (evita solapar varios procs a la vez)

local function Scan(silent)
  local S = PF.db and PF.db.sound
  for _, proc in ipairs(PF.procList) do
    local left, count = PF.Aura("player", proc.name)
    local active = (left ~= nil) and (count >= (proc.stacks or 1))
    if active and not state[proc.key] and not silent
       and S and S.enabled and PF.db.enabled then
      local now = GetTime()
      if now - lastPlayed >= MIN_GAP then
        lastPlayed = now
        PF.PlaySoundEntry(PF.GetProcSound(proc))
      end
    end
    state[proc.key] = active
  end
end

-- La llama Core.lua tras rellenar PF.N con los nombres localizados
function PF.Sounds_Init(class)
  wipe(PF.procList)
  local n = 0
  for _, def in ipairs(PROCS[class] or {}) do
    local name = PF.N[def.key]
    if name then
      n = n + 1
      PF.procList[n] = {
        key = def.key, name = name, stacks = def.stacks,
        default = DEFAULT_ORDER[(n - 1) % #DEFAULT_ORDER + 1],
      }
    end
  end

  local f = CreateFrame("Frame")
  f:RegisterEvent("UNIT_AURA")
  f:RegisterEvent("PLAYER_ENTERING_WORLD")
  f:SetScript("OnEvent", function(_, event, unit)
    if event == "UNIT_AURA" then
      if unit == "player" then Scan(false) end        -- 3.3.5: arg1 = unidad
    else
      Scan(true)                                       -- entrada al mundo: estado inicial en silencio
    end
  end)
  PF.RegisterProfileCallback(function() Scan(true) end)
  Scan(true)
end
