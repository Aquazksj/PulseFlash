-- PulseFlash: Sacerdote (Sombras; Disciplina / Sagrado como daño con Aplastar) - 3.3.5a
--
-- Sombras (rotación estándar de 3.3.5), por orden de prioridad:
--   Toque vampírico (siempre activo) > Plaga devoradora (siempre activa) > Palabra de las
--   Sombras: Dolor (siempre activa) > Explosión mental (a cada enfriamiento) > Palabra de las
--   Sombras: Muerte (ejecución, nunca si te mataría) > Tortura mental (relleno) / Abrasar mente
--   en modo área. Duende de las sombras y Dispersión para el maná.
-- Sin Forma de las Sombras (Disciplina / Sagrado / leveling): Dolor, Fuego sagrado, Penitencia,
--   Explosión mental y Aplastar como relleno.
local CF = PulseFlash
-- Memoria: este archivo solo se carga para PRIEST (en las demás clases se descarta al instante)
do local c = select(2, UnitClass("player")); if c and c ~= "PRIEST" then return end end
local Aura, Dot, First = CF.Aura, CF.Dot, CF.First

local SWD_MIN_HP = 0.40          -- Palabra de las Sombras: Muerte te hiere: no se sugiere con menos vida
local FIEND_MANA = 0.50          -- Duende de las sombras si el maná baja de esto
local DISPERSION_MANA = 0.25     -- Dispersión por maná

local function IsShadow(c, N)
  return (c.spec == 3) or (Aura("player", N.Shadowform) ~= nil)
end

local function evaluate(c, add, N)
  local shadow = IsShadow(c, N)
  local swp = Aura("target", N.ShadowWordPain, true, true)

  if shadow then
    if c.worth then
      Dot(add, c, N.VampiricTouch, Aura("target", N.VampiricTouch, true, true))
      Dot(add, c, N.DevouringPlague, Aura("target", N.DevouringPlague, true, true))
      Dot(add, c, N.ShadowWordPain, swp)
    end
    add(N.MindBlast, 1)
    if c.hp < 0.25 and c.php > SWD_MIN_HP then add(N.ShadowWordDeath, 1) end
    if CF.db.aoe then add(N.MindSear, 1) end                    -- modo área (/pf aoe)
    if c.combat then
      if c.bigCD and c.manaPct < FIEND_MANA then add(N.Shadowfiend, 2) end
      if c.manaPct < DISPERSION_MANA then add(N.Dispersion, 2) end
    end
  else
    -- Sin Forma de las Sombras: Aplastar como relleno
    if c.worth then Dot(add, c, N.ShadowWordPain, swp) end
    if c.worth and not Aura("target", N.HolyFire, true, true) and c.casting ~= N.HolyFire
       and not CF.Pending(N.HolyFire) then
      add(N.HolyFire, 1)
    end
    add(N.Penance, 1)
    add(N.MindBlast, 1)
    if c.hp < 0.25 and c.php > SWD_MIN_HP then add(N.ShadowWordDeath, 1) end
    if c.combat and c.bigCD and c.manaPct < FIEND_MANA then add(N.Shadowfiend, 2) end
  end

  -- Interrupción / defensivos / utilidad (verde)
  if (UnitCastingInfo("target") or UnitChannelInfo("target"))
     and IsSpellInRange(N.Silence, "target") == 1 then
    add(N.Silence, 3)
  end
  if c.combat then
    if c.php < 0.60 and not Aura("player", N.WeakenedSoul, true) then add(N.PowerWordShield, 3) end
    if c.php < 0.35 then add(N.Dispersion, 3) end
    if c.php < 0.30 then add(N.PsychicScream, 3) end
  end
end

-- Relleno infinito: Tortura mental (Sombras) o Aplastar
local function filler(c, N)
  if IsShadow(c, N) then return First(N.MindFlay, N.Smite) end
  return First(N.Smite, N.MindBlast)
end

CF.Register("PRIEST", {
  ids = {
    Smite = 585,             HolyFire = 14914,        ShadowWordPain = 589,
    MindBlast = 8092,        MindFlay = 15407,        VampiricTouch = 34914,
    DevouringPlague = 2944,  ShadowWordDeath = 32379, Penance = 47540,
    PowerWordShield = 17,    InnerFire = 588,         Shadowform = 15473,
    PsychicScream = 8122,    Dispersion = 47585,      WeakenedSoul = 6788,
    Silence = 15487,         Shadowfiend = 34433,     MindSear = 48045,
  },
  multidot = { [3] = { "VampiricTouch", "DevouringPlague", "ShadowWordPain" } },    -- Sombras
  evaluate = evaluate,
  filler = filler,
})
