--[[
  PulseFlash - Roles.lua  (WoW 3.3.5a)
  Detecta si juegas de SANADOR. En ese rol el HUD de daño pasa a ser un ASESOR DE SANACIONES
  (Healer.lua): mide la vida del objetivo / grupo y recomienda la sanación adecuada. Los buffos
  siguen en su HUD. Los TANQUES ya no tienen límite: usan su rotación normal (el DK tanque tiene
  además su modo exclusivo, /pf tank).

    SANADOR ...... Paladín Sagrado | Sacerdote Disciplina / Sagrado | Chamán Restauración |
                   Druida Restauración

  La rama se detecta por la pestaña de talentos con más puntos (PF.spec). El límite se puede
  apagar con /pf roles (por ejemplo un sacerdote Sagrado que sube de nivel con Aplastar).
]]
local PF = PulseFlash

local ROLE_BY_SPEC = {
  PALADIN     = { [1] = "healer" },
  PRIEST      = { [1] = "healer", [2] = "healer" },
  SHAMAN      = { [3] = "healer" },
  DRUID       = { [3] = "healer" },
}

-- "healer" | "dps"
function PF.GetRole(class, spec)
  if PF.db and PF.db.roleLimit == false then return "dps" end
  local t = ROLE_BY_SPEC[class]
  return (t and t[spec]) or "dps"
end

-- Activa el límite por defecto (la llama Core.lua en PLAYER_LOGIN)
function PF.Roles_Init()
  if PF.db and PF.db.roleLimit == nil then PF.db.roleLimit = true end
end
