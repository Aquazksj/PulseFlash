--[[
  PulseFlash - Beta.lua  (WoW 3.3.5a)           *** FUNCIONES NUEVAS (BETA): apagadas por defecto ***

  Funciones en pruebas. Se activan en Config > Funciones nuevas (o con /pf nuevas) y cada una tiene su propio
  interruptor. Con el interruptor general apagado este archivo no cambia NADA de la rotación.

  1) PREDICCIÓN  (interruptor "predict")
     a) Tiempo de vuelo: los hechizos con proyectil (Descarga de las sombras, Inmolar, Descarga de fuego...)
        tardan en llegar al objetivo. Si el último lanzamiento aún va por el aire, el DoT/debuff se da por
        cubierto y no se vuelve a iluminar (PF.Pending). Además, el momento de renovar un DoT pasa de un
        valor fijo (2 s) a: tiempo de lanzamiento + tiempo de vuelo + latencia (PF.Dot).
     b) Recursos en el próximo GCD: si una habilidad MEJOR que la que se puede lanzar ahora estará
        disponible en menos de un instante (energía, maná o runas), y lanzar ahora la peor la retrasaría,
        el HUD muestra "espera" con la cuenta atrás en lugar de gastar el recurso (PF.Beta.PickWait).

  2) SNAPSHOTTING  (interruptor "snap")
     En 3.3.5 los DoTs y sangrados guardan tu poder de ataque / de hechizo / celeridad del instante en que
     se aplican. Se anota ese valor al aplicarlos (registro de combate) y se compara con el actual: si tu poder
     ha subido lo bastante (procs, abalorios, Bloodlust...), se ilumina la renovación aunque aún dure
     bastante, siempre que compense lo que se pierde al pisar el DoT (SNAP_MIN_GAIN / SNAP_CLIP).

  3) EVENTOS DE JEFE  (interruptor "boss")
     Funciona SOLO con lo que informa un addon de jefes: lee los temporizadores de Deadly Boss Mods y de
     BigWigs. PulseFlash no detecta nada por su cuenta (no mira los casteos del jefe): así no hay
     mecánicas inventadas ni errores propios. Sin DBM ni BigWigs esta función no hace nada.
     Cada temporizador del addon de jefes se clasifica por su ID de hechizo o por su texto:
       immune = fase / inmunidad  -> se guardan los cooldowns (tier 2 y objetos de uso) unos segundos
       move   = hay que correr    -> solo hechizos que caben antes del evento (instantáneos o cortos)
       fear   = miedo en área     -> igual que "move"
     Otros addons de jefes (p. ej. PulseBoss) pueden avisar con PF.Beta.BossTimer(tipo, segundos, texto).

  4) LATENCIA  (interruptor "latency")
     Mide tu latencia real entre pulsar y que el servidor acepte el lanzamiento (UNIT_SPELLCAST_SENT ->
     START / SUCCEEDED, media suavizada: la misma idea que la barra de latencia de Quartz). Cuando a tu
     lanzamiento o canalización le queda menos que esa latencia, el HUD ya muestra la siguiente habilidad
     (puedes encadenarla sin perder tiempo) y el hechizo en curso cuenta como lanzado. La misma latencia
     se usa en la ventana de renovación de los DoTs y en la espera de aura de PF.Pending.
]]
local PF = PulseFlash
local B = {}
PF.Beta = B

local GetTime, GetSpellInfo = GetTime, GetSpellInfo
local pairs, select, tonumber, type = pairs, select, tonumber, type
local floor = math.floor
local wipe = table.wipe or wipe
local CLASS = select(2, UnitClass("player"))

----------------------------------------------------------------------
-- Constantes (ajustables)
----------------------------------------------------------------------
local GCD_PROJ = 1.5            -- duración del GCD usada en la simulación de recursos
local GCD_TOL = 1.5             -- igual que en Core: un cooldown con menos que esto cuenta como "casi listo"
local WAIT_MAX = 0.75           -- esperar por una habilidad mejor si hay otra lanzable ahora: máx. este tiempo
local WAIT_IDLE = 1.5           -- ... y si no hay nada lanzable ahora: máx. este tiempo
local WINDOW_MIN, WINDOW_MAX, WINDOW_MARGIN = 1.0, 3.5, 0.25   -- ventana de renovación de un DoT (s)
local SNAP_MIN_GAIN = 0.15      -- el poder actual debe superar al del DoT en al menos un 15 %
local SNAP_CLIP = 0.5           -- ... y (ganancia) >= SNAP_CLIP * (fracción de duración que se pisa)
local BOSS_LEAD = 3.0           -- segundos antes del evento en que se empieza a adaptar la rotación
local POST_MOVE, POST_IMMUNE = 1.0, 2.0   -- segundos tras el evento que se mantiene la adaptación

B.defaults = { on = false, predict = true, snap = true, boss = true, latency = true }

----------------------------------------------------------------------
-- Ajustes (cuenta completa: PulseFlashDB.beta)
----------------------------------------------------------------------
local function Cfg()
  local db = PF.db
  if not db then return nil end
  local d = db.beta
  if type(d) ~= "table" then d = {}; db.beta = d end
  for k, v in pairs(B.defaults) do
    if d[k] == nil then d[k] = v end
  end
  return d
end
B.Cfg = Cfg

-- ¿Está activa la función BETA general (y, si se indica, esa en concreto)?
function B.On(feature)
  local d = PF.db and PF.db.beta
  if not d or not d.on then return false end
  if feature and not d[feature] then return false end
  return true
end
local On = B.On

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------
local measured, measuredAt                 -- latencia medida (s) y cuándo
local function NetLag()
  local _, _, lat = GetNetStats()
  return (lat or 0) / 1000
end

-- Latencia a usar (segundos): la medida entre lanzamiento y respuesta del servidor si la función está
-- activa y hay una medida reciente; si no, la de la red (GetNetStats). Siempre entre 20 y 400 ms.
function B.Lag()
  local lag
  if On("latency") and measured and (GetTime() - measuredAt) < 120 then lag = measured else lag = NetLag() end
  if lag < 0.02 then lag = 0.02 elseif lag > 0.4 then lag = 0.4 end
  return lag
end

local function Latency() return B.Lag() end

local function CastTime(spell)
  if not spell then return 0 end
  local ct = select(7, GetSpellInfo(spell))
  return (tonumber(ct) or 0) / 1000
end
B.CastTime = CastTime

local function CdLeft(spell)
  local s, d = GetSpellCooldown(spell)
  if s and s > 0 and d and d > 0 then
    local l = s + d - GetTime()
    if l > 0 then return l end
  end
  return 0
end

----------------------------------------------------------------------
-- 1a) TIEMPO DE VUELO
-- Velocidad aproximada del proyectil (yardas/s) por ID de hechizo (rango 1; se traduce al nombre del cliente).
----------------------------------------------------------------------
local PROJ = {
  [686] = 20,     -- Descarga de las sombras
  [348] = 20,     -- Inmolar
  [48181] = 18,   -- Atormentar (Haunt)
  [29722] = 21,   -- Incinerar
  [50796] = 21,   -- Descarga del caos
  [133] = 24,     -- Bola de fuego
  [116] = 28,     -- Descarga de escarcha
  [44614] = 28,   -- Descarga de pirofrío
  [51505] = 21,   -- Explosión de lava
  [403] = 25,     -- Descarga de relámpagos
  [5176] = 20,    -- Cólera
  [2912] = 20,    -- Fuego estelar
  [14914] = 24,   -- Fuego sagrado
  [585] = 24,     -- Aporrear
  [47541] = 24,   -- Lazo de la muerte
  [56641] = 40,   -- Disparo firme
  [19434] = 40,   -- Disparo apuntado
  [3044] = 40,    -- Disparo arcano
  [1978] = 40,    -- Picadura de serpiente
  [53209] = 40,   -- Disparo de quimera
}
local projByName

local function ProjSpeed(spell)
  if not projByName then
    projByName = {}
    for id, sp in pairs(PROJ) do
      local n = GetSpellInfo(id)
      if n then projByName[n] = sp end
    end
  end
  return projByName[spell]
end

-- Distancia estimada al objetivo (yardas) con CheckInteractDistance: 9.9 / 28 / más lejos
local distAt, distVal = 0, 20
local function Dist()
  local now = GetTime()
  if now - distAt < 0.5 then return distVal end
  distAt = now
  if not UnitExists("target") then distVal = 20
  elseif CheckInteractDistance("target", 3) then distVal = 8
  elseif CheckInteractDistance("target", 4) then distVal = 20
  else distVal = 33 end
  return distVal
end

-- Segundos que tarda en llegar el proyectil de ese hechizo (0 si es instantáneo / sin proyectil)
function B.Travel(spell)
  local v = ProjSpeed(spell)
  if not v then return 0 end
  return Dist() / v
end

-- Cuándo renovar un DoT: cuando le queden <= lanzamiento + vuelo + latencia + margen (entre 1.0 y 3.5 s)
function B.RefreshWindow(spell)
  if not On("predict") then return nil end
  local w = CastTime(spell) + B.Travel(spell) + Latency() + WINDOW_MARGIN
  if w < WINDOW_MIN then w = WINDOW_MIN elseif w > WINDOW_MAX then w = WINDOW_MAX end
  return w
end

----------------------------------------------------------------------
-- 1b) SIMULACIÓN DE RECURSOS EN EL PRÓXIMO GCD
----------------------------------------------------------------------
local function Regen(ptype)
  if ptype == 3 then                                -- energía
    local ar = GetSpellInfo(13750)                  -- Estimulación (doble regeneración)
    if ar and PF.Aura("player", ar) then return 20 end
    return 10
  elseif ptype == 0 then                            -- maná
    local base, casting = GetManaRegen()
    local r = (UnitAffectingCombat("player") and casting) or base
    return tonumber(r) or 0
  end
  return 0                                          -- ira / poder rúnico: no regeneran
end

-- Runas necesarias (b = sangre, u = profana, f = escarcha) por ID de hechizo (rango 1)
local RUNE_REQ = {
  [45477] = { f = 1 },            -- Toque helado
  [45462] = { u = 1 },            -- Golpe de peste
  [45902] = { b = 1 },            -- Golpe de sangre
  [55050] = { b = 1 },            -- Golpe al corazón
  [48721] = { b = 1 },            -- Hervor de sangre
  [50842] = { b = 1 },            -- Pestilencia
  [49924] = { f = 1, u = 1 },     -- Golpe de la muerte
  [49020] = { f = 1, u = 1 },     -- Aniquilar
  [55090] = { f = 1, u = 1 },     -- Golpe de Azote
  [49184] = { f = 1, u = 1 },     -- Aullido de escarcha
}
local runeByName
local function RuneReq(spell)
  if CLASS ~= "DEATHKNIGHT" then return nil end
  if not runeByName then
    runeByName = {}
    for id, req in pairs(RUNE_REQ) do
      local n = GetSpellInfo(id)
      if n then runeByName[n] = req end
    end
  end
  return runeByName[spell]
end

local TYPE_KEY = { [1] = "b", [2] = "u", [3] = "f", [4] = "d" }   -- GetRuneType: 4 = runa de muerte
local rem = { b = {}, u = {}, f = {}, d = {} }
local pool = {}

-- Segundos hasta tener las runas pedidas (las runas de muerte sustituyen a cualquier tipo)
local function RuneEta(req)
  if not GetRuneCooldown or not GetRuneType then return nil end
  for _, l in pairs(rem) do wipe(l) end
  local now = GetTime()
  for i = 1, 6 do
    local start, dur, ready = GetRuneCooldown(i)
    local left = 0
    if not ready and start and dur and dur > 0 then
      left = start + dur - now
      if left < 0 then left = 0 end
    end
    local key = TYPE_KEY[GetRuneType(i)]
    if key then local l = rem[key]; l[#l + 1] = left end
  end
  local worst = 0
  for key, need in pairs(req) do
    wipe(pool)
    local own, death = rem[key], rem.d
    for i = 1, #own do pool[#pool + 1] = own[i] end
    for i = 1, #death do pool[#pool + 1] = death[i] end
    table.sort(pool)
    local t = pool[need]
    if not t then return nil end
    if t > worst then worst = t end
  end
  return worst
end

local function ResInfo(spell)
  local _, _, _, cost, _, ptype = GetSpellInfo(spell)
  cost = tonumber(cost)
  if cost and cost > 0 then return cost, ptype end
  return nil
end

-- Segundos hasta poder pagar el hechizo (solo recursos; 0 = ya se puede; nil = no se sabe / no llega)
function B.ResourceEta(spell)
  local rq = RuneReq(spell)
  if rq then return RuneEta(rq) end
  local cost, ptype = ResInfo(spell)
  if not cost then return nil end
  local deficit = cost - (UnitPower("player", ptype) or 0)
  if deficit <= 0 then return 0 end
  local regen = Regen(ptype)
  if regen <= 0 then return nil end
  return deficit / regen
end

-- ¿Lanzar "weaker" ahora retrasaría a "better" más allá del siguiente GCD?
local function Delays(better, weaker)
  local rq = RuneReq(better)
  if rq then
    local wq = RuneReq(weaker)
    if not wq then return false end
    for k in pairs(rq) do if wq[k] then return true end end
    return false
  end
  local cb, pb = ResInfo(better)
  if not cb then return false end
  local cw, pw = ResInfo(weaker)
  if not cw or pw ~= pb then return false end
  local projected = (UnitPower("player", pb) or 0) - cw + Regen(pb) * GCD_PROJ
  return projected < cb
end

-- Recibe la lista de candidatos de Resolve() (spells / tiers / states / execs). Devuelve (índice, segundos)
-- de la habilidad de prioridad 1 por la que conviene ESPERAR un instante, o nil.
function B.PickWait(n, spells, tiers, states, execs)
  if not On("predict") then return nil end
  local firstExec
  for i = 1, n do
    if tiers[i] == 1 and execs[i] then firstExec = i; break end
  end
  local limit = firstExec and WAIT_MAX or WAIT_IDLE
  for i = 1, n do
    if i == firstExec then return nil end              -- lo que va antes ya se ha descartado
    local sp = spells[i]
    if tiers[i] == 1 and not execs[i] and (states[i] or 0) >= 1 and not sp:find("^item:")
       and IsSpellInRange(sp, "target") ~= 0 then
      local eta = B.ResourceEta(sp)
      if eta and eta > 0 and eta <= limit then
        local cd = CdLeft(sp)
        if cd <= GCD_TOL then
          if cd > eta then eta = cd end
          if eta <= limit and (not firstExec or Delays(sp, spells[firstExec])) then
            return i, eta
          end
        end
      end
    end
  end
  return nil
end

----------------------------------------------------------------------
-- 2) SNAPSHOTTING
----------------------------------------------------------------------
local snaps, snapGuids = {}, 0         -- [guid][hechizo] = { p, h, c, kind, school }
local playerGUID

local function SchoolIndex(school)
  -- máscara de escuelas del registro de combate (1 física, 2 sagrado, 4 fuego, 8 naturaleza, 16 escarcha,
  -- 32 sombras, 64 arcano) -> índice de GetSpellBonusDamage (1..7)
  local best, bestVal = nil, -1
  for i = 1, 7 do
    if bit.band(school or 0, 2 ^ (i - 1)) ~= 0 then
      local v = (i == 1) and 0 or (GetSpellBonusDamage(i) or 0)
      if v > bestVal then best, bestVal = i, v end
    end
  end
  return best or 3
end

-- "ap" poder de ataque | "rap" poder de ataque a distancia | "sp" poder con hechizos | nil = no se compara
local function Kind(school)
  if CLASS == "ROGUE" or CLASS == "WARRIOR" or CLASS == "DEATHKNIGHT" then return "ap" end
  if CLASS == "HUNTER" then return "rap" end
  if CLASS == "WARLOCK" or CLASS == "PRIEST" or CLASS == "MAGE" or CLASS == "SHAMAN" then return "sp" end
  if CLASS == "DRUID" then return (school == 1) and "ap" or "sp" end   -- sangrados = AP; Fuego lunar / Enjambre = SP
  return nil
end

-- (poder, celeridad %, crítico %) actuales para ese tipo
local function Stats(kind, school)
  if kind == "ap" then
    local b, p, n = UnitAttackPower("player")
    return (b or 0) + (p or 0) + (n or 0), GetCombatRatingBonus(18) or 0, GetCritChance() or 0
  elseif kind == "rap" then
    local b, p, n = UnitRangedAttackPower("player")
    return (b or 0) + (p or 0) + (n or 0), GetCombatRatingBonus(19) or 0, GetRangedCritChance() or 0
  else
    local idx = SchoolIndex(school)
    return GetSpellBonusDamage(idx) or 0, GetCombatRatingBonus(20) or 0, GetSpellCritChance(idx) or 0
  end
end

local function Capture(guid, spell, school)
  local kind = Kind(school)
  if not kind or not guid or not spell then return end
  local g = snaps[guid]
  if not g then
    if snapGuids > 60 then wipe(snaps); snapGuids = 0 end
    g = {}; snaps[guid] = g; snapGuids = snapGuids + 1
  end
  local p, h, c = Stats(kind, school)
  local s = g[spell]
  if not s then s = {}; g[spell] = s end
  s.p, s.h, s.c, s.kind, s.school, s.t = p, h, c, kind, school, GetTime()
end

-- Relación entre tu poder actual y el del DoT activo (1.0 = igual). nil si no hay registro.
function B.SnapshotRatio(spell, guid)
  guid = guid or UnitGUID("target")
  local g = guid and snaps[guid]
  local s = g and g[spell]
  if not s or not s.p or s.p <= 0 then return nil end
  local p, h = Stats(s.kind, s.school)
  return (p / s.p) * ((1 + h / 100) / (1 + (s.h or 0) / 100)), s
end

-- ¿Compensa renovar ahora un DoT que aún dura "left" segundos porque tus estadísticas han subido?
function B.SnapshotWorth(spell, left)
  if not On("snap") or not left or left >= 9000 then return false end
  local R = B.SnapshotRatio(spell)
  if not R or R < 1 + SNAP_MIN_GAIN then return false end
  local _, _, dur = PF.HasDebuff(spell)
  if not dur or dur <= 0 or dur >= 9000 then return false end
  return (R - 1) >= SNAP_CLIP * (left / dur), R
end

----------------------------------------------------------------------
-- 3) EVENTOS DE JEFE
----------------------------------------------------------------------
local timers = {}
B.instant, B.holdCD, B.budget, B.bossLabel = false, false, nil, nil

-- Hechizos concretos (los más seguros); el resto se clasifica por palabras clave del texto del temporizador
local ID_KIND = {
  [70123] = "move",       -- Frío abrasador (Sindragosa)
  [72762] = "move",       -- Profanar (Rey Exánime)
  [68981] = "immune",     -- Invierno implacable (transición del Rey Exánime)
}
local WORDS = {
  immune = { "inmun", "immun", "invulner", "phase", "fase", "transici", "transition", "intermission", "entreacto" },
  fear = { "miedo", "fear", "terror", "horror", "aullido", "howl", "pánico", "panico", "panic", "scream" },
  move = { "corre", "correr", "huir", "huye", "aleja", "sal de", "mover", "mueve", "fuera de",
           "run ", "run!", "move", "flee", "get out", "away", "defile", "profanar", "blistering", "abrasador" },
}
local ORDER = { "immune", "fear", "move" }

function B.Classify(text, spellId)
  local id = tonumber(spellId)
  if id and ID_KIND[id] then return ID_KIND[id] end
  if type(text) ~= "string" then return nil end
  local t = text:lower()
  for i = 1, #ORDER do
    local kind = ORDER[i]
    local list = WORDS[kind]
    for j = 1, #list do
      if t:find(list[j], 1, true) then return kind end
    end
  end
  return nil
end

local function Warn(kind, label)
  label = (label and label ~= "") and label or PF.T("beta_event")
  local r, g, b = 1, 0.5, 0
  if kind == "immune" then r, g, b = 0.4, 0.8, 1 end
  if UIErrorsFrame then UIErrorsFrame:AddMessage(PF.T("beta_w_" .. kind, label), r, g, b, 1, 3) end
end

-- Registra un evento de jefe que ocurrirá dentro de "secs" segundos. kind: "move" | "fear" | "immune".
-- Lo usan los adaptadores de DBM / BigWigs y cualquier otro addon (PulseBoss...).
function B.BossTimer(kind, secs, label, id)
  if not kind or type(secs) ~= "number" or secs <= 0 then return end
  id = id or (kind .. ":" .. tostring(label))
  local t = timers[id]
  if not t then t = {}; timers[id] = t end
  t.kind, t.at, t.label, t.warned = kind, GetTime() + secs, label, false
end

function B.BossStop(id)
  if id then timers[id] = nil end
end

-- Se llama al empezar cada actualización (0.1 s): calcula en qué ventana de evento estamos
function B.Tick()
  B.instant, B.holdCD, B.budget, B.bossLabel = false, false, nil, nil
  if not On("boss") then return end
  local now = GetTime()
  for id, t in pairs(timers) do
    local left = t.at - now
    local post = (t.kind == "immune") and POST_IMMUNE or POST_MOVE
    if left < -post - 5 then
      timers[id] = nil
    elseif left <= BOSS_LEAD and left >= -post then
      if t.kind == "immune" then
        B.holdCD = true
      else
        B.instant = true
        local b = left > 0 and left or 0
        if not B.budget or b < B.budget then B.budget = b end
      end
      B.bossLabel = t.label
      if not t.warned then t.warned = true; Warn(t.kind, t.label) end
    end
  end
end

-- ¿Debe omitirse esta habilidad ahora por un evento de jefe cercano? (la llama add() del motor)
function B.Skip(spell, tier)
  if not (B.instant or B.holdCD) then return false end
  if B.holdCD and (tier == 2 or spell:find("^item:")) then return true end
  if B.instant and tier ~= 3 and B.HardCast(spell) then return true end
  return false
end

-- ¿Ese hechizo se cortaría antes de terminar (no cabe antes del evento)?
function B.HardCast(spell)
  if not B.instant then return false end
  local ct = CastTime(spell)
  if ct <= 0 then return false end
  return (ct + Latency()) > (B.budget or 0)
end

----------------------------------------------------------------------
-- 4) LATENCIA: medición y "ventana de latencia" del lanzamiento en curso
----------------------------------------------------------------------
local sentAt, lagMarked = {}, {}

local function Sample(x)
  if x <= 0 or x >= 1 then return end
  measured = measured and (measured * 0.7 + x * 0.3) or x
  measuredAt = GetTime()
end

-- Si el lanzamiento / canalización en curso termina dentro de la ventana de latencia, devuelve su nombre:
-- a efectos de la rotación ya se ha lanzado (se marca en PF.lastCast para que no se vuelva a recomendar).
function B.CastInLag()
  if not On("latency") then return nil end
  local now = GetTime()
  local name, _, _, _, _, endTime = UnitCastingInfo("player")
  if not name then name, _, _, _, _, endTime = UnitChannelInfo("player") end
  if not name or not endTime then return nil end
  if endTime / 1000 - now > B.Lag() then return nil end
  local t = PF.lastCast[name]
  if not t or now - t > 1 then PF.lastCast[name] = now; lagMarked[name] = true end
  return name
end

----------------------------------------------------------------------
-- Adaptadores: DBM, BigWigs y casteos del jefe
----------------------------------------------------------------------
local hooked = {}

function B.HookMods()
  if not hooked.dbm and DBM and type(DBM.RegisterCallback) == "function" then
    hooked.dbm = pcall(function()
      DBM:RegisterCallback("DBM_TimerStart", function(_, id, msg, timer, icon, ttype, spellId)
        if not On("boss") then return end
        local kind = B.Classify(msg, spellId)
        if kind then B.BossTimer(kind, tonumber(timer), msg, "dbm:" .. tostring(id)) end
      end)
      DBM:RegisterCallback("DBM_TimerStop", function(_, id) B.BossStop("dbm:" .. tostring(id)) end)
    end)
  end
  if not hooked.bw and BigWigs and LibStub then
    local lib = LibStub:GetLibrary("AceEvent-3.0", true)
    if lib then
      hooked.bw = pcall(function()
        lib:Embed(B)
        B:RegisterMessage("BigWigs_StartBar", function(_, mod, key, text, secs)
          if not On("boss") then return end
          local kind = B.Classify(text, type(key) == "number" and key or nil)
          if kind then B.BossTimer(kind, tonumber(secs), text, "bw:" .. tostring(text)) end
        end)
        B:RegisterMessage("BigWigs_StopBar", function(_, mod, text) B.BossStop("bw:" .. tostring(text)) end)
      end)
    end
  end
end

-- ¿Hay algún addon de jefes enlazado? (sin él, la función de eventos de jefe no hace nada)
function B.BossModLinked()
  return (hooked.dbm or hooked.bw) and true or false
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------
local f = CreateFrame("Frame")
B.frame = f

f:SetScript("OnEvent", function(self, event, ...)
  if event == "COMBAT_LOG_EVENT_UNFILTERED" then
    local _, sub, srcGUID, _, _, dstGUID, _, _, _, spellName, school, auraType = ...
    if srcGUID ~= playerGUID then return end
    if sub == "SPELL_AURA_APPLIED" or sub == "SPELL_AURA_REFRESH" then
      if auraType == "DEBUFF" then Capture(dstGUID, spellName, school) end
    elseif sub == "SPELL_AURA_REMOVED" then
      local g = snaps[dstGUID]
      if g then g[spellName] = nil end
    end
  elseif event == "UNIT_SPELLCAST_SENT" then
    local unit, spell = ...
    if unit == "player" and spell then sentAt[spell] = GetTime() end
  elseif event == "UNIT_SPELLCAST_START" or event == "UNIT_SPELLCAST_CHANNEL_START"
      or event == "UNIT_SPELLCAST_SUCCEEDED" then
    local unit, spell = ...
    if unit == "player" and spell then
      local t0 = sentAt[spell]
      if t0 then
        sentAt[spell] = nil
        Sample(GetTime() - t0)                  -- solo la primera respuesta del servidor a ese envío
      end
      if event == "UNIT_SPELLCAST_SUCCEEDED" then lagMarked[spell] = nil end
    end
  elseif event == "UNIT_SPELLCAST_INTERRUPTED" or event == "UNIT_SPELLCAST_FAILED" then
    local unit, spell = ...
    if unit == "player" and spell then
      sentAt[spell] = nil
      if lagMarked[spell] then lagMarked[spell] = nil; PF.lastCast[spell] = nil end   -- no llegó a lanzarse
    end
  elseif event == "PLAYER_REGEN_ENABLED" then
    wipe(snaps); snapGuids = 0                  -- fuera de combate los DoTs ya no cuentan
  elseif event == "PLAYER_ENTERING_WORLD" then
    playerGUID = UnitGUID("player")
    B.HookMods()
  end
end)

-- Registra solo los eventos que hacen falta según lo activado (el registro de combate es el más pesado)
function B.Apply()
  local d = Cfg()
  playerGUID = UnitGUID("player")
  f:UnregisterAllEvents()
  if not d or not d.on then return end
  f:RegisterEvent("PLAYER_ENTERING_WORLD")
  if d.snap then
    f:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
    f:RegisterEvent("PLAYER_REGEN_ENABLED")
  end
  if d.boss then B.HookMods() end
  if d.latency then
    f:RegisterEvent("UNIT_SPELLCAST_SENT")
    f:RegisterEvent("UNIT_SPELLCAST_START")
    f:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
    f:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
    f:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
    f:RegisterEvent("UNIT_SPELLCAST_FAILED")
  end
end

function B.Init()
  Cfg()
  B.Apply()
end

-- Interruptor general / de cada función (lo usan la configuración y /pf beta)
function B.Set(key, value)
  local d = Cfg()
  if not d or d[key] == nil then return end
  d[key] = value and true or false
  B.Apply()
  if not B.On() then B.instant, B.holdCD, B.budget = false, false, nil end
  if PF.RefreshConfig then PF.RefreshConfig() end
end

----------------------------------------------------------------------
-- /pf beta
----------------------------------------------------------------------
local function Flag(v) return v and "|cff33ff33ON|r" or "|cffff5555OFF|r" end

function B.Status()
  local d = Cfg()
  if not d then return end
  PF.Msg(string.format("%s: general %s | predicción %s | latencia %s | snapshotting %s | eventos de jefe %s", PF.T("fn_name"),
    Flag(d.on), Flag(d.predict), Flag(d.latency), Flag(d.snap), Flag(d.boss)))
  PF.Msg(string.format("   latencia: medida %s | red %.0f ms | en uso %.0f ms",
    measured and string.format("%.0f ms", measured * 1000) or "sin datos", NetLag() * 1000, B.Lag() * 1000))
  PF.Msg(string.format("   DBM: %s | BigWigs: %s", hooked.dbm and "enlazado" or (DBM and "sin callbacks" or "no"),
    hooked.bw and "enlazado" or (BigWigs and "sin AceEvent" or "no")))
  local g = UnitGUID("target") and snaps[UnitGUID("target")]
  if g then
    for spell, s in pairs(g) do
      local R = B.SnapshotRatio(spell)
      PF.Msg(string.format("   snapshot %s: poder %.0f (%s), ahora x%.2f", spell, s.p or 0, s.kind or "?", R or 0))
    end
  end
  local now, n = GetTime(), 0
  for _, t in pairs(timers) do
    n = n + 1
    PF.Msg(string.format("   evento %s en %.1f s: %s", t.kind, t.at - now, tostring(t.label)))
  end
  if n == 0 then PF.Msg("   sin eventos de jefe en cola") end
  if d.boss and not B.BossModLinked() then PF.Msg("   " .. PF.T("fn_nomod")) end
  PF.Msg(string.format("   ventana: instantáneos=%s cooldowns retenidos=%s", tostring(B.instant), tostring(B.holdCD)))
end

function B.Command(arg)
  local d = Cfg()
  if not d then return end
  local a, b, c = (arg or ""):match("^(%S*)%s*(%S*)%s*(%S*)$")
  if a == "" then
    B.Set("on", not d.on)
    PF.Msg(PF.T(d.on and "beta_on" or "beta_off"))
  elseif a == "status" or a == "estado" then
    B.Status()
  elseif a == "predict" or a == "snap" or a == "boss" or a == "latency" then
    local v
    if b == "on" then v = true elseif b == "off" then v = false else v = not d[a] end
    B.Set(a, v)
    PF.Msg(string.format("%s %s: %s", PF.T("fn_name"), a, Flag(d[a])))
    if a == "boss" and d.boss and not B.BossModLinked() then PF.Msg(PF.T("fn_nomod")) end
  elseif a == "test" then
    local kind = (b == "fear" or b == "immune") and b or "move"
    local secs = tonumber(c) or 5
    if not d.on or not d.boss then PF.Msg(PF.T("beta_test_off")); return end
    B.BossTimer(kind, secs, "Prueba", "test")
    PF.Msg(string.format("%s: evento de prueba '%s' en %d s", PF.T("fn_name"), kind, secs))
  else
    PF.Msg("/pf nuevas  |  /pf nuevas status  |  /pf nuevas predict|latency|snap|boss [on|off]  |  /pf nuevas test move|fear|immune [seg]")
  end
end
