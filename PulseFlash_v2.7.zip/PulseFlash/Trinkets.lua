--[[
  PulseFlash - Trinkets.lua  (WoW 3.3.5a)
  Recomienda los TRINKETS de uso activo (los de "Uso:") en la cola de cooldowns, SOLO contra jefes
  (Core.lua solo llama a PF.AddTrinkets con c.combat y c.bigCD; /pf cds lo permite siempre).

  Solo se recomiendan los trinkets de DAÑO: se lee el texto de su línea "Uso:" y se descartan los
  de PvP / defensivos (quitar aturdimientos, inmunidad, curación, armadura...). El texto se
  analiza en inglés y en español. El resultado se guarda por objeto para no releer el tooltip.
  Los trinkets pasivos (sin "Uso:") no se recomiendan: se activan solos.
]]
local PF = PulseFlash

local SLOTS = { 13, 14 }
local cache = {}                           -- [itemID] = true (daño) | false (no recomendar)

-- Palabras (en minúsculas) de la línea "Uso:" que indican bonificación de daño
local DPS_WORDS = {
  "attack power", "spell power", "haste", "critical", "crit", "strength", "agility", "intellect",
  "damage", "poder de ataque", "poder con hechizos", "poder de hechizo", "celeridad", "crítico",
  "critico", "fuerza", "agilidad", "intelecto", "daño", "dano",
}
-- Palabras que descartan el trinket (PvP, control de masas, defensivos, curación)
local SKIP_WORDS = {
  "stun", "fear", "root", "snare", "polymorph", "sleep", "charm", "incapacit", "movement impairing",
  "immun", "remove", "dispel", "heal", "health", "armor", "block", "dodge", "parry", "resist",
  "absorb", "aturd", "miedo", "inmoviliz", "ralentiz", "polimorf", "incapacit", "inmun", "elimina",
  "disipa", "cura", "salud", "armadura", "bloqu", "esquiv", "parada", "resisten", "absorbe",
}

local tip

local function UseText(slot)
  if not tip then
    tip = CreateFrame("GameTooltip", "PulseFlashTrinketScan", nil, "GameTooltipTemplate")
    tip:SetOwner(UIParent, "ANCHOR_NONE")
  end
  tip:ClearLines()
  tip:SetInventoryItem("player", slot)
  local trigger = (ITEM_SPELL_TRIGGER_ONUSE or "Use:"):lower()
  local text
  for i = 2, tip:NumLines() do
    local fs = _G["PulseFlashTrinketScanTextLeft" .. i]
    local line = fs and fs:GetText()
    if line and line:lower():find(trigger, 1, true) == 1 then
      text = (text and (text .. " ") or "") .. line:lower()
    end
  end
  return text
end

local function HasAny(text, words)
  for i = 1, #words do
    if text:find(words[i], 1, true) then return true end
  end
  return false
end

-- true si el trinket equipado en `slot` es de uso activo y de daño
local function IsDamageTrinket(id, slot)
  if cache[id] ~= nil then return cache[id] end
  local text = UseText(slot)
  if text == nil then
    -- Sin "Uso:" legible: si el tooltip aún no cargó no se guarda (se reintenta); si sí, es pasivo
    if tip and tip:NumLines() > 1 then cache[id] = false end
    return false
  end
  cache[id] = HasAny(text, DPS_WORDS) and not HasAny(text, SKIP_WORDS)
  return cache[id]
end

-- Añade a la lista del motor los trinkets de daño equipados (tier 2 = cola de cooldowns)
function PF.AddTrinkets(add)
  for _, slot in ipairs(SLOTS) do
    local id = GetInventoryItemID("player", slot)
    if id and IsDamageTrinket(id, slot) then add(PF.Item(id), 2) end
  end
end

-- Al cambiar de equipo se descarta lo guardado de los objetos que ya no están
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
f:SetScript("OnEvent", function() wipe(cache) end)
