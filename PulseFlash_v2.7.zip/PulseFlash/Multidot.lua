--[[
  PulseFlash - Multidot.lua  (WoW 3.3.5a)

  Detecta SOLA la pelea contra varios enemigos (el "pull") y recomienda cambiar de objetivo para repartir
  tus DoTs, pero solo cuando el objetivo actual ya los tiene todos puestos (no interrumpe tu rotación).
  Se activa y desactiva con /pf multidot o en la sección "Multidot" de la configuración (hay quien
  prefiere hacer todo el daño al objetivo único).

  CÓMO FUNCIONA
    * El juego 3.3.5 no deja enumerar enemigos, así que se escucha el registro de combate: un enemigo
      (PNJ hostil) cuenta como "del pull" mientras el grupo le hace daño o él se lo hace al grupo.
      Sale de la lista si muere o pasa ACTIVE_WINDOW segundos sin actividad.
    * Los DoTs propios en cada enemigo se siguen con los eventos de aura del registro de combate
      (aplicado / renovado / quitado / tic) y, en el objetivo actual, se sincronizan con sus auras reales.
    * Un enemigo cuenta como "sin DoTs" si le falta alguno de los DoTs que tu módulo mantiene (lista por
      rama en el módulo de cada clase: campo "multidot"). No se cuentan los inmunes ni los casi muertos
      (cuando su vida se conoce por el grupo / foco / ratón).
    * El aviso aparece bajo el HUD de daño. No se muestra contra jefes (un jefe solo, o con adds, es
      daño al objetivo único) ni si hay menos de PF.db.multidotMin enemigos.
]]
local PF = PulseFlash

local ACTIVE_WINDOW = 8        -- s sin actividad para dejar de contar un enemigo
local MIN_HP_WORTH = 0.20      -- por debajo de esta vida (si se conoce) no merece la pena un DoT
local SHOW_DELAY = 0.3         -- el aviso debe cumplirse este tiempo antes de mostrarse (anti-parpadeo)
local HOLD = 0.8               -- y se mantiene este tiempo tras dejar de cumplirse
local MAX_TRACKED = 40
local HP_SCAN = 0.5            -- s entre lecturas de vida por unidades conocidas
local HP_FRESH = 2.0           -- una lectura de vida vale este tiempo
local MIN_DEFAULT = 3          -- enemigos mínimos en el pull

local band = bit.band
local HOSTILE = COMBATLOG_OBJECT_REACTION_HOSTILE or 0x40
local NPC = COMBATLOG_OBJECT_TYPE_NPC or 0x800
local GROUP = (COMBATLOG_OBJECT_AFFILIATION_MINE or 0x1) + (COMBATLOG_OBJECT_AFFILIATION_PARTY or 0x2)
              + (COMBATLOG_OBJECT_AFFILIATION_RAID or 0x4)

local module, class
local enemies, dots, immune, hpCache = {}, {}, {}, {}
local trackedSet = {}
local nEnemies = 0
local playerGUID
local frame
local trueSince, lastTrue, shown, lastText = nil, nil, false, nil
local scanAt = 0
local tokens

local function Hostile(flags) return flags and band(flags, HOSTILE) ~= 0 and band(flags, NPC) ~= 0 end
local function InGroup(flags) return flags and band(flags, GROUP) ~= 0 end

local function Reset()
  wipe(enemies); wipe(dots); wipe(immune); wipe(hpCache)
  nEnemies = 0
  trueSince, lastTrue, shown, lastText = nil, nil, false, nil
  PF.multiInfo = nil
end

local function Forget(guid)
  if enemies[guid] then enemies[guid] = nil; nEnemies = nEnemies - 1 end
  dots[guid] = nil
  hpCache[guid] = nil
end

local function Seen(guid, name, now)
  local e = enemies[guid]
  if e then
    e.last = now
    return
  end
  if nEnemies >= MAX_TRACKED then                       -- tabla llena: se descarta el más antiguo
    local oldG, oldT
    for g, x in pairs(enemies) do
      if not oldT or x.last < oldT then oldG, oldT = g, x.last end
    end
    if oldG then Forget(oldG) end
  end
  enemies[guid] = { name = name or "?", first = now, last = now }
  nEnemies = nEnemies + 1
end

local function OnLog(timestamp, sub, sGUID, sName, sFlags, dGUID, dName, dFlags, spellId, spellName, school, missType)
  if not sub then return end
  if sub == "UNIT_DIED" or sub == "PARTY_KILL" or sub == "UNIT_DESTROYED" then
    if dGUID then Forget(dGUID) end
    return
  end
  local now = GetTime()
  -- Pertenencia al pull: daño o fallo entre el grupo (o sus mascotas) y un PNJ hostil
  if sub:find("_DAMAGE$") or sub:find("_MISSED$") then
    if InGroup(sFlags) and Hostile(dFlags) then Seen(dGUID, dName, now)
    elseif Hostile(sFlags) and InGroup(dFlags) then Seen(sGUID, sName, now) end
  end
  -- Mis DoTs en cada enemigo
  if sGUID == playerGUID and dGUID and spellName and trackedSet[spellName] and Hostile(dFlags) then
    if sub == "SPELL_AURA_APPLIED" or sub == "SPELL_AURA_REFRESH" or sub == "SPELL_PERIODIC_DAMAGE" then
      Seen(dGUID, dName, now)
      local d = dots[dGUID]
      if not d then d = {}; dots[dGUID] = d end
      d[spellName] = now
    elseif sub == "SPELL_AURA_REMOVED" then
      local d = dots[dGUID]
      if d then d[spellName] = nil end
    elseif sub == "SPELL_MISSED" and missType == "IMMUNE" then
      immune[dGUID .. spellName] = true
    end
  end
end

local function Apply()
  if not frame then return end
  local DB = PF.db
  local on = module and module.multidot and DB and DB.multidot ~= false
  if on then
    frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
    frame:RegisterEvent("PLAYER_REGEN_DISABLED")
    frame:RegisterEvent("PLAYER_REGEN_ENABLED")
  else
    frame:UnregisterAllEvents()
    Reset()
  end
end

-- Interruptor (/pf multidot y la configuración)
function PF.Multidot_Supported() return (module and module.multidot) and true or false end

function PF.Multidot_Set(v)
  if not PF.db then return end
  PF.db.multidot = v and true or false
  Apply()
end

function PF.Multidot_Toggle()
  if not PF.Multidot_Supported() then
    PF.Msg(PF.T("md_only"))
    return
  end
  PF.Multidot_Set(not (PF.db.multidot ~= false))
  PF.Msg(PF.T("t_multidot") .. ": " .. (PF.db.multidot and PF.T("ON_M") or PF.T("OFF_M")))
end

function PF.Multidot_Init(cls)
  class = cls
  module = PF.modules and PF.modules[cls]
  if not module or not module.multidot then return end
  if PF.db.multidot == nil then PF.db.multidot = true end
  if tonumber(PF.db.multidotMin) == nil then PF.db.multidotMin = MIN_DEFAULT end
  playerGUID = UnitGUID("player")
  wipe(trackedSet)
  for spec, list in pairs(module.multidot) do
    if type(spec) == "number" and type(list) == "table" then
      for _, key in ipairs(list) do
        local n = PF.N[key]
        if n then trackedSet[n] = true end
      end
    end
  end
  frame = CreateFrame("Frame")
  frame:SetScript("OnEvent", function(_, event, ...)
    if event == "COMBAT_LOG_EVENT_UNFILTERED" then
      OnLog(...)
    else
      Reset()                                            -- empieza / termina el combate: pull nuevo
      playerGUID = UnitGUID("player") or playerGUID
    end
  end)
  Apply()
end

-- DoTs (nombres localizados y aprendidos) que tu rama mantiene
local function SpecList(c)
  local keys = module.multidot[c.spec]
  if not keys then return nil end
  local out
  for _, key in ipairs(keys) do
    local n = PF.N[key]
    if n and PF.Known(n) and not (module.multidotSkip and module.multidotSkip(key)) then
      out = out or {}
      out[#out + 1] = n
    end
  end
  return out
end

-- Lee la vida de los enemigos que algún miembro del grupo tiene como objetivo (cada HP_SCAN s)
local function BuildTokens()
  tokens = { "target", "focus", "mouseover", "pettarget", "targettarget" }
  for i = 1, 4 do tokens[#tokens + 1] = "party" .. i .. "target" end
  for i = 1, 40 do tokens[#tokens + 1] = "raid" .. i .. "target" end
end

local function ScanHealth(now)
  if now - scanAt < HP_SCAN then return end
  scanAt = now
  if not tokens then BuildTokens() end
  for _, u in ipairs(tokens) do
    local g = UnitExists(u) and UnitGUID(u)
    if g and enemies[g] then
      if UnitIsDead(u) then
        Forget(g)
      else
        local m = UnitHealthMax(u)
        if m and m > 0 then hpCache[g] = { pct = UnitHealth(u) / m, t = now } end
      end
    end
  end
end

-- Devuelve el texto del aviso, o nil. Se llama desde el bucle principal (cada 0,1 s).
function PF.Multidot_Eval(c)
  local DB = PF.db
  if not module or not module.multidot or not DB or DB.multidot == false then return nil end
  if not c.combat or not c.hostile or c.boss then
    trueSince, lastTrue, shown = nil, nil, false
    return nil
  end
  local list = SpecList(c)
  if not list then return nil end
  local now = GetTime()
  local tg = UnitGUID("target")

  -- Sincroniza los DoTs del objetivo actual con sus auras reales
  local covered = true
  if tg then
    local d = dots[tg]
    for _, name in ipairs(list) do
      if PF.HasDebuff(name) then
        if not d then d = {}; dots[tg] = d end
        d[name] = now
      elseif d and d[name] then
        d[name] = nil
      end
      if c.worth and not (d and d[name]) and not PF.Pending(name) and not PF.IsCasting(name)
         and c.casting ~= name and not immune[tg .. name] then
        covered = false
      end
    end
  end
  if not covered then                                   -- aún te falta algún DoT en este objetivo
    trueSince, shown = nil, false
    return nil
  end

  -- Enemigos activos del pull
  for g, e in pairs(enemies) do
    if now - e.last > ACTIVE_WINDOW then Forget(g) end
  end
  local total = nEnemies + ((tg and not enemies[tg]) and 1 or 0)
  local minE = tonumber(DB.multidotMin) or MIN_DEFAULT
  local text
  if total >= minE then
    ScanHealth(now)
    local best, bestName, missing = nil, nil, 0
    for g, e in pairs(enemies) do
      if g ~= tg then
        local h = hpCache[g]
        local nearDead = h and (now - h.t) < HP_FRESH and h.pct < MIN_HP_WORTH
        if not nearDead then
          local d = dots[g]
          for _, name in ipairs(list) do
            if not (d and d[name]) and not immune[g .. name] then
              missing = missing + 1
              if not best or e.first < best.first then best, bestName = e, name end
              break
            end
          end
        end
      end
    end
    if missing > 0 and best then
      text = PF.T("md_msg", missing, best.name, bestName)
    end
  end

  -- Anti-parpadeo
  if text then
    if not trueSince then trueSince = now end
    lastTrue, lastText = now, text
    if now - trueSince >= SHOW_DELAY then shown = true end
  else
    trueSince = nil
    if shown and lastTrue and (now - lastTrue) >= HOLD then shown = false end
  end
  return shown and (text or lastText) or nil
end
