--[[
  PulseFlash - HudStyles.lua  (WoW 3.3.5a)

  ESTILOS del HUD de daño. Los tres usan los mismos tres iconos (principal, siguiente y utilidad) y solo
  cambian su tamaño, su posición y su "piel". Se elige en la configuración (pestaña "Estilo del HUD") y
  se guarda en el perfil: PulseFlashDB.profiles[...].hud.style.

    classic  Origin .............. tres iconos iguales en fila (el diseño de siempre).            144 x 46
    queue    Apex ................ un icono grande (ahora) y dos pequeños apilados (después).     90 x 58
                                  Bordes de color: dorado = ahora, celeste = siguiente, verde = utilidad.
    line     Cascade ............. franja oscura con el icono actual destacado y los siguientes   130 x 50
                                  en pequeño, unidos por flechas (ahora > siguiente > después).
    serenity Serenity ........... tres iconos con marco redondeado claro y sombra oscura. Punto   152 x 42
                                  gris en la esquina y tecla sobre el borde. Al usar la prioridad 1
                                  la cola se DESLIZA un hueco a la izquierda (el icono usado se
                                  desvanece y el nuevo entra por la derecha). Texturas en Media/*.tga.

    assistant Oracle ............. panel oscuro con cabecera: icono principal con resplandor dorado    186 x 73
                                  que "late" y la tecla en grande en el centro, nombre de la habilidad
                                  al lado y los dos siguientes en pequeño con su cuenta atrás. Al cambiar
                                  la habilidad principal sale un anillo que se expande y el texto entra
                                  deslizándose. Texturas en Media/glow_sq.tga y pulse_ring.tga.

  PF.HUDLayout(id, root, main, q1, q2, decor) coloca y dimensiona los iconos y devuelve el ancho y alto
  del conjunto. Lo usan el HUD real (Core.lua) y las vistas previas de la configuración (Config.lua).
]]
local PF = PulseFlash

local GOLD  = { 1.00, 0.82, 0.00 }
local CYAN  = { 0.35, 0.85, 1.00 }
local GREEN = { 0.45, 1.00, 0.55 }
local DARK  = { 0.05, 0.05, 0.05 }
local ARIAL = "Fonts\\ARIALN.TTF"
local FRIZ  = "Fonts\\FRIZQT__.TTF"
local WHITE = "Interface\\Buttons\\WHITE8X8"

local MEDIA = "Interface\\AddOns\\PulseFlash\\Media\\"
-- Texturas del marco (generadas con las medidas de abajo: anillo claro + banda oscura + sombra suave)
local RING = {
  big = { tex = MEDIA .. "ring_big.tga", overlay = 58.4, dot = 7 },       -- icono de 42
}

local function Size(f, s) f:SetWidth(s); f:SetHeight(s) end

-- Posición de la tecla: sobre el borde derecho (Serenity); "classic" = por defecto
local function KeyAnchor(f, mode)
  if not f.key then return end
  f.key:ClearAllPoints()
  if mode == "big" then f.key:SetPoint("TOPRIGHT", f, "TOPRIGHT", 3, 1)
  else f.key:SetPoint("TOPRIGHT", f, "TOPRIGHT", -2, -2) end
end

-- Marco "Serenity" sobre un icono: anillo redondeado por ENCIMA del icono (tapa sus esquinas) + punto gris
local function SkinOn(f)
  local r = RING.big
  if not f.top then return end
  if not f.ring then
    f.ring = f.top:CreateTexture(nil, "ARTWORK")
    f.dot = f.top:CreateTexture(nil, "OVERLAY")
    f.dot:SetTexture(MEDIA .. "dot.tga")
  end
  f.ring:SetTexture(r.tex)
  f.ring:ClearAllPoints(); f.ring:SetPoint("CENTER", f, "CENTER", 0, 0)
  f.ring:SetWidth(r.overlay); f.ring:SetHeight(r.overlay)
  f.ring:Show()
  f.dot:ClearAllPoints(); f.dot:SetPoint("CENTER", f, "BOTTOMRIGHT", -1, 1)
  f.dot:SetWidth(r.dot); f.dot:SetHeight(r.dot)
  f.dot:Show()
  if f.SetBackdropColor then f:SetBackdropColor(0, 0, 0, 0.45) end        -- hueco vacío: oscuro translúcido
  if f.SetBackdropBorderColor then f:SetBackdropBorderColor(0, 0, 0, 0) end   -- el borde lo da el anillo
end

local function SkinOff(f)
  if f.ring then f.ring:Hide() end
  if f.dot then f.dot:Hide() end
  if f.SetBackdropColor then f:SetBackdropColor(0, 0, 0, 1) end
  if f.key then f.key:Show() end
  KeyAnchor(f, "classic")
end

-- Los estilos sin marco Serenity restauran los iconos normales y detienen su animación
local function ResetSkin(m, q1, q2, d)
  if d and d.slideStop then d.slideStop(); d.slots = nil end
  if d and d.assistOff then d.assistOff() end
  SkinOff(m); SkinOff(q1); SkinOff(q2)
end

local function Place(f, point, rel, relPoint, x, y)
  f:ClearAllPoints()
  f:SetPoint(point, rel, relPoint, x, y)
end

-- Tamaño de la letra de la tecla (esquina) y de la cuenta atrás de espera (solo el icono principal)
local function Fonts(f, keySize, waitSize)
  if f.key then f.key:SetFont(ARIAL, keySize, "OUTLINE") end
  if f.wait and waitSize then f.wait:SetFont(ARIAL, waitSize, "OUTLINE") end
end


-- Caja de fondo hecha de TEXTURAS del marco raíz (capas BACKGROUND/BORDER). Las texturas de un marco
-- se dibujan siempre por DEBAJO de sus marcos hijos (los iconos), así nunca los oscurecen. Antes la
-- franja y el panel eran marcos hijos con fondo y, según el nivel de marco, tapaban los iconos.
local function MakeBox(root, bg, edge)
  local b = { extra = {} }
  b.edge = root:CreateTexture(nil, "BACKGROUND")
  b.edge:SetTexture(WHITE); b.edge:SetVertexColor(edge[1], edge[2], edge[3], edge[4])
  b.edge:SetAllPoints(root)
  b.fill = root:CreateTexture(nil, "BORDER")
  b.fill:SetTexture(WHITE); b.fill:SetVertexColor(bg[1], bg[2], bg[3], bg[4])
  b.fill:SetPoint("TOPLEFT", root, "TOPLEFT", 1, -1)
  b.fill:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", -1, 1)
  b.shown = false
  function b:Show()
    self.shown = true; self.edge:Show(); self.fill:Show()
    for i = 1, #self.extra do self.extra[i]:Show() end
  end
  function b:Hide()
    self.shown = false; self.edge:Hide(); self.fill:Hide()
    for i = 1, #self.extra do self.extra[i]:Hide() end
  end
  function b:IsShown() return self.shown end
  b:Hide()
  return b
end

local function Border(f, c, a)
  if f.SetBackdropBorderColor then f:SetBackdropBorderColor(c[1], c[2], c[3], a or 1) end
end

----------------------------------------------------------------------
-- Adornos compartidos: franja de fondo y flechas (solo los usa "line")
----------------------------------------------------------------------
function PF.HUDMakeDecor(root)
  local d = {}
  d.plate = MakeBox(root, { 0.030, 0.040, 0.060, 0.80 }, { 0.30, 0.34, 0.42, 0.95 })
  d.a1 = root:CreateFontString(nil, "OVERLAY")
  d.a2 = root:CreateFontString(nil, "OVERLAY")
  for _, a in ipairs({ d.a1, d.a2 }) do
    a:SetFont(FRIZ, 15, "OUTLINE")
    a:SetText(">")
    a:SetTextColor(GOLD[1], GOLD[2], GOLD[3], 0.85)
    a:Hide()
  end
  d.plate:Hide()
  d.root = root
  ----------------------------------------------------------------
  -- Deslizamiento (solo Serenity). Los tres iconos viven en huecos fijos (d.base) y, al avanzar la
  -- cola, cada icono parte del hueco de su derecha y entra suavemente en el suyo. El icono usado
  -- se desvanece hacia la izquierda (fantasma) y el que llega nuevo aparece con un fundido.
  ----------------------------------------------------------------
  local function Step(k)                                -- k = 0..1 (progreso)
    local e = 1 - (1 - k) * (1 - k) * (1 - k)           -- suavizado de salida (rápido y se asienta)
    for i = 1, 3 do
      local f = d.slots[i]
      Place(f, "LEFT", root, "LEFT", d.base[i] + d.from[i] * (1 - e), 0)
      f:SetAlpha(d.a0[i] + (1 - d.a0[i]) * e)
    end
    if d.ghostOn then
      Place(d.ghost, "LEFT", root, "LEFT", d.base[1] - d.step * 0.55 * e, 0)
      d.ghost:SetAlpha(1 - e)
    end
  end

  function d.slideStop()
    if d.driver then d.driver:SetScript("OnUpdate", nil) end
    d.ghostOn = false
    if d.ghost then d.ghost:Hide() end
    if d.slots then
      for i = 1, 3 do
        local f = d.slots[i]
        f:SetAlpha(1)
        Place(f, "LEFT", root, "LEFT", d.base[i], 0)
      end
    end
  end

  -- p1..p3 = habilidades que tenían los tres huecos ANTES de este cambio
  function d.slide(p1, p2, p3)
    if not d.slots then return end
    local p = { p1, p2, p3 }
    local n = { d.slots[1].spell, d.slots[2].spell, d.slots[3].spell }
    if n[1] == p[1] and n[2] == p[2] and n[3] == p[3] then return end   -- nada cambió
    if not (p[1] or p[2] or p[3]) or not (n[1] or n[2] or n[3]) then return end
    d.from, d.a0 = d.from or {}, d.a0 or {}
    for k = 1, 3 do
      local from, a0, sp = 0, 1, n[k]
      if sp and p[k] ~= sp then
        local j
        for x = k + 1, 3 do if p[x] == sp then j = x; break end end
        if j then from = (j - k) * d.step                 -- venía de la derecha: desliza
        else from, a0 = d.step * 0.4, 0 end               -- habilidad nueva: entra con fundido
      end
      d.from[k], d.a0[k] = from, a0
    end
    -- el icono usado (prioridad 1 anterior) se va desvaneciendo si ya no está en la cola
    local gone = p[1]
    for k = 1, 3 do if n[k] == gone then gone = nil end end
    d.ghostOn = false
    if gone and PF.HUDMakeIcon then
      local tex = PF.Texture and PF.Texture(gone)
      if tex then
        if not d.ghost then
          d.ghost = PF.HUDMakeIcon(root)
          Size(d.ghost, 42); SkinOn(d.ghost); KeyAnchor(d.ghost, "big")
          d.ghost.key:SetText(""); d.ghost.wait:SetText("")
        end
        d.ghost.icon:SetTexture(tex)
        d.ghost.icon:SetAlpha(1)
        d.ghost:Show()
        d.ghostOn = true
      end
    end
    if not d.driver then d.driver = CreateFrame("Frame", nil, root) end
    d.t = 0
    Step(0)
    d.driver:SetScript("OnUpdate", function(_, el)
      d.t = d.t + el
      if d.t >= 0.20 then d.slideStop() else Step(d.t / 0.20) end
    end)
  end
  -- Una flecha solo se ve si el icono al que apunta está visible
  function d.Sync(q1, q2)
    if not d.plate:IsShown() then d.a1:Hide(); d.a2:Hide(); return end
    if q1 and q1:IsShown() then d.a1:Show() else d.a1:Hide() end
    if q2 and q2:IsShown() then d.a2:Show() else d.a2:Hide() end
  end
  return d
end

----------------------------------------------------------------------
-- Estilos
----------------------------------------------------------------------
local STYLES = {}

STYLES.classic = {
  name = "hs_classic", desc = "hs_classic_d",
  layout = function(root, m, q1, q2, d)
    ResetSkin(m, q1, q2, d)
    local S, G = 46, 3
    Size(m, S); Size(q1, S); Size(q2, S)
    Place(m, "LEFT", root, "LEFT", 0, 0)
    Place(q1, "LEFT", m, "RIGHT", G, 0)
    Place(q2, "LEFT", q1, "RIGHT", G, 0)
    Fonts(m, 13, 16); Fonts(q1, 13); Fonts(q2, 13)
    Border(m, DARK); Border(q1, DARK); Border(q2, DARK)
    return S * 3 + G * 2, S
  end,
}

STYLES.queue = {
  name = "hs_queue", desc = "hs_queue_d",
  layout = function(root, m, q1, q2, d)
    ResetSkin(m, q1, q2, d)
    local BIG, SMALL, G = 58, 28, 4                     -- 2 * SMALL + 2 de separación = BIG
    Size(m, BIG); Size(q1, SMALL); Size(q2, SMALL)
    Place(m, "TOPLEFT", root, "TOPLEFT", 0, 0)
    Place(q1, "TOPRIGHT", root, "TOPRIGHT", 0, 0)
    Place(q2, "BOTTOMRIGHT", root, "BOTTOMRIGHT", 0, 0)
    Fonts(m, 15, 18); Fonts(q1, 10); Fonts(q2, 10)
    Border(m, GOLD); Border(q1, CYAN); Border(q2, GREEN)
    return BIG + G + SMALL, BIG
  end,
}

STYLES.line = {
  name = "hs_line", desc = "hs_line_d",
  layout = function(root, m, q1, q2, d)
    ResetSkin(m, q1, q2, d)
    local PAD, BIG, SMALL, ARROW = 5, 40, 28, 12
    Size(m, BIG); Size(q1, SMALL); Size(q2, SMALL)
    Place(m, "LEFT", root, "LEFT", PAD, 0)
    Place(q1, "LEFT", m, "RIGHT", ARROW, 0)
    Place(q2, "LEFT", q1, "RIGHT", ARROW, 0)
    Fonts(m, 13, 15); Fonts(q1, 10); Fonts(q2, 10)
    Border(m, GOLD); Border(q1, CYAN, 0.9); Border(q2, GREEN, 0.9)
    if d then
      d.plate:Show()
      Place(d.a1, "CENTER", m, "RIGHT", ARROW / 2, 0)
      Place(d.a2, "CENTER", q1, "RIGHT", ARROW / 2, 0)
    end
    return PAD + BIG + ARROW + SMALL + ARROW + SMALL + PAD, BIG + PAD * 2
  end,
}

STYLES.serenity = {
  name = "hs_serenity", desc = "hs_serenity_d",
  slide = true,           -- la cola se desliza al avanzar (ver d.slide); los huecos sin habilidad se ocultan
  layout = function(root, m, q1, q2, d)
    ResetSkin(m, q1, q2, d)                              -- por si venimos de otro estilo (p. ej. Oracle)
    local BIG, GAP = 42, 13
    local step = BIG + GAP
    local frames = { m, q1, q2 }
    for _, f in ipairs(frames) do
      Size(f, BIG); SkinOn(f); KeyAnchor(f, "big")
    end
    Fonts(m, 12, 15); Fonts(q1, 12); Fonts(q2, 12)
    if d then
      d.slots, d.base, d.step = frames, { 0, step, step * 2 }, step
      d.slideStop()                                      -- cancela cualquier deslizamiento en curso
    end
    for i, f in ipairs(frames) do                        -- huecos fijos respecto a root (no encadenados)
      Place(f, "LEFT", root, "LEFT", (i - 1) * step, 0)
    end
    return BIG * 3 + GAP * 2, BIG
  end,
}

----------------------------------------------------------------------
-- Estilo "Oracle": panel oscuro con cabecera, icono principal con resplandor dorado y la tecla en
-- grande, nombre de la habilidad al lado y los dos siguientes en pequeño con su cuenta atrás.
----------------------------------------------------------------------
local AS = { PAD = 7, HEAD = 16, BIG = 44, SM = 22, W = 186 }
AS.H  = AS.HEAD + AS.PAD + AS.BIG + AS.PAD
AS.TX = AS.PAD + AS.BIG + 9                              -- inicio del texto

local function PlaceTexts(d, dx)
  d.pTitle:ClearAllPoints()
  d.pTitle:SetPoint("TOPLEFT", d.root, "TOPLEFT", AS.TX + dx, -(AS.HEAD + AS.PAD + 1))
  d.pSub:ClearAllPoints()
  d.pSub:SetPoint("TOPLEFT", d.root, "TOPLEFT", AS.TX + dx, -(AS.HEAD + AS.PAD + 17))
end

-- Cuenta atrás sobre un icono pequeño: 45 | 1:59 | 5m (se ignora el tiempo global de 1,5 s)
local function CdText(f, now)
  local fs = f.cdText
  if not fs then return end
  local r = 0
  if f:IsShown() and f.cs and f.cdur and f.cs > 0 and f.cdur > 1.6 then r = f.cs + f.cdur - now end
  if r <= 0 then fs:SetText(""); return end
  if r < 60 then fs:SetText(format("%d", math.ceil(r)))
  elseif r < 120 then fs:SetText(format("%d:%02d", math.floor(r / 60), math.floor(r % 60)))
  else fs:SetText(format("%dm", math.ceil(r / 60))) end
end

local function AssistBuild(d, root, m, q1, q2)
  if d.pan then return end
  local pan = MakeBox(root, { 0.055, 0.065, 0.14, 0.92 }, { 0.20, 0.22, 0.34, 1 })
  d.pan = pan

  local head = root:CreateFontString(nil, "OVERLAY")
  head:SetFont(FRIZ, 9, "OUTLINE"); head:SetText("PulseFlash")
  head:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
  head:SetPoint("TOP", root, "TOP", 0, -4)
  local line = root:CreateTexture(nil, "ARTWORK")
  line:SetTexture(WHITE); line:SetVertexColor(0.30, 0.32, 0.45, 0.7); line:SetHeight(1)
  line:SetPoint("TOPLEFT", root, "TOPLEFT", 5, -AS.HEAD)
  line:SetPoint("TOPRIGHT", root, "TOPRIGHT", -5, -AS.HEAD)
  pan.extra[#pan.extra + 1] = head
  pan.extra[#pan.extra + 1] = line

  d.pTitle = root:CreateFontString(nil, "OVERLAY")
  d.pTitle:SetFont(FRIZ, 12, "OUTLINE")
  d.pTitle:SetJustifyH("LEFT"); d.pTitle:SetJustifyV("TOP")
  d.pTitle:SetWidth(AS.W - AS.TX - AS.PAD); d.pTitle:SetHeight(15)
  pan.extra[#pan.extra + 1] = d.pTitle
  d.pSub = root:CreateFontString(nil, "OVERLAY")
  d.pSub:SetFont(FRIZ, 9, "")
  d.pSub:SetTextColor(0.72, 0.76, 0.88)
  d.pSub:SetJustifyH("LEFT"); d.pSub:SetJustifyV("TOP")
  d.pSub:SetWidth(AS.W - AS.TX - AS.PAD); d.pSub:SetHeight(11)
  pan.extra[#pan.extra + 1] = d.pSub
  PlaceTexts(d, 0)

  -- resplandor dorado y anillo de pulso sobre el icono principal
  m.aGlow = m.top:CreateTexture(nil, "ARTWORK")
  m.aGlow:SetTexture(MEDIA .. "glow_sq.tga"); m.aGlow:SetBlendMode("ADD")
  m.aGlow:SetVertexColor(1.00, 0.82, 0.10)
  m.aGlow:SetWidth(72); m.aGlow:SetHeight(72); m.aGlow:SetPoint("CENTER", m, "CENTER", 0, 0)
  m.aRing = m.top:CreateTexture(nil, "ARTWORK")
  m.aRing:SetTexture(MEDIA .. "pulse_ring.tga"); m.aRing:SetBlendMode("ADD")
  m.aRing:SetVertexColor(1.00, 0.88, 0.35)
  m.aRing:SetPoint("CENTER", m, "CENTER", 0, 0)
  m.aRing:Hide()

  -- cuenta atrás en los dos iconos pequeños
  d.qs = { q1, q2 }
  for _, f in ipairs(d.qs) do
    if not f.cdText then
      f.cdText = f.top:CreateFontString(nil, "OVERLAY")
      f.cdText:SetFont(ARIAL, 11, "OUTLINE")
      f.cdText:SetTextColor(1, 1, 1)
      f.cdText:SetPoint("BOTTOM", f, "BOTTOM", 0, 1)
    end
    f.cdText:SetText("")
    if not f.aFrame then                                  -- marco redondeado claro (tapa las esquinas del icono)
      f.aFrame = f.top:CreateTexture(nil, "ARTWORK")
      f.aFrame:SetTexture(MEDIA .. "ring_next.tga")
      f.aFrame:SetWidth(AS.SM + 2); f.aFrame:SetHeight(AS.SM + 2)
      f.aFrame:SetPoint("CENTER", f, "CENTER", 0, 0)
    end
  end

  function d.pulse()                                     -- anillo + destello + texto que entra
    d.pt = 0
    m.aRing:SetWidth(54); m.aRing:SetHeight(54); m.aRing:SetAlpha(0.9); m.aRing:Show()
  end

  function d.assistOn()
    pan:Show(); m.aGlow:Show(); m.aRing:Hide()
    for _, f in ipairs(d.qs) do f.aFrame:Show() end
    d.pt = nil; d.curMain = nil
    d.pdrv = d.pdrv or CreateFrame("Frame", nil, root)
    local T, acc = 0, 0
    d.pdrv:SetScript("OnUpdate", function(_, el)
      T = T + el
      local g = 0.72 + 0.28 * math.sin(T * 3.4)          -- el resplandor "respira"
      if d.pt then
        d.pt = d.pt + el
        local k = d.pt / 0.55
        if k >= 1 then
          d.pt = nil; m.aRing:Hide(); PlaceTexts(d, 0)
          d.pTitle:SetAlpha(1); d.pSub:SetAlpha(1)
        else
          local e = 1 - (1 - k) * (1 - k)
          local sz = 54 + 70 * e
          m.aRing:SetWidth(sz); m.aRing:SetHeight(sz); m.aRing:SetAlpha(0.9 * (1 - k))
          g = g + 0.8 * (1 - math.min(1, d.pt / 0.45))
          local ke = math.min(1, d.pt / 0.22); ke = 1 - (1 - ke) * (1 - ke)
          PlaceTexts(d, 10 * (1 - ke))
          d.pTitle:SetAlpha(0.15 + 0.85 * ke); d.pSub:SetAlpha(0.15 + 0.85 * ke)
        end
      end
      m.aGlow:SetAlpha(math.min(1, g))
      acc = acc + el
      if acc >= 0.1 then
        acc = 0
        if not d.sample then
          local now = GetTime()
          CdText(q1, now); CdText(q2, now)
        end
      end
    end)
  end

  function d.assistOff()
    pan:Hide()
    if d.pdrv then d.pdrv:SetScript("OnUpdate", nil) end
    m.aGlow:Hide(); m.aRing:Hide()
    d.pt, d.curMain, d.sample = nil, nil, nil
    d.pTitle:SetAlpha(1); d.pSub:SetAlpha(1)
    for _, f in ipairs(d.qs) do f.cdText:SetText(""); f.aFrame:Hide() end
    m.key:Show(); q1.key:Show(); q2.key:Show()
  end
end

STYLES.assistant = {
  name = "hs_assistant", desc = "hs_assistant_d",
  panel = true,           -- Core.lua llama a PF.HUDPanel (nombre de la habilidad y anillo al cambiar)
  layout = function(root, m, q1, q2, d)
    ResetSkin(m, q1, q2, d)
    local P, HD, BIG, SM = AS.PAD, AS.HEAD, AS.BIG, AS.SM
    Size(m, BIG); Size(q1, SM); Size(q2, SM)
    Place(m, "TOPLEFT", root, "TOPLEFT", P, -(HD + P))
    Place(q1, "BOTTOMLEFT", root, "BOTTOMLEFT", AS.TX, P)
    Place(q2, "BOTTOMLEFT", root, "BOTTOMLEFT", AS.TX + SM + 6, P)
    Fonts(m, 17, 12); Fonts(q1, 9); Fonts(q2, 9)
    m.key:ClearAllPoints(); m.key:SetPoint("CENTER", m, "CENTER", 0, 0)   -- tecla grande en el centro
    q1.key:Hide(); q2.key:Hide()                                          -- los pequeños muestran la cuenta atrás
    m:SetBackdropColor(0, 0, 0, 0.55); Border(m, DARK, 0)                 -- el borde lo da el resplandor
    Border(q1, DARK, 0); Border(q2, DARK, 0)                              -- el marco redondeado lo da ring_next.tga
    if d then
      AssistBuild(d, root, m, q1, q2)
      d.assistOn()
    end
    return AS.W, AS.H
  end,
}

-- Texto del panel: nombre de la habilidad principal (o aviso de objeto) y anillo al cambiar.
function PF.HUDPanel(d, main, wasShown)
  if not (d and d.pan and d.pan:IsShown()) then return end
  d.sample = nil
  if main == d.curMain then return end
  d.curMain = main
  local title, sub, alert = "", "", false
  if main then
    local id = main:match("^item:(%d+)$")
    if id then
      title, sub, alert = PF.T("hs_use"), GetItemInfo(tonumber(id)) or "", true
    else
      title = GetSpellInfo(main) or main
    end
  end
  d.pTitle:SetText(title); d.pSub:SetText(sub)
  if alert then d.pTitle:SetTextColor(GOLD[1], GOLD[2], GOLD[3]) else d.pTitle:SetTextColor(1, 1, 1) end
  if main and wasShown then d.pulse() end
end

-- Textos de muestra para la vista previa de la configuración (sin rotación real)
function PF.HUDPanelSample(d)
  if not (d and d.pan) then return end
  d.sample = true
  d.pTitle:SetText(PF.T("hs_sample")); d.pTitle:SetTextColor(1, 1, 1); d.pSub:SetText("")
  if d.qs then d.qs[1].cdText:SetText("1:59"); d.qs[2].cdText:SetText("5m") end
end

-- Anima el avance de la cola (lo llama Core.lua tras cambiar los iconos). p1..p3 = habilidades previas.
function PF.HUDSlide(decor, p1, p2, p3)
  if decor and decor.slide then decor.slide(p1, p2, p3) end
end

PF.HUD_STYLES = STYLES
PF.HUD_STYLE_ORDER = { "classic", "queue", "line", "serenity", "assistant" }

-- Coloca los tres iconos con el estilo `id` y dimensiona `root`. Devuelve ancho, alto.
function PF.HUDLayout(id, root, main, q1, q2, decor)
  local st = STYLES[id] or STYLES.classic
  if decor then decor.plate:Hide() end                   -- cada estilo lo muestra si lo necesita
  local w, h = st.layout(root, main, q1, q2, decor)
  root:SetWidth(w); root:SetHeight(h)
  if decor then decor.Sync(q1, q2) end
  return w, h
end
