-- PulseFlash: Mago (Arcano / Fuego / Escarcha) - 3.3.5a
--
-- Filosofía (igual que el resto de módulos): se recomienda, por orden, TODA mecánica de la clase
-- que falte o esté lista (procs, mantenimiento, habilidades de la rama); cuando todo está hecho,
-- el motor pulsa el RELLENO infinito. Lo que no se puede lanzar (maná, enfriamiento) se salta solo.
--
--   Arcano ...... Explosión de arcano apilada (Ráfaga arcana x4), Descarga de misiles con el proc,
--                 Ráfaga arcana de descarga si el maná aprieta, Poder arcano + Presencia mental.
--   Fuego ....... Bomba viviente siempre activa, Piroexplosión con Racha ardiente, Bola de fuego.
--   Escarcha .... Elemental de agua invocado, Dedos de escarcha (Congelación profunda + Lanza de
--                 hielo), Descarga de ígnea con Cerebro helado, Venas heladas, Frío glacial.
local CF = PulseFlash
-- Memoria: este archivo solo se carga para MAGE (en las demás clases se descarta al instante)
do local c = select(2, UnitClass("player")); if c and c ~= "MAGE" then return end end
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

-- ¿Ese hechizo está en enfriamiento (más de un GCD)?
local function OnCD(spell)
  if not spell then return false end
  local s, d = GetSpellCooldown(spell)
  return (s and s > 0 and d and d > 1.5) and true or false
end

local ARCANE_CONSERVE_MANA = 0.30      -- con 4 cargas y menos maná que esto: Ráfaga arcana (barata)

local function evaluate(c, add, N)
  local spec, mana = c.spec, c.manaPct

  -- 1) Procs
  Proc(add, N.HotStreak, N.Pyroblast)                         -- Racha ardiente: Piroexplosión instantánea
  Proc(add, N.MissileBarrage, N.ArcaneMissiles)               -- Descarga de misiles
  Proc(add, N.BrainFreeze, Known(N.FrostfireBolt) and N.FrostfireBolt or N.Fireball)

  -- Escarcha: Dedos de escarcha (Congelación profunda primero, luego Lanza de hielo)
  if Aura("player", N.FingersOfFrost) then
    add(N.DeepFreeze, 1)
    add(N.IceLance, 1)
  end

  -- 2) Mantenimiento
  -- Escarcha: el Elemental de agua es parte de la rotación (se vuelve a invocar si muere)
  if spec == 3 and Known(N.SummonWaterElemental) and not UnitExists("pet")
     and c.casting ~= N.SummonWaterElemental and not CF.Pending(N.SummonWaterElemental) then
    add(N.SummonWaterElemental, 1)
  end
  -- Bomba viviente: Fuego (y sin rama definida)
  if c.worth and (spec == 2 or spec == 0) then
    Dot(add, c, N.LivingBomb, Aura("target", N.LivingBomb, true, true))
  end

  -- 3) Rotación por rama
  if CF.db.aoe then                                           -- modo área (/pf aoe)
    if spec == 1 then add(N.ArcaneExplosion, 1)
    elseif spec == 2 then add(N.Flamestrike, 1)
    else add(N.Blizzard, 1) end
  end
  if spec == 1 then            -- Arcano
    local _, stacks = Aura("player", N.ArcaneBlast)
    if (stacks or 0) >= 4 and mana < ARCANE_CONSERVE_MANA and not c.burn then add(N.ArcaneBarrage, 1) end
    add(N.ArcaneBlast, 1)
  end

  -- Cooldowns ofensivos (cola): todos duran más de 1 min -> solo contra jefes (c.bigCD)
  if c.combat and c.bigCD then
    if spec == 1 then
      add(N.ArcanePower, 2)
      add(N.PresenceOfMind, 2)
    end
    if spec == 2 then add(N.Combustion, 2) end
    if spec == 3 then
      add(N.IcyVeins, 2)
      -- Frío glacial reinicia Venas heladas y Congelación profunda: solo cuando ambas esperan
      if OnCD(N.IcyVeins) and (not Known(N.DeepFreeze) or OnCD(N.DeepFreeze)) then
        add(N.ColdSnap, 2)
      end
    end
    add(N.MirrorImage, 2)
  end

  -- Interrupción / defensivos / utilidad (verde)
  if (UnitCastingInfo("target") or UnitChannelInfo("target"))
     and IsSpellInRange(N.Counterspell, "target") == 1 then
    add(N.Counterspell, 3)
  end
  if c.combat then
    if c.php < 0.20 then add(N.IceBlock, 3) end
    if mana < 0.20 then add(N.Evocation, 3) end
  end
end

-- Relleno infinito según la rama
local function filler(c, N)
  if c.spec == 1 then return First(N.ArcaneBlast, N.Fireball, N.Frostbolt) end
  if c.spec == 2 then return First(N.Fireball, N.Frostbolt) end
  return First(N.Frostbolt, N.Fireball)
end

CF.Register("MAGE", {
  ids = {
    Fireball = 133,       Frostbolt = 116,       ArcaneBlast = 30451,
    ArcaneMissiles = 5143, Pyroblast = 11366,    LivingBomb = 44457,
    FrostfireBolt = 44614, IceLance = 30455,     DeepFreeze = 44572,
    Combustion = 11129,   IcyVeins = 12472,      MirrorImage = 55342,
    ArcanePower = 12042,  Counterspell = 2139,   IceBlock = 45438,
    Evocation = 12051,    MoltenArmor = 30482,   MageArmor = 6117,
    IceArmor = 7302,      FrostArmor = 168,
    ArcaneBarrage = 44781, ArcaneExplosion = 1449, PresenceOfMind = 12043,
    ColdSnap = 11958,     SummonWaterElemental = 31687,
    Flamestrike = 2120,   Blizzard = 10,
    -- procs (buffs)
    HotStreak = 48108, MissileBarrage = 44401, FingersOfFrost = 44544, BrainFreeze = 57761,
  },
  multidot = { [0] = { "LivingBomb" }, [2] = { "LivingBomb" } },                         -- Fuego
  evaluate = evaluate,
  filler = filler,
})
