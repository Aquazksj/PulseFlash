--[[
  PulseFlash - Options.lua  (WoW 3.3.5a)

  Entrada de PulseFlash en  Menú del juego > Interfaz > AddOns  (InterfaceOptions_AddCategory), para
  encontrar el addon fácilmente. Al seleccionarla se abre SOLA la configuración completa del addon
  (la misma que abre el botón del minimapa o /pf config) y se cierra la ventana de Interfaz.
  El panel conserva un botón por si la configuración no llegara a abrirse.
]]
local PF = PulseFlash

local panel = CreateFrame("Frame", "PulseFlashOptionsPanel", UIParent)
panel.name = "PulseFlash"

local relabels = {}

local function Label(font, x, y, w)
  local fs = panel:CreateFontString(nil, "ARTWORK", font)
  fs:SetPoint("TOPLEFT", panel, "TOPLEFT", x, y)
  if w then fs:SetWidth(w) end
  fs:SetJustifyH("LEFT")
  return fs
end

local title = Label("GameFontNormalLarge", 16, -16)
title:SetText("PulseFlash")

local by = Label("GameFontHighlightSmall", 16, -42, 560)
relabels[#relabels + 1] = function()
  local author = GetAddOnMetadata and GetAddOnMetadata("PulseFlash", "Author") or "?"
  local ver = GetAddOnMetadata and GetAddOnMetadata("PulseFlash", "Version") or "?"
  by:SetText(PF.T("o_by", author, ver))
end

local desc = Label("GameFontHighlight", 16, -62, 560)
desc:SetHeight(48)
desc:SetJustifyV("TOP")
relabels[#relabels + 1] = function() desc:SetText(PF.T("o_desc")) end

local hint = Label("GameFontHighlightSmall", 16, -118, 560)
hint:SetHeight(32)
hint:SetJustifyV("TOP")
relabels[#relabels + 1] = function() hint:SetText(PF.T("o_hint")) end

local open = CreateFrame("Button", "PulseFlashOptOpen", panel, "UIPanelButtonTemplate")
open:SetPoint("TOPLEFT", panel, "TOPLEFT", 16, -160)
open:SetWidth(190); open:SetHeight(26)
relabels[#relabels + 1] = function() open:SetText(PF.T("o_open")) end

----------------------------------------------------------------------
-- Abrir la configuración completa
----------------------------------------------------------------------
local function OpenSettings()
  if InterfaceOptionsFrame and InterfaceOptionsFrame:IsShown() then HideUIPanel(InterfaceOptionsFrame) end
  if GameMenuFrame and GameMenuFrame:IsShown() then HideUIPanel(GameMenuFrame) end
  if PF.OpenConfig then PF.OpenConfig() end
end
open:SetScript("OnClick", OpenSettings)

-- Al mostrarse la entrada se abre la configuración. Se espera un fotograma: cerrar la ventana de
-- Interfaz en mitad de su propio OnShow da problemas.
local defer = CreateFrame("Frame")
defer:Hide()
defer:SetScript("OnUpdate", function(self)
  self:Hide()
  OpenSettings()
end)

local function Refresh()
  for i = 1, #relabels do relabels[i]() end
end

panel.refresh = Refresh
panel.okay = function() end
panel.cancel = function() end
panel.default = function() end
panel:SetScript("OnShow", function()
  -- Solo se abre la configuración si el usuario seleccionó la entrada en la ventana de Interfaz.
  -- Sin esta comprobación, cualquier cambio de visibilidad de UIParent (p. ej. mostrar u ocultar el
  -- mapa a pantalla completa) volvía a disparar OnShow y abría la configuración sola.
  if not (InterfaceOptionsFrame and InterfaceOptionsFrame:IsVisible() and panel:IsVisible()) then return end
  Refresh()
  defer:Show()
end)
panel:Hide()                      -- un marco nuevo nace visible: se oculta hasta que Interfaz lo muestre

if PF.OnLangChange then PF.OnLangChange(function() if panel:IsShown() then Refresh() end end) end

InterfaceOptions_AddCategory(panel)
