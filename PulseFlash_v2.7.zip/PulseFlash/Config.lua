--[[
  PulseFlash - Config.lua  (WoW 3.3.5a)
  Panel de configuración con el estilo de PulseBoss (fondo azul marino, lista lateral naranja,
  botones rojos con texto amarillo y títulos de sección de colores). Se abre con el botón del minimapa o con
  "/pf config". Todo se construye con frames y texturas básicas (sin plantillas de Blizzard
  ni librerías), y cada control lee / escribe directamente en el perfil activo
  (PF.db.hud, PF.db.fx, PF.db.sound), que Profiles.lua guarda por personaje y rama.

  SECCIONES (lista lateral)
    General ... escala, opacidad (combate / fuera), pulso, intensidad, modo del HUD, estilo
    Estilo del HUD .. elegir entre los diseños del HUD de daño (HudStyles.lua), con vista previa
    Buffos .... segundo HUD (solo buffos que faltan): activar, ver en combate, escala, opacidad
    Rotación .. (solo Pícaro / Druida) modo Normal o Máximo daño (prueba) y estado de la espera
    Combos .... (solo Pícaro / Druida) barra de combos: tamaño, separación, opacidad, color, cuándo verla
    Sonidos ... interruptor global y sonido de cada proc de la clase
    Funciones nuevas (BETA) ... predicción, snapshotting y eventos de jefe (DBM / BigWigs): apagadas por defecto
    Perfiles .. perfil activo (detección automática), Guardar / Cargar / Clonar
]]
local PF = PulseFlash

local floor, format, unpack = math.floor, format, unpack

----------------------------------------------------------------------
-- Estilo (igual que PulseBoss: azul marino, lista naranja, botones rojos, títulos de colores)
----------------------------------------------------------------------
local WHITE = "Interface\\Buttons\\WHITE8X8"
local FONT = "Fonts\\FRIZQT__.TTF"
local C = {
  bg     = { 0.040, 0.065, 0.130, 0.97 },   -- fondo azul marino
  line   = { 0.10, 0.16, 0.30, 1 },         -- bordes
  field  = { 0.075, 0.115, 0.210, 1 },      -- campo de texto / casilla
  accent = { 1.00, 0.82, 0.00, 1 },         -- amarillo (valores, tirador y relleno de los sliders)
  text   = { 1.00, 1.00, 1.00 },
  dim    = { 0.62, 0.66, 0.74 },
  green  = { 0.20, 1.00, 0.20 },
  orange = { 0.88, 0.60, 0.34 },            -- títulos de sección: naranja suave
  yellow = { 1.00, 0.82, 0.00 },
  title  = { 0.85, 0.85, 0.90 },
}
-- Tipos de botón: "red" (pestañas / opciones) y "orange" (lista lateral y listas emergentes)
local KIND = {
  red    = { bg = { 0.55, 0.06, 0.06, 1 }, hi = { 0.80, 0.12, 0.10, 1 }, on = { 0.92, 0.14, 0.12, 1 },
             border = { 0.30, 0.02, 0.02, 1 }, onBorder = { 1.00, 0.82, 0.00, 1 }, text = { 1.00, 0.82, 0.00 } },
  orange = { bg = { 0.34, 0.17, 0.09, 1 }, hi = { 0.45, 0.23, 0.12, 1 }, on = { 0.50, 0.26, 0.12, 1 },
             border = { 0.20, 0.10, 0.05, 1 }, onBorder = { 0.86, 0.62, 0.30, 1 }, text = { 0.92, 0.68, 0.38 } },
}
local W = 396                     -- ancho útil del contenido
local TAB_KEYS = {}                 -- claves de idioma de las secciones (se rellena al construir el panel)
local curTab = 1

local panel, tabs, pages = nil, {}, {}
local pageTitle, pageSub
local refreshers = {}             -- funciones que releen el perfil activo y actualizan los controles

local function Skin(f, bg, border)
  f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1,
                  insets = { left = 1, right = 1, top = 1, bottom = 1 } })
  f:SetBackdropColor(unpack(bg))
  f:SetBackdropBorderColor(unpack(border))
end

local relabels = {}              -- textos que dependen del idioma: se reescriben al cambiarlo

-- K("clave") -> función que devuelve el texto traducido (Text la vuelve a llamar al cambiar de idioma)
local function K(key) return function() return PF.T(key) end end

local function Text(parent, str, size, col, flags)
  local fs = parent:CreateFontString(nil, "OVERLAY")
  fs:SetFont(FONT, size or 11, flags or "")
  local c = col or C.text
  fs:SetTextColor(c[1], c[2], c[3])
  if type(str) == "function" then
    relabels[#relabels + 1] = function() fs:SetText(str()) end
    fs:SetText(str())
  else
    fs:SetText(str or "")
  end
  return fs
end

-- Título de sección de color (RESUMEN / ROL / MODOS...)
local function Header(parent, str, y, col)
  local h = Text(parent, str, 12, col, "OUTLINE")
  h:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y)
  return h
end

-- Botón plano; :SetActive(true) lo marca como seleccionado. kind = "red" (por defecto) | "orange"
local function Button(parent, label, w, h, onClick, kind)
  local k = KIND[kind or "red"]
  local b = CreateFrame("Button", nil, parent)
  b:SetWidth(w); b:SetHeight(h)
  b.k = k
  Skin(b, k.bg, k.border)
  b.text = Text(b, label, 11, k.text, "OUTLINE")
  b.text:SetPoint("CENTER", b, "CENTER", 0, 0)
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  b:SetScript("OnEnter", function(self)
    if not self.active then self:SetBackdropColor(unpack(self.k.hi)) end
  end)
  b:SetScript("OnLeave", function(self)
    self:SetBackdropColor(unpack(self.active and self.k.on or self.k.bg))
  end)
  b:SetScript("OnClick", function(self, mouse)
    if onClick then onClick(self, mouse) end
  end)
  function b:SetActive(on)
    self.active = on and true or false
    self:SetBackdropColor(unpack(self.active and self.k.on or self.k.bg))
    self:SetBackdropBorderColor(unpack(self.active and self.k.onBorder or self.k.border))
  end
  function b:SetLabel(t) self.text:SetText(t) end
  return b
end

-- Cierre: una "X" roja sin caja (como en PulseBoss)
local function CloseButton(parent, onClick)
  local b = CreateFrame("Button", nil, parent)
  b:SetWidth(24); b:SetHeight(24)
  b.text = Text(b, "X", 16, { 1.00, 0.25, 0.10 }, "OUTLINE")
  b.text:SetPoint("CENTER", b, "CENTER", 0, 0)
  b:SetScript("OnEnter", function(self) self.text:SetTextColor(1, 0.65, 0.2) end)
  b:SetScript("OnLeave", function(self) self.text:SetTextColor(1, 0.25, 0.10) end)
  b:SetScript("OnClick", function() onClick() end)
  return b
end

-- Slider horizontal propio. get() devuelve el valor actual; set(v) lo guarda; fmt(v) lo muestra.
local function Slider(parent, y, label, lo, hi, step, get, set, fmt)
  local holder = CreateFrame("Frame", nil, parent)
  holder:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y)
  holder:SetWidth(W); holder:SetHeight(34)

  local lbl = Text(holder, label, 11)
  lbl:SetPoint("TOPLEFT", holder, "TOPLEFT", 0, 0)
  local val = Text(holder, "", 11, C.accent, "OUTLINE")
  val:SetPoint("TOPRIGHT", holder, "TOPRIGHT", 0, 0)

  local s = CreateFrame("Slider", nil, holder)
  s:SetPoint("TOPLEFT", holder, "TOPLEFT", 0, -19)
  s:SetWidth(W); s:SetHeight(12)
  s:SetOrientation("HORIZONTAL")
  s:EnableMouse(true)
  s:EnableMouseWheel(true)
  s:SetMinMaxValues(lo, hi)
  s:SetValueStep(step)

  local track = s:CreateTexture(nil, "BACKGROUND")
  track:SetTexture(WHITE)
  track:SetVertexColor(0.13, 0.20, 0.36, 1)
  track:SetHeight(4)
  track:SetPoint("LEFT", s, "LEFT", 0, 0)
  track:SetPoint("RIGHT", s, "RIGHT", 0, 0)

  -- Relleno amarillo de la barra (desde la izquierda hasta el tirador)
  local fill = s:CreateTexture(nil, "BORDER")
  fill:SetTexture(WHITE)
  fill:SetVertexColor(C.accent[1], C.accent[2], C.accent[3], 1)
  fill:SetHeight(4)
  fill:SetPoint("LEFT", s, "LEFT", 0, 0)
  local function SetFill(v)
    local f = (hi > lo) and ((v - lo) / (hi - lo)) or 0
    if f < 0 then f = 0 elseif f > 1 then f = 1 end
    fill:SetWidth(4 + f * (W - 8))
  end

  s:SetThumbTexture(WHITE)
  local thumb = s:GetThumbTexture()
  thumb:SetVertexColor(C.accent[1], C.accent[2], C.accent[3], 1)
  thumb:SetWidth(8); thumb:SetHeight(14)

  local busy = false                       -- evita que la actualización por código dispare set()
  s:SetScript("OnValueChanged", function(self, v)
    if busy then return end
    v = floor(v / step + 0.5) * step
    if v < lo then v = lo elseif v > hi then v = hi end
    val:SetText(fmt(v))
    SetFill(v)
    set(v)
  end)
  s:SetScript("OnMouseWheel", function(self, delta)
    self:SetValue(self:GetValue() + delta * step)
  end)

  refreshers[#refreshers + 1] = function()
    busy = true
    local v = get()
    s:SetValue(v)
    val:SetText(fmt(v))
    SetFill(v)
    busy = false
  end
  return holder
end

local function Check(parent, y, label, get, set)
  local b = CreateFrame("Button", nil, parent)
  b:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y)
  b:SetWidth(W); b:SetHeight(20)
  local box = CreateFrame("Frame", nil, b)
  box:SetWidth(14); box:SetHeight(14)
  box:SetPoint("LEFT", b, "LEFT", 0, 0)
  Skin(box, C.field, KIND.red.border)
  local tick = box:CreateTexture(nil, "OVERLAY")
  tick:SetTexture(WHITE)
  tick:SetVertexColor(C.yellow[1], C.yellow[2], C.yellow[3], 1)
  tick:SetPoint("TOPLEFT", box, "TOPLEFT", 3, -3)
  tick:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", -3, 3)
  local t = Text(b, label, 11)
  t:SetPoint("LEFT", box, "RIGHT", 8, 0)
  local function refresh() if get() then tick:Show() else tick:Hide() end end
  b:SetScript("OnClick", function() set(not get()); refresh() end)
  refreshers[#refreshers + 1] = refresh
  return b
end

----------------------------------------------------------------------
-- Lista emergente (Cargar / Clonar): filas paginadas junto al panel
----------------------------------------------------------------------
local picker
local PER_PAGE = 8

local function BuildPicker()
  picker = CreateFrame("Frame", "PulseFlashPicker", panel)
  picker:SetWidth(300); picker:SetHeight(40 + PER_PAGE * 24 + 34)
  picker:SetPoint("TOPLEFT", panel, "TOPRIGHT", 6, 0)
  picker:SetFrameLevel(panel:GetFrameLevel() + 5)
  Skin(picker, C.bg, C.line)
  picker.title = Text(picker, "", 12, C.yellow, "OUTLINE")
  picker.title:SetPoint("TOPLEFT", picker, "TOPLEFT", 12, -12)
  picker.empty = Text(picker, K("p_empty"), 11, C.dim)
  picker.empty:SetPoint("TOPLEFT", picker, "TOPLEFT", 12, -44)
  picker.rows = {}
  for i = 1, PER_PAGE do
    local r = Button(picker, "", 284, 22, function(self, mouse)
      if self.item then picker.onPick(self.item, mouse) end
    end, "orange")
    r:SetPoint("TOPLEFT", picker, "TOPLEFT", 8, -34 - (i - 1) * 24)
    r.text:ClearAllPoints()
    r.text:SetPoint("LEFT", r, "LEFT", 8, 0)
    r.text:SetJustifyH("LEFT")
    r.text:SetWidth(270)
    picker.rows[i] = r
  end
  local close = CloseButton(picker, function() picker:Hide() end)
  close:SetPoint("TOPRIGHT", picker, "TOPRIGHT", -6, -6)
  picker.prev = Button(picker, "<", 24, 20, function() picker.page = picker.page - 1; picker:Render() end)
  picker.prev:SetPoint("BOTTOMLEFT", picker, "BOTTOMLEFT", 8, 8)
  picker.next = Button(picker, ">", 24, 20, function() picker.page = picker.page + 1; picker:Render() end)
  picker.next:SetPoint("BOTTOMRIGHT", picker, "BOTTOMRIGHT", -8, 8)
  picker.pageText = Text(picker, "", 10, C.dim)
  picker.pageText:SetPoint("BOTTOM", picker, "BOTTOM", 0, 12)

  function picker:Render()
    local n = #self.items
    local pages = math.max(1, math.ceil(n / PER_PAGE))
    if self.page > pages then self.page = pages elseif self.page < 1 then self.page = 1 end
    for i = 1, PER_PAGE do
      local it = self.items[(self.page - 1) * PER_PAGE + i]
      local r = self.rows[i]
      r.item = it
      if it then r:SetLabel(it.label); r:Show() else r:Hide() end
    end
    if n == 0 then self.empty:Show() else self.empty:Hide() end
    self.pageText:SetText(self.page .. " / " .. pages)
    if self.page > 1 then self.prev:Show() else self.prev:Hide() end
    if self.page < pages then self.next:Show() else self.next:Hide() end
  end
  picker:Hide()
end

-- items = { {label=, ...}, ... } | onPick(item, mouseButton)
local function OpenPicker(title, items, onPick)
  if not picker then BuildPicker() end
  picker.title:SetText(title)
  picker.items, picker.onPick, picker.page = items, onPick, 1
  picker:Render()
  picker:Show()
end

----------------------------------------------------------------------
-- Sección GENERAL
----------------------------------------------------------------------
local function BuildGeneral(page)
  local function pct(v) return format("%d%%", v) end
  local HALF, THIRD = (W - 6) / 2, (W - 12) / 3

  Header(page, K("g_look"), 0, C.orange)
  Slider(page, -20, K("g_scale"), 50, 200, 5,
    function() return floor(PF.db.hud.scale * 100 + 0.5) end,
    function(v) PF.db.hud.scale = v / 100; PF.HUDApplyPos() end, pct)

  Slider(page, -58, K("g_alphaCombat"), 10, 100, 5,
    function() return floor(PF.db.hud.alphaCombat * 100 + 0.5) end,
    function(v) PF.db.hud.alphaCombat = v / 100 end, pct)

  Slider(page, -96, K("g_alphaOOC"), 10, 100, 5,
    function() return floor(PF.db.hud.alphaOOC * 100 + 0.5) end,
    function(v) PF.db.hud.alphaOOC = v / 100 end, pct)

  Slider(page, -134, K("g_alphaChannel"), 10, 100, 5,
    function() return floor(PF.db.hud.alphaChannel * 100 + 0.5) end,
    function(v) PF.db.hud.alphaChannel = v / 100 end, pct)

  Header(page, K("g_flash"), -172, C.yellow)
  -- Velocidad del destello: periodo de un pulso completo, 0.10 s - 1.00 s (el slider va en ms)
  Slider(page, -192, K("g_period"), 100, 1000, 50,
    function() return floor(PF.db.fx.period * 1000 + 0.5) end,
    function(v) PF.db.fx.period = v / 1000 end,
    function(v) return format("%.2f s", v / 1000) end)

  Slider(page, -230, K("g_intensity"), 10, 100, 5,
    function() return floor(PF.db.fx.intensity * 100 + 0.5) end,
    function(v) PF.db.fx.intensity = v / 100 end, pct)

  -- Estilo del destello
  local STYLES = { { "glow", K("g_styleGlow") }, { "size", K("g_styleSize") } }
  local styleBtns = {}
  for i, st in ipairs(STYLES) do
    local b = Button(page, st[2], HALF, 24, function()
      PF.db.fx.style = st[1]
      PF.RefreshConfig()
    end)
    b:SetPoint("TOPLEFT", page, "TOPLEFT", (i - 1) * (HALF + 6), -268)
    styleBtns[st[1]] = b
  end

  -- Modo de activación del HUD
  Header(page, K("g_showHud"), -302, C.green)
  local MODES = { { "combat", K("g_modeCombat") }, { "target", K("g_modeTarget") }, { "always", K("g_modeAlways") } }
  local modeBtns = {}
  for i, m in ipairs(MODES) do
    local b = Button(page, m[2], THIRD, 24, function()
      PF.db.hud.mode = m[1]
      PF.RefreshConfig()
    end)
    b:SetPoint("TOPLEFT", page, "TOPLEFT", (i - 1) * (THIRD + 6), -322)
    modeBtns[m[1]] = b
  end

  -- Acciones rápidas (las mismas que el botón del minimapa)
  Header(page, K("g_actions"), -354, C.orange)
  local lockBtn = Button(page, "", HALF, 24, function() PF.ToggleHUDLock() end)
  lockBtn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -374)
  local testBtn = Button(page, "", HALF, 24, function() PF.ToggleHUDTest() end)
  testBtn:SetPoint("TOPLEFT", page, "TOPLEFT", HALF + 6, -374)

  local hint = Text(page, K("g_hint"), 10, C.dim)
  hint:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -402)
  hint:SetWidth(W); hint:SetJustifyH("LEFT")

  refreshers[#refreshers + 1] = function()
    for id, b in pairs(modeBtns) do b:SetActive(PF.db.hud.mode == id) end
    for id, b in pairs(styleBtns) do b:SetActive(PF.db.fx.style == id) end
    lockBtn:SetLabel(PF.db.hud.locked and PF.T("g_unlock") or PF.T("g_lock"))
    lockBtn:SetActive(not PF.db.hud.locked)
    testBtn:SetLabel(PF.hudTest and PF.T("previewOn") or PF.T("previewOff"))
    testBtn:SetActive(PF.hudTest)
  end
end

----------------------------------------------------------------------
-- Sección ESTILO DEL HUD: tres diseños para el HUD de daño (HudStyles.lua), con vista previa de cada uno
----------------------------------------------------------------------
local FALLBACK_SAMPLE = {
  "Interface\\Icons\\Ability_Warrior_Charge", "Interface\\Icons\\Spell_Fire_FlameBolt",
  "Interface\\Icons\\Spell_Holy_HolyBolt",
}

-- Tres texturas distintas del libro de hechizos del personaje (para las vistas previas)
local function SampleTextures()
  local t = {}
  for n = 1, 60 do
    local tex = GetSpellTexture(n, "spell")
    if tex then
      local dup = false
      for i = 1, #t do if t[i] == tex then dup = true end end
      if not dup then t[#t + 1] = tex end
    end
    if #t == 6 then break end
  end
  for i = #t + 1, 6 do t[i] = FALLBACK_SAMPLE[((i - 1) % 3) + 1] end
  return t
end

local function BuildHudStyle(page)
  Header(page, K("hs_head"), 0, C.orange)
  local cards = {}
  local CARD_H, GAP = 84, 6
  local sample = SampleTextures()
  local keys = { "1", "2", "3" }

  for i, id in ipairs(PF.HUD_STYLE_ORDER or {}) do
    local st = PF.HUD_STYLES[id]
    local card = CreateFrame("Button", nil, page)
    card:SetWidth(W); card:SetHeight(CARD_H)
    card:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -22 - (i - 1) * (CARD_H + GAP))
    Skin(card, C.field, C.line)
    card:SetScript("OnEnter", function(self)
      if not self.active then self:SetBackdropColor(0.10, 0.15, 0.27, 1) end
    end)
    card:SetScript("OnLeave", function(self)
      self:SetBackdropColor(unpack(self.active and { 0.12, 0.17, 0.31, 1 } or C.field))
    end)
    card:SetScript("OnClick", function()
      PF.db.hud.style = id
      if PF.HUDApplyStyle then PF.HUDApplyStyle() end
      PF.RefreshConfig()
    end)
    function card:SetActive(on)
      self.active = on and true or false
      if self.active then
        self:SetBackdropColor(0.12, 0.17, 0.31, 1)
        self:SetBackdropBorderColor(unpack(C.accent))
      else
        self:SetBackdropColor(unpack(C.field))
        self:SetBackdropBorderColor(unpack(C.line))
      end
    end

    -- Vista previa: los mismos iconos del HUD real, con el estilo aplicado
    local pv = CreateFrame("Frame", nil, card)
    pv:SetPoint("LEFT", card, "LEFT", 14, 0)
    pv:SetScale(0.8)
    local m, q1, q2 = PF.HUDMakeIcon(pv), PF.HUDMakeIcon(pv), PF.HUDMakeIcon(pv)
    local decor = PF.HUDMakeDecor(pv)
    local frames = { m, q1, q2 }
    for n, f in ipairs(frames) do
      f.icon:SetTexture(sample[n])
      f.key:SetText(keys[n])
      f:Show()
    end
    PF.HUDLayout(id, pv, m, q1, q2, decor)
    if st.panel and PF.HUDPanelSample then PF.HUDPanelSample(decor) end   -- textos de muestra del estilo Oracle

    local title = Text(card, K(st.name), 13, C.yellow, "OUTLINE")
    title:SetPoint("TOPLEFT", card, "TOPLEFT", 200, -16)
    local desc = Text(card, K(st.desc), 10, C.dim)
    desc:SetPoint("TOPLEFT", card, "TOPLEFT", 200, -36)
    desc:SetWidth(W - 200 - 10); desc:SetJustifyH("LEFT")
    cards[id] = card
  end

  local hint = Text(page, K("hs_hint"), 10, C.dim)
  hint:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -22 - #PF.HUD_STYLE_ORDER * (CARD_H + GAP) + 2)
  hint:SetWidth(W); hint:SetJustifyH("LEFT")

  refreshers[#refreshers + 1] = function()
    for id, c in pairs(cards) do c:SetActive((PF.db.hud.style or "classic") == id) end
  end
end

----------------------------------------------------------------------
-- Sección BETA: funciones experimentales (Beta.lua), apagadas por defecto
----------------------------------------------------------------------
local function BuildBeta(page)
  Header(page, K("beta_head"), 0, C.orange)
  local warn = Text(page, K("beta_warn"), 10, C.yellow)
  warn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -22)
  warn:SetWidth(W); warn:SetJustifyH("LEFT")

  local function Flag(key)
    return function() return PF.db.beta and PF.db.beta[key] and true or false end,
           function(v) if PF.Beta then PF.Beta.Set(key, v) end end
  end
  local g, st = Flag("on")
  Check(page, -74, K("beta_enable"), g, function(v)
    st(v)
    PF.Msg(PF.T(v and "beta_on" or "beta_off"))
  end)

  local y = -112
  for _, key in ipairs({ "predict", "latency", "snap", "boss" }) do
    local get, set = Flag(key)
    Check(page, y, K("beta_" .. key), get, set)
    local d = Text(page, K("beta_" .. key .. "_d"), 10, C.dim)
    d:SetPoint("TOPLEFT", page, "TOPLEFT", 22, y - 22)
    d:SetWidth(W - 22); d:SetJustifyH("LEFT")
    y = y - 80
  end
end

----------------------------------------------------------------------
-- Sección MULTIDOT (solo clases con DoTs): aviso de cambiar de objetivo para repartirlos
----------------------------------------------------------------------
local function BuildMultidot(page)
  Header(page, K("md_head"), 0, C.orange)
  Check(page, -22, K("md_enable"),
    function() return PF.db.multidot ~= false end,
    function(v) PF.Multidot_Set(v) end)
  Slider(page, -58, K("md_min"), 2, 6, 1,
    function() return tonumber(PF.db.multidotMin) or 3 end,
    function(v) PF.db.multidotMin = v end,
    function(v) return format("%d", v) end)
  local d = Text(page, K("md_desc"), 10, C.dim)
  d:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -110)
  d:SetWidth(W); d:SetJustifyH("LEFT")
end

----------------------------------------------------------------------
-- Sección BUFFOS: segundo HUD (solo buffos que te faltan)
----------------------------------------------------------------------
local function BuildBuffs(page)
  local function pct(v) return format("%d%%", v) end
  local HALF = (W - 6) / 2

  Header(page, K("b_title"), 0, C.orange)
  local onBtn = Button(page, "", HALF, 24, function()
    PF.db.bhud.enabled = not PF.db.bhud.enabled
    PF.RefreshConfig()
  end)
  onBtn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -20)
  local combatBtn = Button(page, "", HALF, 24, function()
    PF.db.bhud.combat = not PF.db.bhud.combat
    PF.RefreshConfig()
  end)
  combatBtn:SetPoint("TOPLEFT", page, "TOPLEFT", HALF + 6, -20)
  local pulseBtn = Button(page, "", HALF, 24, function()
    PF.db.bhud.pulse = not PF.db.bhud.pulse
    PF.RefreshConfig()
  end)
  pulseBtn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -50)
  local glowBtn = Button(page, "", HALF, 24, function()
    PF.db.bhud.glow = not PF.db.bhud.glow
    PF.RefreshConfig()
  end)
  glowBtn:SetPoint("TOPLEFT", page, "TOPLEFT", HALF + 6, -50)

  Header(page, K("g_look"), -88, C.yellow)
  Slider(page, -108, K("g_scale"), 50, 200, 5,
    function() return floor(PF.db.bhud.scale * 100 + 0.5) end,
    function(v) PF.db.bhud.scale = v / 100; PF.BuffHUDApplyPos() end, pct)
  Slider(page, -146, K("g_alphaCombat"), 10, 100, 5,
    function() return floor(PF.db.bhud.alphaCombat * 100 + 0.5) end,
    function(v) PF.db.bhud.alphaCombat = v / 100 end, pct)
  Slider(page, -184, K("g_alphaOOC"), 10, 100, 5,
    function() return floor(PF.db.bhud.alphaOOC * 100 + 0.5) end,
    function(v) PF.db.bhud.alphaOOC = v / 100 end, pct)

  -- Acciones rápidas de ESTE HUD (independientes de las del HUD de daño)
  Header(page, K("g_actions"), -228, C.green)
  local lockBtn = Button(page, "", HALF, 24, function() PF.ToggleBuffHUDLock() end)
  lockBtn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -248)
  local testBtn = Button(page, "", HALF, 24, function() PF.ToggleBuffHUDTest() end)
  testBtn:SetPoint("TOPLEFT", page, "TOPLEFT", HALF + 6, -248)

  local hint = Text(page, K("b_hint"), 10, C.dim)
  hint:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -284)
  hint:SetWidth(W); hint:SetJustifyH("LEFT")

  refreshers[#refreshers + 1] = function()
    local B = PF.db.bhud
    onBtn:SetLabel(PF.T("b_enable") .. ": " .. (B.enabled and "ON" or "OFF"))
    onBtn:SetActive(B.enabled)
    combatBtn:SetLabel(PF.T("b_combat") .. ": " .. (B.combat and "ON" or "OFF"))
    combatBtn:SetActive(B.combat)
    pulseBtn:SetLabel(PF.T("b_pulse") .. ": " .. (B.pulse and "ON" or "OFF"))
    pulseBtn:SetActive(B.pulse)
    glowBtn:SetLabel(PF.T("b_glow") .. ": " .. (B.glow and "ON" or "OFF"))
    glowBtn:SetActive(B.glow)
    lockBtn:SetLabel(B.locked and PF.T("g_unlock") or PF.T("g_lock"))
    lockBtn:SetActive(not B.locked)
    testBtn:SetLabel(PF.bhudTest and PF.T("previewOn") or PF.T("previewOff"))
    testBtn:SetActive(PF.bhudTest)
  end
end

----------------------------------------------------------------------
-- Sección ROTACIÓN (solo Pícaro / Druida): Normal o Máximo daño (prueba)
----------------------------------------------------------------------
local function BuildRotation(page)
  local _, class = UnitClass("player")
  local HALF = (W - 6) / 2
  local HI = "|cffffd100"

  Header(page, K("r_title"), 0, C.orange)
  local btns = {}
  local MODES = { { false, K("r_normal") }, { true, K("r_max") } }
  for i, m in ipairs(MODES) do
    local b = Button(page, m[2], HALF, 26, function()
      PF.db.rot.max = m[1]
      PF.RefreshConfig()
    end)
    b:SetPoint("TOPLEFT", page, "TOPLEFT", (i - 1) * (HALF + 6), -22)
    btns[i] = b
  end

  Header(page, K("r_what"), -66, C.yellow)
  local function desc()
    return PF.T(class == "ROGUE" and "r_descRogue" or "r_descDruid")
  end
  local d = Text(page, desc, 10, C.dim)
  d:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -86)
  d:SetWidth(W); d:SetJustifyH("LEFT")

  Header(page, K("r_live"), -296, C.green)
  local live = Text(page, "", 11)
  live:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -316)
  live:SetWidth(W); live:SetJustifyH("LEFT")
  local acc = 0
  page:SetScript("OnUpdate", function(_, dt)
    acc = acc + dt
    if acc < 0.1 then return end
    acc = 0
    if not (PF.db and PF.db.rot and PF.db.rot.max) then
      live:SetText(PF.T("r_liveNormal"))
    elseif PF.holdSpell then
      live:SetText(PF.T("r_liveHold", PF.holdSpell, PF.holdEta or 0))
    else
      live:SetText(PF.T("r_liveNone"))
    end
  end)

  local note = Text(page, K("r_note"), 10, C.dim)
  note:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -350)
  note:SetWidth(W); note:SetJustifyH("LEFT")

  refreshers[#refreshers + 1] = function()
    local on = PF.db.rot.max and true or false
    btns[1]:SetActive(not on)
    btns[2]:SetActive(on)
  end
end

----------------------------------------------------------------------
-- Sección COMBOS (solo Pícaro / Druida): barra de puntos de combo personalizable
----------------------------------------------------------------------
local function BuildCombos(page)
  local function pct(v) return format("%d%%", v) end
  local function px(v) return format("%d px", v) end
  local HALF, THIRD = (W - 6) / 2, (W - 12) / 3
  local FIVE = (W - 20) / 5

  Header(page, K("cb_title"), 0, C.orange)
  Check(page, -20, K("cb_enable"),
    function() return PF.db.combo.enabled end,
    function(v) PF.db.combo.enabled = v end)

  Slider(page, -46, K("cb_scale"), 50, 250, 5,
    function() return floor(PF.db.combo.scale * 100 + 0.5) end,
    function(v) PF.db.combo.scale = v / 100; PF.ComboBarApply() end, pct)
  Slider(page, -82, K("cb_w"), 10, 60, 1,
    function() return floor(PF.db.combo.w + 0.5) end,
    function(v) PF.db.combo.w = v; PF.ComboBarApply() end, px)
  Slider(page, -118, K("cb_h"), 6, 40, 1,
    function() return floor(PF.db.combo.h + 0.5) end,
    function(v) PF.db.combo.h = v; PF.ComboBarApply() end, px)
  Slider(page, -154, K("cb_gap"), 0, 12, 1,
    function() return floor(PF.db.combo.gap + 0.5) end,
    function(v) PF.db.combo.gap = v; PF.ComboBarApply() end, px)
  Slider(page, -190, K("cb_alpha"), 10, 100, 5,
    function() return floor(PF.db.combo.alpha * 100 + 0.5) end,
    function(v) PF.db.combo.alpha = v / 100 end, pct)

  Header(page, K("cb_color"), -234, C.yellow)
  local palBtns = {}
  for i, pal in ipairs(PF.COMBO_PALETTE_LIST) do
    local b = Button(page, K("pal_" .. pal[1]), FIVE, 24, function()
      PF.db.combo.palette = pal[1]
      PF.RefreshConfig()
    end)
    b:SetPoint("TOPLEFT", page, "TOPLEFT", (i - 1) * (FIVE + 5), -254)
    palBtns[pal[1]] = b
  end

  Header(page, K("cb_showHdr"), -288, C.green)
  local SHOWS = { { "always", K("cb_always") }, { "target", K("cb_target") }, { "points", K("cb_points") } }
  local showBtns = {}
  for i, sh in ipairs(SHOWS) do
    local b = Button(page, sh[2], THIRD, 24, function()
      PF.db.combo.show = sh[1]
      PF.RefreshConfig()
    end)
    b:SetPoint("TOPLEFT", page, "TOPLEFT", (i - 1) * (THIRD + 6), -308)
    showBtns[sh[1]] = b
  end

  Check(page, -340, K("cb_number"),
    function() return PF.db.combo.number end,
    function(v) PF.db.combo.number = v end)

  local lockBtn = Button(page, "", HALF, 24, function() PF.ToggleComboLock() end)
  lockBtn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -368)
  local testBtn = Button(page, "", HALF, 24, function() PF.ToggleComboTest() end)
  testBtn:SetPoint("TOPLEFT", page, "TOPLEFT", HALF + 6, -368)

  refreshers[#refreshers + 1] = function()
    for id, b in pairs(palBtns) do b:SetActive(PF.db.combo.palette == id) end
    for id, b in pairs(showBtns) do b:SetActive(PF.db.combo.show == id) end
    lockBtn:SetLabel(PF.db.combo.locked and PF.T("cb_move") or PF.T("cb_fix"))
    lockBtn:SetActive(not PF.db.combo.locked)
    testBtn:SetLabel(PF.comboTest and PF.T("previewOn") or PF.T("previewOff"))
    testBtn:SetActive(PF.comboTest)
  end
end

----------------------------------------------------------------------
-- Sección SONIDOS
----------------------------------------------------------------------
local function BuildSounds(page)
  Header(page, K("s_title"), 0, C.orange)
  Check(page, -22, K("s_enable"),
    function() return PF.db.sound.enabled end,
    function(v) PF.db.sound.enabled = v end)

  local hint = Text(page, K("s_hint"), 10, C.dim)
  hint:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -50)

  if #PF.procList == 0 then
    local none = Text(page, K("s_none"), 11, C.dim)
    none:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -80)
    return
  end

  Header(page, K("s_each"), -74, C.yellow)
  for i, proc in ipairs(PF.procList) do
    local y = -98 - (i - 1) * 30
    local name = Text(page, proc.name, 11)
    name:SetPoint("TOPLEFT", page, "TOPLEFT", 0, y - 6)
    name:SetWidth(170); name:SetJustifyH("LEFT")

    local sb = Button(page, "", 146, 22, function(self, mouse)
      local cur = PF.GetProcSound(proc)
      local nxt = PF.SoundCycle(cur, (mouse == "RightButton") and -1 or 1)
      PF.SetProcSound(proc, nxt)
      PF.PlaySoundEntry(nxt)                  -- vista previa al cambiar
      PF.RefreshConfig()
    end)
    sb:SetPoint("TOPLEFT", page, "TOPLEFT", 176, y)

    local pb = Button(page, K("s_test"), 68, 22, function()
      PF.PlaySoundEntry(PF.GetProcSound(proc))
    end)
    pb:SetPoint("TOPLEFT", page, "TOPLEFT", W - 68, y)

    refreshers[#refreshers + 1] = function()
      local id = PF.GetProcSound(proc)
      sb:SetLabel(PF.SoundName(id))
      sb:SetActive(id ~= "none")
    end
  end
end

----------------------------------------------------------------------
-- Sección PERFILES
----------------------------------------------------------------------
local function BuildProfiles(page)
  local THIRD = (W - 12) / 3

  Header(page, K("p_char"), 0, C.orange)
  local info1 = Text(page, "", 11); info1:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -20)
  local info2 = Text(page, "", 11); info2:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -38)
  local info3 = Text(page, "", 11); info3:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -56)

  refreshers[#refreshers + 1] = function()
    local group, _, spec = PF.GetSpecInfo()
    local _, class = UnitClass("player")
    local cname = (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[class]) or class or "?"
    info1:SetText(PF.T("p_info1", PF.GetCharKey()))
    info2:SetText(PF.T("p_info2", cname))
    info3:SetText(PF.T("p_info3", group, PF.GroupLabel(group), spec))
  end

  Header(page, K("p_saved"), -92, C.yellow)
  local l = Text(page, K("p_name"), 11, C.dim)
  l:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -114)
  local eb = CreateFrame("EditBox", nil, page)
  eb:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -132)
  eb:SetWidth(W); eb:SetHeight(24)
  Skin(eb, C.field, C.line)
  eb:SetFont(FONT, 11)
  eb:SetTextColor(C.text[1], C.text[2], C.text[3])
  eb:SetTextInsets(8, 8, 0, 0)
  eb:SetAutoFocus(false)
  eb:SetMaxLetters(24)
  eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  eb:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

  -- Guardar: crea un perfil con nombre a partir de la configuración actual
  local save = Button(page, K("p_save"), THIRD, 24, function()
    local name = strtrim(eb:GetText() or "")
    if name == "" then name = format("%s R%d", UnitName("player") or "?", PF.activeGroup or 1) end
    PF.SavePreset(name)
    eb:SetText("")
    eb:ClearFocus()
  end)
  save:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -166)

  -- Cargar: aplica un perfil guardado (clic derecho en la lista = eliminar)
  local load = Button(page, K("p_load"), THIRD, 24, function()
    local items = {}
    for _, name in ipairs(PF.ListPresets()) do items[#items + 1] = { label = name, name = name } end
    OpenPicker(PF.T("p_loadTitle"), items, function(it, mouse)
      if mouse == "RightButton" then
        PF.DeletePreset(it.name)
        local left = {}
        for _, n in ipairs(PF.ListPresets()) do left[#left + 1] = { label = n, name = n } end
        picker.items = left
        picker:Render()
      else
        PF.LoadPreset(it.name)
        picker:Hide()
      end
    end)
  end)
  load:SetPoint("TOPLEFT", page, "TOPLEFT", THIRD + 6, -166)

  -- Clonar: copia la configuración de otro personaje / rama de la cuenta
  local clone = Button(page, K("p_clone"), THIRD, 24, function()
    local items = {}
    for _, p in ipairs(PF.ListProfiles()) do
      items[#items + 1] = { label = p.label, key = p.key, group = p.group }
    end
    OpenPicker(PF.T("p_cloneTitle"), items, function(it)
      PF.CloneProfile(it.key, it.group)
      picker:Hide()
    end)
  end)
  clone:SetPoint("TOPLEFT", page, "TOPLEFT", (THIRD + 6) * 2, -166)

  Header(page, K("p_helpHdr"), -210, C.green)
  local help = Text(page, K("p_help"), 10, C.dim)
  help:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -230)
  help:SetWidth(W); help:SetJustifyH("LEFT")
end

----------------------------------------------------------------------
-- Panel principal
----------------------------------------------------------------------
local function SelectTab(i)
  for k, pg in ipairs(pages) do
    if k == i then pg:Show() else pg:Hide() end
    tabs[k]:SetActive(k == i)
    tabs[k]:SetLabel((k == i and "[-] " or "[+] ") .. PF.T(TAB_KEYS[k]))
  end
  curTab = i
  if pageTitle then pageTitle:SetText(PF.T(TAB_KEYS[i])) end
  if picker then picker:Hide() end
end

local function BuildPanel()
  if panel then return end
  panel = CreateFrame("Frame", "PulseFlashConfig", UIParent)
  panel:SetWidth(620); panel:SetHeight(504)
  panel:SetPoint("CENTER", UIParent, "CENTER", 0, 20)
  panel:SetFrameStrata("DIALOG")
  panel:SetClampedToScreen(true)
  panel:SetMovable(true)
  panel:EnableMouse(true)
  panel:RegisterForDrag("LeftButton")
  panel:SetScript("OnDragStart", function(self) self:StartMoving() end)
  panel:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
  Skin(panel, C.bg, C.line)
  tinsert(UISpecialFrames, "PulseFlashConfig")        -- Esc cierra el panel

  -- Cabecera: "PulseFlash" en verde + " - Configuración"
  local title = Text(panel, "PulseFlash", 15, C.green, "OUTLINE")
  title:SetPoint("TOPLEFT", panel, "TOPLEFT", 18, -16)
  local titleRest = Text(panel, K("c_title"), 15, C.title, "OUTLINE")
  titleRest:SetPoint("LEFT", title, "RIGHT", 6, 0)
  local close = CloseButton(panel, function() panel:Hide() end)
  close:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -12, -12)

  -- Firma: nombre del addon y autor, abajo a la izquierda bajo la lista de secciones
  local sigName = Text(panel, "PulseFlash", 14, C.green, "OUTLINE")
  sigName:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 18, 32)
  local sigAuthor = Text(panel, "by Aquazksj", 11, C.dim)
  sigAuthor:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 18, 16)

  -- Secciones: Rotación y Combos solo existen para el Pícaro y el Druida
  local _, class = UnitClass("player")
  local sections = { { "tab_general", BuildGeneral }, { "tab_hudstyle", BuildHudStyle, 22 + #(PF.HUD_STYLE_ORDER or {}) * 90 + 34 }, { "tab_buffs", BuildBuffs } }
  if class == "ROGUE" or class == "DRUID" then
    sections[#sections + 1] = { "tab_rotation", BuildRotation }
    sections[#sections + 1] = { "tab_combos", BuildCombos }
  end
  if PF.Multidot_Supported and PF.Multidot_Supported() then
    sections[#sections + 1] = { "tab_multidot", BuildMultidot }
  end
  sections[#sections + 1] = { "tab_sounds", BuildSounds }
  sections[#sections + 1] = { "tab_beta", BuildBeta }
  sections[#sections + 1] = { "tab_profiles", BuildProfiles }
  for i, sec in ipairs(sections) do TAB_KEYS[i] = sec[1] end

  -- Selector de idioma (arriba a la derecha): ES / EN, común a toda la cuenta
  local langBtns = {}
  for i, code in ipairs(PF.LANGS) do
    local lb = Button(panel, string.upper(code), 30, 20, function()
      PF.SetLang(code)
    end)
    lb:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -44 - (#PF.LANGS - i) * 34, -14)
    langBtns[code] = lb
  end
  refreshers[#refreshers + 1] = function()
    local cur = PF.GetLang()
    for code, lb in pairs(langBtns) do lb:SetActive(code == cur) end
  end

  -- Lista lateral (naranja): una entrada por sección
  for i, key in ipairs(TAB_KEYS) do
    tabs[i] = Button(panel, "[+] " .. PF.T(key), 170, 38, function() SelectTab(i) end, "orange")
    tabs[i]:SetPoint("TOPLEFT", panel, "TOPLEFT", 14, -56 - (i - 1) * 42)
    tabs[i].text:ClearAllPoints()
    tabs[i].text:SetPoint("LEFT", tabs[i], "LEFT", 14, 0)
    tabs[i].text:SetJustifyH("LEFT")
  end

  -- Título de la sección (amarillo) + personaje / rama / especialización (gris)
  pageTitle = Text(panel, "", 13, C.yellow, "OUTLINE")
  pageTitle:SetPoint("TOPLEFT", panel, "TOPLEFT", 206, -58)
  pageSub = Text(panel, "", 10, C.dim)
  pageSub:SetPoint("LEFT", pageTitle, "RIGHT", 8, 0)
  refreshers[#refreshers + 1] = function()
    local group, _, spec = PF.GetSpecInfo()
    pageSub:SetText(PF.T("p_sub", PF.GetCharKey(), group, spec))
  end

  -- Páginas
  for i, sec in ipairs(sections) do
    local build, contentH = sec[2], sec[3]
    if contentH and contentH > 400 then
      -- Página más alta que la ventana: zona con desplazamiento vertical (rueda del ratón o barra)
      local wrap = CreateFrame("Frame", nil, panel)
      wrap:SetPoint("TOPLEFT", panel, "TOPLEFT", 206, -88)
      wrap:SetWidth(W + 16); wrap:SetHeight(400)
      local sf = CreateFrame("ScrollFrame", nil, wrap)
      sf:SetPoint("TOPLEFT", wrap, "TOPLEFT", 0, 0)
      sf:SetWidth(W); sf:SetHeight(400)
      local pg = CreateFrame("Frame", nil, sf)
      pg:SetWidth(W); pg:SetHeight(contentH)
      sf:SetScrollChild(pg)
      local sb = CreateFrame("Slider", nil, wrap)
      sb:SetOrientation("VERTICAL")
      sb:SetPoint("TOPRIGHT", wrap, "TOPRIGHT", -2, 0)
      sb:SetWidth(8); sb:SetHeight(400)
      local track = sb:CreateTexture(nil, "BACKGROUND")
      track:SetAllPoints(sb); track:SetTexture(WHITE); track:SetVertexColor(0.08, 0.09, 0.14, 0.9)
      local thumb = sb:CreateTexture(nil, "OVERLAY")
      thumb:SetTexture(WHITE); thumb:SetVertexColor(0.86, 0.62, 0.30, 0.95)
      thumb:SetWidth(8); thumb:SetHeight(48)
      sb:SetThumbTexture(thumb)
      sb:SetMinMaxValues(0, contentH - 400); sb:SetValueStep(1); sb:SetValue(0)
      sb:SetScript("OnValueChanged", function(_, v) sf:SetVerticalScroll(v) end)
      wrap:EnableMouseWheel(true)
      wrap:SetScript("OnMouseWheel", function(_, delta) sb:SetValue(sb:GetValue() - delta * 45) end)
      pages[i] = wrap
      build(pg)
    else
      local pg = CreateFrame("Frame", nil, panel)
      pg:SetPoint("TOPLEFT", panel, "TOPLEFT", 206, -88)
      pg:SetWidth(W); pg:SetHeight(400)
      pages[i] = pg
      build(pg)
    end
  end

  -- Cambio de idioma: reescribe los textos ya creados y vuelve a pintar los controles
  PF.OnLangChange(function()
    for _, fn in ipairs(relabels) do fn() end
    if picker then picker:Hide() end
    SelectTab(curTab)
    PF.RefreshConfig()
  end)

  panel:SetScript("OnShow", function() PF.RefreshConfig() end)
  panel:SetScript("OnHide", function() if picker then picker:Hide() end end)
  SelectTab(1)
  panel:Hide()
end

----------------------------------------------------------------------
-- API pública
----------------------------------------------------------------------
-- Relee el perfil activo y actualiza todos los controles (no hace nada si el panel no existe)
function PF.RefreshConfig()
  if not panel or not PF.db then return end
  for _, fn in ipairs(refreshers) do fn() end
end

-- Abre el panel (sin alternar): lo usa la entrada de Interfaz > AddOns (Options.lua)
function PF.OpenConfig()
  if not PF.db then PF.Msg(PF.T("noModule")); return end
  BuildPanel()
  panel:Show()
end

function PF.ToggleConfig()
  if not PF.db then PF.Msg(PF.T("noModule")); return end
  BuildPanel()
  if panel:IsShown() then panel:Hide() else panel:Show() end
end

-- Al cambiar de rama / cargar / clonar un perfil, el panel se actualiza solo
PF.RegisterProfileCallback(function() PF.RefreshConfig() end)
