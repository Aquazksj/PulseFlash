--[[
  PulseFlash - Boss.lua  (WoW 3.3.5a)

  DETECCIÓN DE JEFES independiente del nivel. El motor usa c.boss para gastar cooldowns largos, trinkets,
  fases de jefe (apertura / ejecución / remate) y para no avisar de multidot.

  Antes solo contaban el nivel "??", la clasificación de jefe de mundo y los élites 2+ niveles por encima
  del tuyo, así que NO se detectaban los jefes de mazmorras inferiores a tu nivel. Ahora el objetivo es
  jefe si cumple ALGUNA de estas condiciones:
    1. Nivel "??" (calavera) o clasificación de jefe (raids, jefes de mundo, la mayoría de jefes de
       mazmorra heroica).
    2. Es uno de tus marcos de jefe del juego (boss1 .. boss4).
    3. Lo marcaste a mano con /pf boss (se desmarca igual).
    4. Es un élite (o élite raro) 2+ niveles por encima de ti (como antes).
    5. Es un élite con MUCHA más vida que lo normal, fuera de las bandas (en banda la morralla élite ya
       tiene vidas enormes: allí solo valen las condiciones 1 a 3):
         - vida >= BOSS_VS_PLAYER veces tu vida máxima, o
         - vida >= BOSS_VS_ELITE veces la vida "normal" de los élites que ya has visto en esta zona
           (referencia: el cuartil inferior de las vidas vistas; se aprende solo, la morralla de la
           mazmorra sirve de referencia para el jefe y un jefe visto antes no la estropea).
           Limitación: un jefe que sea el PRIMER élite que ves en una zona nueva no se distingue
           hasta haber visto algo de morralla (por eso existe /pf boss).
  Con esto cuentan los jefes de cualquier mazmorra, aunque vayas muy por encima de su nivel.
]]
local PF = PulseFlash

local BOSS_VS_PLAYER = 5.5      -- vida del élite / tu vida máxima
local BOSS_VS_ELITE = 3.0       -- vida del élite / vida "normal" de los élites vistos en la zona
local MAX_SEEN = 24             -- vidas distintas recordadas por zona

local eliteSeen, eliteSet, eliteZone = {}, {}, nil
local forcedGUID = nil

-- /pf boss: marca (o desmarca) el objetivo actual como jefe. Devuelve true si queda marcado.
function PF.ToggleBossMark()
  if not (UnitExists("target") and UnitCanAttack("player", "target")) then return nil end
  local g = UnitGUID("target")
  if forcedGUID == g then forcedGUID = nil; return false end
  forcedGUID = g
  return true
end

-- ¿El objetivo actual es un jefe? level = tu nivel; tl / tc = nivel y clasificación del objetivo.
function PF.DetectBoss(level, tl, tc)
  if tl == -1 or tc == "worldboss" then return true end
  if forcedGUID and UnitGUID("target") == forcedGUID then return true end
  for i = 1, 4 do
    local u = "boss" .. i
    if UnitExists(u) and UnitIsUnit("target", u) then return true end
  end
  if tc ~= "elite" and tc ~= "rareelite" then return false end
  if tc == "elite" and tl >= level + 2 then return true end

  -- zona nueva: se olvida la referencia de élites
  local zone = GetRealZoneText and GetRealZoneText() or ""
  if zone ~= eliteZone then
    eliteZone = zone
    for i = #eliteSeen, 1, -1 do eliteSeen[i] = nil end
    for k in pairs(eliteSet) do eliteSet[k] = nil end
  end

  local _, kind = IsInInstance()
  if kind == "raid" then return false end              -- en banda solo rango / calavera / marco de jefe
  local hm, pm = UnitHealthMax("target"), UnitHealthMax("player")
  if not hm or hm <= 0 or not pm or pm <= 0 then return false end
  if hm >= pm * BOSS_VS_PLAYER then return true end
  -- referencia: cuartil inferior de las vidas de élite vistas (con pocas muestras, la menor)
  local n = #eliteSeen
  if n > 0 then
    local ref = eliteSeen[math.floor(n / 4) + 1]
    if hm >= ref * BOSS_VS_ELITE then return true end
  end
  if not eliteSet[hm] then                               -- élite normal: se recuerda su vida
    eliteSet[hm] = true
    eliteSeen[#eliteSeen + 1] = hm
    table.sort(eliteSeen)
    if #eliteSeen > MAX_SEEN then
      local drop = table.remove(eliteSeen)
      eliteSet[drop] = nil
    end
  end
  return false
end
