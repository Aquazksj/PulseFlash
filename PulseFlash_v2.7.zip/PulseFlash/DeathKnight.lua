-- PulseFlash: Caballero de la Muerte (Escarcha / Profano / Sangre DPS) - 3.3.5a
-- (el DK empieza en el nivel 55; las runas y el poder rúnico los controla IsUsableSpell)
local CF = PulseFlash
-- Memoria: este archivo solo se carga para DEATHKNIGHT (en las demás clases se descarta al instante)
do local c = select(2, UnitClass("player")); if c and c ~= "DEATHKNIGHT" then return end end
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

-- MODO TANQUE (/pf tank): solo lo que importa para mantener amenaza y enfermedades.
--   1. Golpe letal si necesitas curarte (vida baja)   2. Golpe con runa (solo tras esquivar / parar)
--   3. Toque helado y Golpe de peste (enfermedades)   4. Pestilencia para esparcir y renovar
--   5. Golpe letal de nuevo si estás por debajo del umbral moderado. Sin relleno ni cooldowns.
local TANK_HEAL_URGENT = 0.45      -- Golpe letal antes que nada
local TANK_HEAL = 0.75             -- Golpe letal después de lo demás
local PESTI_REFRESH = 4            -- renueva con Pestilencia si a una enfermedad le quedan <= 4 s (glifo)
local PESTI_SPREAD = 8             -- en modo área (/pf aoe): vuelve a esparcir si quedan <= 8 s

-- ¿Llevas el Glifo de enfermedad? (con él Pestilencia renueva las enfermedades). Se compara el
-- nombre del glifo en inglés y en español.
local glyphAt, glyphVal = 0, false
local function HasDiseaseGlyph()
  local now = GetTime()
  if now - glyphAt < 5 then return glyphVal end
  glyphAt, glyphVal = now, false
  if GetNumGlyphSockets and GetGlyphSocketInfo then
    for i = 1, GetNumGlyphSockets() do
      local enabled, _, spellID = GetGlyphSocketInfo(i)
      if enabled and spellID then
        local n = GetSpellInfo(spellID)
        n = n and n:lower()
        if n and (n:find("disease", 1, true) or n:find("enfermedad", 1, true)) then glyphVal = true; break end
      end
    end
  end
  return glyphVal
end

-- MASCOTA DEL PROFANO: sin necrófago activo (nunca invocado, muerto o expirado) se recomienda
-- Levantar muerto con prioridad 1. Se respeta el aviso de mascota (/pf mascota). Si el hechizo
-- no se puede lanzar (en cooldown o sin Polvo de cadáver / sin Maestro de necrófagos), IsUsableSpell
-- lo deja fuera y la rotación sigue con normalidad sin bloquearse.
local function PetMissing()
  return not UnitExists("pet") or UnitIsDead("pet")
end

-- RUNAS Y PODER RÚNICO
--   Runes() cuenta las runas listas por tipo (GetRuneType: 1 sangre, 2 profana, 3 escarcha, 4 muerte).
--   Se usa para: no gastar Potenciar arma rúnica con runas disponibles y vigilar el desborde.
--   Poder rúnico: Escarcha gasta Golpe de escarcha al llegar a RP_CAP_FROST; Profano gasta Death Coil al
--   llegar a RP_CAP_UNHOLY, salvo que se esté ahorrando para la Gárgola (60 de poder; Death Coil cuesta 40).
local RUNE_READY_TOL = 0.3          -- una runa a menos de esto de recargarse cuenta como lista
local RP_CAP_FROST = 80
local RP_CAP_UNHOLY = 85
local DEATHCOIL_COST = 40
local GARGOYLE_COST = 60
local GARGOYLE_POOL_T = 8           -- empieza a ahorrar poder rúnico cuando a la Gárgola le quedan <= 8 s

local function Runes()
  if not GetRuneCooldown then return 0, 0, 0, 0, false end
  local b, u, f, d = 0, 0, 0, 0
  local now = GetTime()
  for i = 1, 6 do
    local start, dur, ready = GetRuneCooldown(i)
    if ready or not start or not dur or dur <= 0 or (start + dur - now) <= RUNE_READY_TOL then
      local t = GetRuneType and GetRuneType(i) or 0
      if t == 4 then d = d + 1 elseif t == 1 then b = b + 1
      elseif t == 2 then u = u + 1 elseif t == 3 then f = f + 1 end
    end
  end
  return b, u, f, d, true
end

-- Segundos que le quedan al cooldown de un hechizo (0 si está listo)
local function CDLeft(spell)
  local s, d = GetSpellCooldown(spell)
  if not s or s == 0 or not d then return 0 end
  local left = s + d - GetTime()
  return left > 0 and left or 0
end

local gargoylePool = false          -- ahorrando poder rúnico para la Gárgola (lo lee también el relleno)

local function tankEvaluate(c, add, N)
  local ft = Aura("target", N.FrostFever, true, true)
  local bp = Aura("target", N.BloodPlague, true, true)

  if c.php < TANK_HEAL_URGENT then add(N.DeathStrike, 1) end        -- curación urgente
  add(N.RuneStrike, 1)                                               -- Golpe con runa (si es usable)

  -- Pestilencia: con ambas enfermedades puestas, renueva (glifo) o esparce (modo área)
  if ft and bp then
    local left = math.min(ft, bp)
    if HasDiseaseGlyph() and left <= PESTI_REFRESH then add(N.Pestilence, 1)
    elseif CF.db.aoe and left <= PESTI_SPREAD then add(N.Pestilence, 1) end
  end
  -- Enfermedades: Toque helado (Fiebre helada) y Golpe de peste (Peste de sangre)
  Dot(add, c, N.IcyTouch, ft)
  Dot(add, c, N.PlagueStrike, bp)

  if c.php < TANK_HEAL then add(N.DeathStrike, 1) end               -- curación moderada
end

local function evaluate(c, add, N)
  if CF.db.dkTank then return tankEvaluate(c, add, N) end
  local spec = c.spec

  -- 0) Mascota (Profano): sin necrófago activo, levantarlo
  if spec == 3 and CF.db.pet ~= false and PetMissing()
     and not (UnitInVehicle and UnitInVehicle("player")) then
    local rd = N.RaiseDead
    if rd and Known(rd) and not CF.IsCasting(rd) and not CF.Pending(rd) then add(rd, 1) end
  end

  local rb, ru, rf, rd, runesKnown = Runes()
  local ready = rb + ru + rf + rd
  gargoylePool = false

  -- 1) Procs
  Proc(add, N.KillingMachine, Known(N.Obliterate) and N.Obliterate or N.FrostStrike)
  Proc(add, N.Rime, N.HowlingBlast)                           -- Rime (Niebla helada)

  -- 2) Mantenimiento de enfermedades
  if c.worth then
    Dot(add, c, N.IcyTouch, Aura("target", N.FrostFever, true, true))
    Dot(add, c, N.PlagueStrike, Aura("target", N.BloodPlague, true, true))
  end

  -- 2b) Gárgola (Profano): contra jefes y justo después de las enfermedades. Solo es ejecutable con
  --     60 de poder rúnico y sin cooldown; mientras se acerca su cooldown se ahorra poder rúnico.
  if spec == 3 and c.combat and c.bigCD and Known(N.SummonGargoyle) then
    add(N.SummonGargoyle, 1)
    gargoylePool = CDLeft(N.SummonGargoyle) <= GARGOYLE_POOL_T
  end

  -- 2c) Desborde de poder rúnico: se gasta antes de llegar al tope (no se pierde nada)
  if spec == 3 then
    if c.runic >= (gargoylePool and 100 or RP_CAP_UNHOLY) then add(N.DeathCoil, 1) end
  elseif spec == 2 then
    if c.runic >= RP_CAP_FROST then add(N.FrostStrike, 1) end
  end

  -- Modo área (/pf aoe): Muerte y descomposición, Brote de sangre, Aullido de sangre
  if CF.db.aoe then
    add(N.DeathAndDecay, 1)
    if c.worth and Aura("target", N.FrostFever, true, true) and Aura("target", N.BloodPlague, true, true) then
      add(N.BloodBoil, 1)
    end
    if spec == 2 then add(N.HowlingBlast, 1) end
  end

  -- 3) Rotación por rama (lo que no sea ejecutable por runas/poder rúnico se salta)
  if spec == 2 then            -- Escarcha
    add(N.Obliterate, 1)
    add(N.BloodStrike, 1)
    add(N.HowlingBlast, 1)
    add(N.FrostStrike, 1)
    add(N.DeathCoil, 1)
    if c.combat then add(N.UnbreakableArmor, 2) end        -- 1 min: se puede usar siempre
  elseif spec == 3 then        -- Profano
    add(N.ScourgeStrike, 1)
    add(N.BloodStrike, 1)
    -- Death Coil con las runas en enfriamiento; ahorrando para la Gárgola solo si sobra poder
    if not gargoylePool or (c.runic - DEATHCOIL_COST) >= GARGOYLE_COST then add(N.DeathCoil, 1) end
  elseif spec == 1 then        -- Sangre DPS
    add(N.HeartStrike, 1)
    add(N.BloodStrike, 1)
    add(N.DeathStrike, 1)
    add(N.DeathCoil, 1)
    if c.combat and c.bigCD then add(N.DancingRuneWeapon, 2) end
  else                         -- sin especialización
    add(N.ScourgeStrike, 1)
    add(N.Obliterate, 1)
    add(N.BloodStrike, 1)
    add(N.DeathCoil, 1)
  end
  -- Potenciar arma rúnica: solo contra jefes y con TODAS las runas en enfriamiento (no se desperdicia)
  if c.combat and c.bigCD and (not runesKnown or ready == 0) then add(N.EmpowerRuneWeapon, 2) end

  -- Interrupción / defensivos (verde)
  if UnitCastingInfo("target") or UnitChannelInfo("target") then
    if IsSpellInRange(N.MindFreeze, "target") == 1 then add(N.MindFreeze, 3)
    elseif IsSpellInRange(N.Strangulate, "target") == 1 then add(N.Strangulate, 3) end
  end
  if c.combat then
    if c.php < 0.40 then add(N.IceboundFortitude, 3) end
    if c.php < 0.50 then add(N.AntiMagicShell, 3) end
  end
end

-- Relleno infinito según la rama
local function filler(c, N)
  if CF.db.dkTank then return nil end                  -- modo tanque: sin relleno, solo lo indicado
  if c.spec == 2 then return First(N.FrostStrike, N.DeathCoil, N.BloodStrike) end
  if c.spec == 3 then
    if gargoylePool and (c.runic - DEATHCOIL_COST) < GARGOYLE_COST then      -- ahorrando para la Gárgola
      return First(N.ScourgeStrike, N.BloodStrike, N.DeathCoil)
    end
    return First(N.DeathCoil, N.ScourgeStrike, N.BloodStrike)
  end
  if c.spec == 1 then return First(N.HeartStrike, N.BloodStrike, N.DeathCoil) end
  return First(N.BloodStrike, N.DeathCoil)
end

CF.Register("DEATHKNIGHT", {
  ids = {
    IcyTouch = 45477,      PlagueStrike = 45462,    BloodStrike = 45902,
    DeathCoil = 47541,     Obliterate = 49020,      FrostStrike = 49143,
    HowlingBlast = 49184,  ScourgeStrike = 55090,   DeathStrike = 49998,
    HeartStrike = 55050,   UnbreakableArmor = 51271, EmpowerRuneWeapon = 47568,
    SummonGargoyle = 49206, DancingRuneWeapon = 49028,
    MindFreeze = 47528,    Strangulate = 47476,     IceboundFortitude = 48792,
    AntiMagicShell = 48707, DeathAndDecay = 49938, BloodBoil = 48721,
    BloodPresence = 48266, UnholyPresence = 48265, HornOfWinter = 57330,
    Pestilence = 50842,    RuneStrike = 56815,
    RaiseDead = 46584,
    -- debuffs de enfermedad y procs (buffs)
    FrostFever = 55095, BloodPlague = 55078, KillingMachine = 51124, Rime = 59052,
  },
  evaluate = evaluate,
  filler = filler,
})
