--[[
  PulseFlash - Locale.lua  (WoW 3.3.5a)
  Textos de la interfaz en Español (es) e Inglés (en) / UI texts in Spanish and English.

  * PF.T("clave", ...)  devuelve el texto en el idioma activo (con string.format si hay argumentos).
  * El idioma se guarda en PulseFlashDB.lang ("es" | "en") y es común a toda la cuenta.
  * Se cambia desde el menú (General > Idioma / Language) o con  /pf lang es | en.
  * Si el jugador no ha elegido idioma se usa PF.DEFAULT_LANG (esta versión del addon: ver abajo).
  * Los nombres de hechizos, talentos y objetos NO se traducen aquí: los da el cliente del juego.
  * Para añadir un texto: crea la misma clave en las dos tablas (ES y EN).
]]
PulseFlash = PulseFlash or {}
local PF = PulseFlash

-- Idioma por defecto de esta versión del addon ("es" = versión en español, "en" = versión en inglés)
PF.DEFAULT_LANG = "en"

PF.LANGS = { "es", "en" }
PF.LANG_NAMES = { es = "Español", en = "English" }
PF.langCallbacks = {}      -- funciones que se llaman al cambiar de idioma (refrescan textos ya creados)

local S = { es = {}, en = {} }
local ES, EN = S.es, S.en

function PF.GetLang()
  local db = PulseFlashDB
  local l = db and db.lang
  if l ~= "es" and l ~= "en" then l = PF.DEFAULT_LANG end
  return l
end

function PF.T(key, ...)
  local s = S[PF.GetLang()][key] or ES[key] or EN[key] or key
  if select("#", ...) > 0 then return format(s, ...) end
  return s
end

-- Devuelve la versión del idioma activo de una tabla { es = "...", en = "..." }
function PF.LT(t)
  if type(t) ~= "table" then return t end
  return t[PF.GetLang()] or t.es or t.en
end

function PF.SetLang(l)
  if l ~= "es" and l ~= "en" then return false end
  if PulseFlashDB then PulseFlashDB.lang = l end
  for _, fn in ipairs(PF.langCallbacks) do pcall(fn) end
  return true
end

function PF.OnLangChange(fn)
  PF.langCallbacks[#PF.langCallbacks + 1] = fn
end

----------------------------------------------------------------------
-- Estados comunes
----------------------------------------------------------------------
ES.ON_M   = "|cff00ff00activado|r";    EN.ON_M   = "|cff00ff00enabled|r"
ES.OFF_M  = "|cffff4040desactivado|r"; EN.OFF_M  = "|cffff4040disabled|r"
ES.ON_F   = "|cff00ff00activada|r";    EN.ON_F   = "|cff00ff00enabled|r"
ES.OFF_F  = "|cffff4040desactivada|r"; EN.OFF_F  = "|cffff4040disabled|r"
ES.on     = "on";                      EN.on     = "on"
ES.off    = "off";                     EN.off    = "off"

----------------------------------------------------------------------
-- Mensajes de chat / avisos (Core.lua)
----------------------------------------------------------------------
ES.noModule      = "no hay módulo para tu clase."
EN.noModule      = "there is no module for your class."
ES.enabled       = "activado"
EN.enabled       = "enabled"
ES.disabled      = "desactivado"
EN.disabled      = "disabled"
ES.profileNotLoaded = "tu perfil aún no está cargado."
EN.profileNotLoaded = "your profile is not loaded yet."
ES.modeOnly      = "el modo máximo daño solo existe para el Pícaro y el Druida feral."
EN.modeOnly      = "max damage mode only exists for Rogue and Feral Druid."
ES.modeUsage     = "uso: /pf modo normal | max"
EN.modeUsage     = "usage: /pf mode normal | max"
ES.modeIs        = "Modo de rotación: %s"
EN.modeIs        = "Rotation mode: %s"
ES.MODE_MAX      = "|cffffd100MÁXIMO DAÑO (prueba)|r"
EN.MODE_MAX      = "|cffffd100MAX DAMAGE (test)|r"
ES.MODE_NORMAL   = "|cff00ff00NORMAL|r"
EN.MODE_NORMAL   = "|cff00ff00NORMAL|r"
ES.comboOnly     = "la barra de combos solo existe para el Pícaro y el Druida."
EN.comboOnly     = "the combo bar only exists for Rogue and Druid."
ES.t_aoe         = "Modo AoE"
EN.t_aoe         = "AoE mode"
ES.t_poison      = "Aviso de venenos"
EN.t_poison      = "Poison reminder"
ES.t_stone       = "Piedra de hechizo (Brujo)"
EN.t_stone       = "Spellstone (Warlock)"
ES.t_hud         = "HUD flotante"
EN.t_hud         = "Floating HUD"
ES.t_alerts      = "Capa roja (defensivos / interrupciones)"
EN.t_alerts      = "Red layer (defensives / interrupts)"
ES.t_pet         = "Avisos de mascota"
EN.t_pet         = "Pet alerts"
ES.t_totem       = "Aviso de tótems (Chamán)"
EN.t_totem       = "Totem alert (Shaman)"
ES.t_range       = "Opacidad por rango (0.35 fuera de alcance)"
EN.t_range       = "Range opacity (0.35 when out of range)"
ES.t_racial      = "Avisos de raciales (azul defensivo / naranja ofensivo)"
EN.t_racial      = "Racial alerts (blue defensive / orange offensive)"
ES.upd_age       = "|cffffd100PulseFlash %s|r lleva %d días desde su publicación: revisa si hay una versión nueva en %s";  EN.upd_age = "|cffffd100PulseFlash %s|r was released %d days ago: check for a newer version at %s"
ES.cdsBoss       = "Cooldowns de más de 1 min y trinkets: solo contra |cffffd100jefes|r"
EN.cdsBoss       = "Cooldowns over 1 min and trinkets: |cffffd100boss|r targets only"
ES.cdsAlways     = "Cooldowns de más de 1 min y trinkets: |cffffd100siempre|r (cualquier objetivo)"
EN.cdsAlways     = "Cooldowns over 1 min and trinkets: |cffffd100always|r (any target)"
ES.g_alphaChannel = "Opacidad al canalizar";  EN.g_alphaChannel = "Opacity while channeling"
ES.phase_opener  = "APERTURA";  EN.phase_opener = "OPENER"
ES.phase_burn    = "EJECUCIÓN"; EN.phase_burn   = "BURN PHASE"
ES.phase_final   = "REMATE";    EN.phase_final  = "FINISH"
ES.t_roles       = "Asesor de sanaciones";  EN.t_roles = "Heal advisor"
ES.tankOnly      = "el modo tanque solo existe para el Caballero de la Muerte.";  EN.tankOnly = "Tank mode only exists for Death Knight."
ES.tankOn        = "|cffff8000MODO TANQUE ACTIVADO|r: enfermedades (Toque helado, Golpe de peste), Pestilencia, Golpe con runa y Golpe letal para curarte."
EN.tankOn        = "|cffff8000TANK MODE ENABLED|r: diseases (Icy Touch, Plague Strike), Pestilence, Rune Strike and Death Strike to heal."
ES.tankOff       = "|cff00ff00MODO TANQUE DESACTIVADO|r: rotación normal de tu rama."
EN.tankOff       = "|cff00ff00TANK MODE DISABLED|r: normal rotation for your spec."
ES.tankLogin     = "|cffff8000Modo tanque ACTIVO|r (Caballero de la Muerte). /pf tank para volver a la rotación normal."
EN.tankLogin     = "|cffff8000Tank mode ACTIVE|r (Death Knight). Use /pf tank to go back to the normal rotation."
ES.role_healer   = "Rol de |cffffd100sanador|r detectado: el HUD recomienda sanaciones según la vida del objetivo y del grupo (/pf roles lo apaga)."
EN.role_healer   = "|cffffd100Healer|r role detected: the HUD recommends heals based on target and group health (/pf roles turns this off)."
ES.upd_curse     = "También en CurseForge: %s";  EN.upd_curse = "Also on CurseForge: %s"
ES.upd_chat      = "|cffffd100¡Nueva versión disponible!|r Tienes %s, última: %s. Descarga: %s";  EN.upd_chat = "|cffffd100New version available!|r You have %s, latest: %s. Download: %s"
ES.upd_version   = "versión instalada: %s";       EN.upd_version = "installed version: %s"
ES.upd_unpub     = "esta es una compilación de pruebas (sin publicar): no anuncia su versión a otros jugadores.";  EN.upd_unpub = "this is a test build (not published): it does not announce its version to other players."
ES.upd_latest    = "no se ha detectado ninguna versión más nueva."; EN.upd_latest = "no newer version detected."
ES.t_bhud        = "HUD de buffos"
EN.t_bhud        = "Buff HUD"
ES.noConfig      = "no se encontró Config.lua."
EN.noConfig      = "Config.lua was not found."
ES.scaleSet      = "escala del HUD: %.2f"
EN.scaleSet      = "HUD scale: %.2f"
ES.scaleUsage    = "uso: /pf scale %.1f - %.1f  (actual: %.2f)"
EN.scaleUsage    = "usage: /pf scale %.1f - %.1f  (current: %.2f)"
ES.hudReset      = "HUD: posición y escala restauradas"
EN.hudReset      = "HUD: position and scale restored"
ES.iccOnly       = "el modo ICC/Banda solo existe para el Brujo."
EN.iccOnly       = "ICC/Raid mode only exists for Warlock."
ES.iccOn         = "|cffff8000MODO ICC/BANDA ACTIVADO|r: |cffffd100%s|r sustituye a |cffffd100%s|r en la prioridad principal."
EN.iccOn         = "|cffff8000ICC/RAID MODE ENABLED|r: |cffffd100%s|r replaces |cffffd100%s|r in the main priority."
ES.iccUnknown    = "aún no conoces %s: mientras tanto se mantiene %s."
EN.iccUnknown    = "you don't know %s yet: %s is kept in the meantime."
ES.iccOff        = "|cff00ff00MODO ESTÁNDAR ACTIVADO|r: rotación normal con |cffffd100%s|r."
EN.iccOff        = "|cff00ff00STANDARD MODE ENABLED|r: normal rotation with |cffffd100%s|r."
ES.iccLogin      = "|cffff8000Modo ICC/Banda ACTIVO|r (Maldición de apocalipsis). /pf icc para volver al modo estándar."
EN.iccLogin      = "|cffff8000ICC/Raid mode ACTIVE|r (Curse of Doom). Use /pf icc to go back to standard mode."
ES.posUsage      = "uso: /pf posicion pantalla | chat | ambos | off"
EN.posUsage      = "usage: /pf position screen | chat | both | off"
ES.posLabel_screen = "solo pantalla";    EN.posLabel_screen = "screen only"
ES.posLabel_chat   = "solo chat";        EN.posLabel_chat   = "chat only"
ES.posLabel_both   = "pantalla + chat";  EN.posLabel_both   = "screen + chat"
ES.posLabel_off    = "desactivado";      EN.posLabel_off    = "disabled"
ES.posIs         = "Aviso de posición (habilidades que exigen estar detrás): %s"
EN.posIs         = "Position alert (abilities that require being behind the target): %s"
ES.posNoClass    = "tu clase no tiene habilidades posicionales; la opción queda guardada pero no se usará."
EN.posNoClass    = "your class has no positional abilities; the option is saved but will not be used."
ES.posText       = "¡COLÓCATE DETRÁS DEL OBJETIVO!"
EN.posText       = "GET BEHIND THE TARGET!"
ES.posChat       = "(esa habilidad exige estar a la espalda del objetivo)"
EN.posChat       = "(that ability requires you to be behind the target)"
ES.numIs         = "número en: %s"
EN.numIs         = "number at: %s"
ES.numCenter     = "el centro";  EN.numCenter = "the center"
ES.numCorner     = "la esquina"; EN.numCorner = "the corner"
ES.langIs        = "Idioma: %s"
EN.langIs        = "Language: %s"
ES.langUsage     = "uso: /pf lang es | en"
EN.langUsage     = "usage: /pf lang es | en"
ES.noModuleClass = "sin módulo para tu clase (%s): el addon queda inactivo."
EN.noModuleClass = "no module for your class (%s): the addon stays inactive."
ES.welcome       = "|cffffd100[PulseFlash]|r by Aquazksj: ¡Bienvenido, %s! Módulo de %s cargado y listo para usar. (use /pf)"
EN.welcome       = "|cffffd100[PulseFlash]|r by Aquazksj: Welcome, %s! %s module loaded and ready to use. (type /pf)"
ES.error         = "|cffff4040error:|r %s"
EN.error         = "|cffff4040error:|r %s"

-- HUD
ES.hudUnlocked   = "HUD de daño |cffffd100desbloqueado|r: arrástralo con el ratón. Clic derecho en el minimapa (o /pf lock) para fijarlo."
EN.hudUnlocked   = "Damage HUD |cffffd100unlocked|r: drag it with the mouse. Right-click the minimap button (or /pf lock) to lock it."
ES.hudLocked     = "HUD de daño |cff00ff00bloqueado|r en x=%d, y=%d"
EN.hudLocked     = "Damage HUD |cff00ff00locked|r at x=%d, y=%d"
ES.hudPreview    = "Vista previa del HUD de daño: %s"
EN.hudPreview    = "Damage HUD preview: %s"
ES.bhudDrag      = "|cff40d9ffPulseFlash|r - HUD de buffos: arrastra para mover  (/pf lock para fijar)"
EN.bhudDrag      = "|cff40d9ffPulseFlash|r - Buff HUD: drag to move  (/pf lock to lock)"
ES.hudDrag       = "|cffffd100PulseFlash|r - arrastra para mover  (/pf lock para fijar)"
EN.hudDrag       = "|cffffd100PulseFlash|r - drag to move  (/pf lock to lock)"

-- Comando de ayuda y depuración
ES.t_multidot     = "Multidot";  EN.t_multidot = "Multidot"
ES.md_only        = "el multidot solo existe para clases con DoTs (Brujo, Sacerdote de Sombras, Druida, Mago, Cazador, Chamán y Guerrero de Armas)."
EN.md_only        = "Multidot only exists for classes with DoTs (Warlock, Shadow Priest, Druid, Mage, Hunter, Shaman and Arms Warrior)."
ES.md_msg         = "|cff59d9ffMULTIDOT:|r cambia de objetivo (%d sin DoT) - %s: %s"
EN.md_msg         = "|cff59d9ffMULTIDOT:|r switch target (%d without DoT) - %s: %s"
ES.tab_multidot   = "Multidot";  EN.tab_multidot = "Multidot"
ES.md_head        = "MULTIDOT AUTOMÁTICO";  EN.md_head = "AUTOMATIC MULTIDOT"
ES.md_enable      = "Recomendar cambiar de objetivo para repartir DoTs"
EN.md_enable      = "Recommend switching target to spread DoTs"
ES.md_min         = "Enemigos mínimos en el pull";  EN.md_min = "Minimum enemies in the pull"
ES.md_desc        = "El addon detecta solo la pelea contra varios enemigos y, cuando tu objetivo ya tiene todos tus DoTs, te avisa bajo el HUD de que cambies de objetivo (Tab) al enemigo que no los tiene. No se muestra contra jefes, ni con menos enemigos de los indicados, ni con enemigos casi muertos o inmunes. Desactívalo si prefieres todo el daño al objetivo único."
EN.md_desc        = "The addon detects fights against several enemies on its own and, once your target has all your DoTs, shows a prompt under the HUD to switch target (Tab) to an enemy that lacks them. It is not shown against bosses, with fewer enemies than set, or for almost-dead or immune enemies. Turn it off if you prefer full single-target damage."
ES.o_desc         = "Rotación estricta por prioridades con un HUD de daño de 3 iconos, HUD de buffos, avisos, sanadores, tanque del Caballero de la Muerte, multidot automático y perfiles por personaje y rama."
EN.o_desc         = "Strict priority rotation with a 3-icon damage HUD, buff HUD, alerts, healers, Death Knight tank mode, automatic multidot and per-character, per-spec profiles."
ES.o_open         = "Abrir configuración";  EN.o_open = "Open settings"
ES.o_hint         = "Al abrir esta entrada se abre sola la configuración completa de PulseFlash. Si no se abre, usa el botón."
EN.o_hint         = "Opening this entry opens the full PulseFlash settings by itself. If it does not open, use the button."
ES.o_by           = "Autor: %s  -  versión %s";  EN.o_by = "Author: %s  -  version %s"
ES.boss_on        = "objetivo marcado como JEFE (se aplican cooldowns y fases de jefe)."
EN.boss_on        = "target marked as BOSS (cooldowns and boss phases apply)."
ES.boss_off       = "marca de jefe quitada del objetivo."
EN.boss_off       = "boss mark removed from the target."
ES.boss_none      = "no tienes un objetivo hostil que marcar como jefe."
EN.boss_none      = "you have no hostile target to mark as boss."
ES.tab_hudstyle   = "Estilo del HUD";  EN.tab_hudstyle = "HUD style"
ES.hs_head        = "ESTILO DEL HUD DE DAÑO";  EN.hs_head = "DAMAGE HUD STYLE"
ES.hs_classic     = "Origin";  EN.hs_classic = "Origin"
ES.hs_classic_d   = "Tres iconos iguales en fila: ahora, siguiente y utilidad. El diseño de siempre."
EN.hs_classic_d   = "Three equal icons in a row: now, next and utility. The original look."
ES.hs_queue       = "Apex";  EN.hs_queue = "Apex"
ES.hs_queue_d     = "Un icono grande para lo que toca ahora y dos pequeños apilados con lo que viene después. Muy compacto, con bordes de color por prioridad."
EN.hs_queue_d     = "One large icon for what to press now and two small stacked ones for what comes next. Very compact, with priority-colored borders."
ES.hs_line        = "Cascade";  EN.hs_line = "Cascade"
ES.hs_line_d      = "Franja oscura con el icono actual destacado y los siguientes en pequeño, unidos por flechas: ahora > siguiente > después."
EN.hs_line_d      = "Dark strip with the current icon highlighted and the next ones smaller, joined by arrows: now > next > after."
ES.hs_serenity    = "Serenity";  EN.hs_serenity = "Serenity"
ES.hs_serenity_d  = "Marco redondeado claro con sombra oscura. Tres iconos para ahora, siguiente y utilidad; al usar la prioridad 1 la cola se desliza suavemente hacia el siguiente icono."
EN.hs_serenity_d  = "Light rounded frame with a dark shadow. Three icons for now, next and utility; when you use priority 1 the queue slides smoothly to the next icon."
ES.hs_assistant   = "Oracle";  EN.hs_assistant = "Oracle"
ES.hs_assistant_d = "Panel oscuro con icono principal resplandeciente, nombre de la habilidad al lado y los dos siguientes con cuenta atrás. Anillo animado al cambiar."
EN.hs_assistant_d = "Dark panel with a glowing main icon, the ability name beside it and the next two with a countdown. Animated ring when it changes."
ES.hs_use         = "¡Usa el objeto!";  EN.hs_use = "Use the item!"
ES.hs_sample      = "Habilidad principal";  EN.hs_sample = "Main ability"
ES.hs_hint        = "El cambio se aplica al instante y se guarda en el perfil de este personaje y rama."
EN.hs_hint        = "The change applies instantly and is saved in this character and talent group's profile."
ES.helpLine      = "comandos: /pf (alias /pulseflash) on | off | aoe | modo | combo | num | venenos | piedra | buffs | bufflock | cds | roles | tank | multidot | boss | version | alertas | mascota | totem | rango | raciales | teclas | alias | nuevas | icc | posicion | hud | move/lock | scale <0.5-2.0> | config | idioma | reset | debug"
EN.helpLine      = "commands: /pf (alias /pulseflash) on | off | aoe | mode | combo | num | poisons | stone | buffs | bufflock | cds | roles | tank | multidot | boss | version | alerts | pet | totem | range | racials | keys | alias | icc | position | hud | move/lock | scale <0.5-2.0> | config | lang | reset | debug"
ES.dbg_class     = "clase %s | spec %d | nivel %d | hechizos en el libro: %d"
EN.dbg_class     = "class %s | spec %d | level %d | spells in book: %d"
ES.dbg_hp        = "  vida del objetivo: %d%%"
EN.dbg_hp        = "  target health: %d%%"
ES.dbg_alerts    = "  avisos paralelos activos (botones): %d"
EN.dbg_alerts    = "  active parallel alerts (buttons): %d"
ES.dbg_hud       = "  HUD: %s | %s | x=%d y=%d escala=%.2f"
EN.dbg_hud       = "  HUD: %s | %s | x=%d y=%d scale=%.2f"
ES.dbg_active    = "activo";      EN.dbg_active   = "active"
ES.dbg_inactive  = "inactivo";    EN.dbg_inactive = "inactive"
ES.dbg_locked    = "bloqueado";   EN.dbg_locked   = "locked"
ES.dbg_unlocked  = "desbloqueado"; EN.dbg_unlocked = "unlocked"
ES.dbg_flags     = "  rango: %s | raciales: %s | ICC: %s | posición: %s"
EN.dbg_flags     = "  range: %s | racials: %s | ICC: %s | position: %s"
ES.dbg_behind    = "  detrás del objetivo: %s"
EN.dbg_behind    = "  behind the target: %s"
ES.dbg_yes       = "sí";                 EN.dbg_yes = "yes"
ES.dbg_front     = "NO (de frente)";     EN.dbg_front = "NO (facing it)"
ES.dbg_rot       = "  modo de rotación: %s | espera: %s"
EN.dbg_rot       = "  rotation mode: %s | hold: %s"
ES.dbg_rotMax    = "MÁXIMO DAÑO";        EN.dbg_rotMax = "MAX DAMAGE"
ES.dbg_rotNormal = "normal";             EN.dbg_rotNormal = "normal"
ES.dbg_prebuffs  = "  buffos que faltan: %s"
EN.dbg_prebuffs  = "  missing buffs: %s"
ES.dbg_cand      = "  cand t%d %s [estado %s]"
EN.dbg_cand      = "  cand t%d %s [state %s]"
ES.dbg_slot      = "  slot %d: %s"
EN.dbg_slot      = "  slot %d: %s"

----------------------------------------------------------------------
-- Perfiles (Profiles.lua)
----------------------------------------------------------------------
ES.noSpec        = "Sin especialización";  EN.noSpec = "No specialization"
ES.group1        = "Principal";            EN.group1 = "Primary"
ES.group2        = "Secundaria";           EN.group2 = "Secondary"
ES.cloneLabel    = "%s  |cff9a9aa5(%s · Rama %d: %s)|r"
EN.cloneLabel    = "%s  |cff9a9aa5(%s · Group %d: %s)|r"
ES.cloned        = "configuración clonada de |cffffd100%s|r (rama %d)."
EN.cloned        = "settings cloned from |cffffd100%s|r (group %d)."
ES.presetSaved   = "perfil guardado: |cffffd100%s|r"
EN.presetSaved   = "profile saved: |cffffd100%s|r"
ES.presetLoaded  = "perfil cargado: |cffffd100%s|r"
EN.presetLoaded  = "profile loaded: |cffffd100%s|r"
ES.presetDeleted = "perfil eliminado: |cffffd100%s|r"
EN.presetDeleted = "profile deleted: |cffffd100%s|r"
ES.profileSwitched = "perfil cargado: |cffffd100%s|r · rama %d (%s)"
EN.profileSwitched = "profile loaded: |cffffd100%s|r · group %d (%s)"

----------------------------------------------------------------------
-- Barra de combos, minimapa, venenos
----------------------------------------------------------------------
ES.comboDrag     = "|cffffd100PulseFlash|r - arrastra la barra de combos"
EN.comboDrag     = "|cffffd100PulseFlash|r - drag the combo bar"
ES.comboLockedMsg = "Barra de combos |cff00ff00bloqueada|r"
EN.comboLockedMsg = "Combo bar |cff00ff00locked|r"
ES.comboUnlockedMsg = "Barra de combos |cffffd100desbloqueada|r: arrástrala con el ratón."
EN.comboUnlockedMsg = "Combo bar |cffffd100unlocked|r: drag it with the mouse."
ES.comboPreview  = "Vista previa de la barra de combos: %s"
EN.comboPreview  = "Combo bar preview: %s"
ES.comboIs       = "Barra de combos: %s"
EN.comboIs       = "Combo bar: %s"
ES.pal_gradient  = "Degradado"; EN.pal_gradient = "Gradient"
ES.pal_yellow    = "Amarillo";  EN.pal_yellow   = "Yellow"
ES.pal_red       = "Rojo";      EN.pal_red      = "Red"
ES.pal_green     = "Verde";     EN.pal_green    = "Green"
ES.pal_white     = "Blanco";    EN.pal_white    = "White"
ES.poisonsMissing = "|cffff4040faltan venenos|r en las armas."
EN.poisonsMissing = "|cffff4040poisons missing|r on your weapons."

ES.mm_left       = "|cffffffffClic izquierdo:|r panel de configuración"
EN.mm_left       = "|cffffffffLeft-click:|r settings panel"
ES.mm_right_lock = "|cffffffffClic derecho:|r bloquear HUD |cff40d9ff(desbloqueado)|r"
EN.mm_right_lock = "|cffffffffRight-click:|r lock HUD |cff40d9ff(unlocked)|r"
ES.mm_right_unlock = "|cffffffffClic derecho:|r desbloquear HUD"
EN.mm_right_unlock = "|cffffffffRight-click:|r unlock HUD"
ES.mm_shift      = "|cffffffffMayús + clic izq.:|r vista previa del HUD"
EN.mm_shift      = "|cffffffffShift + left-click:|r HUD preview"
ES.mm_active     = " |cff00ff00(activa)|r"
EN.mm_active     = " |cff00ff00(active)|r"
ES.mm_drag       = "|cffffffffArrastrar:|r mover el botón"
EN.mm_drag       = "|cffffffffDrag:|r move the button"

----------------------------------------------------------------------
-- Sonidos (catálogo)
----------------------------------------------------------------------
ES.snd_none = "Ninguno";           EN.snd_none = "None"
ES.snd_raid = "Alerta de banda";   EN.snd_raid = "Raid warning"
ES.snd_boss = "Aviso de jefe";     EN.snd_boss = "Boss warning"
ES.snd_ping = "Ping de mapa";      EN.snd_ping = "Map ping"
ES.snd_ready = "Control de listos"; EN.snd_ready = "Ready check"
ES.snd_auction = "Campanilla";     EN.snd_auction = "Chime"
ES.snd_alarm2 = "Alarma suave";    EN.snd_alarm2 = "Soft alarm"
ES.snd_alarm3 = "Alarma";          EN.snd_alarm3 = "Alarm"
ES.snd_tell = "Susurro";           EN.snd_tell = "Whisper"
ES.snd_level = "Nivel";            EN.snd_level = "Level up"
ES.snd_pvp = "Aviso JcJ";          EN.snd_pvp = "PvP warning"
ES.snd_bell = "Campana";           EN.snd_bell = "Bell"

----------------------------------------------------------------------
-- Panel de configuración (Config.lua)
----------------------------------------------------------------------
ES.c_title       = "- Configuración";   EN.c_title = "- Settings"
ES.tab_general   = "HUD de daño";        EN.tab_general = "Damage HUD"
ES.tab_buffs     = "HUD de buffos";      EN.tab_buffs = "Buff HUD"
ES.tab_rotation  = "Rotación";          EN.tab_rotation = "Rotation"
ES.tab_combos    = "Combos";            EN.tab_combos = "Combos"
ES.tab_sounds    = "Sonidos";           EN.tab_sounds = "Sounds"
ES.tab_profiles  = "Perfiles";          EN.tab_profiles = "Profiles"
ES.tab_beta      = "Funciones nuevas (BETA)";  EN.tab_beta = "New features (BETA)"
ES.fn_name       = "Funciones nuevas";  EN.fn_name = "New features"
ES.fn_nomod      = "Eventos de jefe: no hay DBM ni BigWigs enlazado, así que esta función no hará nada hasta que uno esté activo."
EN.fn_nomod      = "Boss events: no DBM or BigWigs is linked, so this feature will do nothing until one is active."
ES.beta_head     = "FUNCIONES NUEVAS (BETA)";  EN.beta_head = "NEW FEATURES (BETA)"
ES.beta_warn     = "Funciones en pruebas (BETA): pueden equivocarse o cambiar en próximas versiones. Están apagadas por defecto: actívalas solo si quieres probarlas."
EN.beta_warn     = "Features in testing (BETA): they may get things wrong or change in future versions. They are off by default: enable them only if you want to try them."
ES.beta_enable   = "Activar funciones nuevas (interruptor general)"
EN.beta_enable   = "Enable new features (master switch)"
ES.beta_predict  = "Predicción: tiempo de vuelo y recursos del próximo GCD"
EN.beta_predict  = "Prediction: travel time and next-GCD resources"
ES.beta_predict_d = "Un hechizo con proyectil que aún va por el aire cuenta como lanzado, y los DoTs se renuevan justo a tiempo (lanzamiento + vuelo + latencia). Si una habilidad mejor estará lista dentro de un instante (energía, maná o runas), el HUD muestra la espera en vez de gastar el recurso en otra peor."
EN.beta_predict_d = "A projectile spell that is still in flight counts as cast, and DoTs are renewed just in time (cast + flight + latency). If a better ability will be ready in a moment (energy, mana or runes), the HUD shows the wait instead of spending the resource on a worse one."
ES.beta_latency  = "Latencia: seguir tus lanzamientos con tu latencia real"
EN.beta_latency  = "Latency: follow your casts using your real latency"
ES.beta_latency_d = "Mide tu latencia entre pulsar y que el servidor acepte el lanzamiento (como la barra de latencia de Quartz). Cuando a tu lanzamiento le queda menos que ese tiempo, el HUD ya muestra la siguiente habilidad para que la encadenes sin perder tiempo, y los DoTs se renuevan con esa latencia."
EN.beta_latency_d = "Measures your latency between pressing the key and the server accepting the cast (like Quartz's latency bar). When your cast has less time left than that, the HUD already shows the next ability so you can chain it without losing time, and DoTs are renewed using that latency."
ES.beta_snap     = "Snapshotting: renovar DoTs si tus estadísticas han subido"
EN.beta_snap     = "Snapshotting: renew DoTs when your stats have risen"
ES.beta_snap_d   = "Los DoTs y sangrados guardan tu poder del momento en que se aplican. Si tu poder sube mucho (procs, abalorios, Ansia de sangre...), se ilumina la renovación aunque aún dure, siempre que compense lo que se pierde al pisarlo."
EN.beta_snap_d   = "DoTs and bleeds keep the power you had when they were applied. If your power rises a lot (procs, trinkets, Bloodlust...), the renewal lights up even if it still has time left, as long as it is worth what is lost by overwriting it."
ES.beta_boss     = "Eventos de jefe (requiere DBM o BigWigs)"
EN.beta_boss     = "Boss events (requires DBM or BigWigs)"
ES.beta_boss_d   = "Si el jefe va a hacer algo en menos de 3 s: con una fase de inmunidad se guardan los cooldowns; con un miedo o una orden de correr solo se sugieren hechizos que caben antes del evento. Funciona solo con los temporizadores de DBM o BigWigs: PulseFlash no detecta mecánicas por su cuenta, así que sin uno de ellos no hace nada."
EN.beta_boss_d   = "If the boss is about to do something in under 3 s: before an immunity phase your cooldowns are held back; before a fear or a run-away mechanic only spells that fit before the event are suggested. It works only from DBM or BigWigs timers: PulseFlash does not detect mechanics on its own, so without one of them it does nothing."
ES.beta_on       = "|cffffd100Funciones nuevas (BETA) activadas.|r Están en pruebas: pueden fallar. Ajusta cada una en Config > Funciones nuevas."
EN.beta_on       = "|cffffd100New features (BETA) enabled.|r They are in testing: they may misbehave. Adjust each one in Config > New features."
ES.beta_off      = "Funciones nuevas (BETA) desactivadas."
EN.beta_off      = "New features (BETA) disabled."
ES.beta_test_off = "Activa antes las funciones nuevas y los eventos de jefe (/pf nuevas  y  /pf nuevas boss on)."
EN.beta_test_off = "Enable the new features and boss events first (/pf new  and  /pf new boss on)."
ES.beta_event    = "evento del jefe";  EN.beta_event = "boss event"
ES.beta_w_move   = "Jefe: %s - solo hechizos que quepan antes (instantáneos)"
EN.beta_w_move   = "Boss: %s - only spells that fit before it (instants)"
ES.beta_w_fear   = "Jefe: %s (miedo) - solo hechizos que quepan antes"
EN.beta_w_fear   = "Boss: %s (fear) - only spells that fit before it"
ES.beta_w_immune = "Jefe: %s - guarda tus cooldowns"
EN.beta_w_immune = "Boss: %s - hold your cooldowns"

ES.g_look        = "APARIENCIA DEL HUD";   EN.g_look = "HUD APPEARANCE"
ES.g_scale       = "Escala y tamaño del HUD"; EN.g_scale = "HUD scale and size"
ES.g_alphaCombat = "Opacidad en combate";  EN.g_alphaCombat = "Opacity in combat"
ES.g_alphaOOC    = "Opacidad fuera de combate"; EN.g_alphaOOC = "Opacity out of combat"
ES.g_flash       = "DESTELLO";             EN.g_flash = "FLASH"
ES.g_period      = "Frecuencia del destello (segundos por pulso)"
EN.g_period      = "Flash rate (seconds per pulse)"
ES.g_intensity   = "Intensidad del brillo"; EN.g_intensity = "Glow intensity"
ES.g_styleGlow   = "Glow clásico";         EN.g_styleGlow = "Classic glow"
ES.g_styleSize   = "Pulso de tamaño";      EN.g_styleSize = "Size pulse"
ES.g_showHud     = "MOSTRAR EL HUD";       EN.g_showHud = "SHOW THE HUD"
ES.g_modeCombat  = "Solo combate";         EN.g_modeCombat = "Combat only"
ES.g_modeTarget  = "Objetivo hostil";      EN.g_modeTarget = "Hostile target"
ES.g_modeAlways  = "Siempre";              EN.g_modeAlways = "Always"
ES.g_actions     = "ACCIONES";             EN.g_actions = "ACTIONS"
ES.g_unlock      = "Desbloquear HUD";      EN.g_unlock = "Unlock HUD"
ES.g_lock        = "Bloquear HUD";         EN.g_lock = "Lock HUD"
ES.previewOn     = "Vista previa: ON";     EN.previewOn = "Preview: ON"
ES.previewOff    = "Vista previa: OFF";    EN.previewOff = "Preview: OFF"
ES.g_hint        = "Los cambios se guardan solos en el perfil de este personaje y rama."
EN.g_hint        = "Changes are saved automatically in this character and talent group's profile."
ES.b_title       = "HUD DE BUFFOS";        EN.b_title = "BUFF HUD"
ES.bhudUnlocked  = "HUD de buffos |cffffd100desbloqueado|r: arrástralo con el ratón. /pf bufflock (o el botón de su pestaña) para fijarlo."
EN.bhudUnlocked  = "Buff HUD |cffffd100unlocked|r: drag it with the mouse. /pf bufflock (or its tab button) to lock it."
ES.bhudLocked    = "HUD de buffos |cff00ff00bloqueado|r en x=%d, y=%d"
EN.bhudLocked    = "Buff HUD |cff00ff00locked|r at x=%d, y=%d"
ES.bhudPreview   = "Vista previa del HUD de buffos: %s"
EN.bhudPreview   = "Buff HUD preview: %s"
ES.b_pulse       = "Animación de pulso";   EN.b_pulse = "Pulse animation"
ES.b_glow        = "Resplandor dorado";    EN.b_glow = "Golden glow"
ES.b_enable      = "HUD de buffos";        EN.b_enable = "Buff HUD"
ES.b_combat      = "Ver en combate";       EN.b_combat = "Show in combat"
ES.b_hint        = "Segundo HUD: solo muestra los buffos que te faltan (aspectos, bendiciones,\nauras, sellos, armaduras, venenos...). Su bloqueo y su vista previa son\nindependientes de los del HUD de daño."
EN.b_hint        = "Second HUD: only shows the buffs you are missing (aspects, blessings,\nauras, seals, armors, poisons...). Its lock and preview are independent\nfrom the damage HUD's."
ES.g_language    = "IDIOMA / LANGUAGE"; EN.g_language = "LANGUAGE / IDIOMA"

ES.r_title       = "MODO DE ROTACIÓN";  EN.r_title = "ROTATION MODE"
ES.r_normal      = "Normal";            EN.r_normal = "Normal"
ES.r_max         = "Máximo daño (prueba)"; EN.r_max = "Max damage (test)"
ES.r_what        = "QUÉ HACE CADA MODO"; EN.r_what = "WHAT EACH MODE DOES"
ES.r_descRogue =
  "|cffffd100Normal|r: brilla siempre lo primero que puedas lanzar ya. Si te falta energía " ..
  "para Mutilar, brilla Golpe siniestro.\n\n" ..
  "|cffffd100Máximo daño|r:\n" ..
  "- Si solo faltan 2 s o menos de energía para |cffffd100Mutilar|r (Asesinato, dos dagas) o " ..
  "|cffffd100Puñalada trapera|r (solo Sutileza), espera en vez de gastarla en Golpe siniestro. " ..
  "Mutilar da 2 PC por 60 de energía: más daño y más PC por energía.\n" ..
  "- Si |cffffd100Rebanar y Cortar|r o |cffffd100Ruptura|r van a vencer y gastar energía " ..
  "ahora te dejaría sin la necesaria para refrescarlos, espera.\n\n" ..
  "El HUD muestra los segundos de espera sobre el icono principal."
EN.r_descRogue =
  "|cffffd100Normal|r: always glows the first ability you can cast right now. If you lack energy " ..
  "for Mutilate, Sinister Strike glows.\n\n" ..
  "|cffffd100Max damage|r:\n" ..
  "- If you are 2 s or less of energy short for |cffffd100Mutilate|r (Assassination, dual daggers) or " ..
  "|cffffd100Backstab|r (Subtlety only), it waits instead of spending energy on Sinister Strike. " ..
  "Mutilate gives 2 CP for 60 energy: more damage and more CP per energy.\n" ..
  "- If |cffffd100Slice and Dice|r or |cffffd100Rupture|r are about to expire and spending energy " ..
  "now would leave you without enough to refresh them, it waits.\n\n" ..
  "The HUD shows the waiting seconds over the main icon."
ES.r_descDruid =
  "|cffffd100Normal|r: brilla siempre lo primero que puedas lanzar ya.\n\n" ..
  "|cffffd100Máximo daño|r (feral):\n" ..
  "- Si |cffffd100Rugido salvaje|r, |cffffd100Desgarrar|r (5 PC), |cffffd100Rastrillar|r o el " ..
  "debuff de |cffffd100Mutilar|r van a vencer y gastar energía en un generador te dejaría sin la " ..
  "necesaria para refrescarlo a tiempo, espera.\n" ..
  "- Con el debuff de Mutilar activo y estando detrás, si faltan 2 s o menos de energía para " ..
  "|cffffd100Destrozar|r, espera en vez de gastarla en Mutilar (no durante Berserk).\n\n" ..
  "El HUD muestra los segundos de espera sobre el icono principal."
EN.r_descDruid =
  "|cffffd100Normal|r: always glows the first ability you can cast right now.\n\n" ..
  "|cffffd100Max damage|r (feral):\n" ..
  "- If |cffffd100Savage Roar|r, |cffffd100Rip|r (5 CP), |cffffd100Rake|r or the " ..
  "|cffffd100Mangle|r debuff are about to expire and spending energy on a builder would leave you " ..
  "without enough to refresh it in time, it waits.\n" ..
  "- With the Mangle debuff up and while behind the target, if you are 2 s or less of energy short for " ..
  "|cffffd100Shred|r, it waits instead of spending energy on Mangle (not during Berserk).\n\n" ..
  "The HUD shows the waiting seconds over the main icon."
ES.r_live        = "ESTADO EN VIVO";    EN.r_live = "LIVE STATUS"
ES.r_liveNormal  = "Modo normal: sin esperas."
EN.r_liveNormal  = "Normal mode: no waiting."
ES.r_liveHold    = "Esperando: |cffffd100%s|r  (%.1f s)"
EN.r_liveHold    = "Waiting for: |cffffd100%s|r  (%.1f s)"
ES.r_liveNone    = "Modo máximo daño: sin espera ahora mismo (se lanza lo que toca)."
EN.r_liveNone    = "Max damage mode: not waiting right now (casting what is next)."
ES.r_note        = "Es un modo de prueba: compáralo con el Normal sobre un muñeco de entrenamiento y quédate con el que más daño haga en tu equipo."
EN.r_note        = "This is a test mode: compare it with Normal on a training dummy and keep the one that does more damage with your gear."

ES.cb_title      = "BARRA DE COMBOS";   EN.cb_title = "COMBO BAR"
ES.cb_enable     = "Activar la barra de combos"; EN.cb_enable = "Enable the combo bar"
ES.cb_scale      = "Escala de la barra"; EN.cb_scale = "Bar scale"
ES.cb_w          = "Ancho de cada punto"; EN.cb_w = "Width of each point"
ES.cb_h          = "Alto de cada punto";  EN.cb_h = "Height of each point"
ES.cb_gap        = "Separación entre puntos"; EN.cb_gap = "Spacing between points"
ES.cb_alpha      = "Opacidad";           EN.cb_alpha = "Opacity"
ES.cb_color      = "COLOR";              EN.cb_color = "COLOR"
ES.cb_showHdr    = "MOSTRAR LA BARRA";   EN.cb_showHdr = "SHOW THE BAR"
ES.cb_always     = "Siempre";            EN.cb_always = "Always"
ES.cb_target     = "Con objetivo";       EN.cb_target = "With target"
ES.cb_points     = "Con puntos";         EN.cb_points = "With points"
ES.cb_number     = "Mostrar el número de puntos sobre la barra"
EN.cb_number     = "Show the point count above the bar"
ES.cb_move       = "Mover la barra";     EN.cb_move = "Move the bar"
ES.cb_fix        = "Fijar la barra";     EN.cb_fix = "Lock the bar"

ES.s_title       = "ALERTAS SONORAS";    EN.s_title = "SOUND ALERTS"
ES.s_enable      = "Activar alertas sonoras de procs"; EN.s_enable = "Enable proc sound alerts"
ES.s_hint        = "Clic izquierdo: sonido siguiente  ·  Clic derecho: anterior"
EN.s_hint        = "Left-click: next sound  ·  Right-click: previous"
ES.s_none        = "Tu clase no tiene procs que modifiquen la rotación."
EN.s_none        = "Your class has no procs that change the rotation."
ES.s_each        = "SONIDO DE CADA PROC"; EN.s_each = "SOUND FOR EACH PROC"
ES.s_test        = "Probar";             EN.s_test = "Test"

ES.p_char        = "PERSONAJE ACTIVO";   EN.p_char = "ACTIVE CHARACTER"
ES.p_info1       = "Personaje: |cffffd100%s|r"; EN.p_info1 = "Character: |cffffd100%s|r"
ES.p_info2       = "Clase: |cffffd100%s|r";     EN.p_info2 = "Class: |cffffd100%s|r"
ES.p_info3       = "Rama activa: |cffffd100%d (%s)|r  ·  Especialización: |cffffd100%s|r"
EN.p_info3       = "Active talent group: |cffffd100%d (%s)|r  ·  Specialization: |cffffd100%s|r"
ES.p_sub         = "(%s  ·  Rama %d  ·  %s)"
EN.p_sub         = "(%s  ·  Group %d  ·  %s)"
ES.p_saved       = "PERFILES GUARDADOS"; EN.p_saved = "SAVED PROFILES"
ES.p_name        = "Nombre del perfil";  EN.p_name = "Profile name"
ES.p_save        = "Guardar";            EN.p_save = "Save"
ES.p_load        = "Cargar...";          EN.p_load = "Load..."
ES.p_clone       = "Clonar...";          EN.p_clone = "Clone..."
ES.p_loadTitle   = "Cargar perfil  |cff9aa3b8(clic der.: eliminar)|r"
EN.p_loadTitle   = "Load profile  |cff9aa3b8(right-click: delete)|r"
ES.p_cloneTitle  = "Clonar de otro personaje / rama"
EN.p_cloneTitle  = "Clone from another character / group"
ES.p_empty       = "(no hay perfiles)"; EN.p_empty = "(no profiles)"
ES.p_helpHdr     = "AYUDA";              EN.p_helpHdr = "HELP"
ES.p_help        =
  "El perfil de cada personaje y rama de talentos se guarda y se carga solo al cambiar de rama.\n\n" ..
  "|cffffd100Guardar|r crea un perfil con nombre.\n" ..
  "|cffffd100Cargar|r aplica uno guardado.\n" ..
  "|cffffd100Clonar|r copia la configuración de otro personaje o rama de tu cuenta."
EN.p_help        =
  "Each character's and talent group's profile is saved and loaded automatically when you switch groups.\n\n" ..
  "|cffffd100Save|r creates a named profile.\n" ..
  "|cffffd100Load|r applies a saved one.\n" ..
  "|cffffd100Clone|r copies the settings of another character or talent group on your account."
