-- Sim.lua
-- Simulador de escenarios de combate (addon de carga bajo demanda).
--
-- Ejecuta la rotación REAL de tu clase (la misma que usa el HUD) sobre un mundo
-- completamente virtual (recursos, cooldowns, auras y tiempo simulados, sin leer
-- nada del juego salvo tu libro de hechizos) y comprueba:
--   1. Orden:      nunca recomienda algo no ejecutable, nunca se queda sin recomendación y
--                  no antepone el relleno/un proc a un DoT que falta y está listo.
--                  Si todo está en enfriamiento o sin recurso el simulador ESPERA (como
--                  harías tú); solo es error no tener ni candidatas ni relleno.
--   2. Auras:      los buffs y debuffs de mantenimiento se mantienen (>= 85 % del tiempo).
--   3. Recursos:   sin tiempo al tope del recurso, sin puntos de combo desperdiciados,
--                  sin procs que caducan sin usar.
--   4. Cooldowns:  los cooldowns largos se usan casi siempre que están listos y los
--                  grandes se coordinan (primer uso en una ventana corta).
--   5. Regresión:  compara con una referencia guardada para saber si un cambio empeora
--                  una rotación anterior.
local PF = PulseFlash
local floor, max, min, format = math.floor, math.max, math.min, string.format

local function L(es, en) return (PF.GetLang and PF.GetLang() == "es") and es or en end

-- Umbrales
local UPTIME_MIN   = 85     -- % mínimo de mantenimiento de un buff/debuff
local CAP_MAX      = 8      -- % máximo de tiempo con el recurso al tope
local CD_EFF_MIN   = 0.75   -- fracción mínima de usos posibles de un cooldown
local CD_DELAY_MAX = 4.0    -- retraso medio máximo (s) entre "listo" y "usado"
local CD_ALIGN     = 12     -- ventana (s) para el primer uso de los cooldowns grandes
local PROC_PERIOD, PROC_DUR = 12, 10
local MAX_STEPS    = 1600
local EXEC_HP      = 0.20   -- por debajo de esto (fase de remate) no se puntúa el mantenimiento de auras
local WAIT_MIN, WAIT_MAX, WAIT_RES = 0.1, 1.0, 0.25   -- esperas (s) cuando no hay nada lanzable

PF.SIM_SCENARIOS = {
  { id = "boss90",  T = 90,  boss = true,  procs = false, hpEnd = 0,   es = "Jefe · 90 s",          en = "Boss · 90 s" },
  { id = "boss180", T = 180, boss = true,  procs = true,  hpEnd = 0,   es = "Jefe · 180 s + procs", en = "Boss · 180 s + procs" },
  { id = "trash30", T = 30,  boss = false, procs = false, hpEnd = 0.4, es = "Corto · 30 s",         en = "Short · 30 s" },
}

local function Scen(id)
  for _, s in ipairs(PF.SIM_SCENARIOS) do if s.id == id then return s end end
end

-- ---------------------------------------------------------------------------
-- Utilidades
-- ---------------------------------------------------------------------------
local function Items(list)
  if not list then return {} end
  if type(list[1]) == "string" then return { list } end
  return list
end

local function NumOf(x, v, cp)
  if type(x) == "function" then
    local ok, r = pcall(x, cp or 5, v)
    return ok and tonumber(r) or nil
  end
  return tonumber(x)
end

local function Consumed(e, N)
  local set = {}
  if not e then return set end
  if e.free and N[e.free] then set[N[e.free]] = true end
  if e.instant then
    local lst = type(e.instant) == "table" and e.instant or { e.instant }
    for _, k in ipairs(lst) do if N[k] then set[N[k]] = true end end
  end
  if e.consume then
    for _, k in ipairs(e.consume) do if N[k] then set[N[k]] = true end end
  end
  return set
end

local function Pct(v) return format("%d%%", floor(v + 0.5)) end

-- ¿Este lanzamiento consumiría ahora mismo un proc (gratis/instantáneo)?
local function UsesProc(v, e, N)
  if not e then return false end
  if e.free then
    local an = N[e.free]
    if an and v:Aura("player", an, false, false) then return true end
  end
  if e.instant then
    local lst = type(e.instant) == "table" and e.instant or { e.instant }
    for _, k in ipairs(lst) do
      local an = N[k]
      if an and v:Aura("player", an, false, false) then return true end
    end
  end
  return false
end

-- ---------------------------------------------------------------------------
-- Qué vigilar según la tabla de simulación del módulo de la clase
-- ---------------------------------------------------------------------------
local function Plan(mod, v)
  local N = PF.N
  local trackers, seen = {}, {}
  local maint, cds = {}, {}

  local function Track(unit, harmful, name, spell)
    local k = unit .. ":" .. name
    if seen[k] then return end
    seen[k] = true
    trackers[#trackers + 1] = { unit = unit, harmful = harmful, name = name, spell = spell,
                                first = nil, span = 0, active = 0 }
  end

  for key, e in pairs(mod.sim) do
    local spell = N[key]
    if spell and PF.Known(spell) then
      if e.cd then
        local cdv = NumOf(e.cd, v, 5)
        -- Se excluyen las que dependen de un proc (Congelación profunda con Dedos de escarcha)
        -- las que solo reinician otros cooldowns (Escalofrío, Presteza) y las que solo se pueden
        -- usar dentro de otro (Aura de inmolación en Metamorfosis): su momento lo marca
        -- otra cosa, no la rotación, y puntuarlas como "retrasadas" daba falsos fallos.
        if cdv and cdv >= 20 and not e.reset and not e.consume and not e.gated then
          cds[spell] = { cd = cdv, uses = 0, delay = 0, maxDelay = 0 }
        end
      else
        for _, it in ipairs(Items(e.debuff)) do
          local an, d = N[it[1]], NumOf(it.dur, v, 5)
          if an and d and d >= 6 then
            Track("target", true, an, spell)
            if not maint[spell] then maint[spell] = an end
          end
        end
        for _, it in ipairs(Items(e.buff)) do
          local an, d = N[it[1]], NumOf(it.dur, v, 5)
          if an and d and d >= 6 then Track("player", false, an, spell) end
        end
      end
    end
  end
  table.sort(trackers, function(a, b) return a.name < b.name end)
  return trackers, maint, cds
end

-- Segundos que conviene esperar cuando no hay nada lanzable: hasta que termine el
-- enfriamiento más próximo de las candidatas de prioridad 1 (o del relleno). Si lo que
-- falta es recurso (energía, ira, maná...) se avanza en pasos cortos mientras se regenera.
local function WaitStep(v)
  local w
  local function consider(sp)
    if not sp then return end
    local cd = v:CD(sp)
    if cd > 0.05 then
      if not w or cd < w then w = cd end
    else
      w = (w and w < WAIT_RES) and w or WAIT_RES
    end
  end
  for i = 1, (v.nC or 0) do
    if v.cTier[i] == 1 then consider(v.cSpell[i]) end
  end
  consider(v.waitFor)
  return max(WAIT_MIN, min(w or WAIT_RES, WAIT_MAX))
end

-- Prioridad 2 (cooldowns, buffs de combate): el HUD los muestra en el segundo icono y el
-- jugador los pulsa en cuanto están listos (casi todos son instantáneos o fuera del GCD).
-- El simulador solo miraba la prioridad 1, así que NUNCA usaba Venas heladas, Imagen
-- espejo, Metamorfosis, Fuego rápido, Marca del cazador... y la secuencia era puro relleno.
-- Solo se usan los que tienen efecto modelado en la tabla sim del módulo (si no, un
-- hechizo sin cooldown simulado se repetiría sin fin).
local function Modeled(e)
  return (e and (e.cd or e.once or e.buff or e.debuff or e.petbuff or e.tbuff or e.fn)) and true or false
end

local function PickCooldown(v, used)
  for i = 1, (v.nC or 0) do
    if v.cTier[i] == 2 then
      local s = v.cSpell[i]
      if used[s] ~= v.t and Modeled(v.byName[s]) and v:State(s) == 3 then return s end
    end
  end
  return nil
end

-- ---------------------------------------------------------------------------
-- Ejecución de un escenario
-- ---------------------------------------------------------------------------
local RES_TYPES = { 1, 3, 6 }   -- ira, energía, poder rúnico

local function Run(sc)
  local mod = PF.module
  if not (mod and type(mod.sim) == "table" and mod.evaluate and PF.SimNewV) then
    return nil, L("Tu clase no tiene tabla de simulación.", "Your class has no simulation table.")
  end
  local N = PF.N
  local T = sc.T

  local c = {
    level = UnitLevel("player"), combat = true, spec = PF.spec, hostile = true,
    boss = sc.boss, bigCD = sc.boss, hp = 1, worth = true, fightTime = 0,
    phase = sc.boss and "opener" or nil, burn = false, php = 1,
    mana = 0, manaPct = 1, rage = 0, energy = 0, runic = 0, cp = 0,
    enemies = 1, behind = true, casting = nil,
  }

  -- Mundo virtual: nada se lee del juego (auras, cooldowns y recursos son simulados)
  local v = PF.SimNewV(c, mod)
  v.simMode = true
  v.real = { pb = PF.SimEmptyAuras, pd = PF.SimEmptyAuras, tb = PF.SimEmptyAuras,
             td = PF.SimEmptyAuras, nb = PF.SimEmptyAuras }
  v.ov = { pb = {}, pd = {}, tb = {}, td = {}, nb = {} }
  v.cdAt = setmetatable({}, { __index = function() return 0 end })
  v.cp = 0
  for _, t in ipairs { 0, 1, 3, 6 } do
    local mx = UnitPowerMax("player", t) or 0
    v.resMax[t] = mx
    v.res[t] = (t == 0 or t == 3) and mx or 0
  end
  for i = 1, 6 do if v.runes[i] then v.runes[i].at = 0 end end

  local trackers, maint, cds = Plan(mod, v)

  -- Procs programados del escenario "+ procs". Si el módulo declara los de su rama
  -- (simProcs) solo se inyectan esos: antes un mago de Escarcha recibía también Pirotecnia
  -- y Descarga de misiles de otras ramas, y la secuencia no se parecía a su rotación.
  local procs = {}
  local want
  if mod.simProcs then
    want = {}
    for _, sp in ipairs(mod.simProcs) do
      if (not sp.spec or sp.spec == PF.spec) and N[sp.aura] then want[N[sp.aura]] = sp end
    end
  end
  for _, p in ipairs(PF.procList or {}) do
    if not p.custom and (not want or want[p.name]) then procs[#procs + 1] = p end
  end

  -- acumuladores
  local seq, seqT, castCount = {}, {}, {}
  local used2 = {}                 -- cooldown de prioridad 2 ya lanzado en este instante
  local steps, zeroN, noPick, notExec = 0, 0, 0, 0
  local idle = 0
  local viol = {}
  local spentType, capTime = {}, {}
  local cpWaste = 0
  local procApplied, procUsed, procExpired = 0, 0, 0
  local ready = {}
  local firstUse = {}
  local nextProc = 4

  PF.V = v
  while v.t < T and steps < MAX_STEPS do
    steps = steps + 1
    local t0 = v.t
    c.fightTime = t0
    c.hp = max(0.01, 1 - (1 - sc.hpEnd) * t0 / T)
    if c.boss then
      if c.hp <= 0.10 then c.phase = "final"
      elseif c.hp <= 0.35 then c.phase = "burn"
      elseif t0 < 12 then c.phase = "opener"
      else c.phase = "main" end
    end
    c.burn = (c.phase == "burn" or c.phase == "final")

    -- procs programados
    if sc.procs then
      while nextProc <= t0 do
        for _, p in ipairs(procs) do
          -- un proc con condición (Decimación: objetivo < 35 % de vida) no se inyecta fuera de ella
          local sp = want and want[p.name]
          if not (sp and sp.when and not sp.when(v)) then
            v:Apply("player", false, p.name, PROC_DUR, (sp and sp.stacks) or p.stacks or 1, true)
            procApplied = procApplied + 1
          end
        end
        nextProc = nextProc + PROC_PERIOD
      end
    end

    -- fotografía previa al paso
    local left0, atCap = {}, {}
    for i, tr in ipairs(trackers) do left0[i] = v:Aura(tr.unit, tr.name, tr.harmful, true) end
    local pLeft0 = {}
    for i, p in ipairs(procs) do pLeft0[i] = v:Aura("player", p.name, false, false) end
    for _, pt in ipairs(RES_TYPES) do
      local cap = v.resMax[pt]
      if cap and cap > 0 then atCap[pt] = ((v.res[pt] or 0) >= cap - 0.5) end
    end

    local inExec = c.hp < EXEC_HP
    local pick, hold = v:Pick()
    local cdPick = PickCooldown(v, used2)
    if cdPick then pick, hold, used2[cdPick] = cdPick, nil, v.t end

    -- cooldowns: ¿listos? (para medir el retraso hasta usarlos)
    for sp, cd in pairs(cds) do
      if v:State(sp) == 3 then ready[sp] = ready[sp] or v.t else ready[sp] = nil end
    end

    if not pick and v.waitFor then
      -- Hay relleno pero aún no se puede lanzar (enfriamiento o recurso): en el juego no
      -- se pulsa nada. Se espera, sin meter nada falso en la secuencia ni marcar error.
      local w = WaitStep(v)
      idle = idle + w
      v:Advance(w)
    elseif not pick then
      -- Ni candidatas ni relleno: esto sí es un fallo de la rotación.
      noPick = noPick + 1
      seq[#seq + 1] = "—"; seqT[#seq] = v.t
      v:Advance(0.5)
    else
      -- prioridad con la que el motor eligió la habilidad (nil = relleno)
      local tier
      for i = 1, (v.nC or 0) do
        if v.cSpell[i] == pick then tier = v.cTier[i]; break end
      end
      local e = v.byName[pick]

      -- 1) ¿es ejecutable?
      local st = v:State(pick)
      if st ~= 3 and not (hold and st == 2) then notExec = notExec + 1 end

      -- 2) mantenimiento antes que relleno o proc
      -- Solo cuenta como "relleno o proc" si es el relleno, o si ESTE lanzamiento aprovecha
      -- de verdad un proc activo. Antes bastaba con que el hechizo PUDIERA ser gratis o
      -- instantáneo (todas las armas del druida feral lo son por Concentración), y se marcaba
      -- como error un mantenimiento perfectamente correcto.
      local bad = (tier == nil) or UsesProc(v, e, N)
      if bad then
        for sp, an in pairs(maint) do
          if sp ~= pick and v:State(sp) == 3 and not v:Aura("target", an, true, true) then
            viol[#viol + 1] = { t = t0, pick = pick, miss = sp }
          end
        end
      end

      -- cooldowns ofrecidos por la rotación
      for i = 1, (v.nC or 0) do
        local cd = cds[v.cSpell[i]]
        if cd and (v.cTier[i] == 1 or v.cTier[i] == 2) then cd.offered = true end
      end

      -- 3) recursos: puntos de combo perdidos y tipos de recurso que se gastan
      if e and e.cp and (v.cp + e.cp) > 5 then cpWaste = cpWaste + (v.cp + e.cp - 5) end
      local cost, pt = PF.Cost(pick), PF.PowerType(pick)
      if cost and pt then spentType[pt] = true end
      if e and e.cost then spentType[e.costType or pt or 3] = true end

      if hold and hold > 0 then v:Advance(hold) end

      -- cooldown: retraso entre "listo" y "usado"
      local cd = cds[pick]
      if cd then
        cd.uses = cd.uses + 1
        -- el primer uso no cuenta como retraso: el arranque (Marca, Picadura, DoTs...) es
        -- inevitable y en combates cortos falseaba la media
        local d = v.t - (ready[pick] or v.t)
        if cd.uses > 1 then
          cd.delay = cd.delay + d
          cd.dn = (cd.dn or 0) + 1
          if d > cd.maxDelay then cd.maxDelay = d end
        end
        ready[pick] = nil
        if not firstUse[pick] then firstUse[pick] = v.t end
      end

      castCount[pick] = (castCount[pick] or 0) + 1
      if #seq < 400 then seq[#seq + 1] = pick; seqT[#seq] = v.t end   -- v.t = segundo real en que se pulsa
      local consumed = Consumed(e, N)
      v:Cast(pick)
      v.casts = v.casts + 1

      -- procs: ¿gastado o caducado?
      local dt = v.t - t0
      for i, p in ipairs(procs) do
        if pLeft0[i] and not v:Aura("player", p.name, false, false) then
          if consumed[p.name] then procUsed = procUsed + 1
          elseif pLeft0[i] <= dt + 0.05 then procExpired = procExpired + 1
          else procUsed = procUsed + 1 end
        end
      end
    end

    -- tras el paso: uptime de auras y tiempo al tope
    local dt = v.t - t0
    if dt > 0 then
      for i, tr in ipairs(trackers) do
        local L0 = left0[i]
        local L1 = v:Aura(tr.unit, tr.name, tr.harmful, true)
        local act
        if L0 then
          if L1 and L1 > L0 - dt + 0.01 then act = dt else act = min(L0, dt) end
        else
          act = L1 and dt or 0
        end
        if not tr.first and (L0 or L1) then tr.first = t0 end
        if tr.first and not inExec then
          tr.span = tr.span + dt
          tr.active = tr.active + act
        end
      end
      for pt, capped in pairs(atCap) do
        if capped then capTime[pt] = (capTime[pt] or 0) + dt end
      end
      zeroN = 0
    else
      zeroN = zeroN + 1
      if zeroN > 5 then v:Advance(0.1); zeroN = 0 end
    end
  end

  -- ------------------------------------------------------------------------
  -- Evaluación
  -- ------------------------------------------------------------------------
  local total = max(v.t, 1)
  local res = { id = sc.id, T = total, steps = steps, seq = seq, seqT = seqT, checks = {}, m = {} }
  local m = res.m
  local nCasts = 0
  for _, n in pairs(castCount) do nCasts = nCasts + n end
  m.casts = nCasts

  -- (1) Orden
  local real = {}
  for _, vi in ipairs(viol) do
    if (castCount[vi.miss] or 0) > 0 then real[#real + 1] = vi end
  end
  m.noPick, m.notExec, m.viol = noPick, notExec, #real
  m.idle = idle
  local okOrder = (noPick == 0 and notExec == 0 and #real == 0)
  local dOrder
  if okOrder then
    dOrder = L(format("%d acciones recomendadas en orden correcto.", nCasts),
               format("%d recommended actions in the right order.", nCasts))
    -- tiempo sin nada lanzable (enfriamientos / recurso): informativo, no es un error
    if idle >= 1 then
      dOrder = dOrder .. L(format(" Espera: %s del tiempo.", Pct(100 * idle / total)),
                           format(" Waiting: %s of the time.", Pct(100 * idle / total)))
    end
  else
    local parts = {}
    if #real > 0 then
      parts[#parts + 1] = L(format("%d× %s antes que %s (con %s faltando y listo)", #real, real[1].pick, real[1].miss, real[1].miss),
                            format("%dx %s before %s (while %s was missing and ready)", #real, real[1].pick, real[1].miss, real[1].miss))
    end
    if notExec > 0 then parts[#parts + 1] = L(notExec .. "× no ejecutable", notExec .. "x not castable") end
    if noPick > 0 then parts[#parts + 1] = L(noPick .. "× sin recomendación", noPick .. "x no recommendation") end
    dOrder = table.concat(parts, " · ")
  end
  res.checks[#res.checks + 1] = { id = "order", ok = okOrder, detail = dOrder }

  -- (2) Buffs y debuffs
  local sum, nT, worst, worstName = 0, 0, 101, nil
  local bad = {}
  for _, tr in ipairs(trackers) do
    if (castCount[tr.spell] or 0) > 0 and tr.span >= 5 then
      local up = 100 * tr.active / tr.span
      sum = sum + up; nT = nT + 1
      if up < worst then worst, worstName = up, tr.name end
      if up < UPTIME_MIN then bad[#bad + 1] = format("%s %s", tr.name, Pct(up)) end
    end
  end
  m.aura = (nT > 0) and (sum / nT) or nil
  local okAura = (#bad == 0)
  local dAura
  if nT == 0 then
    dAura = L("Esta rotación no mantiene buffs ni debuffs largos.", "This rotation maintains no long buffs or debuffs.")
  elseif okAura then
    dAura = L(format("%d auras mantenidas, media %s (peor: %s %s).", nT, Pct(m.aura), worstName, Pct(worst)),
              format("%d auras maintained, average %s (worst: %s %s).", nT, Pct(m.aura), worstName, Pct(worst)))
  else
    dAura = L("Por debajo de " .. UPTIME_MIN .. "%: ", "Below " .. UPTIME_MIN .. "%: ") .. table.concat(bad, ", ")
  end
  res.checks[#res.checks + 1] = { id = "auras", ok = okAura, detail = dAura }

  -- (3) Recursos
  local capWorst, capType = 0, nil
  for pt in pairs(spentType) do
    local p = 100 * (capTime[pt] or 0) / total
    if p > capWorst then capWorst, capType = p, pt end
  end
  -- procs que concedió la propia rotación (solo los que se vigilan, para que el % sea coherente)
  for _, p in ipairs(procs) do procApplied = procApplied + ((v.grantedBy and v.grantedBy[p.name]) or 0) end
  m.capPct, m.cpWaste, m.procExpired = capWorst, cpWaste, procExpired
  m.procUse = (procApplied > 0) and (100 * procUsed / procApplied) or nil
  local waste = {}
  if capWorst > CAP_MAX then
    waste[#waste + 1] = L(format("recurso al tope el %s del tiempo", Pct(capWorst)),
                          format("resource capped %s of the time", Pct(capWorst)))
  end
  if cpWaste > 0 then
    waste[#waste + 1] = L(cpWaste .. " puntos de combo perdidos", cpWaste .. " combo points wasted")
  end
  if procExpired > 0 then
    waste[#waste + 1] = L(procExpired .. " procs caducados sin usar", procExpired .. " procs expired unused")
  end
  local okWaste = (#waste == 0)
  local dWaste
  if okWaste then
    dWaste = L(format("Al tope: %s · combo perdido: 0 · procs caducados: 0.", Pct(capWorst)),
               format("Capped: %s · combo wasted: 0 · procs expired: 0.", Pct(capWorst)))
    if m.procUse then
      dWaste = dWaste .. L(format(" Procs usados: %s.", Pct(m.procUse)), format(" Procs used: %s.", Pct(m.procUse)))
    end
  else
    dWaste = table.concat(waste, " · ")
  end
  res.checks[#res.checks + 1] = { id = "waste", ok = okWaste, detail = dWaste }

  -- (4) Cooldowns
  local nCd, effSum, delaySum = 0, 0, 0
  local cdBad, bigFirst = {}, {}
  for sp, cd in pairs(cds) do
    if cd.offered or cd.uses > 0 then
      nCd = nCd + 1
      -- usos posibles: el último debe empezar al menos un GCD antes del final
      -- (el cooldown empieza a contar desde el primer uso, no desde el segundo 0)
      local possible = max(1, floor((sc.T - 1.5 - (firstUse[sp] or 0)) / cd.cd) + 1)
      local eff = min(1, cd.uses / possible)
      local avg = (cd.uses > 0) and (cd.delay / max(1, cd.dn or 0)) or total
      effSum = effSum + eff
      delaySum = delaySum + avg
      if eff < CD_EFF_MIN then
        cdBad[#cdBad + 1] = L(format("%s usado %d/%d veces", sp, cd.uses, possible),
                              format("%s used %d/%d times", sp, cd.uses, possible))
      elseif avg > CD_DELAY_MAX then
        cdBad[#cdBad + 1] = L(format("%s se retrasa %.1f s de media", sp, avg),
                              format("%s delayed %.1f s on average", sp, avg))
      end
      if cd.cd >= 60 and firstUse[sp] then bigFirst[#bigFirst + 1] = firstUse[sp] end
    end
  end
  m.cdEff = (nCd > 0) and (100 * effSum / nCd) or nil
  m.cdDelay = (nCd > 0) and (delaySum / nCd) or nil
  if #bigFirst >= 2 then
    table.sort(bigFirst)
    if bigFirst[#bigFirst] - bigFirst[1] > CD_ALIGN then
      cdBad[#cdBad + 1] = L(format("cooldowns grandes sin coordinar (primer uso separado %.0f s)", bigFirst[#bigFirst] - bigFirst[1]),
                            format("big cooldowns not aligned (first uses %.0f s apart)", bigFirst[#bigFirst] - bigFirst[1]))
    end
  end
  local okCd = (#cdBad == 0)
  local dCd
  if nCd == 0 then
    dCd = L("La rotación no ofrece cooldowns largos en este escenario.", "The rotation offers no long cooldowns in this scenario.")
  elseif okCd then
    dCd = L(format("%d cooldowns: uso %s de lo posible, retraso medio %.1f s.", nCd, Pct(m.cdEff), m.cdDelay),
            format("%d cooldowns: %s of possible uses, average delay %.1f s.", nCd, Pct(m.cdEff), m.cdDelay))
  else
    dCd = table.concat(cdBad, " · ")
  end
  res.checks[#res.checks + 1] = { id = "cds", ok = okCd, detail = dCd }

  res.pass = 0
  for _, ch in ipairs(res.checks) do if ch.ok then res.pass = res.pass + 1 end end
  return res
end

-- ---------------------------------------------------------------------------
-- API pública
-- ---------------------------------------------------------------------------
PF.simLast = PF.simLast or {}

function PF.Sim_Run(id)
  local sc = Scen(id)
  if not sc then return nil, "scenario" end
  local ok, res, err = pcall(Run, sc)
  PF.V = nil                      -- siempre se vuelve al mundo real
  if not ok then return nil, tostring(res) end
  if not res then return nil, err end
  PF.simLast[id] = res
  return res
end

-- Secuencia recomendada (para el chat)
function PF.Sim_Seq(id, n)
  local r = PF.simLast[id]
  if not r then return "" end
  local out = {}
  for i = 1, min(n or 30, #r.seq) do
    local t = r.seqT and r.seqT[i]
    out[i] = t and format("%s [%.1fs]", r.seq[i], t) or r.seq[i]
  end
  return table.concat(out, " > ")
end

-- ---------------------------------------------------------------------------
-- Referencia y comparación (¿una modificación empeora la rotación anterior?)
-- ---------------------------------------------------------------------------
local function BaseTable()
  if not PulseFlashDB then return nil end
  if type(PulseFlashDB.simBase) ~= "table" then PulseFlashDB.simBase = {} end
  return PulseFlashDB.simBase
end

local function BaseKey(id)
  return PF.GetCharKey() .. "|" .. (PF.spec or 0) .. "|" .. id
end

function PF.Sim_HasBase(id)
  local B = BaseTable()
  return B and B[BaseKey(id)] and true or false
end

function PF.Sim_Save(id)
  local r, B = PF.simLast[id], BaseTable()
  if not (r and B) then return false end
  local seq = {}
  for i = 1, min(80, #r.seq) do seq[i] = r.seq[i] end
  local m = {}
  for k, val in pairs(r.m) do m[k] = val end
  B[BaseKey(id)] = { m = m, seq = seq, pass = r.pass, t = time(),
                     ver = (GetAddOnMetadata and GetAddOnMetadata("PulseFlash", "Version")) or "?" }
  return true
end

-- métrica = { clave, "up" mejor al subir / "down" mejor al bajar, tolerancia, nombre es, nombre en }
local METRICS = {
  { "aura",       "up",   2,   "mantenimiento de auras", "aura uptime" },
  { "procUse",    "up",   5,   "procs usados",           "procs used" },
  { "cdEff",      "up",   5,   "uso de cooldowns",       "cooldown usage" },
  { "casts",      "up",   1,   "acciones",               "actions" },
  { "capPct",     "down", 2,   "tiempo al tope",         "time at cap" },
  { "cpWaste",    "down", 0,   "combo perdido",          "combo wasted" },
  { "procExpired","down", 0,   "procs caducados",        "procs expired" },
  { "cdDelay",    "down", 1.0, "retraso de cooldowns",   "cooldown delay" },
  { "noPick",     "down", 0,   "sin recomendación",      "no recommendation" },
  { "notExec",    "down", 0,   "no ejecutables",         "not castable" },
  { "viol",       "down", 0,   "errores de orden",       "order errors" },
}

-- Devuelve { state = "none"|"same"|"better"|"worse"|"changed", worse = {...}, better = {...}, firstDiff = n }
function PF.Sim_Compare(id)
  local r, B = PF.simLast[id], BaseTable()
  local b = B and B[BaseKey(id)]
  if not r then return { state = "none" } end
  if not b then return { state = "none", noBase = true } end
  local worse, better = {}, {}
  for _, d in ipairs(METRICS) do
    local k, dir, tol = d[1], d[2], d[3]
    local cur, old = r.m[k], b.m[k]
    if cur ~= nil and old ~= nil then
      local name = L(d[4], d[5])
      if dir == "up" then
        if cur < old - tol then worse[#worse + 1] = name
        elseif cur > old + tol then better[#better + 1] = name end
      else
        if cur > old + tol then worse[#worse + 1] = name
        elseif cur < old - tol then better[#better + 1] = name end
      end
    end
  end
  local first
  local n = min(#b.seq, #r.seq, 80)
  for i = 1, n do
    if b.seq[i] ~= r.seq[i] then first = i; break end
  end
  local out = { worse = worse, better = better, firstDiff = first, ver = b.ver, t = b.t }
  if #worse > 0 then out.state = "worse"
  elseif not first and #better == 0 then out.state = "same"
  elseif #better > 0 then out.state = "better"
  else out.state = "changed" end
  return out
end

PF.simLoaded = true
