local CF = PulseFlash

do local c = select(2, UnitClass("player")); if c and c ~= "HUNTER" then return end end
local Aura, Known, First = CF.Aura, CF.Known, CF.First
local Maintain, Cast = CF.Maintain, CF.Cast

-- Umbrales
local ARCANE_MIN_MANA = 0.30        -- Disparo arcano solo con maná de sobra
local ARCANE_MIN_MANA_MM = 0.50     -- Puntería es más estricta: Disparo certero manda
local MEND_PET_HP = 0.50
local KILL_SHOT_HP = 0.20
local DOT_MIN_LIFE = 8              -- no poner Picadura si el objetivo muere antes
local READINESS_RF_CD = 30          -- Presteza solo si Fuego rápido sigue en cooldown

local function PetHurt()
  if not UnitExists("pet") or UnitIsDead("pet") then return false end
  local m = UnitHealthMax("pet")
  return m and m > 0 and (UnitHealth("pet") / m) < MEND_PET_HP
end

-- Cuerpo a cuerpo: zona muerta del arco (los disparos no funcionan, el golpe sí)
local function InMelee(N)
  if PulseFlash.V and PulseFlash.V.simMode then return false end   -- simulador: a distancia
  return Known(N.RaptorStrike) and IsSpellInRange(N.RaptorStrike, "target") == 1
end

local function evaluate(c, add, N)
  local spec = c.spec
  local mana = c.manaPct
  local worth = c.worth and CF.Lives(DOT_MIN_LIFE)
  local ss = Aura("target", N.SerpentSting, true, true)

  -- ------------------------------------------------------------------
  -- 1) Mantenimiento: Picadura de serpiente (antes que cualquier proc)
  --    Puntería con Disparo quimera: basta con ponerla una vez (Quimera la renueva)
  -- ------------------------------------------------------------------
  if worth then
    if spec == 2 and Known(N.ChimeraShot) then
      if not ss then Maintain(add, c, N.SerpentSting, nil) end
    else
      Maintain(add, c, N.SerpentSting, ss)
    end
  end

  -- ------------------------------------------------------------------
  -- 2) Procs: Bloquear y cargar hace gratis y sin espera el siguiente disparo
  -- ------------------------------------------------------------------
  if Aura("player", N.LockAndLoad) then
    add(spec == 3 and N.ExplosiveShot or N.ArcaneShot, 1)
  end

  -- Remate
  if c.hp < KILL_SHOT_HP then add(N.KillShot, 1) end

  -- Ordenar matar no gasta GCD: en cuanto está lista se usa, en cualquier rama (antes iba
  -- detrás de los disparos y en Puntería se retrasaba unos 5 s de media)
  add(N.KillCommand, 1)

  -- Área
  if CF.AoE(3) and (mana > ARCANE_MIN_MANA or c.burn) then
    add(N.MultiShot, 1)
    if CF.AoE(5) then Cast(add, N.Volley, 1) end
  end
  -- Trampa explosiva: daño en área con 3+ enemigos (se lanza a los pies)
  if CF.AoE(3) and c.combat and c.hostile then add(N.ExplosiveTrap, 1) end

  -- ------------------------------------------------------------------
  -- 3) Rotación por rama
  -- ------------------------------------------------------------------
  if spec == 3 then
    -- Supervivencia: Disparo explosivo > Flecha negra > Arcano > Firme
    add(N.ExplosiveShot, 1)
    if c.worth then add(N.BlackArrow, 1) end
    if mana > ARCANE_MIN_MANA or c.burn then add(N.ArcaneShot, 1) end
  elseif spec == 2 then
    -- Puntería: Quimera > Certero > Arcano (si sobra maná)
    add(N.ChimeraShot, 1)
    Cast(add, N.AimedShot, 1)
    if mana > ARCANE_MIN_MANA_MM or c.burn then add(N.MultiShot, 1); add(N.ArcaneShot, 1) end
  elseif spec == 1 then
    -- Bestias: Ordenar matar > Múltiple > Certero > Arcano
    if mana > ARCANE_MIN_MANA or c.burn then add(N.MultiShot, 1) end
    Cast(add, N.AimedShot, 1)
    if mana > ARCANE_MIN_MANA or c.burn then add(N.ArcaneShot, 1) end
  else
    add(N.ArcaneShot, 1)
  end

  -- Disparo firme: el relleno principal de las tres ramas. Va como candidata real (la de
  -- menor prioridad) y no solo como "relleno", para que aparezca también como siguiente
  -- habilidad del HUD y en la secuencia del simulador cuando nada más está listo.
  if not InMelee(N) then Cast(add, N.SteadyShot, 1) end

  -- Zona muerta: si estás pegado al objetivo, golpear en vez de disparar
  if InMelee(N) then
    add(N.MongooseBite, 1)
    add(N.RaptorStrike, 1)
  end

  -- ------------------------------------------------------------------
  -- 4) Cooldowns (prioridad 2)
  -- ------------------------------------------------------------------
  if c.worth and not Aura("target", N.HuntersMark, true) then add(N.HuntersMark, 2) end
  if c.combat and c.bigCD then
    -- Fuego rápido no se vuelve a lanzar con su efecto activo, y Presteza solo cuando ya ha
    -- terminado (antes se usaba al instante y se repetía Fuego rápido solapado 1,5 s después)
    local rf = Aura("player", N.RapidFire)
    if not rf and CF.CDok(c, 300) then add(N.RapidFire, 2) end
    if spec == 1 then add(N.BestialWrath, 2) end
    if not rf and Known(N.Readiness) and CF.CD(N.RapidFire) > READINESS_RF_CD then add(N.Readiness, 2) end
  end

  -- ------------------------------------------------------------------
  -- 5) Utilidad (prioridad 3)
  -- ------------------------------------------------------------------
  if CF.EnemyCasting() and IsSpellInRange(N.SilencingShot, "target") == 1 then
    add(N.SilencingShot, 3)
  end
  if c.combat then
    -- Amenaza: Fingir muerte si el jefe te ataca en grupo; Retirada si estás pegado
    if c.boss and CF.Grouped() and CF.TargetsMe() then add(N.FeignDeath, 3) end
    if InMelee(N) and c.php < 0.60 then add(N.Disengage, 3) end
    if c.php < 0.30 then add(N.Deterrence, 3) end
  end
  if c.combat and PetHurt() and not Aura("pet", N.MendPet) and not CF.Pending(N.MendPet) then
    add(N.MendPet, 3)
  end
end

local function filler(c, N)
  -- En movimiento solo disparos instantáneos
  if CF.Moving() then return CF.ReadyFirst(N.ArcaneShot, N.RaptorStrike) end
  if InMelee(N) then return First(N.RaptorStrike, N.ArcaneShot) end
  return First(N.SteadyShot, N.ArcaneShot, N.RaptorStrike)
end

local SIM = {
  SerpentSting = { debuff = { "SerpentSting", dur = 15 } },
  ChimeraShot = { cd = 10, debuff = { "SerpentSting", dur = 15 } },
  AimedShot = { cd = 10 },
  ArcaneShot = { cd = 6, free = "LockAndLoad", freeInstant = false },
  ExplosiveShot = { cd = 6, free = "LockAndLoad", freeInstant = false },
  BlackArrow = { cd = 30, debuff = { "BlackArrow", dur = 15 } },
  KillShot = { cd = 15 },
  KillCommand = { gcd = 0, cd = 60 },
  MultiShot = { cd = 10 },
  SteadyShot = {},
  RapidFire = { gcd = 0, cd = 300, buff = { "RapidFire", dur = 15 } },
  BestialWrath = { gcd = 0, cd = 120 },
  Readiness = { gcd = 0, cd = 180, reset = true, fn = function(V, N) V:SetCD(N.RapidFire, 0) end },
  HuntersMark = { debuff = { "HuntersMark", dur = 300 } },
  SilencingShot = { gcd = 0, cd = 20 },
  ExplosiveTrap = { cd = 30 },
  -- Solo se puede usar tras una esquiva del objetivo (reactiva)
  MongooseBite = { cd = 5, reactive = true },
}
-- Procs del simulador de escenarios (frecuencia media por lanzamiento; ver Project.lua)
local SIMPROCS = {
  { aura = "LockAndLoad", spec = 3, from = { "BlackArrow", "SerpentSting" }, chance = 0.6, dur = 12 },
}
CF.Register("HUNTER", {
  sim = SIM,
  simProcs = SIMPROCS,
  ids = {
    SteadyShot = 56641,  ArcaneShot = 3044,    AimedShot = 19434,
    MultiShot = 2643,    SerpentSting = 1978,  ChimeraShot = 53209,
    ExplosiveShot = 53301, BlackArrow = 3674,  KillShot = 53351,
    KillCommand = 34026, RaptorStrike = 2973,  HuntersMark = 1130,
    RapidFire = 3045,    BestialWrath = 19574, SilencingShot = 34490,
    Deterrence = 19263,  MendPet = 48990,
    AspectViper = 34074, AspectHawk = 13165,   AspectDragonhawk = 61847,

    LockAndLoad = 56343,

    -- Añadidos en la revisión de profundidad
    MongooseBite = 1495, Readiness = 23989,    FeignDeath = 5384,
    Disengage = 781,       Volley = 1510,       ExplosiveTrap = 13813,
  },
  multidot = { [0] = { "SerpentSting" }, [1] = { "SerpentSting" }, [2] = { "SerpentSting" }, [3] = { "SerpentSting" } },
  evaluate = evaluate,
  filler = filler,
})
