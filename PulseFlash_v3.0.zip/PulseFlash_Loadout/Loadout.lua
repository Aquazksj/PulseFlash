-- PulseFlash - Loadout.lua
-- Pestaña "Barra recomendada" / "Recommended bar".
-- Muestra, en una fila de iconos (como una barra de acción), las habilidades
-- que conviene tener colocadas según tu clase y rama de talentos, con la
-- explicación de por qué cada una. Solo lee el libro de hechizos: no toca tus
-- barras ni pulsa nada por ti.
local PF = PulseFlash

local ES, EN = PF.STRINGS.es, PF.STRINGS.en

------------------------------------------------------------------------------
-- Textos del menú (ES / EN; el resto de idiomas cae en inglés)
------------------------------------------------------------------------------
ES.lo_head       = "Habilidades que deberías tener en la barra"
EN.lo_head       = "Abilities you should have on your bar"
ES.lo_info       = "%s - %s - nivel %d"
EN.lo_info       = "%s - %s - level %d"
ES.lo_showAll    = "Mostrar también las que aún no tengo (nivel / talento)"
EN.lo_showAll    = "Also show the ones I don't have yet (level / talent)"
ES.lo_pick       = "Pasa el ratón o haz clic en un icono para ver por qué se recomienda. El número es la casilla sugerida de tu barra."
EN.lo_pick       = "Hover or click an icon to see why it is recommended. The number is the suggested slot on your bar."
ES.lo_missing    = "Aún no la tienes: se aprende con más nivel o con puntos de talento."
EN.lo_missing    = "You don't have it yet: it is learned at a higher level or with talent points."
ES.lo_none       = "Todavía no hay recomendación para esta clase o rama (o aún no has gastado 5 puntos de talento)."
EN.lo_none       = "No recommendation yet for this class or spec (or you haven't spent 5 talent points yet)."
ES.lo_listHead   = "Por qué cada habilidad"
EN.lo_listHead   = "Why each ability"
ES.lo_empty      = "No tienes ninguna de estas habilidades todavía. Marca la casilla de arriba para ver el plan completo."
EN.lo_empty      = "You don't have any of these abilities yet. Tick the box above to see the full plan."
ES.lo_slot       = "Casilla %s"
EN.lo_slot       = "Slot %s"

ES.lt_main = "Daño principal";     EN.lt_main = "Main damage"
ES.lt_dot  = "DoT / mantenimiento"; EN.lt_dot  = "DoT / upkeep"
ES.lt_proc = "Proc";               EN.lt_proc = "Proc"
ES.lt_cd   = "Gran cooldown";      EN.lt_cd   = "Big cooldown"
ES.lt_aoe  = "Área";               EN.lt_aoe  = "AoE"
ES.lt_int  = "Interrupción";       EN.lt_int  = "Interrupt"
ES.lt_def  = "Defensivo";          EN.lt_def  = "Defensive"
ES.lt_buff = "Buff / postura";     EN.lt_buff = "Buff / stance"
ES.lt_res  = "Recursos";           EN.lt_res  = "Resources"
ES.lt_util = "Utilidad";           EN.lt_util = "Utility"

local TAG = {
  main = { "lt_main", 1.00, 0.82, 0.00 },
  dot  = { "lt_dot",  0.40, 0.85, 1.00 },
  proc = { "lt_proc", 0.95, 0.55, 1.00 },
  cd   = { "lt_cd",   1.00, 0.40, 0.25 },
  aoe  = { "lt_aoe",  1.00, 0.65, 0.25 },
  int  = { "lt_int",  0.90, 0.90, 0.90 },
  def  = { "lt_def",  1.00, 0.30, 0.30 },
  buff = { "lt_buff", 0.45, 1.00, 0.55 },
  res  = { "lt_res",  0.45, 0.65, 1.00 },
  util = { "lt_util", 0.70, 0.75, 0.85 },
}

------------------------------------------------------------------------------
-- Datos: LOADOUT[CLASE][rama] = { { ids, etiqueta, razón ES, razón EN }, ... }
-- ids puede ser un número o una lista (se usa el primero que conozcas).
-- Máximo 12 por rama (una fila de barra). Orden = casillas sugeridas 1..12.
-- Ramas = pestaña de talentos 1/2/3 de WotLK.
-- Solo se guardan en memoria los datos de TU clase; el resto del archivo se
-- descarta al terminar de cargar. Cada entrada: { ids, etiqueta, nº de razon, ES, EN }.
local MYCLASS = select(2, UnitClass("player"))

local function S(ids, tag, r, es, en)
  return { ids, tag, es, en, r }
end

-- Razon en el idioma activo; las traducciones (ru, pt, de, fr) llegan en los
-- paquetes de idioma. Si falta la traduccion cae en ingles.
function PF.LoadoutReason(entry)
  local lang = PF.GetLang()
  if lang == "es" then return entry[3] end
  local tr = PF.LOADOUT_TR and PF.LOADOUT_TR[lang]
  return (tr and tr[entry[5]]) or entry[4]
end

local LOADOUT = {}

if MYCLASS == "WARRIOR" then
LOADOUT.WARRIOR = {
  [1] = { -- Armas
    S(12294, "main", 0, "Tu golpe principal: gran daño y aplica Heridas mortales (menos curación recibida). Úsalo cada vez que esté listo.", "Your core strike: big damage plus Mortal Wounds (reduced healing). Use it every time it is ready."),
    S(772, "dot", 1, "Sangrado que mantienes activo en objetivos que van a vivir un rato; aprovecha Golpes sorpresa y Sed de sangre.", "Bleed you keep up on targets that will live a while; fuels Overpower and Taste for Blood."),
    S(7384, "proc", 2, "Se usa tras esquivar el enemigo o con Sed de sangre: daño barato que no puedes perder.", "Used after a dodge or on Taste for Blood: cheap damage you shouldn't miss."),
    S(1680, "main", 3, "Gran daño a todos los cercanos y también a uno; entra siempre que esté listo.", "Big damage to all nearby enemies and also strong on one; use it whenever it is up."),
    S(1464, "proc", 4, "Con el proc Oleada de sangre es instantáneo y de mucho daño; úsalo solo con proc.", "Instant and hard-hitting with the Bloodsurge proc; cast it on proc only."),
    S(5308, "main", 5, "Remate: con el enemigo bajo el 20% de vida es tu mejor gasto de rabia.", "Finisher: below 20% target health it is your best rage spender."),
    S(78, "res", 6, "Gasta la rabia sobrante sin gastar tiempo global; evita llegar al tope de rabia.", "Dumps spare rage off the global cooldown so you never cap out."),
    S(46924, "cd", 7, "Torbellino de cuchillas: daño sostenido a todos alrededor; úsalo en jefes y grupos.", "Sustained damage to everything around you; use on bosses and packs."),
    S(1719, "cd", 8, "Temeridad: mucho más crítico durante unos segundos; combínalo con tus otros cooldowns.", "Recklessness: much more crit for a few seconds; stack it with your other cooldowns."),
    S(2687, "res", 9, "Rabia instantánea: sácala para arrancar el combate sin esperar a que se acumule.", "Instant rage: use it to start the fight without waiting for rage to build."),
    S(12328, "aoe", 10, "Golpes de barrido: tus ataques saltan a un segundo enemigo; esencial contra varios objetivos.", "Your attacks hit a second target; essential against multiple enemies."),
    S(6552, "int", 11, "Zurrar: corta el lanzamiento del enemigo y lo silencia unos segundos.", "Pummel: interrupts the enemy cast and silences it briefly."),
  },
  [2] = { -- Furia
    S(23881, "main", 12, "Sed de sangre: tu ataque estrella; da daño y cura. Es la prioridad número uno de la rama.", "Bloodthirst: your signature attack, damaging and healing. Top priority of the spec."),
    S(1680, "main", 13, "Torbellino: segundo pilar de la rotación; sale con Sed de sangre en cada hueco.", "Whirlwind: second pillar of the rotation; alternates with Bloodthirst."),
    S(1464, "proc", 14, "Con el proc Oleada de sangre es un golpe instantáneo muy fuerte; úsalo solo con proc.", "A strong instant hit with the Bloodsurge proc; use it on proc only."),
    S(5308, "main", 15, "Remate bajo el 20% de vida del objetivo; con Muerte súbita se puede usar antes.", "Finisher below 20% health; Sudden Death lets you use it earlier."),
    S(78, "res", 16, "Golpe heroico: gasta la rabia sobrante sin gastar tiempo global.", "Heroic Strike: spends excess rage without using the global cooldown."),
    S(34428, "main", 17, "Carga victoriosa: golpe gratis tras matar a un enemigo; barato y cura un poco.", "Free strike after a kill; cheap and heals a little."),
    S(1719, "cd", 18, "Temeridad: más crítico durante unos segundos; gran cooldown de daño.", "Recklessness: more crit for a few seconds; a major damage cooldown."),
    S(12292, "cd", 19, "Deseo de muerte: más daño a costa de recibir más; úsalo con Temeridad.", "Death Wish: more damage at the cost of taking more; pair with Recklessness."),
    S(2687, "res", 20, "Ira de sangre: rabia instantánea para arrancar combates y mantener el ritmo.", "Bloodrage: instant rage to open fights and keep the rhythm."),
    S(2458, "buff", 21, "Postura rabiosa: la postura de más daño para Furia; ponla antes de pelear.", "Berserker Stance: the highest-damage stance for Fury; set it before fighting."),
    S(6673, "buff", 22, "Grito de batalla: aumenta tu poder de ataque; mantenlo siempre activo.", "Battle Shout: boosts your attack power; keep it up at all times."),
    S(6552, "int", 23, "Zurrar: corta el lanzamiento del enemigo.", "Pummel: interrupts the enemy cast."),
  },
  [3] = { -- Protección
    S(23922, "main", 24, "Golpe de escudo: tu mayor daño y amenaza; úsalo en cuanto esté listo.", "Shield Slam: your biggest damage and threat; use it as soon as it is ready."),
    S(6572, "main", 25, "Venganza: tras esquivar o parar, amenaza fuerte y barata.", "Revenge: strong, cheap threat after a dodge or parry."),
    S(20243, "main", 26, "Devastar: relleno que apila Debilitar armadura y genera amenaza constante.", "Devastate: filler that stacks Sunder Armor and builds steady threat."),
    S(6343, "aoe", 27, "Trueno: reduce la velocidad de ataque de los enemigos y da amenaza en área.", "Thunder Clap: slows enemy attack speed and gives AoE threat."),
    S(78, "res", 28, "Golpe heroico: gasta rabia sobrante en amenaza extra.", "Heroic Strike: turns spare rage into extra threat."),
    S(71, "buff", 29, "Actitud defensiva: la postura base del tanque; menos daño recibido.", "Defensive Stance: the tank's base stance; less damage taken."),
    S(469, "buff", 30, "Grito de mando: sube la salud máxima de todo el grupo; mantenlo.", "Commanding Shout: raises max health for the whole group; keep it up."),
    S(2687, "res", 31, "Ira de sangre: rabia instantánea para generar amenaza al inicio.", "Bloodrage: instant rage for threat at the start."),
    S(55694, "def", 32, "Regeneración furiosa: te cura mientras recibes golpes; úsala cuando bajes de vida.", "Enraged Regeneration: heals you while taking hits; use it when health drops."),
    S(6552, "int", 33, "Zurrar: corta lanzamientos peligrosos.", "Pummel: stops dangerous casts."),
  },
}
end

if MYCLASS == "PALADIN" then
LOADOUT.PALADIN = {
  [2] = { -- Protección
    S(20925, "def", 34, "Escudo sagrado: bloquea más y devuelve daño sagrado; mantenlo siempre activo.", "Holy Shield: more blocks and returns Holy damage; keep it up at all times."),
    S(53600, "main", 35, "Escudo del virtuoso: gran daño y amenaza basado en el valor de bloqueo.", "Shield of the Righteous: big damage and threat based on block value."),
    S(53595, "main", 36, "Martillo del honrado: amenaza en área, ideal para tener a todos pegados a ti.", "Hammer of the Righteous: AoE threat that keeps everything on you."),
    S(31935, "main", 37, "Escudo del vengador: daño, amenaza y silencio al primer enemigo.", "Avenger's Shield: damage, threat and a silence on the first target."),
    S({53408, 20271}, "main", 38, "Juicio: daño y aplica el efecto de Sabiduría o Luz; úsalo en cuanto esté listo.", "Judgement: damage and the Wisdom/Light effect; use it as soon as it is ready."),
    S(26573, "aoe", 39, "Consagración: amenaza en el suelo; relleno con maná.", "Consecration: ground threat; mana filler."),
    S(31801, "buff", 40, "Sello de venganza: daño adicional constante y amenaza.", "Seal of Vengeance: steady extra damage and threat."),
    S(498, "def", 41, "Protección divina: reduce mucho el daño recibido un momento.", "Divine Protection: sharply reduces damage taken for a moment."),
    S(642, "def", 42, "Escudo divino: te vuelve invulnerable unos segundos; botón de pánico.", "Divine Shield: makes you invulnerable for a few seconds; panic button."),
    S(853, "util", 43, "Martillo de justicia: aturde al enemigo para cortar daño o lanzamientos.", "Hammer of Justice: stuns to stop damage or casts."),
    S(465, "buff", 44, "Aura de devoción: más armadura para todo el grupo.", "Devotion Aura: more armor for the whole group."),
  },
  [3] = { -- Reprensión
    S({53408, 20271}, "main", 45, "Juicio: daño y efecto extra; lo primero que sale en cuanto está disponible.", "Judgement: damage plus an extra effect; first thing to fire when it is up."),
    S(35395, "main", 46, "Golpe del cruzado: tu ataque principal; genera daño constante y es de prioridad alta.", "Crusader Strike: your main attack; steady damage and high priority."),
    S(53385, "main", 47, "Tormenta divina: daño a varios objetivos y también fuerte a uno.", "Divine Storm: damage to several targets and strong on one."),
    S(879, "proc", 48, "Exorcismo: con el proc Arte de la guerra es instantáneo y muy fuerte.", "Exorcism: instant and very strong with the Art of War proc."),
    S(24275, "main", 49, "Martillo de ira: remate bajo el 20% de vida del objetivo.", "Hammer of Wrath: finisher below 20% target health."),
    S(26573, "aoe", 50, "Consagración: relleno con maná y daño en área.", "Consecration: mana filler and AoE damage."),
    S(31884, "cd", 51, "Cólera vengativa: más daño unos segundos; gran cooldown de daño.", "Avenging Wrath: more damage for a few seconds; major damage cooldown."),
    S(54428, "res", 52, "Súplica divina: recupera maná cuando te falta; úsala sin pensar en daño.", "Divine Plea: restores mana when you run low."),
    S(31801, "buff", 53, "Sello de venganza: base de daño sostenido en la rama.", "Seal of Vengeance: the sustained damage base of the spec."),
    S(853, "util", 54, "Martillo de justicia: aturdimiento para cortar lanzamientos o huir.", "Hammer of Justice: a stun to stop casts or escape."),
    S(642, "def", 55, "Escudo divino: te vuelve invulnerable unos segundos.", "Divine Shield: makes you invulnerable for a few seconds."),
    S(7294, "buff", 56, "Aura de represalia: devuelve daño a los atacantes cuerpo a cuerpo.", "Retribution Aura: returns damage to melee attackers."),
  },
}
end

if MYCLASS == "ROGUE" then
LOADOUT.ROGUE = {
  [1] = { -- Asesinato
    S(1329, "main", 57, "Mutilar: tu generador de puntos de combo y mayor daño de la rama.", "Mutilate: your combo-point builder and biggest damage of the spec."),
    S(32645, "main", 58, "Envenenar: remate que consume Veneno mortal; úsalo con 4-5 puntos.", "Envenom: finisher that consumes Deadly Poison; use at 4-5 points."),
    S(1943, "dot", 59, "Ruptura: sangrado que mantienes con puntos de combo en objetivos largos.", "Rupture: bleed you keep up with combo points on long fights."),
    S(5171, "dot", 60, "Rajar y despedazar: sube tu velocidad de ataque; nunca debe caerse.", "Slice and Dice: raises attack speed; must never drop."),
    S(51662, "cd", 61, "Hambre de sangre: más daño mientras haya un sangrado en el objetivo.", "Hunger for Blood: more damage while a bleed is on the target."),
    S(14177, "cd", 62, "Sangre fría: tu siguiente remate es crítico seguro; úsalo con Envenenar.", "Cold Blood: your next finisher crits for sure; pair with Envenom."),
    S(51723, "aoe", 63, "Abanico de cuchillos: daño en área con ventaja de venenos.", "Fan of Knives: AoE damage that spreads poisons."),
    S(1766, "int", 64, "Patada: corta el lanzamiento del enemigo.", "Kick: interrupts the enemy cast."),
    S(1856, "def", 65, "Desaparecer: sales del combate y reinicias amenaza.", "Vanish: drops combat and resets threat."),
    S(5277, "def", 66, "Evasión: esquivas casi todos los golpes cuerpo a cuerpo un rato.", "Evasion: dodge most melee attacks for a while."),
    S(31224, "def", 67, "Capa de sombras: inmune a hechizos un momento.", "Cloak of Shadows: spell immunity for a moment."),
    S(1784, "buff", 68, "Sigilo: para abrir combate con ventaja y reiniciar secuencias.", "Stealth: opens fights with advantage and restarts sequences."),
  },
  [2] = { -- Combate
    S(1752, "main", 69, "Golpe siniestro: tu generador de puntos de combo principal.", "Sinister Strike: your main combo-point builder."),
    S(2098, "main", 70, "Eviscerar: remate de daño directo; úsalo con 4-5 puntos tras Rajar y despedazar.", "Eviscerate: direct-damage finisher; use at 4-5 points after Slice and Dice."),
    S(5171, "dot", 71, "Rajar y despedazar: velocidad de ataque; siempre activo.", "Slice and Dice: attack speed; always active."),
    S(1943, "dot", 72, "Ruptura: sangrado para combates largos.", "Rupture: bleed for longer fights."),
    S(13877, "cd", 73, "Torrente de cuchillas: tus golpes saltan a otro enemigo y pegas más rápido.", "Blade Flurry: your hits strike a second enemy and attacks come faster."),
    S(13750, "cd", 74, "Descarga de adrenalina: energía y velocidad extra; tu gran cooldown.", "Adrenaline Rush: extra energy and speed; your big cooldown."),
    S(51690, "cd", 75, "Racha de matanza: teletransportes y ataques sin gastar energía.", "Killing Spree: teleports and free attacks."),
    S(51723, "aoe", 76, "Abanico de cuchillos: daño en área.", "Fan of Knives: AoE damage."),
    S(1766, "int", 64, "Patada: corta el lanzamiento del enemigo.", "Kick: interrupts the enemy cast."),
    S(1856, "def", 77, "Desaparecer: reinicias amenaza o escapas.", "Vanish: reset threat or escape."),
    S(5277, "def", 78, "Evasión: esquiva casi todo cuerpo a cuerpo.", "Evasion: dodge nearly all melee."),
    S(31224, "def", 67, "Capa de sombras: inmune a hechizos un momento.", "Cloak of Shadows: spell immunity for a moment."),
  },
  [3] = { -- Sutileza
    S(16511, "main", 79, "Hemorragia: generador de puntos que además aumenta el daño físico recibido.", "Hemorrhage: point builder that also raises physical damage taken."),
    S(53, "main", 80, "Puñalada trapera: mayor daño desde la espalda del objetivo.", "Backstab: highest damage from behind the target."),
    S(2098, "main", 81, "Eviscerar: remate de daño directo con 4-5 puntos.", "Eviscerate: direct-damage finisher at 4-5 points."),
    S(5171, "dot", 71, "Rajar y despedazar: velocidad de ataque; siempre activo.", "Slice and Dice: attack speed; always active."),
    S(1943, "dot", 72, "Ruptura: sangrado para combates largos.", "Rupture: bleed for longer fights."),
    S(51713, "cd", 82, "Danza de sombras: usa habilidades de sigilo en combate; tu gran cooldown.", "Shadow Dance: use stealth openers in combat; your big cooldown."),
    S(14183, "cd", 83, "Premeditación: puntos de combo gratis antes de abrir.", "Premeditation: free combo points before opening."),
    S(8676, "main", 84, "Emboscada: apertura de gran daño desde sigilo o Danza.", "Ambush: big opening damage from stealth or Dance."),
    S(1766, "int", 64, "Patada: corta el lanzamiento del enemigo.", "Kick: interrupts the enemy cast."),
    S(1856, "def", 85, "Desaparecer: vuelve a sigilo y reinicia amenaza.", "Vanish: back to stealth and reset threat."),
    S(5277, "def", 78, "Evasión: esquiva casi todo cuerpo a cuerpo.", "Evasion: dodge nearly all melee."),
    S(31224, "def", 67, "Capa de sombras: inmune a hechizos un momento.", "Cloak of Shadows: spell immunity for a moment."),
  },
}
end

if MYCLASS == "WARLOCK" then
LOADOUT.WARLOCK = {
  [1] = { -- Aflicción
    S(48181, "main", 86, "Atormentar: gran daño y +daño de tus DoTs; siempre que esté listo.", "Haunt: big damage and boosts your DoTs; use it whenever it is ready."),
    S(30108, "dot", 87, "Aflicción inestable: DoT de mucho daño; renuévalo antes de que acabe.", "Unstable Affliction: heavy DoT; refresh it before it expires."),
    S(172, "dot", 88, "Corrupción: DoT instantáneo; mantenlo en el objetivo.", "Corruption: instant DoT; keep it on the target."),
    S(980, "dot", 89, "Maldición de agonía: daño creciente con el tiempo; mantenla activa.", "Curse of Agony: damage that ramps over time; keep it up."),
    S(686, "main", 90, "Descarga de las sombras: tu relleno; se lanza cuando todo está en marcha.", "Shadow Bolt: your filler; cast it when upkeep is done."),
    S(1120, "main", 91, "Drenar alma: daño potente con el objetivo bajo el 25% de vida.", "Drain Soul: strong damage at 25% target health or less."),
    S(1454, "res", 92, "Toque de vida: convierte vida en maná; úsalo cuando el maná baje.", "Life Tap: turns health into mana; use it when mana runs low."),
    S(6789, "util", 93, "Espiral de la muerte: daño y miedo; también cura un poco.", "Death Coil: damage and fear; also heals a little."),
    S(28176, "buff", 94, "Armadura vil: más daño de sombra y fuego; mantenla siempre.", "Fel Armor: more shadow and fire damage; keep it up."),
  },
  [2] = { -- Demonología
    S(47241, "cd", 95, "Metamorfosis: más daño y habilidades de demonio; úsala en jefes.", "Metamorphosis: more damage and demon abilities; use on bosses."),
    S(348, "dot", 96, "Inmolar: DoT de fuego; refréscalo antes de que expire.", "Immolate: fire DoT; refresh before it expires."),
    S(172, "dot", 88, "Corrupción: DoT instantáneo; mantenlo en el objetivo.", "Corruption: instant DoT; keep it on the target."),
    S(603, "dot", 97, "Maldición de condena: gran daño diferido en jefes largos.", "Curse of Doom: big delayed damage on long boss fights."),
    S(6353, "proc", 98, "Fuego de alma: con el proc Diezmar es un gran golpe rápido.", "Soul Fire: a big fast hit with the Decimation proc."),
    S(686, "main", 99, "Descarga de las sombras: tu relleno principal.", "Shadow Bolt: your main filler."),
    S(1454, "res", 100, "Toque de vida: convierte vida en maná.", "Life Tap: turns health into mana."),
    S(1120, "main", 101, "Drenar alma: usa cuando el objetivo esté bajo el 25%.", "Drain Soul: use when the target is at 25% or less."),
    S(6789, "util", 102, "Espiral de la muerte: daño y miedo.", "Death Coil: damage and fear."),
    S(28176, "buff", 103, "Armadura vil: más daño; mantenla siempre.", "Fel Armor: more damage; keep it up."),
  },
  [3] = { -- Destrucción
    S(348, "dot", 104, "Inmolar: DoT de fuego base; sigue siendo la pieza clave de la rama.", "Immolate: base fire DoT; still the key piece of the spec."),
    S(17962, "main", 105, "Conflagrar: gran daño que consume Inmolar; úsalo en cuanto esté listo.", "Conflagrate: big damage that consumes Immolate; use it as soon as it is ready."),
    S(50796, "main", 106, "Descarga del caos: tu golpe de mayor daño; no puede resistirse.", "Chaos Bolt: your biggest hit; cannot be resisted."),
    S(29722, "main", 107, "Incinerar: tu relleno de fuego; es la base de tu rotación.", "Incinerate: your fire filler; the base of your rotation."),
    S(172, "dot", 88, "Corrupción: DoT instantáneo; mantenlo en el objetivo.", "Corruption: instant DoT; keep it on the target."),
    S(603, "dot", 97, "Maldición de condena: gran daño diferido en jefes largos.", "Curse of Doom: big delayed damage on long boss fights."),
    S(6353, "main", 108, "Fuego de alma: gran golpe lento; úsalo cuando el objetivo esté bajo vida.", "Soul Fire: a big slow hit; use it on low-health targets."),
    S(1454, "res", 100, "Toque de vida: convierte vida en maná.", "Life Tap: turns health into mana."),
    S(6789, "util", 102, "Espiral de la muerte: daño y miedo.", "Death Coil: damage and fear."),
    S(28176, "buff", 103, "Armadura vil: más daño; mantenla siempre.", "Fel Armor: more damage; keep it up."),
  },
}
end

if MYCLASS == "PRIEST" then
LOADOUT.PRIEST = {
  [3] = { -- Sombras
    S(15473, "buff", 109, "Forma de las sombras: necesaria para tu daño; ponla antes de pelear.", "Shadowform: required for your damage; set it before fighting."),
    S(34914, "dot", 110, "Toque vampírico: DoT que además te devuelve maná; renuévalo siempre.", "Vampiric Touch: DoT that also returns mana; always refresh it."),
    S(589, "dot", 111, "Palabra de las sombras: dolor: DoT base; mantenlo en el objetivo.", "Shadow Word: Pain: base DoT; keep it on the target."),
    S(2944, "dot", 112, "Plaga devoradora: DoT de gran daño; refréscalo al terminar.", "Devouring Plague: heavy DoT; refresh it when it ends."),
    S(8092, "main", 113, "Explosión mental: gran daño directo; úsalo cada vez que esté listo.", "Mind Blast: big direct damage; use it each time it is ready."),
    S(32379, "main", 114, "Palabra de las sombras: muerte: remate bajo el 25% de vida del objetivo.", "Shadow Word: Death: finisher below 25% target health."),
    S(15407, "main", 115, "Aguijón mental: tu relleno principal; se canaliza entre los demás.", "Mind Flay: your main filler; channel it between the rest."),
    S(34433, "cd", 116, "Sombra maligna: da maná y daño; úsala en cuanto el maná baje.", "Shadowfiend: gives mana and damage; use it as mana drops."),
    S(47585, "def", 117, "Dispersión: reduce daño recibido y recupera maná; botón de emergencia.", "Dispersion: reduces damage taken and restores mana; emergency button."),
    S(588, "buff", 118, "Fuego interior: más armadura y poder; mantenlo siempre activo.", "Inner Fire: more armor and power; keep it active."),
    S(17, "def", 119, "Palabra de poder: escudo: absorbe daño; útil al inicio y en emergencias.", "Power Word: Shield: absorbs damage; handy at the start and in emergencies."),
    S(8122, "util", 120, "Alarido psíquico: miedo en área para sacarte de problemas.", "Psychic Scream: AoE fear to get out of trouble."),
  },
}
end

if MYCLASS == "SHAMAN" then
LOADOUT.SHAMAN = {
  [1] = { -- Elemental
    S(51505, "main", 121, "Ráfaga de lava: gran daño; úsala siempre que esté lista y con Choque de llamas activo.", "Lava Burst: big damage; use whenever ready with Flame Shock up."),
    S(8050, "dot", 122, "Choque de llamas: DoT que potencia Ráfaga de lava; renuévalo siempre.", "Flame Shock: DoT that empowers Lava Burst; always refresh it."),
    S(403, "main", 123, "Relámpago: tu relleno principal; rápido y barato.", "Lightning Bolt: your main filler; fast and cheap."),
    S(421, "aoe", 124, "Cadena de relámpagos: daño a varios objetivos.", "Chain Lightning: damage to several targets."),
    S(8042, "main", 125, "Choque de tierra: daño instantáneo en movimiento.", "Earth Shock: instant damage while moving."),
    S(16166, "cd", 126, "Maestría elemental: tu siguiente hechizo es instantáneo y más fuerte.", "Elemental Mastery: your next spell is instant and stronger."),
    S(2894, "cd", 127, "Tótem de elemental de fuego: invoca un aliado de gran daño; úsalo en jefes.", "Fire Elemental Totem: summons a high-damage ally; use on bosses."),
    S(51490, "aoe", 128, "Tormenta: daño en área y empuje; útil también como defensa.", "Thunderstorm: AoE damage and knockback; also defensive."),
    S(57994, "int", 129, "Choque de viento: corta el lanzamiento del enemigo.", "Wind Shear: interrupts the enemy cast."),
    S({52127, 324}, "buff", 130, "Escudo: mantén Escudo de agua o de relámpagos; el de agua da maná.", "Shield: keep Water Shield or Lightning Shield; Water gives mana."),
  },
  [2] = { -- Mejora
    S(17364, "main", 131, "Golpe tormenta: tu mejor ataque de daño; úsalo en cuanto esté listo.", "Stormstrike: your best damaging attack; use it as soon as it is ready."),
    S(60103, "main", 132, "Latigazo de lava: daño potente que aprovecha tu arma de llama.", "Lava Lash: strong damage using your flame weapon."),
    S(8050, "dot", 133, "Choque de llamas: DoT; renuévalo y aprovecha su daño.", "Flame Shock: DoT; refresh it and use its damage."),
    S(8042, "main", 134, "Choque de tierra: daño instantáneo cuando lo permite el temporizador.", "Earth Shock: instant damage when the timer allows."),
    S(403, "proc", 135, "Relámpago: con 5 cargas de Arma maelstrom es instantáneo y muy fuerte.", "Lightning Bolt: instant and powerful with 5 Maelstrom Weapon stacks."),
    S(421, "aoe", 136, "Cadena de relámpagos: con 5 cargas de Maelstrom, daño en área instantáneo.", "Chain Lightning: instant AoE with 5 Maelstrom stacks."),
    S(51533, "cd", 137, "Espíritu feral: lobos que pelean contigo; gran cooldown.", "Feral Spirit: wolves that fight with you; big cooldown."),
    S(30823, "res", 138, "Rabia chamánica: más daño y menos recibido, y recupera maná.", "Shamanistic Rage: more damage, less taken, and restores mana."),
    S(2894, "cd", 139, "Tótem de elemental de fuego: aliado de daño; úsalo en jefes.", "Fire Elemental Totem: damage ally; use on bosses."),
    S(57994, "int", 129, "Choque de viento: corta el lanzamiento del enemigo.", "Wind Shear: interrupts the enemy cast."),
    S(8232, "buff", 140, "Arma de viento furioso: arma principal; da ataques extra.", "Windfury Weapon: main hand; grants extra attacks."),
    S(8024, "buff", 141, "Arma de lengua de fuego: arma secundaria; potencia el daño.", "Flametongue Weapon: off hand; boosts damage."),
  },
}
end

if MYCLASS == "MAGE" then
LOADOUT.MAGE = {
  [1] = { -- Arcano
    S(30451, "main", 142, "Explosión arcana: tu hechizo principal; apila cargas y sube el daño.", "Arcane Blast: your main spell; stacks charges and raises damage."),
    S(5143, "proc", 143, "Misiles arcanos: con el proc Barrera de misiles es un gran daño canalizado.", "Arcane Missiles: big channeled damage with the Missile Barrage proc."),
    S(44781, "main", 144, "Ráfaga arcana: daño instantáneo; útil para vaciar las cargas.", "Arcane Barrage: instant damage; useful to dump charges."),
    S(12042, "cd", 145, "Poder arcano: más daño unos segundos; gran cooldown.", "Arcane Power: more damage for a few seconds; big cooldown."),
    S(12043, "cd", 146, "Presencia de ánimo: tu siguiente hechizo es instantáneo.", "Presence of Mind: your next spell is instant."),
    S(55342, "cd", 147, "Imagen espejo: copias que lanzan por ti; úsala en jefes.", "Mirror Image: copies that cast for you; use on bosses."),
    S(12051, "res", 148, "Evocación: recupera maná; úsala cuando falte.", "Evocation: restores mana; use it when you run low."),
    S(2139, "int", 149, "Contrahechizo: corta el lanzamiento del enemigo.", "Counterspell: interrupts the enemy cast."),
    S(1449, "aoe", 150, "Explosión arcana (área): daño a varios cercanos.", "Arcane Explosion: damage to several nearby enemies."),
    S(45438, "def", 151, "Bloque de hielo: te vuelve inmune un momento; botón de pánico.", "Ice Block: makes you immune for a moment; panic button."),
    S({30482, 6117}, "buff", 152, "Armadura: Armadura de mago o Fundida; mejora tu daño y maná.", "Armor: Mage or Molten Armor; improves damage and mana."),
  },
  [2] = { -- Fuego
    S(44457, "dot", 153, "Bomba viviente: DoT de gran daño; mantenla y renuévala.", "Living Bomb: heavy DoT; keep it up and refresh it."),
    S(11366, "proc", 154, "Piroexplosión: con Racha caliente es instantáneo y muy fuerte.", "Pyroblast: instant and very strong with the Hot Streak proc."),
    S(133, "main", 155, "Bola de fuego: tu relleno principal; potencia daño y crítico.", "Fireball: your main filler; boosts damage and crit."),
    S(11129, "cd", 156, "Combustión: más críticos; úsala junto a otros cooldowns.", "Combustion: more crits; use it with other cooldowns."),
    S(55342, "cd", 157, "Imagen espejo: copias que lanzan por ti.", "Mirror Image: copies that cast for you."),
    S(2120, "aoe", 158, "Lluvia de fuego: daño en área; útil con muchos enemigos.", "Flamestrike: AoE damage; good with many enemies."),
    S(12051, "res", 159, "Evocación: recupera maná.", "Evocation: restores mana."),
    S(2139, "int", 149, "Contrahechizo: corta el lanzamiento del enemigo.", "Counterspell: interrupts the enemy cast."),
    S(45438, "def", 160, "Bloque de hielo: botón de pánico.", "Ice Block: panic button."),
    S({30482, 6117}, "buff", 161, "Armadura fundida: más daño de fuego; mantenla.", "Molten Armor: more fire damage; keep it up."),
  },
  [3] = { -- Escarcha
    S(116, "main", 162, "Descarga de escarcha: tu hechizo principal de relleno.", "Frostbolt: your main filler spell."),
    S(44614, "proc", 163, "Descarga de pirofrío: con Congelación cerebral es instantáneo y fuerte.", "Frostfire Bolt: instant and strong with Brain Freeze."),
    S(30455, "main", 164, "Lanza de hielo: daño extra con Dedos de escarcha o congelado.", "Ice Lance: bonus damage with Fingers of Frost or frozen targets."),
    S(44572, "main", 165, "Congelación profunda: gran daño y aturdimiento si el objetivo está congelado.", "Deep Freeze: big damage and a stun on frozen targets."),
    S(12472, "cd", 166, "Venas heladas: más celeridad unos segundos; gran cooldown.", "Icy Veins: more haste for a few seconds; big cooldown."),
    S(11958, "cd", 167, "Frío glacial: reinicia tus cooldowns de escarcha.", "Cold Snap: resets your frost cooldowns."),
    S(31687, "buff", 168, "Elemental de agua: tu mascota de daño; mantenla invocada.", "Water Elemental: your damage pet; keep it summoned."),
    S(55342, "cd", 157, "Imagen espejo: copias que lanzan por ti.", "Mirror Image: copies that cast for you."),
    S(2139, "int", 149, "Contrahechizo: corta el lanzamiento del enemigo.", "Counterspell: interrupts the enemy cast."),
    S(45438, "def", 160, "Bloque de hielo: botón de pánico.", "Ice Block: panic button."),
    S(12051, "res", 159, "Evocación: recupera maná.", "Evocation: restores mana."),
    S({30482, 6117}, "buff", 152, "Armadura: Mago o Fundida; mejora tu daño y maná.", "Armor: Mage or Molten Armor; improves damage and mana."),
  },
}
end

if MYCLASS == "DEATHKNIGHT" then
LOADOUT.DEATHKNIGHT = {
  [1] = { -- Sangre
    S(55050, "main", 169, "Golpe de corazón: tu gran golpe de runas de sangre.", "Heart Strike: your big blood-rune strike."),
    S(49998, "main", 170, "Golpe de muerte: daño y cura según el daño recibido.", "Death Strike: damage and healing based on recent damage taken."),
    S(45477, "dot", 171, "Toque de hielo: aplica Fiebre de escarcha.", "Icy Touch: applies Frost Fever."),
    S(45462, "dot", 172, "Golpe de plaga: aplica Plaga de sangre.", "Plague Strike: applies Blood Plague."),
    S(48721, "aoe", 173, "Hervor de sangre: daño en área para varios enemigos.", "Blood Boil: AoE damage for several enemies."),
    S(50842, "aoe", 174, "Pestilencia: propaga tus enfermedades.", "Pestilence: spreads your diseases."),
    S(49028, "cd", 175, "Runa danzante: golpes extra y más defensa; gran cooldown.", "Dancing Rune Weapon: extra strikes and more defense; big cooldown."),
    S(47568, "res", 176, "Potenciar arma rúnica: recupera todas tus runas.", "Empower Rune Weapon: refreshes all your runes."),
    S(47541, "main", 177, "Espiral de la muerte: gasta poder rúnico en daño.", "Death Coil: spends runic power for damage."),
    S(47528, "int", 178, "Congelar mente: corta el lanzamiento del enemigo.", "Mind Freeze: interrupts the enemy cast."),
    S(48707, "def", 179, "Caparazón antimagia: absorbe daño mágico.", "Anti-Magic Shell: absorbs magic damage."),
    S(48266, "buff", 180, "Presencia de sangre: la presencia de tanque/Sangre.", "Blood Presence: the Blood/tank presence."),
  },
  [2] = { -- Escarcha
    S(45477, "dot", 181, "Toque de hielo: aplica Fiebre de escarcha; mantenla activa.", "Icy Touch: applies Frost Fever; keep it up."),
    S(45462, "dot", 182, "Golpe de plaga: aplica Plaga de sangre; mantenla activa.", "Plague Strike: applies Blood Plague; keep it up."),
    S(49020, "main", 183, "Aniquilar: tu mayor daño; usa runas de Escarcha y Profanas.", "Obliterate: your biggest damage; uses Frost and Unholy runes."),
    S(49143, "main", 184, "Golpe de escarcha: gasta poder rúnico en gran daño.", "Frost Strike: spends runic power for big damage."),
    S(49184, "proc", 185, "Aullido helado: con Máquina asesina/Rime es instantáneo y fuerte.", "Howling Blast: instant and strong with Killing Machine/Rime."),
    S(45902, "main", 186, "Golpe de sangre: usa runas de sangre cuando sobran.", "Blood Strike: uses blood runes when spare."),
    S(51271, "cd", 187, "Armadura inquebrantable: más daño y armadura; gran cooldown.", "Unbreakable Armor: more damage and armor; big cooldown."),
    S(47568, "res", 176, "Potenciar arma rúnica: recupera todas tus runas.", "Empower Rune Weapon: refreshes all your runes."),
    S(47541, "main", 188, "Espiral de la muerte: gasta poder rúnico si no hay Golpe de escarcha.", "Death Coil: spends runic power if Frost Strike isn't available."),
    S(47528, "int", 178, "Congelar mente: corta el lanzamiento del enemigo.", "Mind Freeze: interrupts the enemy cast."),
    S(57330, "buff", 189, "Cuerno del invierno: da fuerza y agilidad al grupo.", "Horn of Winter: gives strength and agility to the group."),
    S(48792, "def", 190, "Entereza helada: reduce el daño recibido; defensa.", "Icebound Fortitude: reduces damage taken; defense."),
  },
  [3] = { -- Profano
    S(45477, "dot", 171, "Toque de hielo: aplica Fiebre de escarcha.", "Icy Touch: applies Frost Fever."),
    S(45462, "dot", 172, "Golpe de plaga: aplica Plaga de sangre.", "Plague Strike: applies Blood Plague."),
    S(55090, "main", 191, "Golpe de la plaga: tu golpe principal; gran daño con las enfermedades.", "Scourge Strike: your main strike; big damage with diseases up."),
    S(45902, "main", 186, "Golpe de sangre: usa runas de sangre cuando sobran.", "Blood Strike: uses blood runes when spare."),
    S(47541, "main", 177, "Espiral de la muerte: gasta poder rúnico en daño.", "Death Coil: spends runic power for damage."),
    S(49206, "cd", 192, "Invocar gárgola: gran daño a distancia; úsala en jefes.", "Summon Gargoyle: big ranged damage; use on bosses."),
    S(46584, "buff", 193, "Levantar muerto: invoca tu necrófago; mantenlo activo.", "Raise Dead: summons your ghoul; keep it active."),
    S(49938, "aoe", 194, "Muerte y descomposición: daño en área en el suelo.", "Death and Decay: ground AoE damage."),
    S(47568, "res", 176, "Potenciar arma rúnica: recupera todas tus runas.", "Empower Rune Weapon: refreshes all your runes."),
    S(47528, "int", 178, "Congelar mente: corta el lanzamiento del enemigo.", "Mind Freeze: interrupts the enemy cast."),
    S(48265, "buff", 195, "Presencia profana: más velocidad de ataque; la de daño de la rama.", "Unholy Presence: more attack speed; the damage presence of the spec."),
    S(57330, "buff", 189, "Cuerno del invierno: da fuerza y agilidad al grupo.", "Horn of Winter: gives strength and agility to the group."),
  },
}
end

if MYCLASS == "DRUID" then
LOADOUT.DRUID = {
  [1] = { -- Equilibrio
    S(24858, "buff", 196, "Forma de lechúcico lunar: necesaria para tu daño; ponla antes de pelear.", "Moonkin Form: required for your damage; set it before fighting."),
    S(8921, "dot", 197, "Fuego lunar: DoT que puede dar Eclipse lunar; mantenlo en el objetivo.", "Moonfire: DoT that can trigger Lunar Eclipse; keep it on the target."),
    S(5570, "dot", 198, "Enjambre de insectos: DoT que puede dar Eclipse solar; mantenlo.", "Insect Swarm: DoT that can trigger Solar Eclipse; keep it up."),
    S(5176, "main", 199, "Cólera: aumenta tu daño solar y activa Eclipse lunar; relleno.", "Wrath: raises solar damage and triggers Lunar Eclipse; filler."),
    S(2912, "main", 200, "Fuego estelar: gran daño durante el Eclipse lunar; activa el solar al terminar.", "Starfire: big damage during Lunar Eclipse; triggers Solar after it ends."),
    S(48505, "cd", 201, "Lluvia estelar: daño en área sostenido; gran cooldown.", "Starfall: sustained AoE damage; big cooldown."),
    S(33831, "cd", 202, "Fuerza de la naturaleza: invoca árboles que pelean por ti.", "Force of Nature: summons treants that fight for you."),
    S(16857, "util", 203, "Fuego feérico: reduce la armadura del enemigo y revela sigilo.", "Faerie Fire: reduces enemy armor and reveals stealth."),
    S(22812, "def", 204, "Corteza: reduce el daño recibido y evita interrupciones.", "Barkskin: reduces damage taken and prevents pushback."),
  },
  [2] = { -- Feral (gato)
    S(768, "buff", 205, "Forma felina: base de tu daño; ponla antes de pelear.", "Cat Form: the base of your damage; set it before fighting."),
    S(33876, "dot", 206, "Mutilar: aplica sangrado y es tu golpe con mayor daño.", "Mangle: applies bleed and is your highest-damage strike."),
    S(5221, "main", 207, "Destrozar: generador de puntos de combo desde la espalda.", "Shred: combo-point builder from behind."),
    S(1822, "dot", 208, "Desgarro: sangrado barato; mantenlo activo.", "Rake: cheap bleed; keep it active."),
    S(1079, "dot", 209, "Rasgadura: gran sangrado con puntos de combo; renuévalo.", "Rip: big bleed with combo points; refresh it."),
    S(52610, "dot", 210, "Rugido salvaje: más daño de todos tus ataques; siempre activo.", "Savage Roar: more damage on all your attacks; always active."),
    S(22568, "main", 211, "Mordisco feroz: remate con muchos puntos y energía sobrante.", "Ferocious Bite: finisher with many points and spare energy."),
    S(5217, "cd", 212, "Furia del tigre: energía extra y más daño; úsala en cuanto esté lista.", "Tiger's Fury: extra energy and more damage; use it as soon as ready."),
    S(50334, "cd", 213, "Berserker: sin coste de energía en algunas habilidades; gran cooldown.", "Berserk: some abilities cost no energy; big cooldown."),
    S(62078, "aoe", 214, "Barrido: daño en área para varios enemigos.", "Swipe: AoE damage for several enemies."),
    S(16857, "util", 215, "Fuego feérico: reduce la armadura del enemigo.", "Faerie Fire: reduces enemy armor."),
    S(5215, "buff", 216, "Acechar: sigilo para abrir con Abalanzarse o Despedazar.", "Prowl: stealth to open with Pounce or Ravage."),
  },
}
end

if MYCLASS == "HUNTER" then
LOADOUT.HUNTER = {
  [1] = { -- Bestias
    S(56641, "main", 217, "Disparo firme: tu relleno principal; barato y constante.", "Steady Shot: your main filler; cheap and consistent."),
    S(3044, "main", 218, "Disparo de los arcanos: daño instantáneo cada vez que está listo.", "Arcane Shot: instant damage every time it is ready."),
    S(1978, "dot", 219, "Picadura de serpiente: DoT que debes mantener en el objetivo.", "Serpent Sting: DoT you should keep on the target."),
    S(34026, "main", 220, "Orden de matar: tu mascota golpea más fuerte; úsala cuando esté lista.", "Kill Command: your pet hits harder; use it when ready."),
    S(53351, "main", 221, "Disparo mortal: remate bajo el 20% de vida del objetivo.", "Kill Shot: finisher below 20% target health."),
    S(19574, "cd", 222, "Ira bestial: tú y tu mascota hacéis más daño; gran cooldown.", "Bestial Wrath: you and your pet deal more damage; big cooldown."),
    S(3045, "cd", 223, "Fuego rápido: velocidad de ataque; gran cooldown.", "Rapid Fire: attack speed; big cooldown."),
    S(1130, "dot", 224, "Marca del cazador: más daño a ese objetivo; manténla.", "Hunter's Mark: more damage on that target; keep it up."),
    S(2643, "aoe", 225, "Multidisparo: daño en área a varios objetivos.", "Multi-Shot: AoE damage to several targets."),
    S({61847, 13165}, "buff", 226, "Aspecto de dracohalcón/halcón: más poder de ataque; es tu aspecto por defecto.", "Aspect of the Dragonhawk/Hawk: more attack power; your default aspect."),
    S(34074, "res", 227, "Aspecto de la víbora: recupera maná cuando baja; cámbialo y vuelve.", "Aspect of the Viper: restores mana when low; swap in and back."),
    S(48990, "util", 228, "Sanar mascota: cura a tu bestia durante el combate.", "Mend Pet: heals your beast during combat."),
  },
  [2] = { -- Puntería
    S(19434, "main", 229, "Disparo apuntado: tu gran daño directo; úsalo en cuanto esté listo.", "Aimed Shot: your big direct damage; use it as soon as it is ready."),
    S(53209, "main", 230, "Disparo quimérico: daño y refresca tu picadura; prioridad alta.", "Chimera Shot: damage and refreshes your sting; high priority."),
    S(56641, "main", 231, "Disparo firme: relleno entre tus habilidades.", "Steady Shot: filler between your abilities."),
    S(3044, "main", 232, "Disparo de los arcanos: daño instantáneo.", "Arcane Shot: instant damage."),
    S(1978, "dot", 233, "Picadura de serpiente: DoT; mantenlo activo.", "Serpent Sting: DoT; keep it active."),
    S(53351, "main", 234, "Disparo mortal: remate bajo el 20% de vida.", "Kill Shot: finisher below 20% health."),
    S(34490, "int", 235, "Disparo silenciador: silencia y corta el lanzamiento del enemigo.", "Silencing Shot: silences and interrupts the enemy cast."),
    S(3045, "cd", 223, "Fuego rápido: velocidad de ataque; gran cooldown.", "Rapid Fire: attack speed; big cooldown."),
    S(1130, "dot", 236, "Marca del cazador: más daño a ese objetivo.", "Hunter's Mark: more damage on that target."),
    S(2643, "aoe", 237, "Multidisparo: daño en área.", "Multi-Shot: AoE damage."),
    S({61847, 13165}, "buff", 238, "Aspecto de dracohalcón/halcón: más poder de ataque.", "Aspect of the Dragonhawk/Hawk: more attack power."),
    S(34074, "res", 239, "Aspecto de la víbora: recupera maná cuando baja.", "Aspect of the Viper: restores mana when low."),
  },
  [3] = { -- Supervivencia
    S(53301, "main", 240, "Disparo explosivo: tu mayor daño; úsalo en cuanto esté listo.", "Explosive Shot: your biggest damage; use it as soon as it is ready."),
    S(3674, "dot", 241, "Flecha negra: DoT potente; mantenla activa.", "Black Arrow: strong DoT; keep it active."),
    S(1978, "dot", 233, "Picadura de serpiente: DoT; mantenlo activo.", "Serpent Sting: DoT; keep it active."),
    S(56641, "main", 242, "Disparo firme: relleno entre habilidades.", "Steady Shot: filler between abilities."),
    S(3044, "main", 232, "Disparo de los arcanos: daño instantáneo.", "Arcane Shot: instant damage."),
    S(53351, "main", 234, "Disparo mortal: remate bajo el 20% de vida.", "Kill Shot: finisher below 20% health."),
    S(34026, "main", 243, "Orden de matar: tu mascota golpea más fuerte.", "Kill Command: your pet hits harder."),
    S(3045, "cd", 223, "Fuego rápido: velocidad de ataque; gran cooldown.", "Rapid Fire: attack speed; big cooldown."),
    S(1130, "dot", 236, "Marca del cazador: más daño a ese objetivo.", "Hunter's Mark: more damage on that target."),
    S(2643, "aoe", 237, "Multidisparo: daño en área.", "Multi-Shot: AoE damage."),
    S({61847, 13165}, "buff", 238, "Aspecto de dracohalcón/halcón: más poder de ataque.", "Aspect of the Dragonhawk/Hawk: more attack power."),
    S(34074, "res", 239, "Aspecto de la víbora: recupera maná cuando baja.", "Aspect of the Viper: restores mana when low."),
  },
}
end

------------------------------------------------------------------------------
-- Habilidades que PulseFlash puede recomendar segun la rotacion de cada clase y que
-- no tienen ficha propia arriba. Se anaden al final de la lista para que la barra
-- recomendada muestre TODO lo que el HUD puede sugerir (generico por etiqueta).
------------------------------------------------------------------------------
local AUTO = {}
if MYCLASS == "WARRIOR" then
AUTO.WARRIOR = {
  { 23881, "main" }, -- Bloodthirst
  { 20243, "main" }, -- Devastate
  { 5308, "main" }, -- Execute
  { 12294, "main" }, -- MortalStrike
  { 7384, "main" }, -- Overpower
  { 6572, "main" }, -- Revenge
  { 23922, "main" }, -- ShieldSlam
  { 1464, "main" }, -- Slam
  { 34428, "main" }, -- VictoryRush
  { 772, "dot" }, -- Rend
  { 12328, "aoe" }, -- SweepingStrikes
  { 6343, "aoe" }, -- ThunderClap
  { 1680, "aoe" }, -- Whirlwind
  { 46924, "cd" }, -- Bladestorm
  { 12292, "cd" }, -- DeathWish
  { 1719, "cd" }, -- Recklessness
  { 18499, "res" }, -- BerserkerRage
  { 2687, "res" }, -- Bloodrage
  { 78, "res" }, -- HeroicStrike
  { 6552, "int" }, -- Pummel
  { 72, "int" }, -- ShieldBash
  { 1160, "def" }, -- DemoralizingShout
  { 55694, "def" }, -- EnragedRegeneration
  { 12975, "def" }, -- LastStand
  { 2565, "def" }, -- ShieldBlock
  { 871, "def" }, -- ShieldWall
  { 11578, "util" }, -- Charge
  { 12809, "util" }, -- ConcussionBlow
  { 20252, "util" }, -- Intercept
  { 46968, "util" }, -- Shockwave
  { 355, "util" }, -- Taunt
}
end
if MYCLASS == "PALADIN" then
AUTO.PALADIN = {
  { 31935, "main" }, -- AvengersShield
  { 26573, "main" }, -- Consecration
  { 35395, "main" }, -- CrusaderStrike
  { 879, "main" }, -- Exorcism
  { 53595, "main" }, -- HammerOfTheRighteous
  { 24275, "main" }, -- HammerOfWrath
  { 20473, "main" }, -- HolyShock
  { 2812, "main" }, -- HolyWrath
  { 20271, "main" }, -- JudgementOfLight
  { 53408, "main" }, -- JudgementOfWisdom
  { 53600, "main" }, -- ShieldOfRighteousness
  { 53385, "aoe" }, -- DivineStorm
  { 31884, "cd" }, -- AvengingWrath
  { 54428, "res" }, -- DivinePlea
  { 21084, "buff" }, -- SealOfRighteousness
  { 498, "def" }, -- DivineProtection
  { 642, "def" }, -- DivineShield
  { 20925, "def" }, -- HolyShield
  { 53601, "def" }, -- SacredShield
  { 853, "util" }, -- HammerOfJustice
  { 62124, "util" }, -- HandOfReckoning
}
end
if MYCLASS == "HUNTER" then
AUTO.HUNTER = {
  { 19434, "main" }, -- AimedShot
  { 3044, "main" }, -- ArcaneShot
  { 53209, "main" }, -- ChimeraShot
  { 53301, "main" }, -- ExplosiveShot
  { 34026, "main" }, -- KillCommand
  { 53351, "main" }, -- KillShot
  { 1495, "main" }, -- MongooseBite
  { 2973, "main" }, -- RaptorStrike
  { 56641, "main" }, -- SteadyShot
  { 3674, "dot" }, -- BlackArrow
  { 1130, "dot" }, -- HuntersMark
  { 1978, "dot" }, -- SerpentSting
  { 13813, "aoe" }, -- ExplosiveTrap
  { 2643, "aoe" }, -- MultiShot
  { 1510, "aoe" }, -- Volley
  { 19574, "cd" }, -- BestialWrath
  { 3045, "cd" }, -- RapidFire
  { 23989, "res" }, -- Readiness
  { 34490, "int" }, -- SilencingShot
  { 19263, "def" }, -- Deterrence
  { 5384, "def" }, -- FeignDeath
  { 48990, "def" }, -- MendPet
  { 781, "util" }, -- Disengage
}
end
if MYCLASS == "ROGUE" then
AUTO.ROGUE = {
  { 8676, "main" }, -- Ambush
  { 1833, "main" }, -- CheapShot
  { 32645, "main" }, -- Envenom
  { 2098, "main" }, -- Eviscerate
  { 703, "main" }, -- Garrote
  { 16511, "main" }, -- Hemorrhage
  { 1329, "main" }, -- Mutilate
  { 1752, "main" }, -- SinisterStrike
  { 51662, "dot" }, -- HungerForBlood
  { 1943, "dot" }, -- Rupture
  { 5171, "dot" }, -- SliceAndDice
  { 51723, "aoe" }, -- FanOfKnives
  { 13750, "cd" }, -- AdrenalineRush
  { 13877, "cd" }, -- BladeFlurry
  { 14177, "cd" }, -- ColdBlood
  { 51690, "cd" }, -- KillingSpree
  { 51713, "cd" }, -- ShadowDance
  { 14183, "res" }, -- Premeditation
  { 14185, "res" }, -- Preparation
  { 1784, "buff" }, -- Stealth
  { 1766, "int" }, -- Kick
  { 31224, "def" }, -- CloakOfShadows
  { 5277, "def" }, -- Evasion
  { 48659, "def" }, -- Feint
  { 1856, "def" }, -- Vanish
  { 36554, "util" }, -- Shadowstep
}
end
if MYCLASS == "PRIEST" then
AUTO.PRIEST = {
  { 14914, "main" }, -- HolyFire
  { 8092, "main" }, -- MindBlast
  { 15407, "main" }, -- MindFlay
  { 47540, "main" }, -- Penance
  { 32379, "main" }, -- ShadowWordDeath
  { 585, "main" }, -- Smite
  { 2944, "dot" }, -- DevouringPlague
  { 589, "dot" }, -- ShadowWordPain
  { 34914, "dot" }, -- VampiricTouch
  { 15237, "aoe" }, -- HolyNova
  { 48045, "aoe" }, -- MindSear
  { 34433, "cd" }, -- Shadowfiend
  { 47585, "res" }, -- Dispersion
  { 15473, "buff" }, -- Shadowform
  { 15487, "int" }, -- Silence
  { 48173, "def" }, -- DesperatePrayer
  { 586, "def" }, -- Fade
  { 17, "def" }, -- PowerWordShield
  { 8122, "util" }, -- PsychicScream
}
end
if MYCLASS == "DEATHKNIGHT" then
AUTO.DEATHKNIGHT = {
  { 45902, "main" }, -- BloodStrike
  { 47541, "main" }, -- DeathCoil
  { 49998, "main" }, -- DeathStrike
  { 49143, "main" }, -- FrostStrike
  { 55050, "main" }, -- HeartStrike
  { 49020, "main" }, -- Obliterate
  { 56815, "main" }, -- RuneStrike
  { 55090, "main" }, -- ScourgeStrike
  { 49206, "main" }, -- SummonGargoyle
  { 45477, "dot" }, -- IcyTouch
  { 45462, "dot" }, -- PlagueStrike
  { 49184, "proc" }, -- HowlingBlast
  { 48721, "aoe" }, -- BloodBoil
  { 49938, "aoe" }, -- DeathAndDecay
  { 50842, "aoe" }, -- Pestilence
  { 42650, "cd" }, -- ArmyOfTheDead
  { 49028, "cd" }, -- DancingRuneWeapon
  { 63560, "cd" }, -- GhoulFrenzy
  { 51271, "cd" }, -- UnbreakableArmor
  { 45529, "res" }, -- BloodTap
  { 47568, "res" }, -- EmpowerRuneWeapon
  { 47528, "int" }, -- MindFreeze
  { 47476, "int" }, -- Strangulate
  { 48707, "def" }, -- AntiMagicShell
  { 49222, "def" }, -- BoneShield
  { 48792, "def" }, -- IceboundFortitude
  { 48982, "def" }, -- RuneTap
  { 55233, "def" }, -- VampiricBlood
  { 56222, "util" }, -- DarkCommand
  { 49576, "util" }, -- DeathGrip
  { 46584, "util" }, -- RaiseDead
}
end
if MYCLASS == "SHAMAN" then
AUTO.SHAMAN = {
  { 8042, "main" }, -- EarthShock
  { 8050, "main" }, -- FlameShock
  { 51505, "main" }, -- LavaBurst
  { 60103, "main" }, -- LavaLash
  { 403, "main" }, -- LightningBolt
  { 17364, "main" }, -- Stormstrike
  { 421, "aoe" }, -- ChainLightning
  { 1535, "aoe" }, -- FireNova
  { 16166, "cd" }, -- ElementalMastery
  { 51533, "cd" }, -- FeralSpirit
  { 2894, "cd" }, -- FireElementalTotem
  { 30823, "res" }, -- ShamanisticRage
  { 51479, "def" }, -- AstralShift
  { 51490, "util" }, -- Thunderstorm
}
end
if MYCLASS == "MAGE" then
AUTO.MAGE = {
  { 44781, "main" }, -- ArcaneBarrage
  { 30451, "main" }, -- ArcaneBlast
  { 5143, "main" }, -- ArcaneMissiles
  { 10, "main" }, -- Blizzard
  { 44572, "main" }, -- DeepFreeze
  { 2136, "main" }, -- FireBlast
  { 133, "main" }, -- Fireball
  { 2120, "main" }, -- Flamestrike
  { 116, "main" }, -- Frostbolt
  { 44614, "main" }, -- FrostfireBolt
  { 30455, "main" }, -- IceLance
  { 11366, "main" }, -- Pyroblast
  { 2948, "main" }, -- Scorch
  { 31687, "main" }, -- SummonWaterElemental
  { 44457, "dot" }, -- LivingBomb
  { 1449, "aoe" }, -- ArcaneExplosion
  { 12042, "cd" }, -- ArcanePower
  { 11129, "cd" }, -- Combustion
  { 12472, "cd" }, -- IcyVeins
  { 55342, "cd" }, -- MirrorImage
  { 12043, "cd" }, -- PresenceOfMind
  { 11958, "res" }, -- ColdSnap
  { 12051, "res" }, -- Evocation
  { 2139, "int" }, -- Counterspell
  { 11426, "def" }, -- IceBarrier
  { 45438, "def" }, -- IceBlock
  { 11113, "util" }, -- BlastWave
  { 120, "util" }, -- ConeOfCold
}
end
if MYCLASS == "WARLOCK" then
AUTO.WARLOCK = {
  { 50796, "main" }, -- ChaosBolt
  { 17962, "main" }, -- Conflagrate
  { 47193, "main" }, -- DemonicEmpowerment
  { 1120, "main" }, -- DrainSoul
  { 50589, "main" }, -- ImmolationAura
  { 29722, "main" }, -- Incinerate
  { 27243, "main" }, -- SeedOfCorruption
  { 686, "main" }, -- ShadowBolt
  { 17877, "main" }, -- Shadowburn
  { 6353, "main" }, -- SoulFire
  { 172, "dot" }, -- Corruption
  { 980, "dot" }, -- CurseOfAgony
  { 603, "dot" }, -- CurseOfDoom
  { 1490, "dot" }, -- CurseOfTheElements
  { 48181, "dot" }, -- Haunt
  { 348, "dot" }, -- Immolate
  { 30108, "dot" }, -- UnstableAffliction
  { 5740, "aoe" }, -- RainOfFire
  { 47241, "cd" }, -- Metamorphosis
  { 1454, "res" }, -- LifeTap
  { 6789, "util" }, -- DeathCoil
}
end
if MYCLASS == "DRUID" then
AUTO.DRUID = {
  { 50334, "main" }, -- Berserk
  { 1082, "main" }, -- Claw
  { 22568, "main" }, -- FerociousBite
  { 33745, "main" }, -- Lacerate
  { 33876, "main" }, -- Mangle
  { 33878, "main" }, -- MangleBear
  { 6807, "main" }, -- Maul
  { 9005, "main" }, -- Pounce
  { 6785, "main" }, -- Ravage
  { 5221, "main" }, -- Shred
  { 2912, "main" }, -- Starfire
  { 5217, "main" }, -- TigersFury
  { 5176, "main" }, -- Wrath
  { 5570, "dot" }, -- InsectSwarm
  { 8921, "dot" }, -- Moonfire
  { 16857, "aoe" }, -- FaerieFire
  { 16914, "aoe" }, -- Hurricane
  { 62078, "aoe" }, -- Swipe
  { 779, "aoe" }, -- SwipeBear
  { 33831, "cd" }, -- ForceOfNature
  { 48505, "cd" }, -- Starfall
  { 61384, "cd" }, -- Typhoon
  { 5229, "res" }, -- Enrage
  { 29166, "res" }, -- Innervate
  { 5487, "buff" }, -- BearForm
  { 768, "buff" }, -- CatForm
  { 9634, "buff" }, -- DireBearForm
  { 24858, "buff" }, -- MoonkinForm
  { 22812, "def" }, -- Barkskin
  { 99, "def" }, -- DemoralizingRoar
  { 22842, "def" }, -- FrenziedRegeneration
  { 61336, "def" }, -- SurvivalInstincts
  { 8983, "util" }, -- Bash
  { 16979, "util" }, -- FeralChargeBear
  { 49376, "util" }, -- FeralChargeCat
  { 6795, "util" }, -- Growl
}
end

local AUTO_WHY = {
  main = { "PulseFlash la recomienda en tu rotación cuando está lista.", "PulseFlash recommends it in your rotation when it is ready." },
  dot  = { "Mantenimiento: PulseFlash la recomienda cuando falta en el objetivo o está a punto de acabarse.", "Upkeep: PulseFlash recommends it when it is missing on the target or about to expire." },
  proc = { "Proc: PulseFlash la recomienda cuando se activa el efecto que la mejora.", "Proc: PulseFlash recommends it when the effect that improves it is active." },
  aoe  = { "Área: PulseFlash la recomienda cuando hay varios enemigos (modo AoE).", "AoE: PulseFlash recommends it when several enemies are around (AoE mode)." },
  cd   = { "Cooldown: PulseFlash la recomienda en jefes cuando está lista.", "Cooldown: PulseFlash recommends it on bosses when it is ready." },
  res  = { "Recurso: PulseFlash la recomienda cuando necesitas recuperar o generar recurso.", "Resource: PulseFlash recommends it when you need to recover or build resource." },
  buff = { "Buff / postura: PulseFlash la recomienda para mantenerla activa antes de pelear.", "Buff / stance: PulseFlash recommends it to keep it active before fighting." },
  int  = { "Interrupción: PulseFlash la recomienda cuando el enemigo lanza un hechizo.", "Interrupt: PulseFlash recommends it when the enemy is casting." },
  def  = { "Defensivo: PulseFlash la recomienda cuando tu vida baja o hay peligro.", "Defensive: PulseFlash recommends it when your health drops or you are in danger." },
  util = { "Utilidad: PulseFlash la recomienda en situaciones concretas del combate.", "Utility: PulseFlash recommends it in specific combat situations." },
}

PF.LOADOUT = LOADOUT

------------------------------------------------------------------------------
-- Resolución de datos contra el libro de hechizos del jugador
------------------------------------------------------------------------------
local SLOT_KEYS = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=" }

-- Devuelve nombre, icono y si está aprendida para una entrada de la tabla.
local function Resolve(entry)
  local ids = entry[1]
  if type(ids) ~= "table" then ids = { ids } end
  local firstName, firstIcon, firstId
  for i = 1, #ids do
    local name, _, icon = GetSpellInfo(ids[i])
    if name then
      if not firstName then firstName, firstIcon, firstId = name, icon, ids[i] end
      if PF.Known(name) then return name, icon, true, ids[i] end
    end
  end
  return firstName, firstIcon, false, firstId
end

-- Construye la lista visible según la opción "mostrar las que aún no tengo".
function PF.BuildLoadoutList(showAll)
  local _, class = UnitClass("player")
  local _, tab = PF.GetSpecInfo()
  local data = LOADOUT[class] and LOADOUT[class][tab]
  local auto = AUTO[class]
  local out, seen = {}, {}
  if not data and not auto then return out, false end
  for _, entry in ipairs(data or {}) do
    local name, icon, known, id = Resolve(entry)
    if name and (known or showAll) then
      out[#out + 1] = { name = name, icon = icon, known = known, id = id, entry = entry }
      seen[name] = true
    end
  end
  -- el resto de lo que la rotacion puede recomendar (sin repetir)
  for _, a in ipairs(auto or {}) do
    local why = AUTO_WHY[a[2]] or AUTO_WHY.util
    local entry = { a[1], a[2], why[1], why[2] }
    local name, icon, known, id = Resolve(entry)
    if name and not seen[name] and (known or showAll) then
      out[#out + 1] = { name = name, icon = icon, known = known, id = id, entry = entry }
      seen[name] = true
    end
  end
  return out, true
end

------------------------------------------------------------------------------
-- Pestaña del panel de configuración
------------------------------------------------------------------------------
local WHITE = "Interface\\Buttons\\WHITE8X8"
local FONT = "Fonts\\FRIZQT__.TTF"
local W = 396
local ICON, GAP = 30, 3
local MAXN = 24                -- maximo de habilidades listadas (dos filas de 12)
local floor = math.floor
PF.LOADOUT_CONTENT_H = 870

function PF.BuildLoadoutTab(page)
  local showAll = false
  local selected = 1
  local list = {}

  local function Text(parent, size, r, g, b, flags)
    local fs = parent:CreateFontString(nil, "OVERLAY")
    PF.SetLFont(fs, FONT, size, flags)
    fs:SetTextColor(r or 1, g or 1, b or 1)
    fs:SetJustifyH("LEFT")
    return fs
  end

  local head = Text(page, 12, 0.88, 0.60, 0.34, "OUTLINE")
  head:SetPoint("TOPLEFT", page, "TOPLEFT", 0, 0)

  local info = Text(page, 11, 0.62, 0.66, 0.74)
  info:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -20)
  info:SetWidth(W)

  -- casilla "mostrar también las que aún no tengo"
  local chk = CreateFrame("Button", nil, page)
  chk:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -40)
  chk:SetWidth(W); chk:SetHeight(20)
  local box = CreateFrame("Frame", nil, chk)
  box:SetWidth(14); box:SetHeight(14)
  box:SetPoint("LEFT", chk, "LEFT", 0, 0)
  box:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1,
                    insets = { left = 1, right = 1, top = 1, bottom = 1 } })
  box:SetBackdropColor(0.075, 0.115, 0.210, 1)
  box:SetBackdropBorderColor(0.30, 0.02, 0.02, 1)
  local tick = box:CreateTexture(nil, "OVERLAY")
  tick:SetTexture(WHITE)
  tick:SetVertexColor(1, 0.82, 0, 1)
  tick:SetPoint("TOPLEFT", box, "TOPLEFT", 3, -3)
  tick:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", -3, 3)
  tick:Hide()
  local chkText = Text(chk, 11)
  chkText:SetPoint("LEFT", box, "RIGHT", 8, 0)

  -- fila de iconos (como una barra de acción)
  local slots = {}
  for i = 1, MAXN do
    local b = CreateFrame("Button", nil, page)
    b:SetWidth(ICON); b:SetHeight(ICON)
    b:SetPoint("TOPLEFT", page, "TOPLEFT", ((i - 1) % 12) * (ICON + GAP), -68 - floor((i - 1) / 12) * (ICON + GAP))
    b:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1,
                    insets = { left = 1, right = 1, top = 1, bottom = 1 } })
    b:SetBackdropColor(0, 0, 0, 1)
    b:SetBackdropBorderColor(0.10, 0.16, 0.30, 1)
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetPoint("TOPLEFT", b, "TOPLEFT", 2, -2)
    b.icon:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -2, 2)
    b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    b.bar = b:CreateTexture(nil, "OVERLAY")
    b.bar:SetTexture(WHITE)
    b.bar:SetHeight(3)
    b.bar:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 1, 1)
    b.bar:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -1, 1)
    b.num = Text(b, 9, 1, 1, 1, "OUTLINE")
    b.num:SetPoint("TOPLEFT", b, "TOPLEFT", 3, -3)
    b.index = i
    b:SetScript("OnEnter", function(self)
      if not self.item then return end
      selected = self.index
      page.Refresh()
      if GameTooltip and self.item.id then
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:SetHyperlink("spell:" .. self.item.id)
        GameTooltip:Show()
      end
    end)
    b:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
    b:SetScript("OnClick", function(self)
      if self.item then selected = self.index; page.Refresh() end
    end)
    slots[i] = b
  end

  -- caja de detalle
  local det = CreateFrame("Frame", nil, page)
  det:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -108)
  det:SetWidth(W); det:SetHeight(112)
  det:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1,
                    insets = { left = 1, right = 1, top = 1, bottom = 1 } })
  det:SetBackdropColor(0.075, 0.115, 0.210, 1)
  det:SetBackdropBorderColor(0.10, 0.16, 0.30, 1)
  det.icon = det:CreateTexture(nil, "ARTWORK")
  det.icon:SetWidth(44); det.icon:SetHeight(44)
  det.icon:SetPoint("TOPLEFT", det, "TOPLEFT", 10, -10)
  det.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
  det.name = Text(det, 13, 1, 0.82, 0, "OUTLINE")
  det.name:SetPoint("TOPLEFT", det, "TOPLEFT", 62, -10)
  det.name:SetWidth(W - 72)
  det.tag = Text(det, 10, 1, 1, 1)
  det.tag:SetPoint("TOPLEFT", det, "TOPLEFT", 62, -28)
  det.tag:SetWidth(W - 72)
  det.why = Text(det, 11, 1, 1, 1)
  det.why:SetPoint("TOPLEFT", det, "TOPLEFT", 10, -58)
  det.why:SetWidth(W - 20)
  det.why:SetHeight(50)
  det.why:SetJustifyV("TOP")

  local pick = Text(page, 10, 0.62, 0.66, 0.74)
  pick:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -226)
  pick:SetWidth(W)

  local listHead = Text(page, 12, 1, 0.82, 0, "OUTLINE")
  listHead:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -270)

  local empty = Text(page, 11, 0.62, 0.66, 0.74)
  empty:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -294)
  empty:SetWidth(W)

  -- lista completa: icono + nombre + razón
  local rows = {}
  for i = 1, MAXN do
    local r = CreateFrame("Frame", nil, page)
    r:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -294 - (i - 1) * 46)
    r:SetWidth(W); r:SetHeight(44)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetWidth(30); r.icon:SetHeight(30)
    r.icon:SetPoint("TOPLEFT", r, "TOPLEFT", 0, -2)
    r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    r.name = Text(r, 11, 1, 0.82, 0, "OUTLINE")
    r.name:SetPoint("TOPLEFT", r, "TOPLEFT", 38, -1)
    r.name:SetWidth(W - 40)
    r.why = Text(r, 10, 0.85, 0.87, 0.92)
    r.why:SetPoint("TOPLEFT", r, "TOPLEFT", 38, -15)
    r.why:SetWidth(W - 40)
    r.why:SetHeight(28)
    r.why:SetJustifyV("TOP")
    rows[i] = r
  end

  -- Con mas de 12 habilidades la barra ocupa dos filas: se baja el resto y se ajusta el scroll
  local function Layout(n)
    local extra = (n > 12) and (ICON + GAP) or 0
    det:ClearAllPoints();      det:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -108 - extra)
    pick:ClearAllPoints();     pick:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -226 - extra)
    listHead:ClearAllPoints(); listHead:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -270 - extra)
    empty:ClearAllPoints();    empty:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -294 - extra)
    for i, r in ipairs(rows) do
      r:ClearAllPoints()
      r:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -294 - extra - (i - 1) * 46)
    end
    if page.SetContentHeight then page.SetContentHeight(294 + extra + math.max(n, 1) * 46 + 24) end
  end

  local function Relabel()
    head:SetText(PF.T("lo_head"))
    chkText:SetText(PF.T("lo_showAll"))
    pick:SetText(PF.T("lo_pick"))
    listHead:SetText(PF.T("lo_listHead"))
  end

  function page.Refresh()
    local data, supported = PF.BuildLoadoutList(showAll)
    list = data
    if showAll then tick:Show() else tick:Hide() end

    local _, class = UnitClass("player")
    local _, _, specName = PF.GetSpecInfo()
    local cname = (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[class]) or class or "?"
    info:SetText(PF.T("lo_info", cname, specName or "?", UnitLevel("player") or 0))

    if selected > #list then selected = 1 end
    Layout(#list)

    for i = 1, MAXN do
      local s, it = slots[i], list[i]
      s.item = it
      if it then
        local tg = TAG[it.entry[2]] or TAG.util
        s.icon:SetTexture(it.icon)
        s.icon:SetVertexColor(1, 1, 1)
        s.icon:SetDesaturated(not it.known)
        s.bar:SetVertexColor(tg[2], tg[3], tg[4], it.known and 1 or 0.35)
        s.num:SetText(SLOT_KEYS[i] or tostring(i))
        s:SetBackdropBorderColor(i == selected and 1 or 0.10, i == selected and 0.82 or 0.16, i == selected and 0 or 0.30, 1)
        s:Show()
      else
        s:Hide()
      end
    end

    local sel = list[selected]
    if sel then
      local tg = TAG[sel.entry[2]] or TAG.util
      det.icon:SetTexture(sel.icon)
      det.icon:SetDesaturated(not sel.known)
      det.name:SetText(sel.name)
      det.tag:SetText(PF.T("lo_slot", SLOT_KEYS[selected] or tostring(selected)) .. "  -  " .. PF.T(tg[1]))
      det.tag:SetTextColor(tg[2], tg[3], tg[4])
      local why = PF.LoadoutReason(sel.entry)
      if not sel.known then why = PF.T("lo_missing") .. " " .. why end
      det.why:SetText(why)
      det:Show()
    else
      det:Hide()
    end

    local nothing = (#list == 0)
    if nothing then
      empty:SetText(PF.T(supported and "lo_empty" or "lo_none"))
      empty:Show()
    else
      empty:Hide()
    end
    for i = 1, MAXN do
      local r, it = rows[i], list[i]
      if it then
        local tg = TAG[it.entry[2]] or TAG.util
        r.icon:SetTexture(it.icon)
        r.icon:SetDesaturated(not it.known)
        r.name:SetText((SLOT_KEYS[i] or tostring(i)) .. "  " .. it.name .. "  |cff888888(" .. PF.T(tg[1]) .. ")|r")
        local why = PF.LoadoutReason(it.entry)
        r.why:SetText(why)
        r:Show()
      else
        r:Hide()
      end
    end
  end

  chk:SetScript("OnClick", function()
    showAll = not showAll
    selected = 1
    page.Refresh()
  end)

  page:SetScript("OnShow", function() page.Refresh() end)

  Relabel()
  if PF.OnLangChange then PF.OnLangChange(function() Relabel(); page.Refresh() end) end
  -- Si aprendes un hechizo o cambias de talentos con el panel abierto, se actualiza.
  local ev = CreateFrame("Frame")
  ev:RegisterEvent("SPELLS_CHANGED")
  ev:RegisterEvent("PLAYER_TALENT_UPDATE")
  ev:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
  ev:RegisterEvent("PLAYER_LEVEL_UP")
  ev:SetScript("OnEvent", function() if page:IsVisible() then page.Refresh() end end)
  page.Refresh()
end
