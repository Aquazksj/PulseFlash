local PF = PulseFlash

local floor, format, unpack = math.floor, format, unpack

local WHITE = "Interface\\Buttons\\WHITE8X8"
local FONT = "Fonts\\FRIZQT__.TTF"
local C = {
  bg     = { 0.055, 0.055, 0.055, 0.98 },
  line   = { 0.24, 0.24, 0.24, 1 },
  field  = { 0.090, 0.090, 0.090, 1 },
  accent = { 1.00, 0.82, 0.00, 1 },
  text   = { 1.00, 1.00, 1.00 },
  dim    = { 0.62, 0.66, 0.74 },
  green  = { 0.20, 1.00, 0.20 },
  orange = { 0.88, 0.60, 0.34 },
  yellow = { 1.00, 0.82, 0.00 },
  title  = { 0.85, 0.85, 0.90 },
}

local MEDIA = "Interface\\AddOns\\PulseFlash\\Media\\"
local CURSE_URL = "https://www.curseforge.com/wow/addons/pulseflash"
local VIEW_H = 426
local KIND = {
  -- estilo ElvUI: botones oscuros con texto dorado; el activo lleva borde dorado
  red    = { bg = { 0.100, 0.100, 0.100, 1 }, hi = { 0.170, 0.170, 0.170, 1 }, on = { 0.140, 0.125, 0.060, 1 },
             border = { 0.260, 0.260, 0.260, 1 }, onBorder = { 1.00, 0.82, 0.00, 1 }, text = { 1.00, 0.82, 0.00 } },
  orange = { bg = { 0.075, 0.075, 0.075, 1 }, hi = { 0.160, 0.160, 0.160, 1 }, on = { 0.140, 0.125, 0.060, 1 },
             border = { 0.200, 0.200, 0.200, 1 }, onBorder = { 1.00, 0.82, 0.00, 1 }, text = { 1.00, 0.82, 0.00 } },
}
local W = 396
local TAB_KEYS = {}
local curTab = 1

local panel, tabs, pages = nil, {}, {}
local pageTitle, pageSub
local refreshers = {}

local function Skin(f, bg, border)
  f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1,
                  insets = { left = 1, right = 1, top = 1, bottom = 1 } })
  f:SetBackdropColor(unpack(bg))
  f:SetBackdropBorderColor(unpack(border))
end

local relabels = {}

local function K(key) return function() return PF.T(key) end end

-- Mayusculas que respetan acentos y la enie (string.upper no toca bytes UTF-8)
local function Upper(s)
  s = string.upper(s or "")
  return (s:gsub("\195([\160-\190])", function(c)
    local b = c:byte()
    if b == 183 then return "\195" .. c end   -- division, no es letra
    return "\195" .. string.char(b - 32)
  end))
end

local function Text(parent, str, size, col, flags)
  local fs = parent:CreateFontString(nil, "OVERLAY")
  PF.SetLFont(fs, FONT, size or 11, flags)
  local c = col or C.text
  fs:SetTextColor(c[1], c[2], c[3])
  if type(str) == "function" then
    relabels[#relabels + 1] = function() fs:SetText(str()) end
    fs:SetText(str())
  else
    fs:SetText(str or "")
  end
  return fs
end

local function Header(parent, str, y, col)
  local h = Text(parent, str, 12, col, "OUTLINE")
  h:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y)
  return h
end

local function Button(parent, label, w, h, onClick, kind)
  local k = KIND[kind or "red"]
  local b = CreateFrame("Button", nil, parent)
  b:SetWidth(w); b:SetHeight(h)
  b.k = k
  Skin(b, k.bg, k.border)
  b.text = Text(b, label, 11, k.text, "OUTLINE")
  b.text:SetPoint("CENTER", b, "CENTER", 0, 0)
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  b:SetScript("OnEnter", function(self)
    if not self.active then self:SetBackdropColor(unpack(self.k.hi)) end
  end)
  b:SetScript("OnLeave", function(self)
    self:SetBackdropColor(unpack(self.active and self.k.on or self.k.bg))
  end)
  b:SetScript("OnClick", function(self, mouse)
    if onClick then onClick(self, mouse) end
  end)
  function b:SetActive(on)
    self.active = on and true or false
    self:SetBackdropColor(unpack(self.active and self.k.on or self.k.bg))
    self:SetBackdropBorderColor(unpack(self.active and self.k.onBorder or self.k.border))
  end
  function b:SetLabel(t) self.text:SetText(t) end
  return b
end

local function CloseButton(parent, onClick)
  local b = CreateFrame("Button", nil, parent)
  b:SetWidth(24); b:SetHeight(24)
  b.text = Text(b, "X", 16, { 1.00, 1.00, 1.00 }, "OUTLINE")
  b.text:SetPoint("CENTER", b, "CENTER", 0, 0)
  b:SetScript("OnEnter", function(self) self.text:SetTextColor(1, 0.65, 0.2) end)
  b:SetScript("OnLeave", function(self) self.text:SetTextColor(1, 1, 1) end)
  b:SetScript("OnClick", function() onClick() end)
  return b
end

local function Slider(parent, y, label, lo, hi, step, get, set, fmt, width, flat)
  local SW = width or W
  local holder = CreateFrame("Frame", nil, parent)
  holder:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y)
  holder:SetWidth(SW); holder:SetHeight(34)

  local lbl = Text(holder, label, 11)
  lbl:SetPoint("TOPLEFT", holder, "TOPLEFT", 0, 0)
  local val
  if not flat then
    val = Text(holder, "", 11, C.accent, "OUTLINE")
    val:SetPoint("TOPRIGHT", holder, "TOPRIGHT", 0, 0)
  end

  local s = CreateFrame("Slider", nil, holder)
  s:SetPoint("TOPLEFT", holder, "TOPLEFT", 0, flat and -14 or -19)
  s:SetWidth(SW); s:SetHeight(12)
  s:SetOrientation("HORIZONTAL")
  s:EnableMouse(true)
  s:EnableMouseWheel(true)
  s:SetMinMaxValues(lo, hi)
  s:SetValueStep(step)

  local track = s:CreateTexture(nil, "BACKGROUND")
  track:SetTexture(WHITE)
  if flat then track:SetVertexColor(0.125, 0.125, 0.125, 1)   -- pista gris oscuro
  else track:SetVertexColor(0.13, 0.20, 0.36, 1) end
  track:SetHeight(flat and 5 or 4)
  track:SetPoint("LEFT", s, "LEFT", 0, 0)
  track:SetPoint("RIGHT", s, "RIGHT", 0, 0)

  local fill = s:CreateTexture(nil, "BORDER")
  fill:SetTexture(WHITE)
  fill:SetVertexColor(C.accent[1], C.accent[2], C.accent[3], 1)
  fill:SetHeight(flat and 5 or 4)
  fill:SetPoint("LEFT", s, "LEFT", 0, 0)
  local function SetFill(v)
    local f = (hi > lo) and ((v - lo) / (hi - lo)) or 0
    if f < 0 then f = 0 elseif f > 1 then f = 1 end
    if flat then fill:SetWidth(math.max(2, f * SW))
    else fill:SetWidth(4 + f * (SW - 8)) end
  end

  s:SetThumbTexture(WHITE)
  local thumb = s:GetThumbTexture()
  if flat then
    thumb:SetVertexColor(1, 1, 1, 0)        -- sin pomo visible, solo la barra rellena
    thumb:SetWidth(8); thumb:SetHeight(12)
  else
    thumb:SetVertexColor(C.accent[1], C.accent[2], C.accent[3], 1)
    thumb:SetWidth(8); thumb:SetHeight(14)
  end

  local function Tip(self, v)
    if not flat then return end
    if GameTooltip:GetOwner() ~= self then return end
    GameTooltip:SetText(string.format("%s: %s", type(label) == "function" and label() or label, fmt(v)), 1, 1, 1)
    GameTooltip:Show()
  end

  local busy = false
  s:SetScript("OnValueChanged", function(self, v)
    if busy then return end
    v = floor(v / step + 0.5) * step
    if v < lo then v = lo elseif v > hi then v = hi end
    if val then val:SetText(fmt(v)) end
    SetFill(v)
    set(v)
    Tip(self, v)
  end)
  s:SetScript("OnMouseWheel", function(self, delta)
    self:SetValue(self:GetValue() + delta * step)
  end)
  if flat then
    -- sin cifras junto a la barra (como en la captura): el valor sale al pasar el raton
    s:SetScript("OnEnter", function(self)
      GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
      Tip(self, self:GetValue())
    end)
    s:SetScript("OnLeave", function() GameTooltip:Hide() end)
  end

  refreshers[#refreshers + 1] = function()
    busy = true
    local v = get()
    s:SetValue(v)
    if val then val:SetText(fmt(v)) end
    SetFill(v)
    busy = false
  end
  return holder
end

local function Check(parent, y, label, get, set)
  local b = CreateFrame("Button", nil, parent)
  b:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y)
  b:SetWidth(W); b:SetHeight(20)
  local box = CreateFrame("Frame", nil, b)
  box:SetWidth(14); box:SetHeight(14)
  box:SetPoint("LEFT", b, "LEFT", 0, 0)
  Skin(box, C.field, KIND.red.border)
  local tick = box:CreateTexture(nil, "OVERLAY")
  tick:SetTexture(WHITE)
  tick:SetVertexColor(C.yellow[1], C.yellow[2], C.yellow[3], 1)
  tick:SetPoint("TOPLEFT", box, "TOPLEFT", 3, -3)
  tick:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", -3, 3)
  local t = Text(b, label, 11)
  t:SetPoint("LEFT", box, "RIGHT", 8, 0)
  local function refresh() if get() then tick:Show() else tick:Hide() end end
  b:SetScript("OnClick", function() set(not get()); refresh() end)
  refreshers[#refreshers + 1] = refresh
  return b
end

local picker
local PER_PAGE = 8

local function BuildPicker()
  picker = CreateFrame("Frame", "PulseFlashPicker", panel)
  picker:SetWidth(300); picker:SetHeight(40 + PER_PAGE * 24 + 34)
  picker:SetPoint("TOPLEFT", panel, "TOPRIGHT", 6, 0)
  picker:SetFrameLevel(panel:GetFrameLevel() + 5)
  Skin(picker, C.bg, C.line)
  picker.title = Text(picker, "", 12, C.yellow, "OUTLINE")
  picker.title:SetPoint("TOPLEFT", picker, "TOPLEFT", 12, -12)
  picker.empty = Text(picker, K("p_empty"), 11, C.dim)
  picker.empty:SetPoint("TOPLEFT", picker, "TOPLEFT", 12, -44)
  picker.rows = {}
  for i = 1, PER_PAGE do
    local r = Button(picker, "", 284, 22, function(self, mouse)
      if self.item then picker.onPick(self.item, mouse) end
    end, "orange")
    r:SetPoint("TOPLEFT", picker, "TOPLEFT", 8, -34 - (i - 1) * 24)
    r.text:ClearAllPoints()
    r.text:SetPoint("LEFT", r, "LEFT", 8, 0)
    r.text:SetJustifyH("LEFT")
    r.text:SetWidth(270)
    picker.rows[i] = r
  end
  local close = CloseButton(picker, function() picker:Hide() end)
  close:SetPoint("TOPRIGHT", picker, "TOPRIGHT", -6, -6)
  picker.prev = Button(picker, "<", 24, 20, function() picker.page = picker.page - 1; picker:Render() end)
  picker.prev:SetPoint("BOTTOMLEFT", picker, "BOTTOMLEFT", 8, 8)
  picker.next = Button(picker, ">", 24, 20, function() picker.page = picker.page + 1; picker:Render() end)
  picker.next:SetPoint("BOTTOMRIGHT", picker, "BOTTOMRIGHT", -8, 8)
  picker.pageText = Text(picker, "", 10, C.dim)
  picker.pageText:SetPoint("BOTTOM", picker, "BOTTOM", 0, 12)

  function picker:Render()
    local n = #self.items
    local pages = math.max(1, math.ceil(n / PER_PAGE))
    if self.page > pages then self.page = pages elseif self.page < 1 then self.page = 1 end
    for i = 1, PER_PAGE do
      local it = self.items[(self.page - 1) * PER_PAGE + i]
      local r = self.rows[i]
      r.item = it
      if it then r:SetLabel(it.label); r:Show() else r:Hide() end
    end
    if n == 0 then self.empty:Show() else self.empty:Hide() end
    self.pageText:SetText(self.page .. " / " .. pages)
    if self.page > 1 then self.prev:Show() else self.prev:Hide() end
    if self.page < pages then self.next:Show() else self.next:Hide() end
  end
  picker:Hide()
end

local function OpenPicker(title, items, onPick)
  if not picker then BuildPicker() end
  picker.title:SetText(title)
  picker.items, picker.onPick, picker.page = items, onPick, 1
  picker:Render()
  picker:Show()
end

-- Pestana "Extras": temporizadores de efectos, refresco de DoTs, precision y AoE
local function BuildAssist(page)
  local HALF = (W - 6) / 2

  Header(page, K("as_timers"), 0, C.green)
  Check(page, -22, K("as_show"),
    function() return PF.db.plusTimers ~= false end,
    function(v) PF.db.plusTimers = v and true or false end)
  Slider(page, -48, K("as_size"), 50, 300, 10,
    function() return floor((PF.TimersScale and PF.TimersScale() or 1.5) * 100 + 0.5) end,
    function(v) if PF.SetTimersScale then PF.SetTimersScale(v / 100) end end,
    function(v) return format("%d%%", v) end)
  local moveBtn = Button(page, "", HALF, 24, function()
    if PF.SetTimersMove then PF.SetTimersMove(not PF.TimersMoving()) end
  end)
  moveBtn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -88)
  Button(page, K("as_reset"), HALF, 24, function()
    if PF.ResetTimersPos then PF.ResetTimersPos() end
    PF.RefreshConfig()
  end):SetPoint("TOPLEFT", page, "TOPLEFT", HALF + 6, -88)
  local h2 = Text(page, K("as_move_d"), 10, C.dim)
  h2:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -118)
  h2:SetWidth(W); h2:SetJustifyH("LEFT")

  Header(page, K("as_dots"), -160, C.yellow)
  Slider(page, -182, K("as_dotwin"), 1, 8, 0.5,
    function() return tonumber(PF.db.dotWindow) or 4 end,
    function(v) PF.db.dotWindow = v end,
    function(v) return format("%.1f s", v) end)
  local h4 = Text(page, K("as_dotwin_d"), 10, C.dim)
  h4:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -220)
  h4:SetWidth(W); h4:SetJustifyH("LEFT")

  Header(page, K("as_precision"), -268, C.orange)
  Check(page, -290, K("as_plus"),
    function() return not PF.db.plusOff end,
    function(v) PF.db.plusOff = (not v) or nil end)
  local h3 = Text(page, K("as_plus_d"), 10, C.dim)
  h3:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -316)
  h3:SetWidth(W); h3:SetJustifyH("LEFT")

  Header(page, K("as_target"), -380, C.yellow)
  local function flag(key, y, label)
    Check(page, y, K(label),
      function() return PF.db[key] ~= false end,
      function(v) PF.db[key] = v and true or false end)
  end
  flag("plusAoe", -402, "as_aoe")
  Check(page, -424, K("as_click"),
    function() return PF.db.plusClick == true end,
    function(v) PF.db.plusClick = v and true or false end)
  Check(page, -446, K("as_proj"),
    function() return PF.db.proj ~= false end,
    function(v) PF.db.proj = v and true or false end)

  page:SetScript("OnHide", function()
    if PF.TimersMoving and PF.TimersMoving() then PF.SetTimersMove(false) end
  end)

  refreshers[#refreshers + 1] = function()
    local on = PF.TimersMoving and PF.TimersMoving()
    moveBtn:SetLabel(on and PF.T("as_moveStop") or PF.T("as_move"))
    moveBtn:SetActive(on)
  end
end

-- Pagina "HUD de dano": cabecera verde y seis barras planas, igual que la captura.
-- (Destello, estilo de destello, opacidad al canalizar y bloqueo/prueba viven ahora
--  en la pestana "Estilo del HUD"; mover el HUD sigue en la barra inferior.)
local function BuildGeneral(page)
  local SW = 321
  local function pct(v) return format("%d%%", v) end
  local body = CreateFrame("Frame", nil, page)
  body:SetPoint("TOPLEFT", page, "TOPLEFT", 4, 0)
  body:SetWidth(SW); body:SetHeight(VIEW_H)

  local hdr = Text(body, function() return Upper(PF.T("tab_general")) end, 12, C.green, "OUTLINE")
  hdr:SetPoint("TOPLEFT", body, "TOPLEFT", 0, -4)

  local Y0, STEP = -40, 44
  local function row(i) return Y0 - (i - 1) * STEP end

  -- 1) Escala del HUD
  Slider(body, row(1), K("gs_scale"), 50, 200, 5,
    function() return floor(PF.db.hud.scale * 100 + 0.5) end,
    function(v) PF.db.hud.scale = v / 100; PF.HUDApplyPos() end, pct, SW, true)

  -- 2) Opacidad en combate
  Slider(body, row(2), K("gs_alpha"), 10, 100, 5,
    function() return floor(PF.db.hud.alphaCombat * 100 + 0.5) end,
    function(v) PF.db.hud.alphaCombat = v / 100 end, pct, SW, true)

  -- 3) Mostrar HUD: 1 = solo combate, 2 = objetivo hostil, 3 = siempre
  local MODE_IDS = { "combat", "target", "always" }
  local MODE_KEYS = { "g_modeCombat", "g_modeTarget", "g_modeAlways" }
  Slider(body, row(3), K("gs_show"), 1, 3, 1,
    function()
      for i, id in ipairs(MODE_IDS) do if PF.db.hud.mode == id then return i end end
      return 2
    end,
    function(v) PF.db.hud.mode = MODE_IDS[v] or "target" end,
    function(v) return PF.T(MODE_KEYS[v] or "g_modeTarget") end, SW, true)

  -- 4) Opacidad fuera de combate
  Slider(body, row(4), K("gs_ooc"), 10, 100, 5,
    function() return floor(PF.db.hud.alphaOOC * 100 + 0.5) end,
    function(v) PF.db.hud.alphaOOC = v / 100 end, pct, SW, true)

  -- 5) Numero de iconos (1 a 3)
  Slider(body, row(5), K("gs_icons"), 1, 3, 1,
    function() return tonumber(PF.db.hud.icons) or 3 end,
    function(v) PF.db.hud.icons = v end,
    function(v) return format("%d", v) end, SW, true)

  -- 6) Tamano de los temporizadores bajo el HUD
  Slider(body, row(6), K("gs_size"), 50, 300, 10,
    function() return floor((PF.TimersScale and PF.TimersScale() or 1.5) * 100 + 0.5) end,
    function(v) if PF.SetTimersScale then PF.SetTimersScale(v / 100) end end,
    pct, SW, true)
end

local FALLBACK_SAMPLE = {
  "Interface\\Icons\\Ability_Warrior_Charge", "Interface\\Icons\\Spell_Fire_FlameBolt",
  "Interface\\Icons\\Spell_Holy_HolyBolt",
}

local function SampleTextures()
  local t = {}
  for n = 1, 60 do
    local tex = GetSpellTexture(n, "spell")
    if tex then
      local dup = false
      for i = 1, #t do if t[i] == tex then dup = true end end
      if not dup then t[#t + 1] = tex end
    end
    if #t == 6 then break end
  end
  for i = #t + 1, 6 do t[i] = FALLBACK_SAMPLE[((i - 1) % 3) + 1] end
  return t
end

local function BuildHudStyle(page)
  Header(page, K("hs_head"), 0, C.orange)
  local cards = {}
  local CARD_H, GAP = 84, 6
  local sample = SampleTextures()
  local keys = { "1", "2", "3" }

  for i, id in ipairs(PF.HUD_STYLE_ORDER or {}) do
    local st = PF.HUD_STYLES[id]
    local card = CreateFrame("Button", nil, page)
    card:SetWidth(W); card:SetHeight(CARD_H)
    card:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -22 - (i - 1) * (CARD_H + GAP))
    Skin(card, C.field, C.line)
    card:SetScript("OnEnter", function(self)
      if not self.active then self:SetBackdropColor(0.10, 0.15, 0.27, 1) end
    end)
    card:SetScript("OnLeave", function(self)
      self:SetBackdropColor(unpack(self.active and { 0.16, 0.14, 0.05, 1 } or C.field))
    end)
    card:SetScript("OnClick", function()
      PF.db.hud.style = id
      if PF.HUDApplyStyle then PF.HUDApplyStyle() end
      PF.RefreshConfig()
    end)
    function card:SetActive(on)
      self.active = on and true or false
      if self.active then
        self:SetBackdropColor(0.12, 0.17, 0.31, 1)
        self:SetBackdropBorderColor(unpack(C.accent))
      else
        self:SetBackdropColor(unpack(C.field))
        self:SetBackdropBorderColor(unpack(C.line))
      end
    end

    local pv = CreateFrame("Frame", nil, card)
    pv:SetPoint("LEFT", card, "LEFT", 14, 0)
    pv:SetScale(0.8)
    local m, q1, q2 = PF.HUDMakeIcon(pv), PF.HUDMakeIcon(pv), PF.HUDMakeIcon(pv)
    local decor = PF.HUDMakeDecor(pv)
    local frames = { m, q1, q2 }
    for n, f in ipairs(frames) do
      f.icon:SetTexture(sample[n])
      f.key:SetText(keys[n])
      f:Show()
    end
    PF.HUDLayout(id, pv, m, q1, q2, decor)
    if st.panel and PF.HUDPanelSample then PF.HUDPanelSample(decor) end

    local title = Text(card, K(st.name), 13, C.yellow, "OUTLINE")
    title:SetPoint("TOPLEFT", card, "TOPLEFT", 200, -16)
    local desc = Text(card, K(st.desc), 10, C.dim)
    desc:SetPoint("TOPLEFT", card, "TOPLEFT", 200, -36)
    desc:SetWidth(W - 200 - 10); desc:SetJustifyH("LEFT")
    cards[id] = card
  end

  local hint = Text(page, K("hs_hint"), 10, C.dim)
  hint:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -22 - #PF.HUD_STYLE_ORDER * (CARD_H + GAP) + 2)
  hint:SetWidth(W); hint:SetJustifyH("LEFT")

  -- Destello, opacidad al canalizar y acciones (antes en la pagina "HUD de dano")
  local function pct(v) return format("%d%%", v) end
  local HALF = (W - 6) / 2
  local yF = -(22 + #(PF.HUD_STYLE_ORDER or {}) * (CARD_H + GAP) + 34)
  Header(page, K("g_flash"), yF, C.yellow)
  Slider(page, yF - 20, K("g_period"), 100, 1000, 50,
    function() return floor(PF.db.fx.period * 1000 + 0.5) end,
    function(v) PF.db.fx.period = v / 1000 end,
    function(v) return format("%.2f s", v / 1000) end)
  Slider(page, yF - 58, K("g_intensity"), 10, 100, 5,
    function() return floor(PF.db.fx.intensity * 100 + 0.5) end,
    function(v) PF.db.fx.intensity = v / 100 end, pct)
  local FSTYLES = { { "glow", K("g_styleGlow") }, { "size", K("g_styleSize") } }
  local styleBtns = {}
  for i, st2 in ipairs(FSTYLES) do
    local b = Button(page, st2[2], HALF, 24, function()
      PF.db.fx.style = st2[1]
      PF.RefreshConfig()
    end)
    b:SetPoint("TOPLEFT", page, "TOPLEFT", (i - 1) * (HALF + 6), yF - 96)
    styleBtns[st2[1]] = b
  end
  Slider(page, yF - 134, K("g_alphaChannel"), 10, 100, 5,
    function() return floor(PF.db.hud.alphaChannel * 100 + 0.5) end,
    function(v) PF.db.hud.alphaChannel = v / 100 end, pct)
  local lockBtn = Button(page, "", HALF, 24, function() PF.ToggleHUDLock() end)
  lockBtn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, yF - 176)
  local testBtn = Button(page, "", HALF, 24, function() PF.ToggleHUDTest() end)
  testBtn:SetPoint("TOPLEFT", page, "TOPLEFT", HALF + 6, yF - 176)

  refreshers[#refreshers + 1] = function()
    for id, c in pairs(cards) do c:SetActive((PF.db.hud.style or "classic") == id) end
    for id, b in pairs(styleBtns) do b:SetActive(PF.db.fx.style == id) end
    lockBtn:SetLabel(PF.db.hud.locked and PF.T("g_unlock") or PF.T("g_lock"))
    lockBtn:SetActive(not PF.db.hud.locked)
    testBtn:SetLabel(PF.hudTest and PF.T("previewOn") or PF.T("previewOff"))
    testBtn:SetActive(PF.hudTest)
  end
end

local function BuildMultidot(page)
  Header(page, K("md_head"), 0, C.orange)
  Check(page, -22, K("md_enable"),
    function() return PF.db.multidot ~= false end,
    function(v) PF.Multidot_Set(v) end)
  Slider(page, -58, K("md_min"), 2, 6, 1,
    function() return tonumber(PF.db.multidotMin) or 3 end,
    function(v) PF.db.multidotMin = v end,
    function(v) return format("%d", v) end)
  local d = Text(page, K("md_desc"), 10, C.dim)
  d:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -110)
  d:SetWidth(W); d:SetJustifyH("LEFT")
end

local function BuildBuffs(page)
  local function pct(v) return format("%d%%", v) end
  local HALF = (W - 6) / 2

  Header(page, K("b_title"), 0, C.orange)
  local onBtn = Button(page, "", HALF, 24, function()
    PF.db.bhud.enabled = not PF.db.bhud.enabled
    PF.RefreshConfig()
  end)
  onBtn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -20)
  local combatBtn = Button(page, "", HALF, 24, function()
    PF.db.bhud.combat = not PF.db.bhud.combat
    PF.RefreshConfig()
  end)
  combatBtn:SetPoint("TOPLEFT", page, "TOPLEFT", HALF + 6, -20)
  local pulseBtn = Button(page, "", HALF, 24, function()
    PF.db.bhud.pulse = not PF.db.bhud.pulse
    PF.RefreshConfig()
  end)
  pulseBtn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -50)
  local glowBtn = Button(page, "", HALF, 24, function()
    PF.db.bhud.glow = not PF.db.bhud.glow
    PF.RefreshConfig()
  end)
  glowBtn:SetPoint("TOPLEFT", page, "TOPLEFT", HALF + 6, -50)

  Header(page, K("g_look"), -88, C.yellow)
  Slider(page, -108, K("g_scale"), 50, 200, 5,
    function() return floor(PF.db.bhud.scale * 100 + 0.5) end,
    function(v) PF.db.bhud.scale = v / 100; PF.BuffHUDApplyPos() end, pct)
  Slider(page, -146, K("g_alphaCombat"), 10, 100, 5,
    function() return floor(PF.db.bhud.alphaCombat * 100 + 0.5) end,
    function(v) PF.db.bhud.alphaCombat = v / 100 end, pct)
  Slider(page, -184, K("g_alphaOOC"), 10, 100, 5,
    function() return floor(PF.db.bhud.alphaOOC * 100 + 0.5) end,
    function(v) PF.db.bhud.alphaOOC = v / 100 end, pct)

  Header(page, K("g_actions"), -228, C.green)
  local lockBtn = Button(page, "", HALF, 24, function() PF.ToggleBuffHUDLock() end)
  lockBtn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -248)
  local testBtn = Button(page, "", HALF, 24, function() PF.ToggleBuffHUDTest() end)
  testBtn:SetPoint("TOPLEFT", page, "TOPLEFT", HALF + 6, -248)

  local hint = Text(page, K("b_hint"), 10, C.dim)
  hint:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -284)
  hint:SetWidth(W); hint:SetJustifyH("LEFT")

  refreshers[#refreshers + 1] = function()
    local B = PF.db.bhud
    onBtn:SetLabel(PF.T("b_enable") .. ": " .. (B.enabled and "ON" or "OFF"))
    onBtn:SetActive(B.enabled)
    combatBtn:SetLabel(PF.T("b_combat") .. ": " .. (B.combat and "ON" or "OFF"))
    combatBtn:SetActive(B.combat)
    pulseBtn:SetLabel(PF.T("b_pulse") .. ": " .. (B.pulse and "ON" or "OFF"))
    pulseBtn:SetActive(B.pulse)
    glowBtn:SetLabel(PF.T("b_glow") .. ": " .. (B.glow and "ON" or "OFF"))
    glowBtn:SetActive(B.glow)
    lockBtn:SetLabel(B.locked and PF.T("g_unlock") or PF.T("g_lock"))
    lockBtn:SetActive(not B.locked)
    testBtn:SetLabel(PF.bhudTest and PF.T("previewOn") or PF.T("previewOff"))
    testBtn:SetActive(PF.bhudTest)
  end
end

local function BuildRotation(page)
  local _, class = UnitClass("player")
  local HALF = (W - 6) / 2
  local HI = "|cffffd100"

  Header(page, K("r_title"), 0, C.orange)
  local btns = {}
  local MODES = { { false, K("r_normal") }, { true, K("r_max") } }
  for i, m in ipairs(MODES) do
    local b = Button(page, m[2], HALF, 26, function()
      PF.db.rot.max = m[1]
      PF.RefreshConfig()
    end)
    b:SetPoint("TOPLEFT", page, "TOPLEFT", (i - 1) * (HALF + 6), -22)
    btns[i] = b
  end

  Header(page, K("r_what"), -66, C.yellow)
  local function desc()
    return PF.T(class == "ROGUE" and "r_descRogue" or "r_descDruid")
  end
  local d = Text(page, desc, 10, C.dim)
  d:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -86)
  d:SetWidth(W); d:SetJustifyH("LEFT")

  Header(page, K("r_live"), -296, C.green)
  local live = Text(page, "", 11)
  live:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -316)
  live:SetWidth(W); live:SetJustifyH("LEFT")
  local acc = 0
  page:SetScript("OnUpdate", function(_, dt)
    acc = acc + dt
    if acc < 0.1 then return end
    acc = 0
    if not (PF.db and PF.db.rot and PF.db.rot.max) then
      live:SetText(PF.T("r_liveNormal"))
    elseif PF.holdSpell then
      live:SetText(PF.T("r_liveHold", PF.holdSpell, PF.holdEta or 0))
    else
      live:SetText(PF.T("r_liveNone"))
    end
  end)

  local note = Text(page, K("r_note"), 10, C.dim)
  note:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -350)
  note:SetWidth(W); note:SetJustifyH("LEFT")

  refreshers[#refreshers + 1] = function()
    local on = PF.db.rot.max and true or false
    btns[1]:SetActive(not on)
    btns[2]:SetActive(on)
  end
end

local function BuildCombos(page)
  local function pct(v) return format("%d%%", v) end
  local function px(v) return format("%d px", v) end
  local HALF, THIRD = (W - 6) / 2, (W - 12) / 3
  local FIVE = (W - 20) / 5

  Header(page, K("cb_title"), 0, C.orange)
  Check(page, -20, K("cb_enable"),
    function() return PF.db.combo.enabled end,
    function(v) PF.db.combo.enabled = v end)

  Slider(page, -46, K("cb_scale"), 50, 250, 5,
    function() return floor(PF.db.combo.scale * 100 + 0.5) end,
    function(v) PF.db.combo.scale = v / 100; PF.ComboBarApply() end, pct)
  Slider(page, -82, K("cb_w"), 10, 60, 1,
    function() return floor(PF.db.combo.w + 0.5) end,
    function(v) PF.db.combo.w = v; PF.ComboBarApply() end, px)
  Slider(page, -118, K("cb_h"), 6, 40, 1,
    function() return floor(PF.db.combo.h + 0.5) end,
    function(v) PF.db.combo.h = v; PF.ComboBarApply() end, px)
  Slider(page, -154, K("cb_gap"), 0, 12, 1,
    function() return floor(PF.db.combo.gap + 0.5) end,
    function(v) PF.db.combo.gap = v; PF.ComboBarApply() end, px)
  Slider(page, -190, K("cb_alpha"), 10, 100, 5,
    function() return floor(PF.db.combo.alpha * 100 + 0.5) end,
    function(v) PF.db.combo.alpha = v / 100 end, pct)

  Header(page, K("cb_color"), -234, C.yellow)
  local palBtns = {}
  for i, pal in ipairs(PF.COMBO_PALETTE_LIST) do
    local b = Button(page, K("pal_" .. pal[1]), FIVE, 24, function()
      PF.db.combo.palette = pal[1]
      PF.RefreshConfig()
    end)
    b:SetPoint("TOPLEFT", page, "TOPLEFT", (i - 1) * (FIVE + 5), -254)
    palBtns[pal[1]] = b
  end

  Header(page, K("cb_showHdr"), -288, C.green)
  local SHOWS = { { "always", K("cb_always") }, { "target", K("cb_target") }, { "points", K("cb_points") } }
  local showBtns = {}
  for i, sh in ipairs(SHOWS) do
    local b = Button(page, sh[2], THIRD, 24, function()
      PF.db.combo.show = sh[1]
      PF.RefreshConfig()
    end)
    b:SetPoint("TOPLEFT", page, "TOPLEFT", (i - 1) * (THIRD + 6), -308)
    showBtns[sh[1]] = b
  end

  Check(page, -340, K("cb_number"),
    function() return PF.db.combo.number end,
    function(v) PF.db.combo.number = v end)

  local lockBtn = Button(page, "", HALF, 24, function() PF.ToggleComboLock() end)
  lockBtn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -368)
  local testBtn = Button(page, "", HALF, 24, function() PF.ToggleComboTest() end)
  testBtn:SetPoint("TOPLEFT", page, "TOPLEFT", HALF + 6, -368)

  refreshers[#refreshers + 1] = function()
    for id, b in pairs(palBtns) do b:SetActive(PF.db.combo.palette == id) end
    for id, b in pairs(showBtns) do b:SetActive(PF.db.combo.show == id) end
    lockBtn:SetLabel(PF.db.combo.locked and PF.T("cb_move") or PF.T("cb_fix"))
    lockBtn:SetActive(not PF.db.combo.locked)
    testBtn:SetLabel(PF.comboTest and PF.T("previewOn") or PF.T("previewOff"))
    testBtn:SetActive(PF.comboTest)
  end
end

local function BuildSounds(page)
  Header(page, K("s_title"), 0, C.orange)
  Check(page, -22, K("s_enable"),
    function() return PF.db.sound.enabled end,
    function(v) PF.db.sound.enabled = v end)

  local hint = Text(page, K("s_hint"), 10, C.dim)
  hint:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -50)

  if #PF.procList == 0 then
    local none = Text(page, K("s_none"), 11, C.dim)
    none:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -80)
    return
  end

  Header(page, K("s_each"), -74, C.yellow)
  for i, proc in ipairs(PF.procList) do
    local y = -98 - (i - 1) * 30
    local name = Text(page, proc.name, 11)
    name:SetPoint("TOPLEFT", page, "TOPLEFT", 0, y - 6)
    name:SetWidth(170); name:SetJustifyH("LEFT")

    local sb = Button(page, "", 146, 22, function(self, mouse)
      local cur = PF.GetProcSound(proc)
      local nxt = PF.SoundCycle(cur, (mouse == "RightButton") and -1 or 1)
      PF.SetProcSound(proc, nxt)
      PF.PlaySoundEntry(nxt)
      PF.RefreshConfig()
    end)
    sb:SetPoint("TOPLEFT", page, "TOPLEFT", 176, y)

    local pb = Button(page, K("s_test"), 68, 22, function()
      PF.PlaySoundEntry(PF.GetProcSound(proc))
    end)
    pb:SetPoint("TOPLEFT", page, "TOPLEFT", W - 68, y)

    refreshers[#refreshers + 1] = function()
      local id = PF.GetProcSound(proc)
      sb:SetLabel(PF.SoundName(id))
      sb:SetActive(id ~= "none")
    end
  end
end

-- Pestana "Avisos": aviso en pantalla cuando aparece un proc
local function BuildAlerts(page)
  local function AL() return PF.Alerts end
  local MAXC = (PF.Alerts and PF.Alerts.MAX_CUSTOM) or 4   -- avisos personalizados permitidos
  local THIRD = (W - 12) / 3
  local nBuilt = 0
  for _, p in ipairs(PF.procList) do if not p.custom then nBuilt = nBuilt + 1 end end

  Header(page, K("as_alerts"), 0, C.orange)
  Check(page, -22, K("as_a_on"),
    function() local A = AL(); return A and A.Cfg().enabled end,
    function(v) local A = AL(); if A then A.Cfg().enabled = v and true or false end end)
  Slider(page, -48, K("as_a_size"), 50, 300, 10,
    function() local A = AL(); return floor(((A and A.Cfg().scale) or 1) * 100 + 0.5) end,
    function(v) local A = AL(); if A then A.SetScale(v / 100) end end,
    function(v) return format("%d%%", v) end)
  Slider(page, -88, K("as_a_dur"), 10, 60, 5,
    function() local A = AL(); return floor(((A and A.Cfg().dur) or 2.5) * 10 + 0.5) end,
    function(v) local A = AL(); if A then A.Cfg().dur = v / 10 end end,
    function(v) return format("%.1f s", v / 10) end)
  Check(page, -128, K("as_a_icon"),
    function() local A = AL(); return A and A.Cfg().icon end,
    function(v) local A = AL(); if A then A.Cfg().icon = v and true or false end end)
  Check(page, -150, K("as_a_text"),
    function() local A = AL(); return A and A.Cfg().text end,
    function(v) local A = AL(); if A then A.Cfg().text = v and true or false end end)

  local moveBtn = Button(page, "", THIRD, 24, function()
    local A = AL()
    if A then A.SetMove(not A.IsMoving()) end
  end)
  moveBtn:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -176)
  Button(page, K("as_reset"), THIRD, 24, function()
    local A = AL()
    if A then A.ResetPos() end
    PF.RefreshConfig()
  end):SetPoint("TOPLEFT", page, "TOPLEFT", THIRD + 6, -176)
  Button(page, K("as_a_test"), THIRD, 24, function()
    local A = AL()
    if A then A.Test(PF.procList[1] and PF.procList[1].name or nil) end
  end):SetPoint("TOPLEFT", page, "TOPLEFT", (THIRD + 6) * 2, -176)
  local hint = Text(page, K("as_a_hint"), 10, C.dim)
  hint:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -206)
  hint:SetWidth(W); hint:SetJustifyH("LEFT")

  -- procs de la clase: sonido, aviso si/no y prueba
  Header(page, K("as_procs"), -246, C.yellow)
  if nBuilt == 0 then
    local none = Text(page, K("as_noprocs"), 11, C.dim)
    none:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -270)
    none:SetWidth(W); none:SetJustifyH("LEFT")
  end
  local function ProcRow(proc, y, getProc)
    local name = Text(page, proc and proc.name or "", 11)
    name:SetPoint("TOPLEFT", page, "TOPLEFT", 0, y - 6)
    name:SetWidth(120); name:SetJustifyH("LEFT")
    local sb = Button(page, "", 120, 22, function(self, mouse)
      local p = getProc(); if not p then return end
      local nxt = PF.SoundCycle(PF.GetProcSound(p), (mouse == "RightButton") and -1 or 1)
      PF.SetProcSound(p, nxt)
      PF.PlaySoundEntry(nxt)
      PF.RefreshConfig()
    end)
    sb:SetPoint("TOPLEFT", page, "TOPLEFT", 126, y)
    local tb = Button(page, "", 70, 22, function()
      local p = getProc(); local A = AL()
      if not (p and A) then return end
      local off = A.Cfg().off
      off[p.key] = (not off[p.key]) or nil
      PF.RefreshConfig()
    end)
    tb:SetPoint("TOPLEFT", page, "TOPLEFT", 252, y)
    local test = Button(page, K("as_a_test"), 68, 22, function()
      local p = getProc(); local A = AL()
      if p and A then A.Test(p.name); PF.PlaySoundEntry(PF.GetProcSound(p)) end
    end)
    test:SetPoint("TOPLEFT", page, "TOPLEFT", W - 68, y)
    return { name = name, sb = sb, tb = tb, test = test }
  end

  local builtRows = {}
  local k = 0
  for i, proc in ipairs(PF.procList) do
    if not proc.custom then
      k = k + 1
      local row = ProcRow(proc, -270 - (k - 1) * 28, function() return proc end)
      builtRows[#builtRows + 1] = { row = row, proc = proc }
    end
  end

  local yC = -270 - math.max(nBuilt, 1) * 28 - 14
  Header(page, K("as_custom"), yC, C.green)
  local eb = CreateFrame("EditBox", nil, page)
  eb:SetPoint("TOPLEFT", page, "TOPLEFT", 0, yC - 22)
  eb:SetWidth(W - 110); eb:SetHeight(24)
  Skin(eb, C.field, C.line)
  PF.SetLFont(eb, FONT, 11)
  eb:SetTextColor(C.text[1], C.text[2], C.text[3])
  eb:SetTextInsets(8, 8, 0, 0)
  eb:SetAutoFocus(false)
  eb:SetMaxLetters(40)
  eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  local function DoAdd()
    local A = AL()
    local nm = strtrim(eb:GetText() or "")
    if A and nm ~= "" and A.AddCustom(nm) then eb:SetText("") end
    eb:ClearFocus()
    PF.RefreshConfig()
  end
  eb:SetScript("OnEnterPressed", DoAdd)
  Button(page, K("as_c_add"), 104, 24, DoAdd):SetPoint("TOPLEFT", page, "TOPLEFT", W - 104, yC - 22)
  local ch = Text(page, K("as_c_hint"), 10, C.dim)
  ch:SetPoint("TOPLEFT", page, "TOPLEFT", 0, yC - 52)
  ch:SetWidth(W); ch:SetJustifyH("LEFT")

  local customRows = {}
  for i = 1, MAXC do
    local y = yC - 84 - (i - 1) * 28
    local row = ProcRow(nil, y, function() return PF.procList[nBuilt + i] end)
    row.test:ClearAllPoints()
    row.test:SetPoint("TOPLEFT", page, "TOPLEFT", 252 + 70 + 4, y)
    row.test:SetWidth(46)
    row.tb:SetWidth(70)
    local rm = Button(page, "x", 24, 22, function()
      local A = AL(); if A then A.RemoveCustom(i) end
      PF.RefreshConfig()
    end)
    rm:SetPoint("TOPLEFT", page, "TOPLEFT", W - 24, y)
    row.rm = rm
    customRows[i] = row
  end

  page:SetScript("OnHide", function()
    local A = PF.Alerts
    if A and A.IsMoving() then A.SetMove(false) end
  end)

  local function Paint(row, proc)
    if not proc then return end
    row.name:SetText(proc.name)
    local id = PF.GetProcSound(proc)
    row.sb:SetLabel(PF.SoundName(id)); row.sb:SetActive(id ~= "none")
    local A = PF.Alerts
    local on = not (A and A.Cfg().off[proc.key])
    row.tb:SetLabel(on and PF.T("as_pa_on") or PF.T("as_pa_off")); row.tb:SetActive(on)
  end

  refreshers[#refreshers + 1] = function()
    local A = PF.Alerts
    moveBtn:SetLabel(A and A.IsMoving() and PF.T("as_moveStop") or PF.T("as_a_move"))
    moveBtn:SetActive(A and A.IsMoving())
    for _, b in ipairs(builtRows) do Paint(b.row, b.proc) end
    local custom = (A and A.Cfg().custom) or {}
    for i = 1, MAXC do
      local row = customRows[i]
      local proc = custom[i] and PF.procList[nBuilt + i]
      local show = proc ~= nil
      for _, w in pairs({ row.name, row.sb, row.tb, row.test, row.rm }) do
        if show then w:Show() else w:Hide() end
      end
      if show then Paint(row, proc) end
    end
  end
end

local function BuildProfiles(page)
  Header(page, K("p_char"), 0, C.orange)
  local info1 = Text(page, "", 11); info1:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -20)
  local info2 = Text(page, "", 11); info2:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -38)
  local info3 = Text(page, "", 11); info3:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -56)

  refreshers[#refreshers + 1] = function()
    local group, _, spec = PF.GetSpecInfo()
    local _, class = UnitClass("player")
    local cname = (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[class]) or class or "?"
    info1:SetText(PF.T("p_info1", PF.GetCharKey()))
    info2:SetText(PF.T("p_info2", cname))
    info3:SetText(PF.T("p_info3", group, PF.GroupLabel(group), spec))
  end

  local clone = Button(page, K("p_clone"), W, 24, function()
    local items = {}
    for _, p in ipairs(PF.ListProfiles()) do
      items[#items + 1] = { label = p.label, key = p.key, group = p.group }
    end
    OpenPicker(PF.T("p_cloneTitle"), items, function(it)
      PF.CloneProfile(it.key, it.group)
      picker:Hide()
    end)
  end)
  clone:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -92)

  Header(page, K("p_helpHdr"), -136, C.green)
  local help = Text(page, K("p_help"), 10, C.dim)
  help:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -156)
  help:SetWidth(W); help:SetJustifyH("LEFT")
end

-- La pestana "Barra recomendada" vive en el addon PulseFlash_Loadout: se carga
-- y se construye solo la primera vez que se abre esa pestana.
local pendingLoadout

-- ---------------------------------------------------------------------------
-- Pestana "Analisis": informe tras un combate contra un jefe (diseno de la foto)
-- ---------------------------------------------------------------------------
local COL2 = 277                                  -- columna "Resultado"
local function HLine(parent, y)
  local l = parent:CreateTexture(nil, "ARTWORK")
  l:SetTexture(WHITE)
  l:SetVertexColor(0.17, 0.17, 0.17, 1)
  l:SetHeight(1)
  l:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y)
  l:SetPoint("TOPRIGHT", parent, "TOPRIGHT", 0, y)
  return l
end

local function BuildAnalysis(page)
  local head = Text(page, K("an_head"), 14, C.text)
  head:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -2)
  head:SetWidth(W); head:SetJustifyH("LEFT")

  local h1 = Text(page, K("an_metric"), 13, C.text, "OUTLINE")
  h1:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -62)
  local h2 = Text(page, K("an_result"), 13, C.text, "OUTLINE")
  h2:SetPoint("TOPLEFT", page, "TOPLEFT", COL2, -62)

  local ROW0, ROWH = 90, 40
  local keys = { "an_dot", "an_procs", "an_idle", "an_early" }
  local vals = {}
  for i, key in ipairs(keys) do
    local top = ROW0 + (i - 1) * ROWH
    HLine(page, -top)
    local name = Text(page, K(key), 12, C.text)
    name:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -(top + 13))
    local val = Text(page, "—", 12, C.text)
    val:SetPoint("TOPLEFT", page, "TOPLEFT", COL2, -(top + 13))
    vals[i] = val
  end

  local info = Text(page, "", 10, C.dim)
  info:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -(ROW0 + 4 * ROWH + 14))
  info:SetWidth(W); info:SetJustifyH("LEFT")

  Check(page, -(ROW0 + 4 * ROWH + 54), K("an_onlyboss"),
    function() return not PF.db.anAll end,
    function(v) PF.db.anAll = (not v) or nil end)

  if not PF.Analysis and LoadAddOn then LoadAddOn("PulseFlash_Analysis") end
  local clear = Button(page, K("an_clear")(), 150, 24, function()
    if PF.Analysis then PF.Analysis.Clear() end
    PF.RefreshConfig()
  end)
  clear:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -(ROW0 + 4 * ROWH + 86))
  relabels[#relabels + 1] = function() clear:SetLabel(PF.T("an_clear")) end

  local function Update()
    local A = PF.Analysis
    local rep = A and (A.Live() or A.Last())
    if not rep then
      for i = 1, 4 do vals[i]:SetText("—") end
      info:SetText(PF.T("an_none"))
      return
    end
    vals[1]:SetText(rep.dot and format("%d%%", floor(rep.dot + 0.5)) or "—")
    vals[2]:SetText(rep.procs and format("%d%%", floor(rep.procs + 0.5)) or "—")
    vals[3]:SetText(rep.idle and format("%.1f%%", rep.idle) or "—")
    vals[4]:SetText(tostring(rep.early or 0))
    local d = rep.dur or 0
    local dur = format("%d:%02d", floor(d / 60), floor(d % 60))
    if rep.live then
      info:SetText(PF.T("an_live", rep.boss or "?"))
    else
      info:SetText(PF.T("an_last", rep.boss or "?", dur, rep.t and date("%d/%m %H:%M", rep.t) or ""))
    end
  end
  refreshers[#refreshers + 1] = Update
  local acc = 0
  page:SetScript("OnUpdate", function(_, dt)
    acc = acc + dt
    if acc >= 1 then acc = 0; Update() end
  end)
end

-- ---------------------------------------------------------------------------
-- Pestana "Simulador": escenarios simulados y verificaciones (motor en PulseFlash_Sim)
-- ---------------------------------------------------------------------------
local function BuildSim(page)
  local green, red = { 0.30, 1.00, 0.30 }, { 1.00, 0.30, 0.30 }
  local sel = 1
  local THIRD = (W - 12) / 3

  Header(page, function() return Upper(PF.T("tab_sim")) end, -4, C.green)

  local scBtns = {}
  local function ScLabel(i)
    local sc = PF.SIM_SCENARIOS and PF.SIM_SCENARIOS[i]
    if sc then return (PF.GetLang() == "es") and sc.es or sc.en end
    return ({ "Jefe · 90 s", "Jefe · 180 s + procs", "Corto · 30 s" })[i]
  end
  local function ScId(i)
    local sc = PF.SIM_SCENARIOS and PF.SIM_SCENARIOS[i]
    return sc and sc.id or ({ "boss90", "boss180", "trash30" })[i]
  end

  local status = Text(page, "", 10, C.dim)
  status:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -92)
  status:SetWidth(W); status:SetJustifyH("LEFT")

  local h1 = Text(page, K("sim_col"), 13, C.text, "OUTLINE")
  h1:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -110)
  local h2 = Text(page, K("an_result"), 13, C.text, "OUTLINE")
  h2:SetPoint("TOPLEFT", page, "TOPLEFT", COL2, -110)

  local ROW0, ROWH = 130, 58
  local keys = { "sim_order", "sim_auras", "sim_waste", "sim_cds", "sim_reg" }
  local rowRes, rowDet = {}, {}
  for i, key in ipairs(keys) do
    local top = ROW0 + (i - 1) * ROWH
    HLine(page, -top)
    local name = Text(page, K(key), 12, C.text)
    name:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -(top + 8))
    local res = Text(page, "—", 12, C.dim)
    res:SetPoint("TOPLEFT", page, "TOPLEFT", COL2, -(top + 8))
    local det = Text(page, "", 10, C.dim)
    det:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -(top + 26))
    det:SetWidth(COL2 - 8); det:SetHeight(28)
    det:SetJustifyH("LEFT"); det:SetJustifyV("TOP")
    rowRes[i], rowDet[i] = res, det
  end

  local function Clear()
    for i = 1, 5 do
      rowRes[i]:SetText("—"); rowRes[i]:SetTextColor(C.dim[1], C.dim[2], C.dim[3])
      rowDet[i]:SetText("")
    end
    status:SetText(PF.T("sim_idle"))
  end

  local function Render()
    local id = ScId(sel)
    local r = PF.simLast and PF.simLast[id]
    if not r then Clear(); return end
    for i, ch in ipairs(r.checks) do
      rowRes[i]:SetText(PF.T(ch.ok and "sim_ok" or "sim_fail"))
      local col = ch.ok and green or red
      rowRes[i]:SetTextColor(col[1], col[2], col[3])
      rowDet[i]:SetText(ch.detail or "")
    end
    status:SetText(PF.T("sim_done", r.m.casts or 0, r.pass or 0))
    local cmp = PF.Sim_Compare and PF.Sim_Compare(id) or { state = "none" }
    local es = PF.GetLang() == "es"
    local txt, col, det = PF.T("sim_noreg"), C.dim,
      es and "Guarda una referencia antes de tocar el addon y compara después."
         or "Save a baseline before changing the addon, then compare."
    if cmp.state == "same" then
      txt, col = PF.T("sim_same"), green
      det = es and ("Idéntico a la referencia (v" .. (cmp.ver or "?") .. ").")
               or ("Identical to the baseline (v" .. (cmp.ver or "?") .. ").")
    elseif cmp.state == "better" then
      txt, col = PF.T("sim_better"), green
      det = (es and "Mejora en: " or "Improves: ") .. table.concat(cmp.better, ", ")
    elseif cmp.state == "worse" then
      txt, col = PF.T("sim_worse"), red
      det = (es and "Empeora en: " or "Worse in: ") .. table.concat(cmp.worse, ", ")
      if cmp.firstDiff then det = det .. (es and (" · cambia desde la acción " .. cmp.firstDiff) or (" · differs from action " .. cmp.firstDiff)) end
    elseif cmp.state == "changed" then
      txt, col = PF.T("sim_chg"), C.yellow
      det = es and ("Otra secuencia desde la acción " .. (cmp.firstDiff or "?") .. ", sin empeorar métricas.")
               or ("Different sequence from action " .. (cmp.firstDiff or "?") .. ", no metric got worse.")
    end
    rowRes[5]:SetText(txt); rowRes[5]:SetTextColor(col[1], col[2], col[3])
    rowDet[5]:SetText(det)
  end

  for i = 1, 3 do
    local b = Button(page, ScLabel(i), THIRD, 24, function()
      sel = i
      for k = 1, 3 do scBtns[k]:SetActive(k == sel) end
      Render()
    end)
    b:SetPoint("TOPLEFT", page, "TOPLEFT", (i - 1) * (THIRD + 6), -26)
    scBtns[i] = b
  end

  local function Ensure()
    if not PF.Sim_Run and LoadAddOn then LoadAddOn("PulseFlash_Sim") end
    if PF.Sim_Run then return true end
    status:SetText("PulseFlash_Sim: no se pudo cargar / could not load")
    return false
  end

  local function RunNow()
    if not Ensure() then return false end
    local r, err = PF.Sim_Run(ScId(sel))
    if not r then Clear(); status:SetText(tostring(err)); return false end
    Render()
    return true
  end

  local bRun = Button(page, K("sim_run")(), THIRD, 24, function() RunNow() end, "orange")
  bRun:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -58)
  local bSave = Button(page, K("sim_save")(), THIRD, 24, function()
    if not (PF.simLast and PF.simLast[ScId(sel)]) and not RunNow() then return end
    if PF.Sim_Save and PF.Sim_Save(ScId(sel)) then Render() end
  end, "orange")
  bSave:SetPoint("TOPLEFT", page, "TOPLEFT", THIRD + 6, -58)
  local bSeq = Button(page, K("sim_seq")(), THIRD, 24, function()
    if not (PF.simLast and PF.simLast[ScId(sel)]) and not RunNow() then return end
    PF.Msg(PF.Sim_Seq(ScId(sel), 30))
  end, "orange")
  bSeq:SetPoint("TOPLEFT", page, "TOPLEFT", 2 * (THIRD + 6), -58)
  relabels[#relabels + 1] = function()
    bRun:SetLabel(PF.T("sim_run")); bSave:SetLabel(PF.T("sim_save")); bSeq:SetLabel(PF.T("sim_seq"))
  end

  refreshers[#refreshers + 1] = function()
    for i = 1, 3 do scBtns[i]:SetLabel(ScLabel(i)); scBtns[i]:SetActive(i == sel) end
    Render()
  end
end

local function BuildLoadoutLazy(page)
  pendingLoadout = function()
    if not PF.BuildLoadoutTab and LoadAddOn then LoadAddOn("PulseFlash_Loadout") end
    if PF.BuildLoadoutTab then PF.BuildLoadoutTab(page) end
  end
end

local function SelectTab(i)
  if pendingLoadout and TAB_KEYS[i] == "tab_loadout" then
    local build = pendingLoadout
    pendingLoadout = nil
    build()
  end
  for k, pg in ipairs(pages) do
    if k == i then pg:Show() else pg:Hide() end
    tabs[k]:SetActive(k == i)
    tabs[k]:SetLabel(PF.T(TAB_KEYS[k]))
  end
  curTab = i
  if pageTitle then pageTitle:SetText(PF.T(TAB_KEYS[i])) end
  if picker then picker:Hide() end
end

local function BuildLanguage(page)
  Header(page, K("lang_head"), 0, C.yellow)
  local hint = Text(page, K("lang_hint"), 10, C.dim)
  hint:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -22)
  hint:SetWidth(W); hint:SetJustifyH("LEFT")
  local btns = {}
  for i, code in ipairs(PF.LANGS) do
    local b = Button(page, PF.LANG_NAMES[code], W, 34, function() PF.SetLang(code) end)
    b:SetPoint("TOPLEFT", page, "TOPLEFT", 0, -52 - (i - 1) * 42)
    PF.SetLFont(b.text, "Fonts\\ARIALN.TTF", 14, "OUTLINE", true)
    btns[code] = b
  end
  refreshers[#refreshers + 1] = function()
    local cur = PF.GetLang()
    for code, b in pairs(btns) do b:SetActive(code == cur) end
  end
end

local function BuildPanel()
  if panel then return end
  panel = CreateFrame("Frame", "PulseFlashConfig", UIParent)
  panel:SetWidth(680); panel:SetHeight(604)
  panel:SetPoint("CENTER", UIParent, "CENTER", 0, 20)
  panel:SetFrameStrata("FULLSCREEN_DIALOG")
  panel:SetClampedToScreen(true)
  panel:SetMovable(true)
  panel:EnableMouse(true)
  panel:RegisterForDrag("LeftButton")
  panel:SetScript("OnDragStart", function(self) self:StartMoving() end)
  panel:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
  Skin(panel, C.bg, C.line)
  tinsert(UISpecialFrames, "PulseFlashConfig")

  -- Logo (esquina superior izquierda)
  local logo = panel:CreateTexture(nil, "ARTWORK")
  logo:SetTexture(MEDIA .. "logo.tga")
  logo:SetWidth(204); logo:SetHeight(51)
  logo:SetPoint("TOPLEFT", panel, "TOPLEFT", 12, -10)

  -- Version
  local verLabel = Text(panel, K("c_version"), 12, C.text, "OUTLINE")
  verLabel:SetPoint("TOPLEFT", panel, "TOPLEFT", 236, -14)
  local verVal = Text(panel, (GetAddOnMetadata and GetAddOnMetadata("PulseFlash", "Version")) or "?", 12, C.green, "OUTLINE")
  verVal:SetPoint("LEFT", verLabel, "RIGHT", 6, 0)

  local close = CloseButton(panel, function() panel:Hide() end)
  close:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -12, -5)

  -- Enlace de CurseForge (se puede seleccionar y copiar con Ctrl+C)
  local curLabel = Text(panel, "CurseForge:", 11, C.text, "OUTLINE")
  curLabel:SetPoint("TOPLEFT", panel, "TOPLEFT", 236, -34)
  local curEdit = CreateFrame("EditBox", nil, panel)
  curEdit:SetWidth(430); curEdit:SetHeight(22)
  curEdit:SetPoint("TOPLEFT", panel, "TOPLEFT", 236, -48)
  Skin(curEdit, C.field, C.line)
  PF.SetLFont(curEdit, FONT, 11)
  curEdit:SetTextColor(C.text[1], C.text[2], C.text[3])
  curEdit:SetTextInsets(8, 8, 0, 0)
  curEdit:SetAutoFocus(false)
  curEdit:SetText(CURSE_URL)
  curEdit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  curEdit:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
  curEdit:SetScript("OnTextChanged", function(self) if self:GetText() ~= CURSE_URL then self:SetText(CURSE_URL) end end)
  local curHint = Text(panel, K("c_copyhint"), 10, { 1.00, 0.20, 0.20 })
  curHint:SetPoint("TOPLEFT", panel, "TOPLEFT", 236, -73)

  -- Contenido: caja con borde
  local box = CreateFrame("Frame", nil, panel)
  box:SetWidth(440); box:SetHeight(VIEW_H + 20)
  box:SetPoint("TOPLEFT", panel, "TOPLEFT", 226, -92)
  Skin(box, { 0.040, 0.040, 0.040, 1 }, C.line)

  -- Firma inferior derecha
  local sigAuthor = Text(panel, "PulseFlash  ·  by Aquazksj", 10, C.dim)
  sigAuthor:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -85, 42)

  local _, class = UnitClass("player")
  local nHS = #(PF.HUD_STYLE_ORDER or {})
  local sections = {
    { "tab_general", BuildGeneral },
    { "tab_hudstyle", BuildHudStyle, 22 + nHS * 90 + 34 + 210 },
    { "tab_buffs", BuildBuffs },
    { "tab_loadout", BuildLoadoutLazy, 1000 },
    { "tab_assist", BuildAssist, 460 },
  }
  if class == "ROGUE" or class == "DRUID" then
    sections[#sections + 1] = { "tab_rotation", BuildRotation }
    sections[#sections + 1] = { "tab_combos", BuildCombos }
  end
  if PF.Multidot_Supported and PF.Multidot_Supported() then
    sections[#sections + 1] = { "tab_multidot", BuildMultidot }
  end
  sections[#sections + 1] = { "tab_sounds", BuildSounds }
  do
    local nb = 0
    for _, p in ipairs(PF.procList) do if not p.custom then nb = nb + 1 end end
    sections[#sections + 1] = { "tab_alerts", BuildAlerts,
      270 + math.max(nb, 1) * 28 + 14 + 84 + ((PF.Alerts and PF.Alerts.MAX_CUSTOM) or 4) * 28 + 20 }
  end
  sections[#sections + 1] = { "tab_analysis", BuildAnalysis }
  sections[#sections + 1] = { "tab_sim", BuildSim }
  sections[#sections + 1] = { "tab_profiles", BuildProfiles }
  sections[#sections + 1] = { "tab_lang", BuildLanguage }
  for i, sec in ipairs(sections) do TAB_KEYS[i] = sec[1] end

  -- barra lateral: pestanas de 28 px con paso de 32 px (se reparten si hay muchas)
  local tabStep = math.min(32, math.floor((VIEW_H + 20) / math.max(#TAB_KEYS, 1)))
  for i, key in ipairs(TAB_KEYS) do
    tabs[i] = Button(panel, PF.T(key), 204, tabStep - 4, function() SelectTab(i) end, "orange")
    tabs[i]:SetPoint("TOPLEFT", panel, "TOPLEFT", 12, -92 - (i - 1) * tabStep)
  end

  -- titulo de la pestana (arriba a la derecha, junto a la X)
  pageTitle = Text(panel, "", 13, C.yellow, "OUTLINE")
  pageTitle:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -35, -16)
  pageTitle:SetJustifyH("RIGHT")

  -- "(Personaje · Rama N · Talentos)" abajo a la izquierda
  pageSub = Text(panel, "", 10, C.dim)
  pageSub:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 16, 42)
  refreshers[#refreshers + 1] = function()
    local group, _, spec = PF.GetSpecInfo()
    pageSub:SetText(PF.T("p_sub", PF.GetCharKey(), group, spec))
  end

  for i, sec in ipairs(sections) do
    local build, contentH = sec[2], sec[3]
    if contentH and contentH > VIEW_H then
      local wrap = CreateFrame("Frame", nil, panel)
      wrap:SetPoint("TOPLEFT", panel, "TOPLEFT", 236, -102)
      wrap:SetWidth(W + 16); wrap:SetHeight(VIEW_H)
      local sf = CreateFrame("ScrollFrame", nil, wrap)
      sf:SetPoint("TOPLEFT", wrap, "TOPLEFT", 0, 0)
      sf:SetWidth(W); sf:SetHeight(VIEW_H)
      local pg = CreateFrame("Frame", nil, sf)
      pg:SetWidth(W); pg:SetHeight(contentH)
      sf:SetScrollChild(pg)
      local sb = CreateFrame("Slider", nil, wrap)
      sb:SetOrientation("VERTICAL")
      sb:SetPoint("TOPRIGHT", wrap, "TOPRIGHT", -2, 0)
      sb:SetWidth(8); sb:SetHeight(VIEW_H)
      local track = sb:CreateTexture(nil, "BACKGROUND")
      track:SetAllPoints(sb); track:SetTexture(WHITE); track:SetVertexColor(0.08, 0.09, 0.14, 0.9)
      local thumb = sb:CreateTexture(nil, "OVERLAY")
      thumb:SetTexture(WHITE); thumb:SetVertexColor(0.86, 0.62, 0.30, 0.95)
      thumb:SetWidth(8); thumb:SetHeight(48)
      sb:SetThumbTexture(thumb)
      sb:SetMinMaxValues(0, contentH - VIEW_H); sb:SetValueStep(1); sb:SetValue(0)
      sb:SetScript("OnValueChanged", function(_, v) sf:SetVerticalScroll(v) end)
      -- las pestanas con contenido variable (p. ej. Barra recomendada) ajustan la altura
      function pg.SetContentHeight(h)
        h = math.max(h, VIEW_H)
        pg:SetHeight(h)
        sb:SetMinMaxValues(0, h - VIEW_H)
        if sb:GetValue() > h - VIEW_H then sb:SetValue(h - VIEW_H) end
      end
      wrap:EnableMouseWheel(true)
      wrap:SetScript("OnMouseWheel", function(_, delta) sb:SetValue(sb:GetValue() - delta * 45) end)
      pages[i] = wrap
      build(pg)
    else
      local pg = CreateFrame("Frame", nil, panel)
      pg:SetPoint("TOPLEFT", panel, "TOPLEFT", 236, -102)
      pg:SetWidth(W); pg:SetHeight(VIEW_H)
      pages[i] = pg
      build(pg)
    end
  end

  -- Barra inferior: APL personalizado | Mover HUD | Idioma | CurseForge | Recargar UI
  local function BarButton(i, labelKey, fn)
    local bw = 125
    local b = Button(panel, K(labelKey)(), bw, 26, fn, "red")
    b:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 14 + (i - 1) * (bw + 6), 12)
    relabels[#relabels + 1] = function() b:SetLabel(PF.T(labelKey)) end
    return b
  end
  local langIdx = #TAB_KEYS
  for i, key in ipairs(TAB_KEYS) do if key == "tab_lang" then langIdx = i end end
  BarButton(1, "b_apl", function() if PF.APL_Edit then PF.APL_Edit() end end)
  BarButton(2, "b_move", function()
    if SlashCmdList and SlashCmdList["PULSEFLASH"] then SlashCmdList["PULSEFLASH"]("move") end
  end)
  BarButton(3, "tab_lang", function() SelectTab(langIdx) end)
  BarButton(4, "b_curse", function() curEdit:SetFocus(); curEdit:HighlightText() end)
  BarButton(5, "b_reload", function() ReloadUI() end)

  PF.OnLangChange(function()
    for _, fn in ipairs(relabels) do fn() end
    if picker then picker:Hide() end
    SelectTab(curTab)
    PF.RefreshConfig()
  end)

  panel:SetScript("OnShow", function() PF.RefreshConfig() end)
  panel:SetScript("OnHide", function() if picker then picker:Hide() end end)
  SelectTab(1)
  panel:Hide()
end

function PF.RefreshConfig()
  if not panel or not PF.db then return end
  for _, fn in ipairs(refreshers) do fn() end
end

-- Construye el panel de forma segura: si algo falla a mitad, se limpian los restos
-- para que la siguiente apertura reintente desde cero (antes quedaba un panel a
-- medio construir hasta hacer /reload).
local function SafeBuild()
  if panel then return true end
  local ok, err = pcall(BuildPanel)
  if ok then return true end
  if panel then panel:Hide(); panel:SetParent(nil) end
  for _, t in ipairs({ tabs, pages, refreshers, relabels, TAB_KEYS }) do
    for k in pairs(t) do t[k] = nil end
  end
  panel, picker, pageTitle, pageSub = nil, nil, nil, nil
  PF.Msg("|cffff4040Error:|r " .. tostring(err))
  return false
end

function PF.OpenConfig()
  if not PF.db then PF.Msg(PF.T("noModule")); return end
  if not SafeBuild() then return end
  panel:Show()
end

function PF.ToggleConfig()
  if not PF.db then PF.Msg(PF.T("noModule")); return end
  if not SafeBuild() then return end
  if panel:IsShown() then panel:Hide() else panel:Show() end
end

PF.RegisterProfileCallback(function() PF.RefreshConfig() end)

-- Solo ahora se considera cargado (si el archivo falla antes, se podrá reintentar)
PF.configLoaded = true
