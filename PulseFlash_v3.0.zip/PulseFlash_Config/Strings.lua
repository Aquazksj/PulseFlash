-- Textos ES/EN que solo usa el panel de configuracion (salen del nucleo para ahorrar memoria).
local PF = PulseFlash
local ES, EN = PF.STRINGS.es, PF.STRINGS.en

ES.g_alphaChannel = "Opacidad al canalizar";  EN.g_alphaChannel = "Opacity while channeling"
ES.tab_multidot   = "Multidot";  EN.tab_multidot = "Multidot"
ES.md_head        = "MULTIDOT AUTOMÁTICO";  EN.md_head = "AUTOMATIC MULTIDOT"
ES.md_enable      = "Recomendar cambiar de objetivo para repartir DoTs"
EN.md_enable      = "Recommend switching target to spread DoTs"
ES.md_min         = "Enemigos mínimos en el pull";  EN.md_min = "Minimum enemies in the pull"
ES.md_desc        = "El addon detecta solo la pelea contra varios enemigos y, cuando tu objetivo ya tiene todos tus DoTs, te avisa bajo el HUD de que cambies de objetivo (Tab) al enemigo que no los tiene. No se muestra contra jefes, ni con menos enemigos de los indicados, ni con enemigos casi muertos o inmunes. Desactívalo si prefieres todo el daño al objetivo único."
EN.md_desc        = "The addon detects fights against several enemies on its own and, once your target has all your DoTs, shows a prompt under the HUD to switch target (Tab) to an enemy that lacks them. It is not shown against bosses, with fewer enemies than set, or for almost-dead or immune enemies. Turn it off if you prefer full single-target damage."
ES.tab_hudstyle   = "Estilo del HUD";  EN.tab_hudstyle = "HUD style"
ES.hs_head        = "ESTILO DEL HUD DE DAÑO";  EN.hs_head = "DAMAGE HUD STYLE"
ES.hs_hint        = "El cambio se aplica al instante y se guarda en el perfil de este personaje y rama."
EN.hs_hint        = "The change applies instantly and is saved in this character and talent group's profile."
ES.pal_gradient  = "Degradado"; EN.pal_gradient = "Gradient"
ES.pal_yellow    = "Amarillo";  EN.pal_yellow   = "Yellow"
ES.pal_red       = "Rojo";      EN.pal_red      = "Red"
ES.pal_green     = "Verde";     EN.pal_green    = "Green"
ES.pal_white     = "Blanco";    EN.pal_white    = "White"
ES.c_title       = "- Configuración";   EN.c_title = "- Settings"
ES.tab_general   = "HUD de daño";        EN.tab_general = "Damage HUD"
ES.tab_buffs     = "HUD de buffos";      EN.tab_buffs = "Buff HUD"
ES.tab_rotation  = "Rotación";          EN.tab_rotation = "Rotation"
ES.tab_combos    = "Combos";            EN.tab_combos = "Combos"
ES.tab_sounds    = "Sonidos";           EN.tab_sounds = "Sounds"
ES.tab_profiles  = "Perfiles";          EN.tab_profiles = "Profiles"
ES.g_look        = "APARIENCIA DEL HUD";   EN.g_look = "HUD APPEARANCE"
ES.g_scale       = "Escala y tamaño del HUD"; EN.g_scale = "HUD scale and size"
ES.g_alphaCombat = "Opacidad en combate";  EN.g_alphaCombat = "Opacity in combat"
ES.g_alphaOOC    = "Opacidad fuera de combate"; EN.g_alphaOOC = "Opacity out of combat"
ES.g_flash       = "DESTELLO";             EN.g_flash = "FLASH"
ES.g_period      = "Frecuencia del destello (segundos por pulso)"
EN.g_period      = "Flash rate (seconds per pulse)"
ES.g_intensity   = "Intensidad del brillo"; EN.g_intensity = "Glow intensity"
ES.g_styleGlow   = "Glow clásico";         EN.g_styleGlow = "Classic glow"
ES.g_styleSize   = "Pulso de tamaño";      EN.g_styleSize = "Size pulse"
ES.g_showHud     = "MOSTRAR EL HUD";       EN.g_showHud = "SHOW THE HUD"
ES.g_modeCombat  = "Solo combate";         EN.g_modeCombat = "Combat only"
ES.g_modeTarget  = "Objetivo hostil";      EN.g_modeTarget = "Hostile target"
ES.g_modeAlways  = "Siempre";              EN.g_modeAlways = "Always"
ES.g_actions     = "ACCIONES";             EN.g_actions = "ACTIONS"
ES.g_unlock      = "Desbloquear HUD";      EN.g_unlock = "Unlock HUD"
ES.g_lock        = "Bloquear HUD";         EN.g_lock = "Lock HUD"
ES.previewOn     = "Vista previa: ON";     EN.previewOn = "Preview: ON"
ES.previewOff    = "Vista previa: OFF";    EN.previewOff = "Preview: OFF"
ES.g_hint        = "Los cambios se guardan solos en el perfil de este personaje y rama."
EN.g_hint        = "Changes are saved automatically in this character and talent group's profile."
ES.b_title       = "HUD DE BUFFOS";        EN.b_title = "BUFF HUD"
ES.b_pulse       = "Animación de pulso";   EN.b_pulse = "Pulse animation"
ES.b_glow        = "Resplandor dorado";    EN.b_glow = "Golden glow"
ES.b_enable      = "HUD de buffos";        EN.b_enable = "Buff HUD"
ES.b_combat      = "Ver en combate";       EN.b_combat = "Show in combat"
ES.b_hint        = "Segundo HUD: solo muestra los buffos que te faltan (aspectos, bendiciones,\nauras, sellos, armaduras, venenos...). Su bloqueo y su vista previa son\nindependientes de los del HUD de daño."
EN.b_hint        = "Second HUD: only shows the buffs you are missing (aspects, blessings,\nauras, seals, armors, poisons...). Its lock and preview are independent\nfrom the damage HUD's."
ES.r_title       = "MODO DE ROTACIÓN";  EN.r_title = "ROTATION MODE"
ES.r_normal      = "Normal";            EN.r_normal = "Normal"
ES.r_max         = "Máximo daño (prueba)"; EN.r_max = "Max damage (test)"
ES.r_what        = "QUÉ HACE CADA MODO"; EN.r_what = "WHAT EACH MODE DOES"
ES.r_descRogue =
  "|cffffd100Normal|r: brilla siempre lo primero que puedas lanzar ya. Si te falta energía " ..
  "para Mutilar, brilla Golpe siniestro.\n\n" ..
  "|cffffd100Máximo daño|r:\n" ..
  "- Si solo faltan 2 s o menos de energía para |cffffd100Mutilar|r (Asesinato, dos dagas) o " ..
  "|cffffd100Puñalada trapera|r (solo Sutileza), espera en vez de gastarla en Golpe siniestro. " ..
  "Mutilar da 2 PC por 60 de energía: más daño y más PC por energía.\n" ..
  "- Si |cffffd100Rebanar y Cortar|r o |cffffd100Ruptura|r van a vencer y gastar energía " ..
  "ahora te dejaría sin la necesaria para refrescarlos, espera.\n\n" ..
  "El HUD muestra los segundos de espera sobre el icono principal."
EN.r_descRogue =
  "|cffffd100Normal|r: always glows the first ability you can cast right now. If you lack energy " ..
  "for Mutilate, Sinister Strike glows.\n\n" ..
  "|cffffd100Max damage|r:\n" ..
  "- If you are 2 s or less of energy short for |cffffd100Mutilate|r (Assassination, dual daggers) or " ..
  "|cffffd100Backstab|r (Subtlety only), it waits instead of spending energy on Sinister Strike. " ..
  "Mutilate gives 2 CP for 60 energy: more damage and more CP per energy.\n" ..
  "- If |cffffd100Slice and Dice|r or |cffffd100Rupture|r are about to expire and spending energy " ..
  "now would leave you without enough to refresh them, it waits.\n\n" ..
  "The HUD shows the waiting seconds over the main icon."
ES.r_descDruid =
  "|cffffd100Normal|r: brilla siempre lo primero que puedas lanzar ya.\n\n" ..
  "|cffffd100Máximo daño|r (feral):\n" ..
  "- Si |cffffd100Rugido salvaje|r, |cffffd100Desgarrar|r (5 PC), |cffffd100Rastrillar|r o el " ..
  "debuff de |cffffd100Mutilar|r van a vencer y gastar energía en un generador te dejaría sin la " ..
  "necesaria para refrescarlo a tiempo, espera.\n" ..
  "- Con el debuff de Mutilar activo y estando detrás, si faltan 2 s o menos de energía para " ..
  "|cffffd100Destrozar|r, espera en vez de gastarla en Mutilar (no durante Berserk).\n\n" ..
  "El HUD muestra los segundos de espera sobre el icono principal."
EN.r_descDruid =
  "|cffffd100Normal|r: always glows the first ability you can cast right now.\n\n" ..
  "|cffffd100Max damage|r (feral):\n" ..
  "- If |cffffd100Savage Roar|r, |cffffd100Rip|r (5 CP), |cffffd100Rake|r or the " ..
  "|cffffd100Mangle|r debuff are about to expire and spending energy on a builder would leave you " ..
  "without enough to refresh it in time, it waits.\n" ..
  "- With the Mangle debuff up and while behind the target, if you are 2 s or less of energy short for " ..
  "|cffffd100Shred|r, it waits instead of spending energy on Mangle (not during Berserk).\n\n" ..
  "The HUD shows the waiting seconds over the main icon."
ES.r_live        = "ESTADO EN VIVO";    EN.r_live = "LIVE STATUS"
ES.r_liveNormal  = "Modo normal: sin esperas."
EN.r_liveNormal  = "Normal mode: no waiting."
ES.r_liveHold    = "Esperando: |cffffd100%s|r  (%.1f s)"
EN.r_liveHold    = "Waiting for: |cffffd100%s|r  (%.1f s)"
ES.r_liveNone    = "Modo máximo daño: sin espera ahora mismo (se lanza lo que toca)."
EN.r_liveNone    = "Max damage mode: not waiting right now (casting what is next)."
ES.r_note        = "Es un modo de prueba: compáralo con el Normal sobre un muñeco de entrenamiento y quédate con el que más daño haga en tu equipo."
EN.r_note        = "This is a test mode: compare it with Normal on a training dummy and keep the one that does more damage with your gear."
ES.cb_title      = "BARRA DE COMBOS";   EN.cb_title = "COMBO BAR"
ES.cb_enable     = "Activar la barra de combos"; EN.cb_enable = "Enable the combo bar"
ES.cb_scale      = "Escala de la barra"; EN.cb_scale = "Bar scale"
ES.cb_w          = "Ancho de cada punto"; EN.cb_w = "Width of each point"
ES.cb_h          = "Alto de cada punto";  EN.cb_h = "Height of each point"
ES.cb_gap        = "Separación entre puntos"; EN.cb_gap = "Spacing between points"
ES.cb_alpha      = "Opacidad";           EN.cb_alpha = "Opacity"
ES.cb_color      = "COLOR";              EN.cb_color = "COLOR"
ES.cb_showHdr    = "MOSTRAR LA BARRA";   EN.cb_showHdr = "SHOW THE BAR"
ES.cb_always     = "Siempre";            EN.cb_always = "Always"
ES.cb_target     = "Con objetivo";       EN.cb_target = "With target"
ES.cb_points     = "Con puntos";         EN.cb_points = "With points"
ES.cb_number     = "Mostrar el número de puntos sobre la barra"
EN.cb_number     = "Show the point count above the bar"
ES.cb_move       = "Mover la barra";     EN.cb_move = "Move the bar"
ES.cb_fix        = "Fijar la barra";     EN.cb_fix = "Lock the bar"
ES.s_title       = "ALERTAS SONORAS";    EN.s_title = "SOUND ALERTS"
ES.s_enable      = "Activar alertas sonoras de procs"; EN.s_enable = "Enable proc sound alerts"
ES.s_hint        = "Clic izquierdo: sonido siguiente  ·  Clic derecho: anterior"
EN.s_hint        = "Left-click: next sound  ·  Right-click: previous"
ES.s_none        = "Tu clase no tiene procs que modifiquen la rotación."
EN.s_none        = "Your class has no procs that change the rotation."
ES.s_each        = "SONIDO DE CADA PROC"; EN.s_each = "SOUND FOR EACH PROC"
ES.s_test        = "Probar";             EN.s_test = "Test"
ES.p_char        = "PERSONAJE ACTIVO";   EN.p_char = "ACTIVE CHARACTER"
ES.p_info1       = "Personaje: |cffffd100%s|r"; EN.p_info1 = "Character: |cffffd100%s|r"
ES.p_info2       = "Clase: |cffffd100%s|r";     EN.p_info2 = "Class: |cffffd100%s|r"
ES.p_info3       = "Rama activa: |cffffd100%d (%s)|r  ·  Especialización: |cffffd100%s|r"
EN.p_info3       = "Active talent group: |cffffd100%d (%s)|r  ·  Specialization: |cffffd100%s|r"
ES.p_sub         = "(%s  ·  Rama %d  ·  %s)"
EN.p_sub         = "(%s  ·  Group %d  ·  %s)"
ES.p_clone       = "Clonar...";          EN.p_clone = "Clone..."
ES.p_cloneTitle  = "Clonar de otro personaje / rama"
EN.p_cloneTitle  = "Clone from another character / group"
ES.p_empty       = "(no hay perfiles)"; EN.p_empty = "(no profiles)"
ES.p_helpHdr     = "AYUDA";              EN.p_helpHdr = "HELP"
ES.p_help        =
  "El perfil de cada personaje y rama de talentos se guarda y se carga solo al cambiar de rama.\n\n" ..
  "|cffffd100Clonar|r copia la configuración de otro personaje o rama de tu cuenta."
EN.p_help        =
  "Each character's and talent group's profile is saved and loaded automatically when you switch groups.\n\n" ..
  "|cffffd100Clone|r copies the settings of another character or talent group on your account."
ES.tab_lang      = "Idioma";             EN.tab_lang = "Language"
ES.tab_loadout   = "Barra recomendada";   EN.tab_loadout = "Recommended bar"
ES.lang_head     = "IDIOMA DE LA INTERFAZ"; EN.lang_head = "INTERFACE LANGUAGE"
ES.lang_hint     = "El idioma se guarda para toda tu cuenta y se aplica al instante."
EN.lang_hint     = "The language is saved for your whole account and applies instantly."
ES.tab_assist = "Asistencia";  EN.tab_assist = "Assist"
ES.as_moveStop = "Terminar de mover";  EN.as_moveStop = "Done moving"
ES.as_reset = "Restablecer posición";  EN.as_reset = "Reset position"
ES.as_timers = "Temporizadores de efectos";  EN.as_timers = "Effect timers"
ES.as_show = "Mostrar temporizadores bajo el HUD";  EN.as_show = "Show timers under the HUD"
ES.as_size = "Tamaño de los temporizadores";  EN.as_size = "Timer size"
ES.as_move = "Mover temporizadores";  EN.as_move = "Move timers"
ES.as_move_d = "Pulsa \"Mover\", arrastra el recuadro amarillo donde quieras y pulsa \"Terminar de mover\".";  EN.as_move_d = "Press \"Move\", drag the yellow box where you want it and press \"Done moving\"."
ES.as_dots = "Refresco de DoTs";  EN.as_dots = "DoT refresh"
ES.as_dotwin = "Sugerir renovar cuando queden menos de";  EN.as_dotwin = "Suggest renewing when less than this is left"
ES.as_dotwin_d = "Un efecto vuelve a sugerirse cuando le queda menos de este tiempo. Súbelo si algún DoT con tiempo de lanzamiento largo se acaba antes de que lo renueves; bájalo si renuevas demasiado pronto.";  EN.as_dotwin_d = "An effect is suggested again when it has less than this time left. Raise it if a DoT with a long cast time runs out before you can renew it; lower it if you are renewing too early."
ES.as_precision = "Precisión extra";  EN.as_precision = "Extra precision"
ES.as_plus = "Activar mejoras de precisión";  EN.as_plus = "Enable precision improvements"
ES.as_plus_d = "Evita que la sugerencia parpadee, muestra los segundos que faltan cuando una habilidad aún no está lista y adelanta la siguiente según tu latencia real.";  EN.as_plus_d = "Stops the suggestion from flickering, shows the seconds left when an ability is not ready yet, and moves on to the next ability earlier based on your real latency."
ES.as_aoe = "AoE automático según el número de enemigos";  EN.as_aoe = "Automatic AoE based on enemy count"
ES.as_proj = "Cola proyectada (simula el efecto de cada habilidad)";  EN.as_proj = "Projected queue (simulates each ability's effect)"
ES.as_click = "Clic izquierdo en el HUD alterna el AoE (con el HUD bloqueado)";  EN.as_click = "Left-click on the HUD toggles AoE (when the HUD is locked)"
ES.as_target = "Objetivos y AoE";  EN.as_target = "Targets and AoE"
ES.tab_alerts = "Alertas";  EN.tab_alerts = "Alerts"
ES.as_alerts = "Avisos en pantalla";  EN.as_alerts = "On-screen alerts"
ES.as_a_on = "Mostrar un aviso en pantalla cuando aparece un proc";  EN.as_a_on = "Show an on-screen alert when a proc appears"
ES.as_a_size = "Tamaño del aviso";  EN.as_a_size = "Alert size"
ES.as_a_dur = "Duración del aviso";  EN.as_a_dur = "Alert duration"
ES.as_a_icon = "Mostrar icono";  EN.as_a_icon = "Show icon"
ES.as_a_text = "Mostrar texto";  EN.as_a_text = "Show text"
ES.as_a_move = "Mover aviso";  EN.as_a_move = "Move alert"
ES.as_a_test = "Probar";  EN.as_a_test = "Test"
ES.as_a_hint = "Pulsa \"Mover aviso\", arrastra el recuadro amarillo donde quieras y pulsa \"Terminar de mover\".";  EN.as_a_hint = "Press \"Move alert\", drag the yellow box where you want it and press \"Done moving\"."
ES.as_procs = "Procs de tu clase";  EN.as_procs = "Your class procs"
ES.as_noprocs = "Tu clase no tiene procs predefinidos: agrega los tuyos abajo.";  EN.as_noprocs = "Your class has no predefined procs: add your own below."
ES.as_pa_on = "Aviso: sí";  EN.as_pa_on = "Alert: on"
ES.as_pa_off = "Aviso: no";  EN.as_pa_off = "Alert: off"
ES.as_custom = "Avisos personalizados";  EN.as_custom = "Custom alerts"
ES.as_c_hint = "Escribe el nombre exacto del efecto (buff) como aparece en el juego y pulsa Agregar. Máximo 4.";  EN.as_c_hint = "Type the exact name of the effect (buff) as shown in game and press Add. Max 4."
ES.as_c_add = "Agregar";  EN.as_c_add = "Add"

ES.c_version  = "Versión:";  EN.c_version  = "Version:"
ES.c_copyhint = "Selecciona el enlace y pulsa Ctrl+C para copiarlo."
EN.c_copyhint = "Select the link and press Ctrl+C to copy it."
ES.b_apl      = "APL personalizado";  EN.b_apl    = "Custom APL"
ES.b_move     = "Mover HUD";          EN.b_move   = "Move HUD"
ES.b_curse    = "CurseForge";         EN.b_curse  = "CurseForge"
ES.b_reload   = "Recargar UI";        EN.b_reload = "Reload UI"

-- Pagina "HUD de daño" (barras planas, como la captura)
ES.gs_scale = "Escala";            EN.gs_scale = "Scale"
ES.gs_alpha = "Opacidad";          EN.gs_alpha = "Opacity"
ES.gs_show  = "Mostrar HUD";       EN.gs_show  = "Show HUD"
ES.gs_ooc   = "Fuera de combate";  EN.gs_ooc   = "Out of combat"
ES.gs_icons = "Número de iconos";  EN.gs_icons = "Number of icons"
ES.gs_size  = "Tamaño";            EN.gs_size  = "Size"

-- Otros idiomas (si estan cargados); si no, se usa el ingles
do
  local S = PF.STRINGS
  local TR = {
    de = { "Skalierung", "Deckkraft", "HUD anzeigen", "Außerhalb des Kampfes", "Anzahl der Symbole", "Größe" },
    fr = { "Échelle", "Opacité", "Afficher le HUD", "Hors combat", "Nombre d'icônes", "Taille" },
    pt = { "Escala", "Opacidade", "Mostrar HUD", "Fora de combate", "Número de ícones", "Tamanho" },
    ru = { "Масштаб", "Непрозрачность", "Показывать HUD", "Вне боя", "Количество значков", "Размер" },
  }
  local KEYS = { "gs_scale", "gs_alpha", "gs_show", "gs_ooc", "gs_icons", "gs_size" }
  for lang, vals in pairs(TR) do
    if S[lang] then for i, k in ipairs(KEYS) do S[lang][k] = vals[i] end end
  end
end

-- Pestanas "Analisis" (informe tras un jefe) y "Simulador"
ES.tab_analysis = "Análisis";   EN.tab_analysis = "Analysis"
ES.tab_sim      = "Simulador";  EN.tab_sim      = "Simulator"
ES.an_head   = "Después de una pelea, mostrar un pequeño informe:"
EN.an_head   = "After a fight, show a short report:"
ES.an_metric = "Métrica";                         EN.an_metric = "Metric"
ES.an_result = "Resultado";                       EN.an_result = "Result"
ES.an_dot    = "Mantenimiento de DoT";            EN.an_dot    = "DoT uptime"
ES.an_procs  = "Aprovechamiento de procs";        EN.an_procs  = "Proc usage"
ES.an_idle   = "Tiempo sin actividad ofensiva";   EN.an_idle   = "Time without offensive activity"
ES.an_early  = "Renovaciones anticipadas";        EN.an_early  = "Early refreshes"
ES.an_last   = "Último combate: %s · %s · %s";    EN.an_last   = "Last fight: %s · %s · %s"
ES.an_live   = "Combate en curso: %s";            EN.an_live   = "Fight in progress: %s"
ES.an_none   = "Aún no hay informe. Se genera solo al terminar un combate contra un jefe."
EN.an_none   = "No report yet. It is created when a boss fight ends."
ES.an_onlyboss = "Analizar solo combates contra jefes y dummys"; EN.an_onlyboss = "Analyze boss and dummy fights only"
ES.an_clear  = "Borrar informe";                  EN.an_clear  = "Clear report"
ES.sim_run   = "Ejecutar";                        EN.sim_run   = "Run"
ES.sim_save  = "Guardar referencia";              EN.sim_save  = "Save baseline"
ES.sim_seq   = "Ver secuencia";                   EN.sim_seq   = "Show sequence"
ES.sim_col   = "Verificación";                    EN.sim_col   = "Check"
ES.sim_order = "Orden de las habilidades";        EN.sim_order = "Ability order"
ES.sim_auras = "Buffs y debuffs";                 EN.sim_auras = "Buffs and debuffs"
ES.sim_waste = "Recursos";                        EN.sim_waste = "Resources"
ES.sim_cds   = "Cooldowns";                       EN.sim_cds   = "Cooldowns"
ES.sim_reg   = "Frente a la referencia";          EN.sim_reg   = "Versus baseline"
ES.sim_ok    = "Correcto";                        EN.sim_ok    = "Pass"
ES.sim_fail  = "Fallo";                           EN.sim_fail  = "Fail"
ES.sim_idle  = "Elige un escenario y pulsa Ejecutar. Simula la rotación real de tu clase sin tocar el combate."
EN.sim_idle  = "Pick a scenario and press Run. It simulates your class's real rotation without touching combat."
ES.sim_done  = "%d acciones simuladas · %d/4 verificaciones correctas"
EN.sim_done  = "%d simulated actions · %d/4 checks passed"
ES.sim_noreg = "Sin referencia"; EN.sim_noreg = "No baseline"
ES.sim_same  = "Igual";          EN.sim_same  = "Same"
ES.sim_better= "Mejora";         EN.sim_better= "Better"
ES.sim_worse = "Empeora";        EN.sim_worse = "Worse"
ES.sim_chg   = "Cambia";         EN.sim_chg   = "Changed"
