local CF = PulseFlash

do local c = select(2, UnitClass("player")); if c and c ~= "DRUID" then return end end
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

local BERSERK_POOL = 85
local TF_ENERGY = 40
local BERSERK_TF_CD = 15
local RIP_DYING_HP = 0.05

local ECLIPSE_SOLAR_WAIT = 15
local lunarWas, lunarEndedAt = false, nil

local function TrackEclipse(c, N)
  if not c.combat then lunarWas, lunarEndedAt = false, nil; return end
  if Aura("player", N.EclipseLunar) then
    lunarWas, lunarEndedAt = true, nil
  elseif lunarWas then
    lunarWas, lunarEndedAt = false, GetTime()
  end
  if Aura("player", N.EclipseSolar) then lunarEndedAt = nil end
end

local function upkeep(c, add, N)
  if c.spec ~= 2 then TrackEclipse(c, N) end
end

local function IsCat(c, N)
  return c.spec == 2 and Known(N.CatForm)
end

local CDLeft = CF.CD

local DOT_MIN_LIFE = 8
local LACERATE_STACKS = 5
local LACERATE_REFRESH = 3.0
local MAUL_RAGE = 40

local function InBear(N)
  return (Aura("player", N.DireBearForm) or Aura("player", N.BearForm)) and true or false
end

-- Oso (tanque): Destrozar > Laceración (5 cargas) > Fuego feérico > Zarpazo,
-- con Mutilar (oso) siempre que esté listo y Machacar para gastar rabia.
local function bearEvaluate(c, add, N)
  local lacLeft, lacStacks = Aura("target", N.Lacerate, true, true)

  add(N.MangleBear, 1)
  if c.hostile and (not lacLeft or (lacStacks or 0) < LACERATE_STACKS or lacLeft <= LACERATE_REFRESH) then
    add(N.Lacerate, 1)
  end
  if CF.AoE(2) then add(N.SwipeBear, 1) end
  if c.hostile and not Aura("target", N.FaerieFire, true) then add(N.FaerieFire, 1) end
  if c.rage >= MAUL_RAGE then add(N.Maul, 1) end

  if c.combat then
    if c.hostile and not Aura("target", N.DemoralizingRoar, true) then add(N.DemoralizingRoar, 2) end
    if c.rage < 15 then add(N.Enrage, 2) end
    if c.bigCD then add(N.Berserk, 2) end
  end

  if CF.EnemyCasting() and IsSpellInRange(N.Bash, "target") == 1 then add(N.Bash, 3) end
  if c.combat then
    if CF.Grouped() and c.hostile and not CF.TargetsMe()
       and IsSpellInRange(N.Growl, "target") == 1 then
      add(N.Growl, 3)
    end
    if c.hostile and not CF.TargetsMe() then add(N.FeralChargeBear, 3) end
    if c.php < 0.50 then add(N.FrenziedRegeneration, 3) end
    if c.php < 0.40 then add(N.SurvivalInstincts, 3) end
    if c.php < 0.50 then add(N.Barkskin, 3) end
  end
end

-- Gato + Oso (bearweave, /pf bearweave; requiere Furor): en oso se recomienda
-- Laceración con la rabia ganada y se vuelve a gato al recuperar energía.
local function weaveBear(c, add, N)
  local sr = Aura("player", N.SavageRoar)
  local ripLeft = Aura("target", N.Rip, true, true)
  local cc = Aura("player", N.Clearcasting)
  local lacLeft, lacStacks = Aura("target", N.Lacerate, true, true)
  local hasRage = c.rage >= 13 or cc
  local exitCat = c.energy > 70 or cc or (ripLeft and ripLeft < 3) or (sr and sr < 3)
  if hasRage and lacLeft and lacLeft < 3 then add(N.Lacerate, 1) end
  if exitCat then add(N.CatForm, 1) end
  if hasRage and (not lacLeft or (lacStacks or 0) < LACERATE_STACKS or lacLeft < 9) then add(N.Lacerate, 1) end
  if (lacLeft and (lacStacks or 0) >= LACERATE_STACKS and lacLeft >= 9) or c.rage < 13 then add(N.CatForm, 1) end
  add(N.Lacerate, 1)
end

local function Reapply(add, spell, left)
  if not spell or left then return end
  if CF.IsCasting(spell) or CF.Pending(spell) then return end
  add(spell, 1)
end

-- ---------------------------------------------------------------------------
-- Gato (Feral): rotación al estilo de la guía definitiva de WotLK
--   Furia de tigre < 40 energía > Rabia (Berserk) con FT en recarga >= 15 s >
--   Rugido salvaje > Mangle (debuff) > Desgarrar a 5 PC > Mordisco con excedente >
--   Rastrillar > Destrozar (Clearcasting) > Fuego feérico > Destrozar / Mangle
--   Los efectos se renuevan ANTES de caducar y no se ponen si el objetivo muere pronto.
-- ---------------------------------------------------------------------------
local SR_REFRESH, RAKE_REFRESH, RIP_REFRESH = 3.0, 3.0, 2.0
local BITE_MIN_RIP, BITE_MIN_SR = 10, 8
local BITE_MAX_ENERGY = 67

local function catEvaluate(c, add, N)
  local cp, energy = c.cp, c.energy
  local maxMode = CF.db and CF.db.rot and CF.db.rot.max
  local berserk = Aura("player", N.Berserk)
  local cc = Aura("player", N.Clearcasting)
  local sr = Aura("player", N.SavageRoar)
  local ripLeft = Aura("target", N.Rip, true, true)
  local rakeLeft = Aura("target", N.Rake, true, true)

  if not Aura("player", N.CatForm) then add(N.CatForm, 1) end

  if Aura("player", N.Prowl) then
    if c.behind then add(N.Ravage, 1) end
    add(N.Pounce, 1)
  end

  -- Bearweave: con poca energía y sin nada urgente, pasar a oso a ganar rabia
  if CF.db and CF.db.bearweave and not cc and not berserk and energy < 40
     and (not ripLeft or ripLeft >= 4.5) and (not sr or sr >= 4)
     and not ((not rakeLeft or rakeLeft < 3) and energy >= 35) then
    local bear = Known(N.DireBearForm) and N.DireBearForm or (Known(N.BearForm) and N.BearForm)
    if bear then add(bear, 1) end
  end

  local mangleName = N.Mangle and (N.Mangle:gsub("%s*%b()", "")) or nil
  local mangleLeft = Aura("target", mangleName, true) or Aura("target", N.Trauma, true)
  local mangleMine = Aura("target", mangleName, true, true)

  local dying = (not c.worth) or (c.boss and c.hp <= RIP_DYING_HP)
  local tfLeft = CDLeft(N.TigersFury)

  if c.combat then
    -- Furia de tigre con poca energía (no durante Rabia: se desperdicia)
    if energy < TF_ENERGY and not berserk then add(N.TigersFury, 1) end
    -- Rabia poco después de Furia de tigre (FT en recarga >= 15 s)
    if c.bigCD and CF.CDok(c, 180) then
      local bsOk = (not Known(N.TigersFury)) or tfLeft >= BERSERK_TF_CD
      if bsOk then add(N.Berserk, 1) else add(N.Berserk, 2) end
    end
  end

  -- Rugido salvaje. Desincronización: si Desgarrar caduca poco después, se
  -- renueva antes para llegar a 5 PC con Desgarrar a tiempo.
  local clipSR = false
  if sr and ripLeft and cp >= 1 then
    local window = sr + 5 + 2
    clipSR = ripLeft < window and ripLeft > sr and sr <= 10
  end
  if cp >= 1 and (not sr or sr < SR_REFRESH or clipSR) then Reapply(add, N.SavageRoar, nil) end

  if CF.AoE(3) then
    -- Área: mantener los sangrados del objetivo y gastar el resto en Rastrillo
    if c.worth and (not rakeLeft or rakeLeft < RAKE_REFRESH) then Reapply(add, N.Rake, nil) end
    if cp >= 5 and not dying and (not ripLeft or ripLeft < RIP_REFRESH) and Known(N.Rip) then
      Reapply(add, N.Rip, nil)
    end
    if Known(N.Mangle) and not mangleLeft then add(N.Mangle, 1) end
    if cp < 5 or dying then add(N.Swipe, 1) end
  else
    -- Mangle: debuff de sangrado (si nadie más lo aporta)
    if c.hostile and Known(N.Mangle) and (not mangleLeft or (mangleMine and mangleMine < 3 and not Aura("target", N.Trauma, true))) then
      add(N.Mangle, 1)
    end

    local bleedEnd = cp >= 5 and (not CF.Lives(10) or (ripLeft and not CF.Lives(ripLeft + 10)))
    -- Mordisco feroz solo con Desgarrar y Rugido de sobra y sin riesgo de topar la energía
    local canBite = cp >= 5 and not cc and not berserk and energy < BITE_MAX_ENERGY
      and ((dying and Known(N.FerociousBite)) or bleedEnd
           or (ripLeft and sr and ripLeft >= BITE_MIN_RIP and sr >= BITE_MIN_SR))

    if cp >= 5 then
      if not Known(N.Rip) then
        add(N.FerociousBite, 1)
      elseif dying or bleedEnd then
        add(N.FerociousBite, 1)
      elseif (not ripLeft or ripLeft < RIP_REFRESH) and CF.Lives(10) then
        Reapply(add, N.Rip, nil)
      elseif canBite then
        add(N.FerociousBite, 1)
      end
    end

    if c.worth and CF.Lives(9) and (not rakeLeft or rakeLeft < RAKE_REFRESH) then
      Reapply(add, N.Rake, nil)
    end

    -- Clearcasting: Destrozar gratis
    if cc and cp < 5 then
      if c.behind then add(N.Shred, 1) end
      add(N.Mangle, 1)
    end

    -- Fuego feérico (Feral): puede dar Concentración; sin coste de energía
    if c.combat and c.hostile and not cc and not berserk and energy < 90 and CF.CD(N.FaerieFire) <= 0 then
      add(N.FaerieFire, 1)
    end

    if maxMode and not cc then
      local gen = (c.behind and Known(N.Shred) and N.Shred) or (Known(N.Mangle) and N.Mangle) or N.Claw
      local spendCost = CF.Cost(gen)
      local best, bestT
      local function Cand(spell, left, ok, window)
        if not (spell and left and ok) or not Known(spell) then return end
        local t = left - (window or 0)
        if t <= 0 or t > CF.POOL_MAX_T then return end
        if CF.CanSpend(spendCost, CF.Cost(spell), t, 10) then return end
        if not bestT or t < bestT then best, bestT = spell, t end
      end
      Cand(N.SavageRoar, sr, cp >= 1, SR_REFRESH)
      Cand(N.Rip, ripLeft, cp >= 5 and not dying and Known(N.Rip), RIP_REFRESH)
      Cand(N.Rake, rakeLeft, c.worth, RAKE_REFRESH)
      if best then add(best, 1, bestT) end
    end

    if c.behind then
      local hold = (maxMode and mangleLeft and not berserk) and CF.HoldEta(N.Shred, 10) or nil
      add(N.Shred, 1, hold)
    end
    add(N.Mangle, 1)
    add(N.Claw, 1)
  end
end

local function evaluate(c, add, N)
  local spec = c.spec
  local cp = c.cp

  if InBear(N) then
    if CF.db and CF.db.bearweave and c.spec == 2 and Known(N.CatForm) then return weaveBear(c, add, N) end
    return bearEvaluate(c, add, N)
  end

  if IsCat(c, N) then
    catEvaluate(c, add, N)
  else

    if spec == 1 and Known(N.MoonkinForm) and not Aura("player", N.MoonkinForm) then
      add(N.MoonkinForm, 2)
    end

    -- Mantenimiento primero (antes de cualquier cambio de eclipse)
    if c.worth and CF.Lives(DOT_MIN_LIFE) then
      CF.Maintain(add, c, N.InsectSwarm, Aura("target", N.InsectSwarm, true, true), 0.3)
      CF.Maintain(add, c, N.Moonfire, Aura("target", N.Moonfire, true, true), 0.3)
    end

    if CF.AoE(4) then CF.Cast(add, N.Hurricane, 1) end
    if CF.AoE(3) and c.combat then add(N.Typhoon, 2) end

    -- Eclipse: lunar -> Fuego estelar; solar -> Cólera; tras el lunar se insiste
    -- con Fuego estelar hasta ECLIPSE_SOLAR_WAIT para activar el solar
    if Aura("player", N.EclipseLunar) then
      CF.Cast(add, N.Starfire, 1)
    elseif Aura("player", N.EclipseSolar) then
      CF.Cast(add, N.Wrath, 1)
    elseif lunarEndedAt and (GetTime() - lunarEndedAt) <= ECLIPSE_SOLAR_WAIT then
      CF.Cast(add, N.Starfire, 1)
    end

    if c.hostile and c.combat and not Aura("target", N.FaerieFire, true) then add(N.FaerieFire, 2) end
    if c.combat and c.bigCD then
      add(N.Starfall, 2)
      add(N.ForceOfNature, 2)
    end
    if c.combat and c.manaPct < 0.20 then add(N.Innervate, 3) end
  end

  if c.combat then
    if c.php < 0.50 then add(N.Barkskin, 3) end
    if c.php < 0.40 then add(N.SurvivalInstincts, 3) end
    if IsCat(c, N) and c.hostile and not CF.TargetsMe() then add(N.FeralChargeCat, 3) end
  end
end

local function filler(c, N)
  if InBear(N) then return First(N.MangleBear, N.Lacerate, N.Maul) end
  if IsCat(c, N) then
    if CF.AoE(3) and Known(N.Swipe) then return N.Swipe end
    if c.behind and Known(N.Shred) then return N.Shred end
    return First(N.Mangle, N.Claw)
  end
  -- Balance en movimiento: solo los DoTs (instantáneos) sirven; nada que rellenar
  if CF.Moving() then return nil end
  return First(N.Wrath, N.Starfire)
end

-- Efectos para la proyección de la cola
local function MangleBase() local n = CF.N.Mangle; return n and (n:gsub("%s*%b()", "")) or nil end
local function CC(e) e.free = "Clearcasting"; e.freeInstant = false; return e end
local SIM = {
  Shred = CC{ cp = 1 }, Mangle = CC{ cp = 1, fn = function(V) V:Apply("target", true, MangleBase(), 60) end },
  Claw = CC{ cp = 1 }, Rake = CC{ cp = 1, debuff = { "Rake", dur = 9 } },
  Swipe = CC{}, Ravage = { cp = 1 }, Pounce = { cp = 1 },
  Rip = CC{ fin = true, debuff = { "Rip", dur = function() return 12 + (CF.HasGlyph(CF.N.Rip) and 4 or 0) end } },
  FerociousBite = CC{ fin = true },
  SavageRoar = CC{ fin = true, buff = { "SavageRoar", dur = function(cp) return 9 + 5 * cp + (CF.HasGlyph(CF.N.SavageRoar) and 3 or 0) end } },
  TigersFury = { gcd = 0, cd = 30, gain = { [3] = 60 } },
  Berserk = { gcd = 0, cd = 180, buff = { "Berserk", dur = 15 } },
  FaerieFire = { cd = 6, debuff = { "FaerieFire", dur = 300, mine = false } },
  CatForm = { buff = { "CatForm" } },
  Wrath = {}, Starfire = {}, Moonfire = { debuff = { "Moonfire", dur = 12 } },
  InsectSwarm = { debuff = { "InsectSwarm", dur = 12 } },
}

CF.Register("DRUID", {
  sim = SIM,
  gcd = function(V) return V:Aura("player", CF.N.CatForm) and 1.0 or 1.5 end,
  ids = {
    Wrath = 5176,        Starfire = 2912,      Moonfire = 8921,
    InsectSwarm = 5570,  Starfall = 48505,     ForceOfNature = 33831,
    MoonkinForm = 24858, CatForm = 768,        Shred = 5221,
    Mangle = 33876,      Rake = 1822,          Rip = 1079,
    FerociousBite = 22568, SavageRoar = 52610, TigersFury = 5217,
    Berserk = 50334,     Claw = 1082,          Barkskin = 22812,

    Prowl = 5215,        Ravage = 6785,        Pounce = 9005,
    Swipe = 62078,       FaerieFire = 16857,   Clearcasting = 16870,
    Trauma = 46855,

    EclipseLunar = 48518, EclipseSolar = 48517,

    -- Añadidos en la revisión de profundidad
    BearForm = 5487,     DireBearForm = 9634,  MangleBear = 33878,
    Lacerate = 33745,    SwipeBear = 779,      Maul = 6807,
    DemoralizingRoar = 99, Enrage = 5229,      FrenziedRegeneration = 22842,
    SurvivalInstincts = 61336, Growl = 6795,   Bash = 8983,
    FeralChargeBear = 16979, FeralChargeCat = 49376,
    Innervate = 29166,   Hurricane = 16914,    Typhoon = 61384,
  },

  positional = { "Shred", "Ravage" },
  multidot = { [0] = { "InsectSwarm", "Moonfire" }, [1] = { "InsectSwarm", "Moonfire" } },
  upkeep = upkeep,
  evaluate = evaluate,
  filler = filler,
})
