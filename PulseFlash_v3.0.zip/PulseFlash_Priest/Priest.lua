local CF = PulseFlash

do local c = select(2, UnitClass("player")); if c and c ~= "PRIEST" then return end end
local Aura, Known, First = CF.Aura, CF.Known, CF.First
local Maintain, Cast = CF.Maintain, CF.Cast

-- Umbrales
local SWD_SELF_MIN_HP = 0.45     -- Palabra de las sombras: muerte daña al lanzador si no mata
local SWD_FREE_MIN_HP = 0.80     -- con tanta vida se usa "en cooldown" aunque no sea fase de remate
local SWD_EXECUTE_HP = 0.35      -- fase de remate del objetivo
local FIEND_MANA = 0.50
local DISPERSION_MANA = 0.25
local DOT_MIN_LIFE = 6           -- no poner DoTs si el objetivo muere antes

local function IsShadow(c, N)
  return (c.spec == 3) or (Aura("player", N.Shadowform) ~= nil)
end

-- Palabra de las sombras: muerte: remate o uso libre si hay vida de sobra
local function ShadowDeath(c, add, N)
  if not Known(N.ShadowWordDeath) then return end
  if c.hp <= SWD_EXECUTE_HP and c.php > SWD_SELF_MIN_HP then
    add(N.ShadowWordDeath, 1)
  elseif c.php > SWD_FREE_MIN_HP then
    add(N.ShadowWordDeath, 1)
  end
end

local function evaluate(c, add, N)
  local shadow = IsShadow(c, N)
  local worth = c.worth and CF.Lives(DOT_MIN_LIFE)
  local swp = Aura("target", N.ShadowWordPain, true, true)

  if shadow then
    -- ------------------------------------------------------------------
    -- Sombras: Toque vampírico > Dolor > Plaga > Descarga > Muerte > Tortura
    -- ------------------------------------------------------------------
    if worth then
      Maintain(add, c, N.VampiricTouch, Aura("target", N.VampiricTouch, true, true), 0.6)
      Maintain(add, c, N.ShadowWordPain, swp)
      Maintain(add, c, N.DevouringPlague, Aura("target", N.DevouringPlague, true, true))
    end
    Cast(add, N.MindBlast, 1)
    ShadowDeath(c, add, N)
    if CF.AoE(3) then Cast(add, N.MindSear, 1) end

    if c.combat then
      -- Maná: Abrasador de sombras primero, Dispersión como último recurso
      if c.bigCD and c.manaPct < FIEND_MANA then add(N.Shadowfiend, 2) end
      if c.manaPct < DISPERSION_MANA then add(N.Dispersion, 2) end
    end
  else
    -- ------------------------------------------------------------------
    -- Disciplina / Sagrado (daño): Fuego sagrado, Dolor, Penitencia, Descarga
    -- ------------------------------------------------------------------
    if worth then Maintain(add, c, N.ShadowWordPain, swp) end
    if worth and not Aura("target", N.HolyFire, true, true) and c.casting ~= N.HolyFire
       and not CF.Pending(N.HolyFire) then
      Cast(add, N.HolyFire, 1)
    end
    Cast(add, N.Penance, 1)
    Cast(add, N.MindBlast, 1)
    ShadowDeath(c, add, N)
    if CF.AoE(3) then add(N.HolyNova, 1) end
    if c.combat and c.bigCD and c.manaPct < FIEND_MANA then add(N.Shadowfiend, 2) end
  end

  -- ------------------------------------------------------------------
  -- Utilidad (prioridad 3)
  -- ------------------------------------------------------------------
  if CF.EnemyCasting() and IsSpellInRange(N.Silence, "target") == 1 then
    add(N.Silence, 3)
  end
  if c.combat then
    -- Amenaza: Desvanecer cuando el jefe te ataca en grupo
    if c.boss and CF.Grouped() and CF.TargetsMe() then add(N.Fade, 3) end
    if c.php < 0.60 and not Aura("player", N.WeakenedSoul, true) then add(N.PowerWordShield, 3) end
    if c.php < 0.40 then add(N.DesperatePrayer, 3) end
    if c.php < 0.35 then add(N.Dispersion, 3) end
    if c.php < 0.30 then add(N.PsychicScream, 3) end
  end
end

local function filler(c, N)
  -- En movimiento: solo instantáneos
  if CF.Moving() then
    -- Palabra de las sombras: muerte solo si sobra vida (daña al lanzador)
    if c.php > SWD_FREE_MIN_HP then return CF.ReadyFirst(N.ShadowWordDeath) end
    return nil
  end
  if IsShadow(c, N) then return First(N.MindFlay, N.Smite) end
  return First(N.Smite, N.MindBlast)
end

local SIM = {
  ShadowWordPain = { debuff = { "ShadowWordPain", dur = 18 } },
  VampiricTouch = { debuff = { "VampiricTouch", dur = 15 } },
  DevouringPlague = { debuff = { "DevouringPlague", dur = 24 } },
  MindBlast = { cd = 5.5 },
  MindFlay = { cast = 3 },
  ShadowWordDeath = { cd = 12 },
  HolyFire = { cd = 10, debuff = { "HolyFire", dur = 7 } },
  Penance = { cd = 12, cast = 2 },
  Shadowfiend = { cd = 180, fn = function(V) V:Gain(0, (V.resMax[0] or 0) * 0.05) end },
  Dispersion = { cd = 120, cast = 6, fn = function(V) V:Gain(0, (V.resMax[0] or 0) * 0.36) end },
  MindSear = { cast = 5 },
}
CF.Register("PRIEST", {
  sim = SIM,
  ids = {
    Smite = 585,             HolyFire = 14914,        ShadowWordPain = 589,
    MindBlast = 8092,        MindFlay = 15407,        VampiricTouch = 34914,
    DevouringPlague = 2944,  ShadowWordDeath = 32379, Penance = 47540,
    PowerWordShield = 17,    InnerFire = 588,         Shadowform = 15473,
    PsychicScream = 8122,    Dispersion = 47585,      WeakenedSoul = 6788,
    Silence = 15487,         Shadowfiend = 34433,     MindSear = 48045,

    -- Añadidos en la revisión de profundidad
    Fade = 586,              DesperatePrayer = 48173, HolyNova = 15237,
  },
  multidot = { [3] = { "VampiricTouch", "DevouringPlague", "ShadowWordPain" } },
  evaluate = evaluate,
  filler = filler,
})
