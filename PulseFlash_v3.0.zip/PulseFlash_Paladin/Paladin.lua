local CF = PulseFlash

do local c = select(2, UnitClass("player")); if c and c ~= "PALADIN" then return end end
local Aura, Known, Proc, First = CF.Aura, CF.Known, CF.Proc, CF.First
local Cast = CF.Cast

-- Umbrales
local CONSECRATION_MIN_MANA = 0.30   -- Ret: Consagración solo con maná de sobra
local HOLY_SHIELD_REFRESH = 1.5      -- Prot: renovar Escudo sagrado con esto restante
local HAMMER_WRATH_HP = 0.20
local PLEA_MANA = 0.50               -- Súplica divina por debajo de este maná
local PLEA_MANA_URGENT = 0.25        -- por debajo de esto pasa a prioridad 1

local function evaluate(c, add, N)
  local spec = c.spec
  local judgement = First(N.JudgementOfWisdom, N.JudgementOfLight)
  local executing = c.hp < HAMMER_WRATH_HP

  if spec == 2 then
    -- ------------------------------------------------------------------
    -- Protección: Escudo sagrado > Escudo de rectitud > Martillo del recto >
    -- Escudo del vengador > Juicio > Consagración
    -- ------------------------------------------------------------------
    local hs = Aura("player", N.HolyShield)
    if (not hs or hs <= HOLY_SHIELD_REFRESH) and not CF.Pending(N.HolyShield) then
      add(N.HolyShield, 1)
    end
    -- Martillo del recto golpea a 3 objetivos: con 3+ enemigos va antes que el escudo
    if CF.AoE(3) then add(N.HammerOfTheRighteous, 1) end
    add(N.ShieldOfRighteousness, 1)
    add(N.HammerOfTheRighteous, 1)
    add(N.AvengersShield, 1)
    add(judgement, 1)
    if executing then add(N.HammerOfWrath, 1) end
    add(N.Consecration, 1)

    -- Escudo sagrado (absorción) si falta
    if c.combat and not Aura("player", N.SacredShield) then add(N.SacredShield, 2) end
  elseif spec == 1 then
    -- ------------------------------------------------------------------
    -- Sagrado (daño): Sacudida > Juicio > Exorcismo > Consagración
    -- ------------------------------------------------------------------
    if Aura("player", N.ArtOfWar) then Cast(add, N.Exorcism, 1, true) end
    add(judgement, 1)
    add(N.HolyShock, 1)
    if executing then add(N.HammerOfWrath, 1) end
    Cast(add, N.Exorcism, 1)
    add(N.Consecration, 1)
  else
    -- ------------------------------------------------------------------
    -- Reprensión / sin rama: Juicio > Martillo de ira (remate) > Golpe del
    -- cruzado > Tormenta divina > Exorcismo (Arte de la guerra) > Consagración
    -- ------------------------------------------------------------------
    add(judgement, 1)
    if executing then add(N.HammerOfWrath, 1) end
    -- Con 3+ enemigos: Tormenta divina y Consagración suben de prioridad
    if CF.AoE(3) then
      add(N.DivineStorm, 1)
      add(N.Consecration, 1)
    end
    add(N.CrusaderStrike, 1)
    add(N.DivineStorm, 1)
    -- Ira sagrada: solo hace daño a muertos vivientes y demonios
    if CF.IsUndeadOrDemon() then add(N.HolyWrath, 1) end
    -- Arte de la guerra vuelve Exorcismo instantáneo: se permite en movimiento
    if Aura("player", N.ArtOfWar) then Cast(add, N.Exorcism, 1, true) end
    if c.manaPct > CONSECRATION_MIN_MANA or spec == 0 or c.burn then add(N.Consecration, 1) end
    if not Known(N.CrusaderStrike) then Cast(add, N.Exorcism, 1) end
  end

  -- ------------------------------------------------------------------
  -- Cooldowns y maná (prioridad 2; 1 si el maná es crítico)
  -- ------------------------------------------------------------------
  if c.combat then
    if spec ~= 2 and c.bigCD and CF.CDok(c, 180) then add(N.AvengingWrath, 2) end
    if spec == 2 and c.manaPct < 0.25 then add(N.DivinePlea, 2) end
    if spec ~= 2 then
      if c.manaPct < PLEA_MANA_URGENT then
        add(N.DivinePlea, 1)
      elseif c.manaPct < PLEA_MANA then
        add(N.DivinePlea, 2)
      end
    end
  end

  -- ------------------------------------------------------------------
  -- Utilidad (prioridad 3)
  -- ------------------------------------------------------------------
  if CF.EnemyCasting() and IsSpellInRange(N.HammerOfJustice, "target") == 1 then
    add(N.HammerOfJustice, 3)
  end
  if c.combat then
    -- Provocar: solo en grupo y si el objetivo no te mira
    if spec == 2 and CF.Grouped() and c.hostile and not CF.TargetsMe()
       and IsSpellInRange(N.HandOfReckoning, "target") == 1 then
      add(N.HandOfReckoning, 3)
    end
    if c.php < 0.40 then add(N.DivineProtection, 3) end
    if c.php < 0.15 then add(N.DivineShield, 3) end
  end
end

local function filler(c, N)
  if c.spec == 2 then
    return First(N.HammerOfTheRighteous, N.ShieldOfRighteousness, N.Consecration, N.JudgementOfWisdom, N.JudgementOfLight)
  elseif c.spec == 1 then
    return First(N.HolyShock, N.Consecration, N.JudgementOfWisdom, N.JudgementOfLight, N.Exorcism)
  end
  return First(N.CrusaderStrike, N.JudgementOfWisdom, N.JudgementOfLight,
               N.Consecration, N.SealOfRighteousness)
end

local SIM = {
  CrusaderStrike = { cd = 4 }, DivineStorm = { cd = 10 }, Consecration = { cd = 8 },
  JudgementOfWisdom = { cd = 8 }, JudgementOfLight = { cd = 8 },
  Exorcism = { cd = 15, instant = "ArtOfWar" },
  HammerOfWrath = { cd = 6 }, HolyWrath = { cd = 30 },
  AvengingWrath = { gcd = 0, cd = 180, buff = { "AvengingWrath", dur = 20 } },
  DivinePlea = { cd = 60, buff = { "DivinePlea", dur = 15 } },
  HolyShock = { cd = 6 },
  HolyShield = { cd = 8, buff = { "HolyShield", dur = 10 } },
  ShieldOfRighteousness = { cd = 6 }, HammerOfTheRighteous = { cd = 6 },
  AvengersShield = { cd = 30 },
}
CF.Register("PALADIN", {
  sim = SIM,
  ids = {
    CrusaderStrike = 35395, DivineStorm = 53385,     JudgementOfWisdom = 53408,
    JudgementOfLight = 20271, Consecration = 26573,  Exorcism = 879,
    HammerOfWrath = 24275,  AvengingWrath = 31884,   DivinePlea = 54428,
    HammerOfJustice = 853,  DivineProtection = 498,  DivineShield = 642,
    HolyShock = 20473,      HolyShield = 20925,      ShieldOfRighteousness = 53600,
    HammerOfTheRighteous = 53595, AvengersShield = 31935,
    SealOfCommand = 20375,  SealOfVengeance = 31801, SealOfCorruption = 53736,
    SealOfRighteousness = 21084, SealOfWisdom = 20166, SealOfLight = 20165,
    SealOfJustice = 20164,
    SanctityAura = 20218, RetributionAura = 7294, DevotionAura = 465,
    ConcentrationAura = 19746, FireResistanceAura = 19891,
    FrostResistanceAura = 19888, ShadowResistanceAura = 19876,

    ArtOfWar = 59578,
    HolyWrath = 2812,

    -- Añadidos en la revisión de profundidad
    HandOfReckoning = 62124, SacredShield = 53601,
  },
  evaluate = evaluate,
  filler = filler,
})
