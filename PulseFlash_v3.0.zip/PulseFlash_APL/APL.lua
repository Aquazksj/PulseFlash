-- APL.lua - Modo APL personalizado (lista de prioridades escrita por el jugador)
--
-- Sintaxis del APL (formato de importar/exportar RCAPL1):
--
--   priority:
--   - Icy Veins if cooldown_ready and not buff_active("Icy Veins")
--   - Deep Freeze if buff_active("Fingers of Frost")
--   - Ice Lance if buff_active("Fingers of Frost")
--   - Frostbolt
--
-- Una regla por línea: "Habilidad [if condición [and condición ...]]".
-- La primera regla cuyas condiciones se cumplen Y cuya habilidad se puede
-- lanzar ahora es la recomendación; las siguientes forman la cola.
-- Los comentarios empiezan con # o --. No usa loadstring: el texto se
-- interpreta con cadenas y toda evaluación va protegida con pcall.
--
-- Condiciones (todas aceptan "not"):
--   always                          cooldown_ready          spell_known
--   cooldown_remaining <op> n       buff_active(x)          debuff_active(x)
--   target_has_debuff(x)            debuff_mine(x)
--   buff_remaining(x) <op> n        debuff_remaining(x) <op> n
--   buff_stacks(x) <op> n           debuff_stacks(x) <op> n
--   target_hp / player_hp / mana_pct  (en %, 0-100)
--   rage / energy / runic_power / combo_points <op> n
--   enemies <op> n                  in_combat   moving   boss   aoe
--   target_casting                  fight_time <op> n
-- Operadores: <  <=  >  >=  ==  ~=  !=  =  <>
-- Extensión: "or" entre grupos ("a and b or c").
--
-- Comandos: /pf apl [edit|enable|disable|import <texto>|export|share|clear|check]

local PF = PulseFlash
if not PF then return end
local CF = PF

local strlower, strfind, strsub = string.lower, string.find, string.sub
local tonumber, type, pcall, ipairs, pairs = tonumber, type, pcall, ipairs, pairs

-- ---------------------------------------------------------------------------
-- Utilidades de texto
-- ---------------------------------------------------------------------------
local function Trim(s) return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", "")) end

local function Norm(s)
  if type(s) ~= "string" then return "" end
  s = s:lower()
  s = s:gsub("[%p%c]", " ")
  s = s:gsub("%s+", " ")
  return Trim(s)
end

local function Key(s) return (Norm(s):gsub(" ", "_")) end
-- Sin espacios: "IcyVeins", "icy veins" e "Icy_Veins" son el mismo nombre
local function Compact(s) return (Norm(s):gsub(" ", "")) end

-- ---------------------------------------------------------------------------
-- Parser
-- ---------------------------------------------------------------------------
local OPS = { "<=", ">=", "==", "~=", "!=", "<>", "<", ">", "=" }

local function ParseCondition(token)
  token = Trim(token)
  if token == "" then return nil end
  local cond = { negate = false }
  local low = token:lower()
  if low:match("^not%s+") then
    cond.negate = true
    token = Trim(token:sub(5))
  end
  local name = token:match("^([%a_][%w_]*)")
  if not name then return nil, token end
  cond.name = name:lower()
  local rest = token:sub(#name + 1)
  local open = rest:find("%(")
  if open and rest:sub(1, open - 1):match("^%s*$") then
    local close = rest:find("%)", open)
    if close then
      local inner = rest:sub(open + 1, close - 1)
      local args = {}
      for part in (inner .. ","):gmatch("(.-),") do
        local a = Trim(part)
        a = a:gsub('^"(.*)"$', "%1"):gsub("^'(.*)'$", "%1")
        args[#args + 1] = a
      end
      cond.arg = args[1]
      cond.arg2 = args[2]
      rest = rest:sub(close + 1)
    end
  end
  rest = Trim(rest)
  if rest ~= "" then
    local found
    for _, op in ipairs(OPS) do
      if rest:sub(1, #op) == op then
        local val = tonumber(Trim(rest:sub(#op + 1)))
        if val then
          if op == "=" then op = "==" elseif op == "!=" or op == "<>" then op = "~=" end
          cond.op, cond.value = op, val
          found = true
        end
        break
      end
    end
    if not found then return nil, token end
  end
  return cond
end

-- Devuelve reglas, lista de errores. Cada regla = { ability=, groups={ {cond,...}, ... }, line= }
function PF.ParseAPL(text)
  local rules, errors = {}, {}
  if type(text) ~= "string" then return rules, { "sin texto" } end
  local n = 0
  for raw in (text .. "\n"):gmatch("(.-)\n") do
    n = n + 1
    local line = Trim(raw:gsub("\r", ""))
    local lower = line:lower()
    if line ~= "" and not line:match("^#") and not line:match("^%-%-")
       and not lower:match("^priority%s*:?%s*$") and not lower:match("^actions%s*:?%s*$")
       and not lower:match("^prioridad%s*:?%s*$") then
      line = line:gsub("^[%-%*%+]%s*", "")
      local ability, condText = line:match("^(.-)%s+[Ii][Ff]%s+(.+)$")
      if not ability then ability, condText = line, nil end
      ability = Trim(ability)
      if ability ~= "" then
        local rule = { ability = ability, groups = {}, line = n }
        local ok = true
        if condText then
          -- separar por "or" y luego por "and" (sin distinguir mayúsculas)
          local t = " " .. condText .. " "
          t = t:gsub("%s+[Oo][Rr]%s+", "\2"):gsub("%s+[Aa][Nn][Dd]%s+", "\1")
          for grp in (t .. "\2"):gmatch("(.-)\2") do
            local list = {}
            for clause in (grp .. "\1"):gmatch("(.-)\1") do
              if Trim(clause) ~= "" then
                local c, bad = ParseCondition(clause)
                if c then list[#list + 1] = c
                else errors[#errors + 1] = "línea " .. n .. ": condición no válida '" .. Trim(clause) .. "'"; ok = false end
              end
            end
            if #list > 0 then rule.groups[#rule.groups + 1] = list end
          end
        end
        if ok then rules[#rules + 1] = rule end
      end
    end
  end
  return rules, errors
end

-- ---------------------------------------------------------------------------
-- Almacenamiento (por rama de talentos)
-- ---------------------------------------------------------------------------
local function Store()
  local db = CF.db
  if not db then return nil end
  db.apl = db.apl or { enabled = false, src = {} }
  db.apl.src = db.apl.src or {}
  return db.apl
end
local function SpecKey() return tostring(PF.spec or 0) end

local parsedCache = {}   -- texto -> reglas
local function Rules()
  local st = Store()
  if not st then return nil end
  local src = st.src[SpecKey()]
  if type(src) ~= "string" or src == "" then return nil end
  local r = parsedCache[src]
  if not r then
    r = PF.ParseAPL(src)
    parsedCache[src] = r
  end
  if #r == 0 then return nil end
  return r
end

function PF.APL_Active()
  local st = Store()
  return st and st.enabled and Rules() ~= nil or false
end

-- ---------------------------------------------------------------------------
-- Resolución de nombres
-- ---------------------------------------------------------------------------
local abilityCache, bookNorm = {}, nil
local function BuildBook()
  bookNorm = {}
  local i = 1
  while true do
    local n = GetSpellName and GetSpellName(i, BOOKTYPE_SPELL)
    if not n then break end
    local k = Norm(n)
    if not bookNorm[k] then bookNorm[k] = n end
    i = i + 1
    if i > 1500 then break end
  end
end

local function Invalidate() abilityCache = {}; bookNorm = nil end

-- clave del módulo, nombre localizado o nombre del libro de hechizos -> nombre de hechizo
local function ResolveSpell(name)
  if not name or name == "" then return nil end
  local hit = abilityCache[name]
  if hit ~= nil then return hit or nil end
  local N, mod = PF.N, PF.module
  local key, norm = Compact(name), Norm(name)
  local result
  if N then
    for k, v in pairs(N) do
      if type(v) == "string" and (Compact(k) == key or Compact(v) == key) then result = v; break end
    end
  end
  if not result and mod and mod.ids and GetSpellInfo then
    for k, id in pairs(mod.ids) do
      if Compact(k) == key then result = GetSpellInfo(id); break end
    end
  end
  if not result then
    if not bookNorm then BuildBook() end
    result = bookNorm[norm]
  end
  abilityCache[name] = result or false
  return result
end

local function ResolveAura(name)
  if not name or name == "" then return nil end
  local N = PF.N
  local key = Compact(name)
  if N then
    for k, v in pairs(N) do
      if type(v) == "string" and (Compact(k) == key or Compact(v) == key) then return v end
    end
  end
  return name
end

-- ---------------------------------------------------------------------------
-- Evaluación de condiciones
-- ---------------------------------------------------------------------------
local function Compare(result, cond)
  if cond.op and type(result) == "number" then
    local v, op = cond.value, cond.op
    if op == "<" then return result < v
    elseif op == "<=" then return result <= v
    elseif op == ">" then return result > v
    elseif op == ">=" then return result >= v
    elseif op == "==" then return result == v
    else return result ~= v end
  elseif type(result) == "number" then
    return result > 0
  end
  return result and true or false
end

local function AuraInfo(unit, name, harmful, mine)
  local left, count = PF.Aura(unit, ResolveAura(name), harmful, mine)
  return left, count
end

local function Eval(c, cond, spell)
  local n, r = cond.name, nil
  if n == "always" then r = true
  elseif n == "cooldown_ready" then
    r = (not spell) or (CF.CD(spell) <= 0)
  elseif n == "cooldown_remaining" then r = spell and CF.CD(spell) or 0
  elseif n == "spell_known" then r = spell and PF.Known(spell) or false
  elseif n == "buff_active" then r = (AuraInfo("player", cond.arg, false)) ~= nil
  elseif n == "debuff_active" or n == "target_has_debuff" then r = (AuraInfo("target", cond.arg, true)) ~= nil
  elseif n == "debuff_mine" then r = (AuraInfo("target", cond.arg, true, true)) ~= nil
  elseif n == "buff_remaining" then
    local l = AuraInfo("player", cond.arg, false); r = l and math.min(l, 9999) or 0
  elseif n == "debuff_remaining" then
    local l = AuraInfo("target", cond.arg, true); r = l and math.min(l, 9999) or 0
  elseif n == "buff_stacks" then
    local l, k = AuraInfo("player", cond.arg, false); r = l and (k or 1) or 0
  elseif n == "debuff_stacks" then
    local l, k = AuraInfo("target", cond.arg, true); r = l and (k or 1) or 0
  elseif n == "target_hp" then r = (c.hp or 1) * 100
  elseif n == "player_hp" then r = (c.php or 1) * 100
  elseif n == "mana_pct" then r = (c.manaPct or 1) * 100
  elseif n == "rage" then r = c.rage or 0
  elseif n == "energy" then r = c.energy or 0
  elseif n == "runic_power" then r = c.runic or 0
  elseif n == "combo_points" then r = c.cp or 0
  elseif n == "enemies" then r = PF.Enemies and PF.Enemies() or 1
  elseif n == "in_combat" then r = c.combat
  elseif n == "moving" then r = CF.Moving()
  elseif n == "boss" then r = c.boss
  elseif n == "aoe" then r = CF.AoE(3)
  elseif n == "target_casting" then r = CF.EnemyCasting and CF.EnemyCasting() or false
  elseif n == "fight_time" then r = c.fightTime or 0
  else r = false end
  local out = Compare(r, cond)
  if cond.negate then out = not out end
  return out
end

local function RulePasses(c, rule, spell)
  if #rule.groups == 0 then return true end
  for _, grp in ipairs(rule.groups) do
    local all = true
    for _, cond in ipairs(grp) do
      local ok, res = pcall(Eval, c, cond, spell)
      if not ok or not res then all = false; break end
    end
    if all then return true end
  end
  return false
end

-- Sustituye a module.evaluate cuando el APL está activo (lo llama Core.lua)
function PF.APL_Evaluate(c, add)
  local rules = Rules()
  if not rules then return end
  for i = 1, #rules do
    local rule = rules[i]
    local spell = ResolveSpell(rule.ability)
    if spell and PF.Known(spell) and RulePasses(c, rule, spell) then add(spell, 1) end
  end
end

-- ---------------------------------------------------------------------------
-- Exportar / compartir / validar
-- ---------------------------------------------------------------------------
function PF.APL_Export()
  local st = Store()
  local src = st and st.src[SpecKey()]
  if type(src) == "string" and src ~= "" then return src end
  local out = { "priority:" }
  if PF.module and PF.module.ids then
    local keys = {}
    for k in pairs(PF.module.ids) do keys[#keys + 1] = k end
    table.sort(keys)
    for _, k in ipairs(keys) do out[#out + 1] = "- " .. k end
  end
  return table.concat(out, "\n")
end

function PF.APL_Share()
  return "RCAPL1:" .. PF.APL_Export():gsub("\r", ""):gsub("\n", "\\n")
end

local function DecodeShare(text)
  local body = type(text) == "string" and text:match("^%s*RCAPL1:(.*)$")
  if body then return (body:gsub("\\n", "\n")) end
  return text
end

-- Guarda el texto. Devuelve nº de reglas, errores
function PF.APL_Set(text)
  local st = Store()
  if not st then return 0, { "sin base de datos" } end
  text = DecodeShare(text)
  local rules, errors = PF.ParseAPL(text)
  if #rules == 0 then return 0, (#errors > 0 and errors) or { "vacío" } end
  st.src[SpecKey()] = text
  parsedCache[text] = rules
  return #rules, errors
end

-- Informe: cada regla, si se reconoce la habilidad y si está aprendida
function PF.APL_Check()
  local st = Store()
  local src = st and st.src[SpecKey()]
  if not src or src == "" then PF.Msg("APL: sin reglas guardadas para esta rama."); return end
  local rules, errors = PF.ParseAPL(src)
  for _, e in ipairs(errors) do PF.Msg("APL: " .. e) end
  for i, rule in ipairs(rules) do
    local sp = ResolveSpell(rule.ability)
    local state = not sp and "NO RECONOCIDA" or (PF.Known(sp) and "ok" or "no aprendida")
    PF.Msg(string.format("APL %d. %s -> %s", i, rule.ability, state))
  end
end

-- ---------------------------------------------------------------------------
-- Ventana de edición
-- ---------------------------------------------------------------------------
local frame
local function BuildFrame()
  if frame then return frame end
  local f = CreateFrame("Frame", "PulseFlashAPLFrame", UIParent)
  f:SetWidth(520); f:SetHeight(420)
  f:SetPoint("CENTER")
  f:SetFrameStrata("DIALOG")
  f:SetMovable(true); f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  f:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
  })
  local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  title:SetPoint("TOP", 0, -16)
  title:SetText("PulseFlash - APL personalizado")
  local help = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  help:SetPoint("TOPLEFT", 20, -40); help:SetWidth(480); help:SetJustifyH("LEFT")
  help:SetText("Una regla por linea:  Habilidad if condicion and condicion\n" ..
               "Ej:  Icy Veins if cooldown_ready and not buff_active(\"Icy Veins\")")
  local sf = CreateFrame("ScrollFrame", "PulseFlashAPLScroll", f, "UIPanelScrollFrameTemplate")
  sf:SetPoint("TOPLEFT", 20, -72); sf:SetPoint("BOTTOMRIGHT", -40, 52)
  local eb = CreateFrame("EditBox", "PulseFlashAPLEdit", sf)
  eb:SetMultiLine(true); eb:SetAutoFocus(false)
  eb:SetFontObject(ChatFontNormal)
  eb:SetWidth(450); eb:SetMaxLetters(8000)
  eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  sf:SetScrollChild(eb)
  f.edit = eb

  local function Btn(label, x, fn)
    local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    b:SetWidth(110); b:SetHeight(24); b:SetPoint("BOTTOMLEFT", x, 18)
    b:SetText(label); b:SetScript("OnClick", fn)
    return b
  end
  f.btnSave = Btn("Guardar", 20, function()
    local n, errs = PF.APL_Set(f.edit:GetText())
    if n > 0 then PF.Msg("APL guardado: " .. n .. " reglas.") else PF.Msg("APL no guardado: " .. tostring(errs and errs[1] or "?")) end
    if errs then for i = 1, math.min(#errs, 3) do PF.Msg("APL: " .. errs[i]) end end
  end)
  f.btnOn = Btn("Activar", 140, function()
    local n = PF.APL_Set(f.edit:GetText())
    local st = Store()
    if n > 0 and st then st.enabled = true; PF.Msg("APL personalizado: ACTIVADO (" .. n .. " reglas)")
    else PF.Msg("APL: no hay reglas validas.") end
  end)
  f.btnOff = Btn("Desactivar", 260, function()
    local st = Store(); if st then st.enabled = false end
    PF.Msg("APL personalizado: DESACTIVADO (rotacion de clase)")
  end)
  f.btnClose = Btn("Cerrar", 380, function() f:Hide() end)
  f:Hide()
  frame = f
  return f
end

function PF.APL_Edit()
  local f = BuildFrame()
  f.edit:SetText(PF.APL_Export())
  f:Show()
end

-- ---------------------------------------------------------------------------
-- Comando /pf apl ...
-- ---------------------------------------------------------------------------
function PF.APL_Command(arg)
  arg = arg or ""
  local sub, rest = arg:match("^(%S*)%s*(.-)$")
  sub = (sub or ""):lower()
  local st = Store()
  if not st then PF.Msg("APL: base de datos no disponible."); return end
  if sub == "" or sub == "edit" or sub == "editar" then
    PF.APL_Edit()
  elseif sub == "enable" or sub == "on" or sub == "activar" then
    if not Rules() then PF.Msg("APL: no hay reglas guardadas para esta rama (usa /pf apl edit).") return end
    st.enabled = true; PF.Msg("APL personalizado: ACTIVADO")
  elseif sub == "disable" or sub == "off" or sub == "desactivar" then
    st.enabled = false; PF.Msg("APL personalizado: DESACTIVADO")
  elseif sub == "clear" or sub == "borrar" then
    st.src[SpecKey()] = nil; PF.Msg("APL borrado.")
  elseif sub == "import" or sub == "importar" then
    if rest == "" then PF.APL_Edit(); return end
    local n, errs = PF.APL_Set(rest)
    if n > 0 then st.enabled = true; PF.Msg("APL importado: " .. n .. " reglas") else PF.Msg("APL error: " .. tostring(errs and errs[1])) end
  elseif sub == "export" or sub == "exportar" then
    for line in (PF.APL_Export() .. "\n"):gmatch("(.-)\n") do PF.Msg(line) end
  elseif sub == "share" or sub == "compartir" then
    PF.Msg(PF.APL_Share())
  elseif sub == "check" or sub == "revisar" then
    PF.APL_Check()
  else
    PF.Msg("APL: /pf apl edit|enable|disable|import [texto]|export|share|clear|check")
  end
end

-- Invalidar cachés cuando cambian hechizos o talentos
local ev = CreateFrame("Frame")
ev:RegisterEvent("SPELLS_CHANGED")
ev:RegisterEvent("PLAYER_TALENT_UPDATE")
ev:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
ev:SetScript("OnEvent", Invalidate)
PF.APL_Invalidate = Invalidate
