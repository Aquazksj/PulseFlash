local CF = PulseFlash

do local c = select(2, UnitClass("player")); if c and c ~= "DEATHKNIGHT" then return end end
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

-- Umbrales (tanque)
local TANK_HEAL_URGENT = 0.45
local TANK_HEAL = 0.75
local PESTI_REFRESH = 4
local PESTI_SPREAD = 8
-- Umbrales (daño)
local RUNE_READY_TOL = 0.3
local RP_CAP_FROST = 80
local RP_CAP_UNHOLY = 85
local DEATHCOIL_COST = 40
local FROSTSTRIKE_COST = 40
local GARGOYLE_COST = 60
local GARGOYLE_POOL_T = 8
local DISEASE_MIN_LIFE = 6        -- no poner enfermedades si el objetivo muere antes

-- ---------------------------------------------------------------------------
-- Glifo de enfermedades (permite Pestilencia para renovar sin gastar Golpe)
-- ---------------------------------------------------------------------------
local glyphAt, glyphVal = 0, false
local function HasDiseaseGlyph()
  local now = GetTime()
  if now - glyphAt < 5 then return glyphVal end
  glyphAt, glyphVal = now, false
  if GetNumGlyphSockets and GetGlyphSocketInfo then
    for i = 1, GetNumGlyphSockets() do
      local enabled, _, spellID = GetGlyphSocketInfo(i)
      if enabled and spellID then
        local n = GetSpellInfo(spellID)
        n = n and n:lower()
        if n and (n:find("disease", 1, true) or n:find("enfermedad", 1, true)) then glyphVal = true; break end
      end
    end
  end
  return glyphVal
end

local function PetMissing()
  return not UnitExists("pet") or UnitIsDead("pet")
end

-- ---------------------------------------------------------------------------
-- Runas disponibles (o a punto de estarlo) por tipo.
-- Tipos de GetRuneType: 1 sangre, 2 profano, 3 escarcha, 4 muerte.
-- ---------------------------------------------------------------------------
local function Runes()
  if not GetRuneCooldown then return 0, 0, 0, 0, false end
  local b, u, f, d = 0, 0, 0, 0
  for i = 1, 6 do
    local left, t = CF.RuneInfo(i)
    if left <= RUNE_READY_TOL then
      if t == 4 then d = d + 1 elseif t == 1 then b = b + 1
      elseif t == 2 then u = u + 1 elseif t == 3 then f = f + 1 end
    end
  end
  return b, u, f, d, true
end

-- ¿Alcanzan las runas para un coste (sangre, profano, escarcha)?
-- Las runas de muerte sustituyen a cualquier otra.
local function Afford(rb, ru, rf, rd, nB, nU, nF)
  local lack = math.max(0, nB - rb) + math.max(0, nU - ru) + math.max(0, nF - rf)
  return lack <= rd
end

local gargoylePool = false

-- Jefe real (no trash elite): para cooldowns largos
local function TrueBoss(c)
  if CF.IsTrueBoss then return CF.IsTrueBoss() end
  return c.boss
end

-- ---------------------------------------------------------------------------
-- Pestilencia: propagar al entrar enemigos nuevos (o antes de que caduque)
-- ---------------------------------------------------------------------------
local pestAt, pestN = 0, 0
do
  local f = CreateFrame("Frame")
  f:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
  local pname = GetSpellInfo and GetSpellInfo(50842)
  f:SetScript("OnEvent", function(_, _, unit, spell)
    if unit == "player" and pname and spell == pname then
      pestAt = GetTime()
      pestN = CF.Enemies and CF.Enemies() or 2
    end
  end)
end

local function PestSpread(c, ft, bp, rb, rd)
  if not (ft and bp) or (rb + rd) < 1 or not CF.AoE(2) then return false end
  local now = GetTime()
  local n = CF.Enemies and CF.Enemies() or 2
  if not c.combat then pestN = 0 end
  if n < pestN then pestN = n end
  if math.min(ft, bp) <= PESTI_SPREAD and (now - pestAt) >= 8 then return true end
  return n > pestN and (now - pestAt) >= 3
end

-- ---------------------------------------------------------------------------
-- Tanque (Sangre / Escarcha / Profano con /pf tank)
-- ---------------------------------------------------------------------------
local function tankEvaluate(c, add, N)
  local spec = c.spec
  local ft = Aura("target", N.FrostFever, true, true)
  local bp = Aura("target", N.BloodPlague, true, true)
  local rb, ru, rf, rd = Runes()

  -- Curación de emergencia
  if c.php < TANK_HEAL_URGENT then add(N.DeathStrike, 1) end
  -- Golpe de runa: se activa tras esquivar / parar (IsUsable lo controla)
  add(N.RuneStrike, 1)

  -- Pestilencia: renueva enfermedades (glifo) o las extiende (AoE)
  if ft and bp then
    local left = math.min(ft, bp)
    if HasDiseaseGlyph() and left <= PESTI_REFRESH then add(N.Pestilence, 1)
    elseif PestSpread(c, ft, bp, rb, rd) then add(N.Pestilence, 1) end
  end

  Dot(add, c, N.IcyTouch, ft)
  Dot(add, c, N.PlagueStrike, bp)

  -- Generador principal según la rama
  if spec == 1 then
    add(N.HeartStrike, 1)
    add(N.BloodStrike, 1)
  end
  if c.php < TANK_HEAL then add(N.DeathStrike, 1) end
  if spec == 2 then add(N.Obliterate, 1) end

  if CF.AoE(3) then
    add(N.DeathAndDecay, 1)
    add(N.BloodBoil, 1)
  elseif CF.AoE(2) then
    add(N.BloodBoil, 1)
  end

  -- Gasto de poder rúnico: Frost Strike en Escarcha, Death Coil en el resto
  if spec == 2 then
    if c.runic >= RP_CAP_FROST then add(N.FrostStrike, 1) end
  elseif c.runic >= 90 then
    add(N.DeathCoil, 1)
  end

  -- Cooldowns y beneficios (prioridad 2)
  if c.combat then
    if not Aura("player", N.BoneShield) then add(N.BoneShield, 2) end
    if spec == 1 and c.bigCD then add(N.DancingRuneWeapon, 2) end
    if Known(N.BloodTap) and CF.CD(N.BloodTap) <= 0 and rb == 0 then add(N.BloodTap, 2) end
    if Known(N.HornOfWinter) and CF.CD(N.HornOfWinter) <= 0 and c.runic <= 90 then add(N.HornOfWinter, 2) end
  end

  -- Utilidad (prioridad 3)
  if c.combat then
    if CF.Grouped() and c.hostile and not CF.TargetsMe() then
      if IsSpellInRange(N.DarkCommand, "target") == 1 then add(N.DarkCommand, 3) end
    end
    if c.php < 0.60 then add(N.RuneTap, 3) end
    if c.php < 0.50 then add(N.VampiricBlood, 3) end
    if c.php < 0.40 then add(N.IceboundFortitude, 3) end
    if c.php < 0.50 then add(N.AntiMagicShell, 3) end
  end
  if CF.EnemyCasting() then
    if IsSpellInRange(N.MindFreeze, "target") == 1 then add(N.MindFreeze, 3)
    elseif IsSpellInRange(N.Strangulate, "target") == 1 then add(N.Strangulate, 3) end
  end
end

-- ---------------------------------------------------------------------------
-- Daño
-- ---------------------------------------------------------------------------
local function evaluate(c, add, N)
  if CF.db.dkTank then return tankEvaluate(c, add, N) end
  local spec = c.spec
  local alive = not PetMissing()

  -- Mascota (Profano): levantar si falta
  if spec == 3 and CF.db.pet ~= false and PetMissing()
     and not (UnitInVehicle and UnitInVehicle("player")) then
    local rd = N.RaiseDead
    if rd and Known(rd) and not CF.IsCasting(rd) and not CF.Pending(rd) then add(rd, 1) end
  end

  local rb, ru, rf, rd, runesKnown = Runes()
  local ready = rb + ru + rf + rd
  gargoylePool = false

  local ft = Aura("target", N.FrostFever, true, true)
  local bp = Aura("target", N.BloodPlague, true, true)

  -- ------------------------------------------------------------------
  -- 1) Enfermedades (mantenimiento: van antes que los procs)
  -- ------------------------------------------------------------------
  if c.worth and CF.Lives(DISEASE_MIN_LIFE) then
    -- Glifo de enfermedades: Pestilencia renueva ambas con una sola runa de sangre
    if ft and bp and HasDiseaseGlyph() and math.min(ft, bp) <= (spec == 2 and 3 or PESTI_REFRESH)
       and (rb + rd) >= 1 then
      add(N.Pestilence, 1)
    end
    Dot(add, c, N.IcyTouch, ft)
    Dot(add, c, N.PlagueStrike, bp)
    -- Varios enemigos: propagar en cuanto entra uno nuevo (1 runa de sangre)
    if PestSpread(c, ft, bp, rb, rd) then add(N.Pestilence, 1) end
  end

  -- ------------------------------------------------------------------
  -- 2) Procs
  -- ------------------------------------------------------------------
  -- Máquina de matar: Aniquilar si hay runas (Escarcha + Profano); si no, Golpe de escarcha
  if Aura("player", N.KillingMachine) then
    -- Golpe de escarcha no gasta runas y es el mejor receptor del crítico garantizado
    if Known(N.FrostStrike) and c.runic >= FROSTSTRIKE_COST then
      add(N.FrostStrike, 1)
    elseif Known(N.Obliterate) and Afford(rb, ru, rf, rd, 0, 1, 1) then
      add(N.Obliterate, 1)
    else
      add(N.FrostStrike, 1)
    end
  end
  Proc(add, N.Rime, N.HowlingBlast)
  -- Muerte súbita: Anillo de muerte gratis
  if Aura("player", N.SuddenDoom) then add(N.DeathCoil, 1) end

  -- ------------------------------------------------------------------
  -- 3) Gárgola (Profano): reservar poder rúnico antes de invocarla
  -- ------------------------------------------------------------------
  if spec == 3 and c.combat and TrueBoss(c) and Known(N.SummonGargoyle) and CF.CDok(c, 180) then
    add(N.SummonGargoyle, 1)
    gargoylePool = CF.CD(N.SummonGargoyle) <= GARGOYLE_POOL_T
  end

  -- ------------------------------------------------------------------
  -- 4) Gasto de poder rúnico al llegar al tope
  -- ------------------------------------------------------------------
  if spec == 3 then
    if c.runic >= (gargoylePool and 100 or RP_CAP_UNHOLY) then add(N.DeathCoil, 1) end
  elseif spec == 2 then
    if c.runic >= RP_CAP_FROST then add(N.FrostStrike, 1) end
  end

  -- ------------------------------------------------------------------
  -- 5) Área
  -- ------------------------------------------------------------------
  if CF.AoE(2) then
    local both = ft and bp
    if CF.AoE(3) then
      add(N.DeathAndDecay, 1)
      if c.worth and both then add(N.BloodBoil, 1) end
      if spec == 2 then add(N.HowlingBlast, 1) end
    end
  end

  -- ------------------------------------------------------------------
  -- 6) Generadores por rama
  -- ------------------------------------------------------------------
  if spec == 2 then
    -- Escarcha: Aniquilar > Golpe de sangre > Aullido > Golpe de escarcha > Anillo
    add(N.Obliterate, 1)
    add(N.BloodStrike, 1)
    add(N.HowlingBlast, 1)
    add(N.FrostStrike, 1)
    add(N.DeathCoil, 1)
    if c.combat then add(N.UnbreakableArmor, 2) end
  elseif spec == 3 then
    -- Profano: Muerte y descomposición (en cuanto esté lista) > Golpe de la Plaga > Golpe de sangre
    if ft and bp and Afford(rb, ru, rf, rd, 1, 1, 1) then add(N.DeathAndDecay, 1) end
    add(N.ScourgeStrike, 1)
    add(N.BloodStrike, 1)
    if not gargoylePool or (c.runic - DEATHCOIL_COST) >= GARGOYLE_COST then add(N.DeathCoil, 1) end
    -- Frenesí de necrófago: mantener a la mascota potenciada
    if c.combat and alive and not Aura("pet", N.GhoulFrenzy) then add(N.GhoulFrenzy, 2) end
  elseif spec == 1 then
    -- Sangre: Golpe de corazón > Golpe de sangre > Golpe de muerte > Anillo
    add(N.HeartStrike, 1)
    add(N.BloodStrike, 1)
    add(N.DeathStrike, 1)
    add(N.DeathCoil, 1)
    if c.combat and c.bigCD then add(N.DancingRuneWeapon, 2) end
  else
    add(N.ScourgeStrike, 1)
    add(N.Obliterate, 1)
    add(N.BloodStrike, 1)
    add(N.DeathCoil, 1)
  end

  -- ------------------------------------------------------------------
  -- 7) Cooldowns (prioridad 2)
  -- ------------------------------------------------------------------
  -- Sangre rúnica: cuando no queda ninguna runa de sangre lista
  if c.combat and runesKnown and rb == 0 and ready < 4 and Known(N.BloodTap)
     and CF.CD(N.BloodTap) <= 0 then
    add(N.BloodTap, 2)
  end
  -- Cuerno de invierno: poder rúnico gratis siempre que esté disponible
  if c.combat and Known(N.HornOfWinter) and CF.CD(N.HornOfWinter) <= 0 and c.runic <= 90 then
    add(N.HornOfWinter, 2)
  end
  if c.combat and TrueBoss(c) and (not runesKnown or ready == 0) and CF.CDok(c, 300) then
    add(N.EmpowerRuneWeapon, 2)
  end

  -- ------------------------------------------------------------------
  -- 8) Utilidad (prioridad 3)
  -- ------------------------------------------------------------------
  if CF.EnemyCasting() then
    if IsSpellInRange(N.MindFreeze, "target") == 1 then add(N.MindFreeze, 3)
    elseif IsSpellInRange(N.Strangulate, "target") == 1 then add(N.Strangulate, 3) end
  end
  -- Atraer: solo si no es jefe y está fuera de cuerpo a cuerpo
  if c.hostile and not c.boss and Known(N.DeathGrip)
     and IsSpellInRange(N.DeathGrip, "target") == 1
     and IsSpellInRange(N.PlagueStrike, "target") == 0 then
    add(N.DeathGrip, 3)
  end
  if c.combat then
    if c.php < 0.40 then add(N.IceboundFortitude, 3) end
    if c.php < 0.50 then add(N.AntiMagicShell, 3) end
  end
end

local function filler(c, N)
  if CF.db.dkTank then return nil end
  if c.spec == 2 then return First(N.FrostStrike, N.DeathCoil, N.BloodStrike) end
  if c.spec == 3 then
    if gargoylePool and (c.runic - DEATHCOIL_COST) < GARGOYLE_COST then
      return First(N.ScourgeStrike, N.BloodStrike, N.DeathCoil)
    end
    return First(N.DeathCoil, N.ScourgeStrike, N.BloodStrike)
  end
  if c.spec == 1 then return First(N.HeartStrike, N.BloodStrike, N.DeathCoil) end
  return First(N.BloodStrike, N.DeathCoil)
end

-- ---------------------------------------------------------------------------
-- Efectos para la proyección de la cola (runas: b sangre, u profano, f escarcha)
-- ---------------------------------------------------------------------------
local function KM(e) e.consume = e.consume or {}; table.insert(e.consume, "KillingMachine"); return e end
local SIM = {
  IcyTouch = KM{ runes = { f = 1 }, gain = { [6] = 10 }, debuff = { "FrostFever", dur = 21 } },
  PlagueStrike = { runes = { u = 1 }, gain = { [6] = 10 }, debuff = { "BloodPlague", dur = 21 } },
  BloodStrike = { runes = { b = 1 }, gain = { [6] = 10 } },
  HeartStrike = { runes = { b = 1 }, gain = { [6] = 10 } },
  Obliterate = KM{ runes = { f = 1, u = 1 }, gain = { [6] = 15 } },
  ScourgeStrike = { runes = { f = 1, u = 1 }, gain = { [6] = 10 } },
  DeathStrike = { runes = { f = 1, u = 1 }, gain = { [6] = 15 } },
  HowlingBlast = KM{ runes = { f = 1, u = 1 }, gain = { [6] = 10 }, free = "Rime", freeInstant = false,
                     debuff = { "FrostFever", dur = 21 } },
  FrostStrike = KM{ gain = {} },
  DeathCoil = { free = "SuddenDoom", freeInstant = false },
  DeathAndDecay = { runes = { b = 1, f = 1, u = 1 }, cd = 30, gain = { [6] = 10 } },
  Pestilence = { runes = { b = 1 }, gain = { [6] = 10 }, fn = function(V, N)
    -- renueva las enfermedades
    V:Apply("target", true, N.FrostFever, 21); V:Apply("target", true, N.BloodPlague, 21)
  end },
  BloodBoil = { runes = { b = 1 }, gain = { [6] = 10 } },
  UnbreakableArmor = { gcd = 0, cd = 60, buff = { "UnbreakableArmor", dur = 20 } },
  EmpowerRuneWeapon = { gcd = 0, cd = 300, gain = { [6] = 25 }, fn = function(V)
    for i = 1, 6 do if V.runes[i] then V.runes[i].at = V.t end end
  end },
  BloodTap = { gcd = 0, cd = 60, fn = function(V)
    for i = 1, 6 do local r = V.runes[i]; if r and r.type == 1 then r.type = 4; r.at = V.t; break end end
  end },
  SummonGargoyle = { cd = 180 },
  DancingRuneWeapon = { cd = 90 },
  GhoulFrenzy = { petbuff = { "GhoulFrenzy", dur = 30 } },
  RuneStrike = { gcd = 0, gain = { [6] = 10 }, reactive = true },
  RaiseDead = { once = true },
  HornOfWinter = { cd = 20, gain = { [6] = 10 } },
}

CF.Register("DEATHKNIGHT", {
  sim = SIM,
  ids = {
    IcyTouch = 45477,      PlagueStrike = 45462,    BloodStrike = 45902,
    DeathCoil = 47541,     Obliterate = 49020,      FrostStrike = 49143,
    HowlingBlast = 49184,  ScourgeStrike = 55090,   DeathStrike = 49998,
    HeartStrike = 55050,   UnbreakableArmor = 51271, EmpowerRuneWeapon = 47568,
    SummonGargoyle = 49206, DancingRuneWeapon = 49028,
    MindFreeze = 47528,    Strangulate = 47476,     IceboundFortitude = 48792,
    AntiMagicShell = 48707, DeathAndDecay = 49938, BloodBoil = 48721,
    BloodPresence = 48266, UnholyPresence = 48265, HornOfWinter = 57330,
    Pestilence = 50842,    RuneStrike = 56815,
    RaiseDead = 46584,

    FrostFever = 55095, BloodPlague = 55078, KillingMachine = 51124, Rime = 59052,

    -- Añadidos en la revisión de profundidad
    SuddenDoom = 49530,    BloodTap = 45529,        GhoulFrenzy = 63560,
    DeathGrip = 49576,     ArmyOfTheDead = 42650,   BoneShield = 49222,
    VampiricBlood = 55233, RuneTap = 48982,         DarkCommand = 56222,
  },
  evaluate = evaluate,
  filler = filler,
})
