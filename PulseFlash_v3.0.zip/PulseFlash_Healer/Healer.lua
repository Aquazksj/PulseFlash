local PF = PulseFlash

do local c = select(2, UnitClass("player")); if c and c ~= "PRIEST" and c ~= "PALADIN" and c ~= "SHAMAN" and c ~= "DRUID" then return end end

-- Rol segun la rama de talentos. Un sanador usa el asesor de sanaciones; con
-- /pf roles se desactiva (por ejemplo, un sacerdote Sagrado subiendo de nivel con Castigar).
local ROLE_BY_SPEC = {
  PALADIN = { [1] = "healer" },
  PRIEST  = { [1] = "healer", [2] = "healer" },
  SHAMAN  = { [3] = "healer" },
  DRUID   = { [3] = "healer" },
}

function PF.GetRole(class, spec)
  if PF.db and PF.db.roleLimit == false then return "dps" end
  local t = ROLE_BY_SPEC[class]
  return (t and t[spec]) or "dps"
end

function PF.Roles_Init()
  if PF.db and PF.db.roleLimit == nil then PF.db.roleLimit = true end
end


local NEED_PCT         = 0.95
local INJURED_PCT      = 0.80
local AOE_COUNT        = 3
local EMERGENCY_PCT    = 0.30
local EMERGENCY_TTD    = 3.0
local COOLDOWN_PCT     = 0.20
local BIG_FRACTION     = 0.80
local FAST_FRACTION    = 0.50
local HOT_MIN_DEFICIT  = 0.10
local MIN_DEFICIT_FRAC = 0.50
local MIN_DEFICIT_MAXHP = 0.06
local SCAN_INTERVAL    = 0.20
local AMOUNT_TTL       = 45

local DEF = {
  PRIEST = {
    big = { 2060, 2054 },
    fast = { 2061 },
    inst = { 47540 },
    hot = { 139 },
    aoe = { 34861, 596 },
    shield = { 17 },
    emergency = { 47788 },
  },
  PALADIN = {
    big = { 635 },
    fast = { 19750 },
    inst = { 20473 },
    emergency = { 633 },
  },
  SHAMAN = {
    big = { 331 },
    fast = { 8004 },
    inst = { 61295 },
    hot = { 61295 },
    aoe = { 1064 },
    emergency = { 16188 },
  },
  DRUID = {
    big = { 5185 },
    fast = { 50464, 8936 },
    inst = { 18562 },
    hot = { 774, 33763 },
    aoe = { 48438 },
    emergency = { 17116 },
  },
}
local SWIFTMEND_REQ = { 774, 8936 }

local S = {}
local class
local DB

local tip
local bookIndex = {}
local amounts = {}

local function BuildBook()
  wipe(bookIndex)
  for i = 1, 400 do
    local name = GetSpellName(i, BOOKTYPE_SPELL)
    if not name then break end
    bookIndex[name] = i
  end
end

local function ParseTooltip(name)
  local idx = bookIndex[name]
  if not idx then return nil end
  if not tip then
    tip = CreateFrame("GameTooltip", "PulseFlashHealScan", nil, "GameTooltipTemplate")
    tip:SetOwner(UIParent, "ANCHOR_NONE")
  end
  tip:ClearLines()
  tip:SetSpell(idx, BOOKTYPE_SPELL)

  for i = tip:NumLines(), 2, -1 do
    local fs = _G["PulseFlashHealScanTextLeft" .. i]
    local line = fs and fs:GetText()
    if line then
      local nums = {}
      for n in line:gmatch("%d+") do
        local v = tonumber(n)
        if v >= 100 then nums[#nums + 1] = v end
      end
      if #nums >= 2 and nums[2] >= nums[1] and nums[2] <= nums[1] * 2.5 then
        return (nums[1] + nums[2]) / 2
      elseif #nums >= 1 then
        return nums[1]
      end
    end
  end
  return nil
end

local observed = {}
local playerGUID

local function Amount(spell)
  if not spell then return nil end
  local o = observed[spell]
  if o and o.n >= 3 then return o.v end
  local e = amounts[spell]
  local now = GetTime()
  if e and now - e.t < AMOUNT_TTL then return e.v or nil end
  local v = ParseTooltip(spell)
  amounts[spell] = { v = v or false, t = now }
  return v
end
PF.HealAmount = Amount

local function CastTime(spell)
  local _, _, _, _, _, _, ms = GetSpellInfo(spell)
  return (ms and ms > 0) and ms / 1000 or (ms == 0 and 0 or 2.5)
end

local hist = {}
local units = {}
local nextScan = 0
local cache = { list = {}, injured = 0 }

local RAID_U, PARTY_U = {}, {}

local function GroupUnits()
  wipe(units)
  local raid = GetNumRaidMembers and GetNumRaidMembers() or 0
  if raid > 0 then
    for i = 1, raid do
      local u = RAID_U[i]
      if not u then u = "raid" .. i; RAID_U[i] = u end
      units[i] = u
    end
  else
    units[1] = "player"
    for i = 1, (GetNumPartyMembers and GetNumPartyMembers() or 0) do
      local u = PARTY_U[i]
      if not u then u = "party" .. i; PARTY_U[i] = u end
      units[i + 1] = u
    end
  end
  return units
end

local function InRange(unit, probe)
  if probe then
    local r = IsSpellInRange(probe, unit)
    if r ~= nil then return r == 1 end
  end
  if UnitInRange and unit ~= "player" then
    local ir = UnitInRange(unit)
    if ir ~= nil then return ir and true or false end
  end
  return true
end

local function Track(unit, hp, now)
  local guid = UnitGUID(unit)
  local h = hist[unit]
  if not h or h.guid ~= guid then
    hist[unit] = { guid = guid, hp = hp, t = now, rate = 0 }
    return 0
  end
  local dt = now - h.t
  if dt < 0.1 then return h.rate end
  local inst = (h.hp - hp) / dt
  if inst < 0 then inst = 0 end
  local k = math.min(1, dt / 2.0)
  h.rate = h.rate * (1 - k) + inst * k
  h.hp, h.t = hp, now
  return h.rate
end

local function Info(unit, now, probe, t)
  if not UnitExists(unit) or UnitIsDeadOrGhost(unit) or not UnitIsConnected(unit)
     or not UnitCanAssist("player", unit) then
    return nil
  end
  local hp, max = UnitHealth(unit), UnitHealthMax(unit)
  if not max or max <= 0 then return nil end
  local rate = Track(unit, hp, now)
  if t then
    t.unit, t.name, t.hp, t.max = unit, UnitName(unit), hp, max
    t.deficit, t.pct, t.rate = max - hp, hp / max, rate
    t.ttd = (rate > 0) and (hp / rate) or 999
    t.inRange = InRange(unit, probe)
    return t
  end
  return {
    unit = unit, name = UnitName(unit), hp = hp, max = max,
    deficit = max - hp, pct = hp / max, rate = rate,
    ttd = (rate > 0) and (hp / rate) or 999,
    inRange = InRange(unit, probe),
  }
end

local function Threshold(max, minAmt)
  return math.max((minAmt or 0) * MIN_DEFICIT_FRAC, max * MIN_DEFICIT_MAXHP)
end

local function Needs(i, minAmt)
  if not i or not i.inRange or i.pct > NEED_PCT then return false end
  return i.pct < EMERGENCY_PCT or i.deficit >= Threshold(i.max, minAmt)
end

local scanPool = {}
local function ByNeed(a, b)
  if a.pct ~= b.pct then return a.pct < b.pct end
  return a.deficit > b.deficit
end

local function Scan(now, probe, minAmt)
  if now < nextScan then return end
  nextScan = now + SCAN_INTERVAL
  local list, injured = cache.list, 0
  wipe(list)
  local gu = GroupUnits()
  for k = 1, #gu do
    local unit = gu[k]
    local slot = scanPool[unit]
    if not slot then slot = {}; scanPool[unit] = slot end
    local i = Info(unit, now, probe, slot)
    if Needs(i, minAmt) then
      list[#list + 1] = i
      if i.pct <= INJURED_PCT then injured = injured + 1 end
    end
  end
  table.sort(list, ByNeed)
  cache.injured = injured
end

local candList, candPool = {}, {}
local function ByAmt(a, b) return a.amt > b.amt end
local function Cand(u, spell, amt, defaultFrac)
  if not spell then return end
  for i = 1, #candList do if candList[i].spell == spell then return end end
  local n = #candList + 1
  local e = candPool[n]
  if not e then e = {}; candPool[n] = e end
  e.spell, e.amt, e.cast = spell, amt or (u.max * defaultFrac), CastTime(spell)
  candList[n] = e
end

local function Short(n)
  if n >= 1000 then return string.format("%.1fk", n / 1000) end
  return tostring(math.floor(n + 0.5))
end

local function HasAnyAura(unit, ids)
  for i = 1, #ids do
    local n = GetSpellInfo(ids[i])
    if n and PF.Aura(unit, n, false, true) then return true end
  end
  return false
end


-- ---------------------------------------------------------------------------
-- Capa de soporte para sanadores:
--   * Disipaciones: magia / enfermedad / veneno / maldición según la clase
--   * Mantenimiento sobre el tanque: Escudo de tierra, Flor de vida, Faro de
--     luz, Escudo sagrado, Rezo de alivio, Escudo de palabras de poder, Rejuv.
--   * Recursos y cooldowns de banda: Presteza / Marea de maná / Himno divino /
--     Tranquilidad / Iluminación divina / Súplica divina / Infusión de poder
-- Cada hechizo se resuelve por ID (cualquier rango) y solo se recomienda si
-- está aprendido. El texto del HUD indica a QUIÉN va dirigido.
-- ---------------------------------------------------------------------------
local SUP = {
  PRIEST = {
    pom = { 48113, 33076 },  pws = { 17 },  hymn = { 64843 },  hope = { 64901 },
    pi = { 10060 },  fiend = { 34433 },  innerfocus = { 14751 },
    dispelMagic = { 988, 527 },  abolish = { 552 },  cureDisease = { 528 },
    pain = { 33206 },  guardian = { 47788 },  poh = { 596 },
  },
  PALADIN = {
    beacon = { 53563 },  sshield = { 53601 },  cleanse = { 4987 },
    illum = { 31842 },  plea = { 54428 },  purify = { 1152 },
  },
  SHAMAN = {
    earthshield = { 974 },  manatide = { 16190 },  cleanseSpirit = { 51886 },
    cureToxins = { 526 },  curePoison = { 526 },  cureDisease = { 526 },
    watershield = { 52127 },  riptide = { 61295 },
  },
  DRUID = {
    lifebloom = { 33763 },  tranq = { 740 },  innervate = { 29166 },
    abolish = { 2893 },  removeCurse = { 2782 },  wildgrowth = { 48438 },
    rejuv = { 774 },  nourish = { 50464 },
  },
}
-- Qué hechizo quita cada tipo de efecto, por clase (orden = preferencia)
local DISPEL_KEYS = {
  PRIEST  = { Magic = { "dispelMagic" }, Disease = { "abolish", "cureDisease" } },
  PALADIN = { Magic = { "cleanse" }, Poison = { "cleanse", "purify" }, Disease = { "cleanse", "purify" } },
  SHAMAN  = { Curse = { "cleanseSpirit" }, Poison = { "cleanseSpirit", "cureToxins" }, Disease = { "cleanseSpirit", "cureToxins" } },
  DRUID   = { Curse = { "removeCurse" }, Poison = { "abolish" } },
}
-- Efectos que NO se deben disipar (castigan al que disipa)
local NO_DISPEL_IDS = { 30108, 34914, 31117 }   -- Aflicción inestable, Toque vampírico
local noDispel = {}

local sup = {}                       -- spell name por clave, resuelto en Resolve()
local tankCache = { at = -10, unit = nil, sure = false }
local dispelCache = { at = -10, unit = nil, kind = nil }

local function SupResolve()
  wipe(sup)
  wipe(noDispel)
  for _, id in ipairs(NO_DISPEL_IDS) do
    local n = GetSpellInfo(id)
    if n then noDispel[n] = true end
  end
  local t = SUP[class]
  if not t then return end
  for key, ids in pairs(t) do
    for i = 1, #ids do
      local n = GetSpellInfo(ids[i])
      if n and PF.Known(n) then sup[key] = n; break end
    end
  end
end

local function Assisted(unit)
  return UnitExists(unit) and not UnitIsDeadOrGhost(unit) and UnitIsConnected(unit)
         and UnitCanAssist("player", unit)
end

-- Tanque. Se puntua a cada miembro del grupo y gana el de mayor puntuacion:
--   100  asignacion de tanque principal (banda)
--    90  rol de tanque asignado (buscador de mazmorras)
--    50  tiene una aura de tanque (Furia justa, Forma de oso, Actitud defensiva, Presencia de escarcha)
--   +10  con aura/rol y ademas tiene la amenaza asegurada, o 40 si solo tiene la amenaza (sin aura)
-- Si nadie puntua: 2) quien es el objetivo del objetivo del enemigo actual  3) el foco.
-- Devuelve (unidad, fiable). "fiable" = asignacion, rol o aura (sirve tambien fuera de combate).
local TANK_AURA_IDS = { 25780, 5487, 9634, 71, 48263 }
local tankAuras

local function HasTankAura(unit)
  if not tankAuras then
    tankAuras = {}
    for _, id in ipairs(TANK_AURA_IDS) do
      local n = GetSpellInfo(id)
      if n then tankAuras[#tankAuras + 1] = n end
    end
  end
  for i = 1, #tankAuras do
    if PF.Aura(unit, tankAuras[i], false, false) then return true end
  end
  return false
end

local function FindTank(now)
  if now - tankCache.at < 0.5 then return tankCache.unit, tankCache.sure end
  tankCache.at, tankCache.unit, tankCache.sure = now, nil, false
  local gu = GroupUnits()
  if #gu <= 1 then return nil end

  local best, bestScore = nil, 0
  for k = 1, #gu do
    local u = gu[k]
    if u ~= "player" and Assisted(u) then
      local score = 0
      if GetPartyAssignment then
        local ok, r = pcall(GetPartyAssignment, "MAINTANK", u)
        if ok and r then score = 100 end
      end
      if score == 0 and UnitGroupRolesAssigned then
        local ok, role = pcall(UnitGroupRolesAssigned, u)
        if ok and role == "TANK" then score = 90 end
      end
      if score == 0 and HasTankAura(u) then score = 50 end
      if UnitThreatSituation then
        local th = UnitThreatSituation(u)
        if th == 3 then score = score + ((score > 0) and 10 or 40) end
      end
      if score > bestScore then best, bestScore = u, score end
    end
  end
  if best then
    tankCache.unit, tankCache.sure = best, (bestScore >= 50 and bestScore ~= 40)
    return tankCache.unit, tankCache.sure
  end

  if UnitExists("target") and UnitCanAttack("player", "target") and UnitExists("targettarget") then
    for k = 1, #gu do
      local u = gu[k]
      if u ~= "player" and Assisted(u) and UnitIsUnit("targettarget", u) then
        tankCache.unit = u
        return u, false
      end
    end
  end
  if UnitExists("focus") and Assisted("focus") and not UnitIsUnit("focus", "player") then
    tankCache.unit = "focus"
  end
  return tankCache.unit, false
end

-- Primer miembro con un efecto disipable que podamos quitar (cacheado 0.5 s)
local function FindDispel(now)
  if now - dispelCache.at < 0.5 then return dispelCache.unit, dispelCache.kind, dispelCache.spell end
  dispelCache.at, dispelCache.unit, dispelCache.kind, dispelCache.spell = now, nil, nil, nil
  local map = DISPEL_KEYS[class]
  if not map then return nil end
  local gu = GroupUnits()
  local best, bestKind, bestSpell, bestPct
  for k = 1, #gu do
    local u = gu[k]
    if Assisted(u) then
      for i = 1, 40 do
        local name, _, _, _, dtype = UnitDebuff(u, i)
        if not name then break end
        if dtype and map[dtype] and not noDispel[name] then
          local spell
          for _, key in ipairs(map[dtype]) do
            if sup[key] then spell = sup[key]; break end
          end
          if spell and IsSpellInRange(spell, u) ~= 0 then
            local mx = UnitHealthMax(u)
            local pct = (mx and mx > 0) and (UnitHealth(u) / mx) or 1
            -- se prefiere al más herido
            if not best or pct < bestPct then best, bestKind, bestSpell, bestPct = u, dtype, spell, pct end
            break
          end
        end
      end
    end
  end
  dispelCache.unit, dispelCache.kind, dispelCache.spell = best, bestKind, bestSpell
  return best, bestKind, bestSpell
end

local function UName(unit) return UnitName(unit) or unit end

-- Devuelve (texto, unidad) de la primera recomendación de soporte realmente lanzable
local function SupportEval(c, add, u, now)
  if not sup or next(sup) == nil then return nil end
  local mana = c.manaPct or 1
  local tier = ((not u) or u.pct > 0.65) and 1 or 2
  local info, infoUnit
  local function want(spell, unit, label)
    if not spell then return end
    if add(spell, tier) and not info and PF.State(spell) == 3 then
      info, infoUnit = label, unit
    end
  end
  local function aura(unit, name) return PF.Aura(unit, name, false, true) end

  -- 1) Disipaciones
  local du, dkind, dspell = FindDispel(now)
  if du then
    want(dspell, du, string.format("%s: %s (%s)", dspell, UName(du), dkind))
  end

  local tank, sure = FindTank(now)
  if tank and not c.combat and not sure then tank = nil end

  -- Mantenimiento sobre el tanque: no recomendar si esta fuera de alcance
  local function wantT(spell, unit, label)
    if IsSpellInRange(spell, unit) == 0 then return end
    want(spell, unit, label)
  end

  -- 2) Mantenimiento sobre el tanque (en combate; fuera de combate solo si el tanque es fiable)
  if tank then
    local tn = UName(tank)
    if class == "PALADIN" then
      if sup.beacon then
        local left = aura(tank, sup.beacon)
        if not left or left < 8 then wantT(sup.beacon, tank, sup.beacon .. ": " .. tn) end
      end
      if sup.sshield then
        local left = aura(tank, sup.sshield)
        if not left or left < 5 then wantT(sup.sshield, tank, sup.sshield .. ": " .. tn) end
      end
    elseif class == "SHAMAN" then
      if sup.earthshield then
        local left, n = aura(tank, sup.earthshield)
        if not left or (n or 1) <= 2 then wantT(sup.earthshield, tank, sup.earthshield .. ": " .. tn) end
      end
      if sup.riptide and not aura(tank, sup.riptide) then
        wantT(sup.riptide, tank, sup.riptide .. ": " .. tn)
      end
    elseif class == "DRUID" then
      if sup.lifebloom then
        local left, n = aura(tank, sup.lifebloom)
        if not left or (n or 1) < 3 or left < 3 then wantT(sup.lifebloom, tank, sup.lifebloom .. ": " .. tn) end
      end
      if sup.rejuv and not aura(tank, sup.rejuv) then
        wantT(sup.rejuv, tank, sup.rejuv .. ": " .. tn)
      end
    elseif class == "PRIEST" then
      if sup.pom and not aura(tank, sup.pom) then wantT(sup.pom, tank, sup.pom .. ": " .. tn) end
      local weak = GetSpellInfo(6788)
      if sup.pws and not aura(tank, sup.pws) and not (weak and PF.Aura(tank, weak, true)) then
        wantT(sup.pws, tank, sup.pws .. ": " .. tn)
      end
      if S.hot and not aura(tank, S.hot) then wantT(S.hot, tank, S.hot .. ": " .. tn) end
    end

    -- Cooldown de supervivencia del tanque (siempre prioridad 3, tampoco roba el turno)
    local ti = Info(tank, now, S.fast or S.big or S.inst)
    if ti and ti.pct < 0.35 then
      if sup.pain then add(sup.pain, 3) end
      if sup.guardian then add(sup.guardian, 3) end
    end
  end

  if c.combat then
    -- 3) Cooldowns de banda
    local injured = cache.injured or 0
    if injured >= 5 then
      if sup.hymn then add(sup.hymn, 2) end
      if sup.tranq then add(sup.tranq, 2) end
    end
    if injured >= 3 and sup.pi then add(sup.pi, 2) end
    if injured >= 4 and sup.poh and sup.poh ~= S.aoe then add(sup.poh, 2) end
    if injured >= 3 and sup.wildgrowth and sup.wildgrowth ~= S.aoe then add(sup.wildgrowth, 2) end
    if sup.innerfocus and injured >= 2 then add(sup.innerfocus, 2) end

    -- 4) Maná
    if mana < 0.20 then
      if sup.innervate then add(sup.innervate, 1) end
      if sup.manatide then add(sup.manatide, 1) end
      if sup.hope then add(sup.hope, 1) end
      if sup.fiend and UnitExists("target") and UnitCanAttack("player", "target") then add(sup.fiend, 1) end
    elseif mana < 0.40 then
      if sup.manatide then add(sup.manatide, 2) end
      if sup.illum then add(sup.illum, 2) end
      if sup.hope then add(sup.hope, 2) end
    end
    if mana < 0.50 and sup.plea then add(sup.plea, 2) end
  end

  return info, infoUnit
end

function PF.HealerEval(c, add)
  PF.healInfo, c.healUnit = nil, nil
  if not class or not S.any then return end
  local now = GetTime()
  local probe = S.fast or S.big or S.inst

  local bigAmt, fastAmt, instAmt = Amount(S.big), Amount(S.fast), Amount(S.inst)
  local minAmt
  local a = bigAmt or 0
  if a > 0 then minAmt = a end
  a = fastAmt or 0
  if a > 0 and (not minAmt or a < minAmt) then minAmt = a end
  a = instAmt or 0
  if a > 0 and (not minAmt or a < minAmt) then minAmt = a end
  Scan(now, probe, minAmt)

  local u
  local t = Info("target", now, probe)
  if Needs(t, minAmt) then
    u = t
  else
    u = cache.list[1]
    if u then u = Info(u.unit, now, probe) end
    if not Needs(u, minAmt) then u = nil end
  end
  if not u then
    local sInfo, sUnit = SupportEval(c, add, nil, now)
    if sInfo then PF.healInfo = sInfo; c.healUnit = sUnit end
    return
  end

  c.healUnit = u.unit
  local isTarget = UnitIsUnit and UnitIsUnit(u.unit, "target")
  PF.healInfo = string.format("%s%s  %d%%  -%s%s", isTarget and "" or "> ", u.name or "?",
    math.floor(u.pct * 100 + 0.5), Short(u.deficit),
    u.rate > 0 and (" (" .. Short(u.rate) .. "/s)") or "")

  local mana = c.manaPct or 1
  local thr = Threshold(u.max, minAmt)
  local emergency = (u.pct < EMERGENCY_PCT) or (u.ttd < EMERGENCY_TTD and u.deficit >= thr)
  local hasHot = S.hot and PF.Aura(u.unit, S.hot, false, true) and true or false
  local swiftOK = S.inst and (class ~= "DRUID" or HasAnyAura(u.unit, SWIFTMEND_REQ))
  local inst = swiftOK and S.inst or nil

  if cache.injured >= AOE_COUNT and S.aoe then add(S.aoe, 1) end

  if emergency then

    add(inst, 1)
    add(S.fast, 1)

    local weak = GetSpellInfo(6788)
    if S.shield and not PF.Aura(u.unit, S.shield, false) and not (weak and PF.Aura(u.unit, weak, true)) then
      add(S.shield, 1)
    end
    add(S.big, 2)
  else

    local cands = candList
    wipe(cands)
    Cand(u, S.big, bigAmt, 0.45); Cand(u, S.fast, fastAmt, 0.25); Cand(u, inst, instAmt, 0.25)
    table.sort(cands, ByAmt)

    local pick
    for _, cd in ipairs(cands) do
      local need = u.deficit + u.rate * cd.cast
      if need >= cd.amt * BIG_FRACTION and u.ttd > cd.cast + 0.5 then pick = cd; break end
    end

    if not pick and #cands > 0 then
      local sm = cands[#cands]
      if u.deficit + u.rate * sm.cast >= sm.amt * FAST_FRACTION and u.ttd > sm.cast + 0.5 then pick = sm end
    end
    if pick then
      add(pick.spell, 1)
      for _, cd in ipairs(cands) do if cd ~= pick then add(cd.spell, 2) end end
    end

    if S.hot and not hasHot and not pick
       and (u.deficit >= u.max * HOT_MIN_DEFICIT or (u.rate > 0 and u.deficit >= thr)) then
      add(S.hot, 1)
    elseif S.hot and not hasHot then
      add(S.hot, 2)
    end
  end

  if u.pct < COOLDOWN_PCT and S.emergency then
    for i = 1, #S.emergency do add(S.emergency[i], 3) end
  end

  SupportEval(c, add, u, now)
end

local function Resolve()
  wipe(S)
  local def = DEF[class]
  if not def then return end
  local function first(ids)
    for i = 1, #ids do
      local n = GetSpellInfo(ids[i])
      if n and PF.Known(n) then return n end
    end
  end
  S.big, S.fast, S.inst = first(def.big or {}), first(def.fast or {}), first(def.inst or {})
  S.hot, S.aoe, S.shield = first(def.hot or {}), first(def.aoe or {}), first(def.shield or {})
  S.emergency = {}
  for _, id in ipairs(def.emergency or {}) do
    local n = GetSpellInfo(id)
    if n and PF.Known(n) then S.emergency[#S.emergency + 1] = n end
  end
  S.any = (S.big or S.fast or S.inst) and true or false
  SupResolve()
  BuildBook()
  wipe(amounts)
  wipe(observed)
end

local lf, logOn
function PF.Healer_SyncLog()
  if not lf then return end
  local want = (PF.role == "healer")
  if want == logOn then return end
  logOn = want
  if want then lf:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
  else lf:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED") end
end

function PF.Healer_Init(cls)
  DB = PF.db
  class = cls
  playerGUID = UnitGUID("player")
  Resolve()

  lf = CreateFrame("Frame")
  logOn = false
  lf:SetScript("OnEvent", function(_, _, _, sub, sGUID, _, _, _, _, _, _, spellName, _, amount, _, _, critical)
    if sub ~= "SPELL_HEAL" or sGUID ~= playerGUID or not spellName or not amount or amount <= 0 or critical then
      return
    end
    local o = observed[spellName]
    if not o then observed[spellName] = { v = amount, n = 1 }
    else o.v = o.v * 0.8 + amount * 0.2; o.n = o.n + 1 end
  end)
  local f = CreateFrame("Frame")
  f:RegisterEvent("SPELLS_CHANGED")
  f:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
  f:RegisterEvent("PLAYER_TALENT_UPDATE")
  f:SetScript("OnEvent", function() Resolve() end)
end
