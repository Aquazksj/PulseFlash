-- Analysis.lua
-- Informe después de una pelea contra un jefe o un muñeco de entrenamiento (dummy). Mide cuatro cosas:
--   * Mantenimiento de DoT      % del tiempo que tus DoTs/debuffs estuvieron activos en el jefe
--   * Aprovechamiento de procs  % de procs que gastaste antes de que caducaran
--   * Tiempo sin actividad      % del combate sin lanzar nada (más allá del GCD)
--   * Renovaciones anticipadas  veces que refrescaste un DoT con mucho tiempo restante
-- Solo escucha el registro de combate mientras dura el combate; fuera de él no cuesta nada.
-- El informe se guarda en PulseFlashDB.reports[personaje] y se ve en la pestaña "Análisis".
local PF = PulseFlash
local GetTime, floor, max, min = GetTime, math.floor, math.max, math.min

local MIN_FIGHT  = 15    -- combates más cortos (s) no generan informe
local MAX_GAP    = 10    -- huecos mayores (s) se toman por mecánica de jefe, no por inactividad
local PROC_EARLY = 0.7   -- un proc que se quita con más de esto restante cuenta como aprovechado
local HIST       = 10    -- informes guardados por personaje

local A = { cur = nil }
PF.Analysis = A

local pGUID

-- ---------------------------------------------------------------------------
-- Almacén
-- ---------------------------------------------------------------------------
local function Store()
  if not PulseFlashDB then return nil end
  if type(PulseFlashDB.reports) ~= "table" then PulseFlashDB.reports = {} end
  local key = PF.GetCharKey()
  local r = PulseFlashDB.reports[key]
  if type(r) ~= "table" then r = {}; PulseFlashDB.reports[key] = r end
  if type(r.hist) ~= "table" then r.hist = {} end
  return r
end

function A.Last()
  local st = Store()
  return st and st.last or nil
end

function A.History()
  local st = Store()
  return st and st.hist or {}
end

function A.Clear()
  local st = Store()
  if st then st.last = nil; st.hist = {} end
end

-- ---------------------------------------------------------------------------
-- Sesión de combate
-- ---------------------------------------------------------------------------
local function Gcd()
  local _, class = UnitClass("player")
  if class == "ROGUE" then return 1.0 end
  local h = 0
  if GetCombatRatingBonus and CR_HASTE_SPELL then h = GetCombatRatingBonus(CR_HASTE_SPELL) or 0 end
  local g = 1.5 / (1 + h / 100)
  if g < 1.0 then g = 1.0 end
  return g
end

local function NewSession()
  local s = {
    t0 = GetTime(), boss = false, bossName = nil, anyName = nil,
    bossG = {}, tgtG = {},
    dots = {}, early = 0,
    procNames = {}, procs = {}, procApplied = 0, procUsed = 0,
    firstCast = nil, busyUntil = nil, idle = 0, pending = nil, casts = 0,
    gcd = Gcd(),
  }
  for _, p in ipairs(PF.procList or {}) do s.procNames[p.name] = p end
  return s
end

-- Hueco entre el fin de la acción anterior y ahora
local function Gap(s, now)
  if s.busyUntil and now > s.busyUntil then
    local gap = now - s.busyUntil
    if gap < MAX_GAP then s.idle = s.idle + gap end
  end
end

local function OnCast(s, sub, spellId, now)
  if sub == "SPELL_CAST_START" then
    Gap(s, now)
    if not s.firstCast then s.firstCast = now end
    local ct = (select(7, GetSpellInfo(spellId)) or 0) / 1000
    s.busyUntil = now + max(s.gcd, ct)
    s.pending = spellId
  else -- SPELL_CAST_SUCCESS
    s.casts = s.casts + 1
    if s.pending == spellId then
      s.pending = nil
      if not s.busyUntil or s.busyUntil < now then s.busyUntil = now end
    else
      Gap(s, now)
      if not s.firstCast then s.firstCast = now end
      s.busyUntil = now + s.gcd
    end
    -- canalizaciones: ocupado hasta que termine el canal
    local endT = select(6, UnitChannelInfo("player"))
    if endT and endT / 1000 > s.busyUntil then s.busyUntil = endT / 1000 end
  end
end

local function CheckEarly(s, e, now)
  local rem = (e.exp or 0) - now
  local win = (tonumber(PF.db and PF.db.dotWindow) or 4) + 0.5
  if rem > win then s.early = s.early + 1 end
end

local function OnDot(s, sub, dG, spellName, now)
  local k = dG .. spellName
  local e = s.dots[k]
  if sub == "SPELL_AURA_REMOVED" then
    if e and e.on then e.total = e.total + (now - e.since); e.on = false end
    return
  end
  local dur
  if dG == UnitGUID("target") then
    local _, _, d = PF.Aura("target", spellName, true, true)
    if d and d > 0 then dur = d end
  end
  if not e then
    e = { g = dG, name = spellName, first = now, total = 0, on = false, exp = 0 }
    s.dots[k] = e
  end
  dur = dur or e.dur or 12
  e.dur = dur
  if e.on then
    CheckEarly(s, e, now)          -- renovación con el aura todavía activa
  else
    e.on, e.since = true, now
  end
  e.exp = now + dur
end

local function OnProc(s, sub, p, spellName, now)
  if sub == "SPELL_AURA_APPLIED" or sub == "SPELL_AURA_REFRESH" then
    if sub == "SPELL_AURA_REFRESH" and p.stacks then return end   -- cargas: es el mismo proc
    local left = PF.Aura("player", spellName)
    s.procApplied = s.procApplied + 1
    s.procs[spellName] = { on = true, exp = now + ((left and left < 9000) and left or 15) }
  elseif sub == "SPELL_AURA_REMOVED" then
    local st = s.procs[spellName]
    if st and st.on then
      st.on = false
      if now < st.exp - PROC_EARLY then s.procUsed = s.procUsed + 1 end
    end
  end
end

local function OnLog(_, _, _, sub, sG, _, _, dG, _, _, spellId, spellName, _, auraType)
  local s = A.cur
  if not s then return end
  local now = GetTime()
  if sG == pGUID then
    if sub == "SPELL_CAST_START" or sub == "SPELL_CAST_SUCCESS" then
      OnCast(s, sub, spellId, now)
      return
    end
    if auraType == "DEBUFF" and dG and dG ~= pGUID
       and (sub == "SPELL_AURA_APPLIED" or sub == "SPELL_AURA_REFRESH" or sub == "SPELL_AURA_REMOVED") then
      OnDot(s, sub, dG, spellName, now)
    end
  end
  if dG == pGUID and auraType == "BUFF"
     and (sub == "SPELL_AURA_APPLIED" or sub == "SPELL_AURA_REFRESH" or sub == "SPELL_AURA_REMOVED") then
    local p = s.procNames[spellName]
    if p then OnProc(s, sub, p, spellName, now) end
  end
end

-- Detección de jefe (cada 0,5 s mientras dura el combate)
local function Poll(s)
  if UnitExists("target") and UnitCanAttack("player", "target") and not UnitIsDead("target") then
    local g = UnitGUID("target")
    if g then
      s.tgtG[g] = true
      if not s.anyName then s.anyName = UnitName("target") end
      if not s.bossG[g] and PF.DetectBoss
         and PF.DetectBoss(UnitLevel("player"), UnitLevel("target"), UnitClassification("target")) then
        s.bossG[g] = true
        s.boss = true
        s.bossName = UnitName("target")
      end
    end
  end
  for i = 1, 4 do
    local u = "boss" .. i
    if UnitExists(u) then
      local g = UnitGUID(u)
      if g and not s.bossG[g] then
        s.bossG[g] = true
        s.boss = true
        s.bossName = s.bossName or UnitName(u)
      end
    end
  end
end

-- ---------------------------------------------------------------------------
-- Cálculo del informe
-- ---------------------------------------------------------------------------
local function Compute(s, now)
  local rep = { dur = now - s.t0, boss = s.bossName or s.anyName, casts = s.casts }

  -- 1) Mantenimiento de DoT (ponderado por tiempo, solo en el jefe)
  local up, span, n = 0, 0, 0
  local useAll = next(s.bossG) == nil
  for _, e in pairs(s.dots) do
    if s.bossG[e.g] or (useAll and s.tgtG[e.g]) then
      local tot = e.total + (e.on and (now - e.since) or 0)
      local sp = now - e.first
      if sp >= 3 then
        up = up + min(tot, sp)
        span = span + sp
        n = n + 1
      end
    end
  end
  rep.nDots = n
  rep.dot = (span > 0) and (100 * up / span) or nil

  -- 2) Aprovechamiento de procs
  rep.nProcs = s.procApplied
  rep.procs = (s.procApplied > 0) and (100 * s.procUsed / s.procApplied) or nil

  -- 3) Tiempo sin actividad ofensiva
  if s.firstCast then
    local idle = s.idle
    if s.busyUntil and now > s.busyUntil and now - s.busyUntil < MAX_GAP then
      idle = idle + (now - s.busyUntil)
    end
    local tot = now - s.firstCast
    if tot >= 5 then rep.idle = min(100, 100 * idle / tot) end
  end

  -- 4) Renovaciones anticipadas
  rep.early = s.early
  return rep
end

-- Informe en vivo (combate en curso) o nil
function A.Live()
  local s = A.cur
  if not s then return nil end
  local r = Compute(s, GetTime())
  r.live = true
  r.boss = r.boss or nil
  return r
end

-- ---------------------------------------------------------------------------
-- Ciclo de vida
-- ---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
local tick = CreateFrame("Frame")
tick:Hide()
local acc = 0
tick:SetScript("OnUpdate", function(_, dt)
  acc = acc + dt
  if acc < 0.5 then return end
  acc = 0
  if A.cur then Poll(A.cur) end
end)

local function Pct(v) return v and format("%d%%", floor(v + 0.5)) or "—" end

local function Finish()
  local s = A.cur
  A.cur = nil
  tick:Hide()
  ev:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
  if not s then return end
  local now = GetTime()
  if now - s.t0 < MIN_FIGHT then return end
  if not (s.boss or (PF.db and PF.db.anAll)) then return end

  local rep = Compute(s, now)
  rep.t = time()
  rep.spec = PF.spec
  rep.class = select(2, UnitClass("player"))
  local st = Store()
  if not st then return end
  st.last = rep
  table.insert(st.hist, 1, rep)
  while #st.hist > HIST do table.remove(st.hist) end

  local es = PF.GetLang and PF.GetLang() == "es"
  local idle = rep.idle and format("%.1f%%", rep.idle) or "—"
  if es then
    PF.Msg(format("Análisis del combate (%s): DoT %s · procs %s · sin actividad %s · renovaciones anticipadas %d. Mira la pestaña Análisis.",
      rep.boss or "?", Pct(rep.dot), Pct(rep.procs), idle, rep.early or 0))
  else
    PF.Msg(format("Fight analysis (%s): DoT %s · procs %s · idle %s · early refreshes %d. See the Analysis tab.",
      rep.boss or "?", Pct(rep.dot), Pct(rep.procs), idle, rep.early or 0))
  end
end

-- Inicio de sesion de analisis. Lo llama el evento de entrar en combate y, la primera
-- vez, el cargador (Lazy.lua), porque este modulo se carga justo al empezar ese combate.
local function Begin()
  if A.cur then return end
  if PF.db and (PF.db.enabled == false or PF.db.anOff) then return end
  pGUID = UnitGUID("player")
  A.cur = NewSession()
  acc = 0
  Poll(A.cur)
  tick:Show()
  ev:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
end
A.Begin = Begin

ev:RegisterEvent("PLAYER_REGEN_DISABLED")
ev:RegisterEvent("PLAYER_REGEN_ENABLED")
ev:SetScript("OnEvent", function(self, event, ...)
  if event == "COMBAT_LOG_EVENT_UNFILTERED" then
    OnLog(self, event, ...)
  elseif event == "PLAYER_REGEN_DISABLED" then
    Begin()
  else
    Finish()
  end
end)
