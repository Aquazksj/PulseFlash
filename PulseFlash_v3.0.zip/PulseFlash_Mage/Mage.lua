local CF = PulseFlash

do local c = select(2, UnitClass("player")); if c and c ~= "MAGE" then return end end
local Aura, Known, First = CF.Aura, CF.Known, CF.First
local Maintain, Cast = CF.Maintain, CF.Cast

-- Umbrales
local ARCANE_CONSERVE_MANA = 0.30   -- Arcano: fase de ahorro por debajo de este maná
local ARCANE_MAX_STACKS = 4         -- cargas de Explosión arcana antes de Descarga
local EVOCATION_MANA = 0.20
local DOT_MIN_LIFE = 8              -- no poner Bomba viviente si el objetivo muere antes

local function evaluate(c, add, N)
  local spec, mana = c.spec, c.manaPct
  local moving = CF.Moving()
  local worth = c.worth and CF.Lives(DOT_MIN_LIFE)

  -- ------------------------------------------------------------------
  -- 1) Mantenimiento antes que procs: Bomba viviente (Fuego / sin rama) y
  --    Elemental de agua (Escarcha). Los procs duran 10-15 s, un GCD de
  --    retraso no los pierde; un DoT caído sí cuesta daño.
  -- ------------------------------------------------------------------
  if worth and (spec == 2 or spec == 0) then
    -- exacto: se renueva al expirar para no cancelar la explosión final
    Maintain(add, c, N.LivingBomb, Aura("target", N.LivingBomb, true, true), 0.3, 1, true)
  end
  -- Quemar mejorado (Fuego con talento): mantener 5 cargas de Vulnerabilidad al
  -- fuego en jefes; si otro mago ya las aporta, el debuff ajeno cuenta igual.
  if spec == 2 and c.boss and worth and Known(N.Scorch) and CF.HasTalent(N.ImprovedScorch)
     and c.casting ~= N.Scorch and not CF.Pending(N.Scorch) then
    local left, stacks = Aura("target", N.FireVulnerability, true)
    if not left or (stacks or 0) < 5 or left <= 8 then Cast(add, N.Scorch, 1) end
  end
  if spec == 3 and Known(N.SummonWaterElemental) and not UnitExists("pet")
     and c.casting ~= N.SummonWaterElemental and not CF.Pending(N.SummonWaterElemental) then
    Cast(add, N.SummonWaterElemental, 1)
  end

  -- ------------------------------------------------------------------
  -- 2) Procs
  --    Pirotecnia y Congelación cerebral los vuelven instantáneos (se permiten
  --    en movimiento). Descarga de misiles es un canalizado: solo parado.
  -- ------------------------------------------------------------------
  if Aura("player", N.HotStreak) then Cast(add, N.Pyroblast, 1, true) end
  if Aura("player", N.MissileBarrage) then Cast(add, N.ArcaneMissiles, 1) end
  if Aura("player", N.BrainFreeze) then
    Cast(add, Known(N.FrostfireBolt) and N.FrostfireBolt or N.Fireball, 1, true)
  end

  -- Dedos de escarcha: Congelación profunda y luego Lanza de hielo (ambos instantáneos)
  if Aura("player", N.FingersOfFrost) then
    add(N.DeepFreeze, 1)
    add(N.IceLance, 1)
  end

  -- ------------------------------------------------------------------
  -- 3) Área
  -- ------------------------------------------------------------------
  if CF.AoE(3) then
    if spec == 1 then add(N.ArcaneExplosion, 1)          -- instantáneo
    elseif spec == 2 then
      add(N.BlastWave, 1)                                -- instantáneo, cuerpo a cuerpo
      Cast(add, N.Flamestrike, 1)
    else
      add(N.ConeOfCold, 1)                               -- instantáneo, cuerpo a cuerpo
      Cast(add, N.Blizzard, 1)
    end
  end

  -- ------------------------------------------------------------------
  -- 4) Arcano: Explosión arcana x4 -> Descarga si estamos ahorrando maná
  -- ------------------------------------------------------------------
  if spec == 1 then
    local _, stacks = Aura("player", N.ArcaneBlast)
    stacks = stacks or 0
    if moving then
      add(N.ArcaneBarrage, 1)                              -- instantáneo
    elseif stacks >= ARCANE_MAX_STACKS and mana < ARCANE_CONSERVE_MANA and not c.burn then
      add(N.ArcaneBarrage, 1)
    end
    Cast(add, N.ArcaneBlast, 1)
  end

  -- En movimiento cualquier especialización dispone de instantáneos
  if moving then
    add(N.FireBlast, 1)
    add(N.IceLance, 1)
  end

  -- ------------------------------------------------------------------
  -- 5) Cooldowns (prioridad 2)
  -- ------------------------------------------------------------------
  if c.combat and c.bigCD then
    if spec == 1 then
      if CF.CDok(c, 120) then add(N.ArcanePower, 2) end
      add(N.PresenceOfMind, 2)
    end
    if spec == 2 and CF.CDok(c, 120) then add(N.Combustion, 2) end
    if spec == 3 then
      local iv = Aura("player", N.IcyVeins)
      if not iv and CF.CDok(c, 180) then add(N.IcyVeins, 2) end
      -- Escalofrío: solo si Venas heladas (ya gastadas y terminadas) y Congelación profunda
      -- están en cooldown; con las Venas aún activas se desperdiciarían sus segundos.
      if not iv and CF.CD(N.IcyVeins) > 0 and (not Known(N.DeepFreeze) or CF.CD(N.DeepFreeze) > 0) then
        add(N.ColdSnap, 2)
      end
    end
    if CF.CDok(c, 180) then add(N.MirrorImage, 2) end
  end

  -- ------------------------------------------------------------------
  -- 6) Utilidad (prioridad 3)
  -- ------------------------------------------------------------------
  if CF.EnemyCasting() and IsSpellInRange(N.Counterspell, "target") == 1 then
    add(N.Counterspell, 3)
  end
  if c.combat then
    if c.php < 0.60 and not Aura("player", N.IceBarrier) then add(N.IceBarrier, 3) end
    if c.php < 0.20 then add(N.IceBlock, 3) end
    if mana < EVOCATION_MANA then add(N.Evocation, 3) end
  end
end

local function filler(c, N)
  -- En movimiento: instantáneos listos
  if CF.Moving() then return CF.ReadyFirst(N.FireBlast, N.IceLance, N.ArcaneBarrage) end
  if c.spec == 1 then return First(N.ArcaneBlast, N.Fireball, N.Frostbolt) end
  if c.spec == 2 then return First(N.Fireball, N.Frostbolt) end
  return First(N.Frostbolt, N.Fireball)
end

local SIM = {
  ArcaneBlast = { buff = { "ArcaneBlast", add = 1, max = 4, dur = 6 } },
  ArcaneBarrage = { cd = 3, gcd = 1.5 },
  ArcaneMissiles = { consume = { "MissileBarrage" }, cast = 5 },
  Pyroblast = { instant = "HotStreak" },
  Fireball = { instant = "BrainFreeze" },
  FrostfireBolt = { instant = "BrainFreeze" },
  Frostbolt = {},
  LivingBomb = { debuff = { "LivingBomb", dur = 12 } },
  IceLance = { consume = { "FingersOfFrost" }, consumeStack = true },
  DeepFreeze = { cd = 30, consume = { "FingersOfFrost" }, consumeStack = true },
  Scorch = {},
  FireBlast = { cd = 8 },
  ArcanePower = { gcd = 0, cd = 120, buff = { "ArcanePower", dur = 15 } },
  PresenceOfMind = { gcd = 0, cd = 120 },
  Combustion = { cd = 120, buff = { "Combustion", dur = 10 } },
  IcyVeins = { gcd = 0, cd = 180, buff = { "IcyVeins", dur = 20 } },
  MirrorImage = { cd = 180 },
  ColdSnap = { cd = 480, reset = true, fn = function(V, N) V:SetCD(N.IcyVeins, 0); V:SetCD(N.DeepFreeze, 0) end },
  Flamestrike = {}, Blizzard = {}, ArcaneExplosion = {},
  ConeOfCold = { gcd = 1.5, cd = 8 }, BlastWave = { gcd = 1.5, cd = 30 },
  SummonWaterElemental = { once = true },
}
-- Procs del simulador de escenarios (frecuencia media por lanzamiento; ver Project.lua)
local SIMPROCS = {
  { aura = "BrainFreeze",    spec = 3, from = { "Frostbolt", "FrostfireBolt" }, chance = 0.15, dur = 15 },
  { aura = "FingersOfFrost", spec = 3, from = { "Frostbolt", "FrostfireBolt" }, chance = 0.15, dur = 15, stacks = 2 },
  { aura = "HotStreak",      spec = 2, from = { "Fireball", "FrostfireBolt", "Scorch", "FireBlast" }, chance = 0.17, dur = 10 },
  { aura = "MissileBarrage", spec = 1, from = { "ArcaneBlast", "ArcaneBarrage" }, chance = 0.15, dur = 15 },
}
CF.Register("MAGE", {
  sim = SIM,
  simProcs = SIMPROCS,
  ids = {
    Fireball = 133,       Frostbolt = 116,       ArcaneBlast = 30451,
    ArcaneMissiles = 5143, Pyroblast = 11366,    LivingBomb = 44457,
    FrostfireBolt = 44614, IceLance = 30455,     DeepFreeze = 44572,
    Combustion = 11129,   IcyVeins = 12472,      MirrorImage = 55342,
    ArcanePower = 12042,  Counterspell = 2139,   IceBlock = 45438,
    Evocation = 12051,    MoltenArmor = 30482,   MageArmor = 6117,
    IceArmor = 7302,      FrostArmor = 168,
    ArcaneBarrage = 44781, ArcaneExplosion = 1449, PresenceOfMind = 12043,
    ColdSnap = 11958,     SummonWaterElemental = 31687,
    Flamestrike = 2120,   Blizzard = 10,
    ConeOfCold = 120,     BlastWave = 11113,

    HotStreak = 48108, MissileBarrage = 44401, FingersOfFrost = 44544, BrainFreeze = 57761,

    -- Añadidos en la revisión de profundidad
    FireBlast = 2136,     IceBarrier = 11426,
    Scorch = 2948,        ImprovedScorch = 11095, FireVulnerability = 22959,
  },
  multidot = { [0] = { "LivingBomb" }, [2] = { "LivingBomb" } },
  evaluate = evaluate,
  filler = filler,
})
