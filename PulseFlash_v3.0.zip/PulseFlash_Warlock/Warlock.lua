local CF = PulseFlash

do local c = select(2, UnitClass("player")); if c and c ~= "WARLOCK" then return end end
local Aura, Known, First = CF.Aura, CF.Known, CF.First
local Maintain, Cast = CF.Maintain, CF.Cast

-- Umbrales
local LIFETAP_LOW_MANA = 0.20     -- por debajo de este maná, Matar vida es prioridad 1
local LIFETAP_MIN_HP = 0.50       -- nunca con menos vida que esto
local LIFETAP_GLYPH_MIN_HP = 0.40
local LIFETAP_REFRESH = 2.0       -- renovar el beneficio del glifo cuando quede esto
local EXECUTE_HP = 0.25           -- Drenar alma (Aflicción)
local DECIMATION_HP = 0.35        -- Decimación se activa por debajo de este % de vida
local SHADOWBURN_HP = 0.20

local eradSince = nil

-- ---------------------------------------------------------------------------
-- Glifo de Matar vida (se detecta una vez cada pocos segundos)
-- ---------------------------------------------------------------------------
local ltGlyph, ltGlyphAt, ltSeen = false, 0, false

local function HasLifeTapGlyph(N)
  local now = GetTime()
  if now - ltGlyphAt < 2 then return ltGlyph end
  ltGlyphAt = now
  ltGlyph = false
  local lt = N.LifeTap
  if lt and GetNumGlyphSockets and GetGlyphSocketInfo then
    for i = 1, GetNumGlyphSockets() do
      local enabled, _, glyphSpellID = GetGlyphSocketInfo(i)
      if enabled and glyphSpellID then
        local gname = GetSpellInfo(glyphSpellID)
        if gname and gname:find(lt, 1, true) then ltGlyph = true; break end
      end
    end
  end
  return ltGlyph
end

-- Se ejecuta aunque no haya objetivo: Erradicación y el beneficio de Matar vida
local function upkeep(c, add, N)
  if Aura("player", N.Eradication) then
    if not eradSince then eradSince = GetTime() end
  else
    eradSince = nil
  end

  if Known(N.LifeTap) then
    local ltLeft = Aura("player", N.LifeTap)
    if ltLeft then ltSeen = true end
    if (ltSeen or HasLifeTapGlyph(N)) and (not ltLeft or ltLeft <= LIFETAP_REFRESH)
       and c.php > LIFETAP_GLYPH_MIN_HP and not CF.Pending(N.LifeTap) then
      add(N.LifeTap, 1)
    end
  end
end

-- ---------------------------------------------------------------------------
-- Elección de maldición
--   * Modo ICC: Maldición de fatalidad
--   * Jefe en grupo: Maldición de los elementos, salvo que otro la aporte
--     (Brujo, Tierra y luna del Druida o Plaga de ébano del Caballero de la Muerte)
--   * En cualquier otro caso: Maldición de agonía
-- ---------------------------------------------------------------------------
local function PickCurse(c, N)
  if CF.db.icc and Known(N.CurseOfDoom) then return N.CurseOfDoom end
  if c.boss and CF.Grouped() and Known(N.CurseOfTheElements) then
    local mine = Aura("target", N.CurseOfTheElements, true, true)
    local any = CF.AnyAura("target", true, false,
                           N.CurseOfTheElements, N.EarthAndMoon, N.EbonPlague)
    if mine or not any then return N.CurseOfTheElements end
  end
  return N.CurseOfAgony
end

local function PetAlive()
  return UnitExists("pet") and not UnitIsDead("pet")
end

-- Orden de prioridades (misma filosofía para todas las ramas):
--   1. Maná crítico (Matar vida)
--   2. Área (solo si el modo AoE está activo)
--   3. MANTENIMIENTO: DoTs, maldición, Atormentar... si faltan o están por acabarse
--   4. Mascota / Metamorfosis
--   5. Habilidades de rama que dependen del mantenimiento (Conflagrar, Caos)
--   6. Procs que solo mejoran un relleno (Núcleo fundido, Reflujo, Trance, Diezmar)
--   7. Remates y relleno
-- Así un proc NUNCA tapa un DoT que se ha acabado: Incinerar mejorado por
-- Núcleo fundido solo sale cuando Inmolar y Corrupción están al día.
local function evaluate(c, add, N)
  local spec, hp = c.spec, c.hp
  local inMeta = Aura("player", N.Metamorphosis) ~= nil

  -- 1) Maná
  if c.manaPct < LIFETAP_LOW_MANA and c.php > LIFETAP_MIN_HP then add(N.LifeTap, 1) end

  -- 2) Área: Semilla de corrupción con 3+ enemigos (una por objetivo; explota al
  --    recibir daño suficiente y expande Corrupción), Lluvia de fuego con 4+
  if c.hostile and CF.AoE(3) then
    if not Aura("target", N.SeedOfCorruption, true, true) and CF.Lives(6)
       and c.casting ~= N.SeedOfCorruption and not CF.Pending(N.SeedOfCorruption) then
      Cast(add, N.SeedOfCorruption, 1)
    end
    if CF.AoE(4) then Cast(add, N.RainOfFire, 1) end
  end

  -- 3) Mantenimiento (solo si el objetivo merece la pena)
  local imm, corr
  if c.worth then
    imm = Aura("target", N.Immolate, true, true)
    corr = Aura("target", N.Corruption, true, true)
    local curse = PickCurse(c, N)
    local curseLeft = Aura("target", curse, true, true)
    -- Fatalidad no se refresca mientras está puesta (daña al terminar)
    if curse == N.CurseOfDoom and curseLeft then curseLeft = 9999 end
    -- Destrucción con Caos solo mantiene maldición si es la de los elementos / fatalidad
    local wantCurse = (curse ~= N.CurseOfAgony) or not (spec == 3 and Known(N.ChaosBolt))

    -- Erradicación: si el proc es posterior a mi Corrupción, volver a lanzarla
    if eradSince then
      local cLeft, _, cDur, cExp = Aura("target", N.Corruption, true, true)
      if cLeft and cDur and cExp and cDur > 0 and cExp > 0
         and (cExp - cDur) < (eradSince - 0.2) and c.casting ~= N.Corruption
         and not CF.Pending(N.Corruption) then
        add(N.Corruption, 1)
      end
    end

    if spec == 1 then
      -- Aflicción: Atormentar > Aflicción inestable > Corrupción > maldición
      Maintain(add, c, N.Haunt, Aura("target", N.Haunt, true, true), 0.8)
      Maintain(add, c, N.UnstableAffliction, Aura("target", N.UnstableAffliction, true, true), 0.4, 1, true)
      if not Known(N.UnstableAffliction) then Maintain(add, c, N.Immolate, imm) end
      Maintain(add, c, N.Corruption, corr)
      if wantCurse then Maintain(add, c, curse, curseLeft) end
    elseif spec == 3 then
      -- Destrucción: Inmolar manda (Incinerar y Conflagrar dependen de él)
      Maintain(add, c, N.Immolate, imm)
      Maintain(add, c, N.Corruption, corr)
      if wantCurse then Maintain(add, c, curse, curseLeft) end
    elseif spec == 2 then
      -- Demonología: Corrupción > Inmolar > maldición
      Maintain(add, c, N.Corruption, corr)
      Maintain(add, c, N.Immolate, imm)
      if wantCurse then Maintain(add, c, curse, curseLeft) end
    else
      Maintain(add, c, N.Immolate, imm)
      Maintain(add, c, N.Corruption, corr)
      Maintain(add, c, curse, curseLeft)
    end
  end

  -- 4) Mascota potenciada (Demonología) y Inmolación en Metamorfosis
  if spec == 2 and PetAlive() then add(N.DemonicEmpowerment, 1) end
  if inMeta and c.worth and c.hostile then add(N.ImmolationAura, 1) end

  -- 5) Habilidades de rama que dependen del mantenimiento
  if spec == 3 then
    if imm then add(N.Conflagrate, 1) end        -- necesita Inmolar activo
    Cast(add, N.ChaosBolt, 1)
  end

  -- 6) Procs que solo mejoran un relleno: van DESPUÉS del mantenimiento
  if hp < DECIMATION_HP and Aura("player", N.Decimation) then Cast(add, N.SoulFire, 1) end
  if Aura("player", N.Backlash) then
    Cast(add, spec == 3 and N.Incinerate or N.ShadowBolt, 1, true)
  end
  if Aura("player", N.ShadowTrance) then Cast(add, N.ShadowBolt, 1, true) end
  if Aura("player", N.MoltenCore) then
    -- Incinerar mejorado: solo con Inmolar activo (si no, el relleno normal)
    if imm or not c.worth then Cast(add, N.Incinerate, 1) end
  end

  -- 7) Remates
  if spec == 1 and hp <= EXECUTE_HP then Cast(add, N.DrainSoul, 1) end
  if spec == 3 and hp <= SHADOWBURN_HP then add(N.Shadowburn, 1) end

  -- Cooldowns y utilidad
  if c.combat and c.bigCD and spec == 2 and not inMeta and CF.CDok(c, 180) then add(N.Metamorphosis, 2) end
  if c.combat and c.php < 0.35 then add(N.DeathCoil, 3) end
end

local function filler(c, N)
  -- En movimiento solo valen los instantáneos
  if CF.Moving() then return CF.ReadyFirst(N.Conflagrate, N.Shadowburn) end
  if c.spec == 1 and c.hp <= EXECUTE_HP and Known(N.DrainSoul) then return N.DrainSoul end
  if c.spec == 3 then return First(N.Incinerate, N.ShadowBolt) end
  return First(N.ShadowBolt, N.Incinerate)
end

local SIM = {
  ShadowBolt = { instant = { "ShadowTrance", "Backlash" } },
  -- Núcleo fundido (Demonología) se gasta de carga en carga; Contragolpe la hace instantánea
  Incinerate = { instant = "Backlash", consume = { "MoltenCore" }, consumeStack = true },
  Immolate = { debuff = { "Immolate", dur = 15 } },
  Corruption = { debuff = { "Corruption", dur = 18 } },
  CurseOfAgony = { debuff = { "CurseOfAgony", dur = 24 } },
  CurseOfDoom = { cd = 60, debuff = { "CurseOfDoom", dur = 60 } },
  CurseOfTheElements = { debuff = { "CurseOfTheElements", dur = 300 } },
  UnstableAffliction = { debuff = { "UnstableAffliction", dur = 15 } },
  Haunt = { cd = 8, debuff = { "Haunt", dur = 12 } },
  ChaosBolt = { cd = 12 },
  Conflagrate = { cd = 10, fn = function(V, N)
    if not CF.HasGlyph(N.Conflagrate) then V:Remove("target", true, N.Immolate) end
  end },
  SoulFire = { consume = { "Decimation" } },
  SeedOfCorruption = { debuff = { "SeedOfCorruption", dur = 18 } },
  -- Matar vida da maná y, con el glifo, el beneficio de 40 s que el addon renueva
  -- (misma condición que en upkeep). Sin modelar ese beneficio el simulador
  -- recomendaba Matar vida en bucle porque nunca "veía" el efecto.
  LifeTap = { fn = function(V, N)
    V:Gain(0, (V.resMax[0] or 0) * 0.15)
    if ltSeen or HasLifeTapGlyph(N) then V:Apply("player", false, N.LifeTap, 40, 1, true) end
  end },
  Metamorphosis = { gcd = 0, cd = 180, buff = { "Metamorphosis", dur = 30 } },
  DemonicEmpowerment = { cd = 60 },
  ImmolationAura = { cd = 30, gated = true },   -- solo dentro de Metamorfosis (30 s)
  Shadowburn = { cd = 15 },
  DrainSoul = {},
}
-- Procs del simulador de escenarios (frecuencia media por lanzamiento; ver Project.lua)
local SIMPROCS = {
  { aura = "ShadowTrance", spec = 1, from = { "Corruption", "Haunt", "UnstableAffliction", "ShadowBolt" }, chance = 0.12, dur = 10 },
  { aura = "MoltenCore",   spec = 2, from = { "Corruption", "ShadowBolt", "Immolate" }, chance = 0.20, dur = 15, stacks = 3 },
  -- Contragolpe nace de recibir daño; se aproxima como uno cada ~15-20 s de lanzamientos
  { aura = "Backlash",     from = { "Incinerate", "Immolate", "Corruption", "ChaosBolt", "Conflagrate", "ShadowBolt" }, chance = 0.08, dur = 8 },
  { aura = "Decimation",   spec = 2, from = { "ShadowBolt", "Incinerate", "SoulFire" }, chance = 0.25, dur = 10,
    when = function(V) return (V.c0.hp or 1) < DECIMATION_HP end },
}
CF.Register("WARLOCK", {
  sim = SIM,
  simProcs = SIMPROCS,
  ids = {
    ShadowBolt = 686,   Immolate = 348,          Corruption = 172,
    CurseOfAgony = 980, CurseOfDoom = 603, UnstableAffliction = 30108, Haunt = 48181,
    Conflagrate = 17962, ChaosBolt = 50796,      Incinerate = 29722,
    SoulFire = 6353,    DrainSoul = 1120,        LifeTap = 1454,
    Metamorphosis = 47241, DeathCoil = 6789,
    FelArmor = 28176,   DemonArmor = 706,        DemonSkin = 687,
    CreateSpellstone = 2362,

    ShadowTrance = 17941, Backlash = 34936, Decimation = 63167, MoltenCore = 47383,
    Eradication = 64371,

    -- Añadidos en la revisión de profundidad
    SeedOfCorruption = 27243, RainOfFire = 5740,    Shadowburn = 17877,
    DemonicEmpowerment = 47193, ImmolationAura = 50589,
    CurseOfTheElements = 1490, EarthAndMoon = 60433, EbonPlague = 65142,
  },
  upkeep = upkeep,

  multidot = {
    [0] = { "Immolate", "Corruption", "CurseOfAgony" },
    [1] = { "UnstableAffliction", "Corruption", "CurseOfAgony" },
    [2] = { "Corruption", "Immolate", "CurseOfAgony" },
    [3] = { "Immolate", "Corruption" },
  },
  multidotSkip = function(key) return key == "CurseOfAgony" and CF.db.icc end,
  evaluate = evaluate,
  filler = filler,
})
