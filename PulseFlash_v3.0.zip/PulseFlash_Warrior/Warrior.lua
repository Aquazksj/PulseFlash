local CF = PulseFlash

do local c = select(2, UnitClass("player")); if c and c ~= "WARRIOR" then return end end
local Aura, Known, First = CF.Aura, CF.Known, CF.First
local Maintain, Cast = CF.Maintain, CF.Cast

-- Rabia a partir de la cual se gasta en Golpe heroico / Hendedura
local DUMP_RAGE_ARMS = 50
local DUMP_RAGE_BURN = 40
local DUMP_RAGE_FURY = 60
local DUMP_RAGE_LOW = 25          -- niveles bajos sin habilidades principales
local DUMP_RAGE_PROT = 60         -- tanque: más amenaza con la rabia sobrante

local EXECUTE_HP = 0.20
local REND_MIN_LIFE = 10          -- no poner Romper si el objetivo muere antes
local RAGE_STARVED = 20           -- Ira sangrienta por debajo de esto

local function evaluate(c, add, N)
  local spec = c.spec

  -- Furia sin Sed de sangre aprendida (niveles bajos): rotación genérica
  if spec == 2 and not Known(N.Bloodthirst) then spec = 0 end
  local executing = (c.hp < EXECUTE_HP)
  local dump = CF.AoE(2) and N.Cleave or N.HeroicStrike

  -- ¿Aún sin las habilidades principales? (nivel bajo)
  local lowLevel = not (Known(N.MortalStrike) or Known(N.Bloodthirst) or Known(N.Whirlwind))

  if spec == 2 then
    -- ------------------------------------------------------------------
    -- Furia: Sed de sangre > Torbellino > Machacar (proc) > Remate
    -- ------------------------------------------------------------------
    if CF.AoE(2) then add(N.Whirlwind, 1) end
    add(N.Bloodthirst, 1)
    add(N.Whirlwind, 1)
    -- Sed de sangre-surge vuelve instantáneo Machacar: permitido en movimiento
    if Aura("player", N.Bloodsurge) then Cast(add, N.Slam, 1, true) end
    add(N.VictoryRush, 1)
    if Aura("player", N.SuddenDeath) then add(N.Execute, 1) end
    if executing then add(N.Execute, 1) end
    if c.rage >= (c.burn and DUMP_RAGE_BURN or DUMP_RAGE_FURY) then add(dump, 1) end

    -- Rabia berserker: dispara Enfurecer y rompe miedos
    if c.combat then add(N.BerserkerRage, 2) end
  elseif spec == 3 then
    -- ------------------------------------------------------------------
    -- Protección: Rebanar escudo > Venganza > Devastar > área / control
    -- ------------------------------------------------------------------
    add(N.ShieldSlam, 1)
    add(N.Revenge, 1)
    -- Estruendo / Sacudida solo con varios objetivos o como golpe de talento
    add(N.Shockwave, 1)                       -- talento de Protección: en cuanto esté listo
    if CF.AoE(3) then add(N.ThunderClap, 1) end
    add(N.ConcussionBlow, 1)
    add(N.Devastate, 1)
    if c.rage >= DUMP_RAGE_PROT then add(dump, 1) end

    if c.combat then
      -- Grito desmoralizador: mantenerlo sobre el objetivo (de cualquier guerrero)
      if c.hostile and not Aura("target", N.DemoralizingShout, true) then
        add(N.DemoralizingShout, 2)
      end
      if c.hostile and not Aura("target", N.ThunderClap, true) then add(N.ThunderClap, 2) end
    end
  else
    -- ------------------------------------------------------------------
    -- Armas / sin rama: Romper > Golpe mortal > Sobrepotencia > Remate
    -- ------------------------------------------------------------------
    -- Mantenimiento primero: Romper caído o por caer
    if c.worth and not executing and CF.Lives(REND_MIN_LIFE) then
      Maintain(add, c, N.Rend, Aura("target", N.Rend, true, true))
    end
    if Aura("player", N.SuddenDeath) then add(N.Execute, 1) end
    if executing then add(N.Execute, 1) end
    add(N.VictoryRush, 1)
    if CF.AoE(2) then add(N.SweepingStrikes, 1) end
    if CF.AoE(3) then
      add(N.ThunderClap, 1)
      add(N.Whirlwind, 1)
    end
    if Aura("player", N.TasteForBlood) then add(N.Overpower, 1) end
    add(N.MortalStrike, 1)
    add(N.Overpower, 1)
    add(N.Whirlwind, 1)
    if Aura("player", N.Bloodsurge) then Cast(add, N.Slam, 1, true) end
    if c.rage >= (lowLevel and DUMP_RAGE_LOW or (c.burn and DUMP_RAGE_BURN or DUMP_RAGE_ARMS)) then
      add(dump, 1)
    end
  end

  -- ------------------------------------------------------------------
  -- Cooldowns (prioridad 2)
  -- ------------------------------------------------------------------
  if c.combat then
    if c.rage < RAGE_STARVED then add(N.Bloodrage, 2) end
    if c.bigCD then
      if spec ~= 3 then
        -- Imprudencia solo en fase de remate o si el usuario quiere cooldowns siempre
        if (c.burn or CF.db.cdAlways) and CF.CDok(c, 300) then add(N.Recklessness, 2) end
        if CF.CDok(c, 180) then add(N.DeathWish, 2) end
        if CF.CDok(c, 90) then add(N.Bladestorm, 2) end
      end
    end
  end

  -- ------------------------------------------------------------------
  -- Utilidad (prioridad 3)
  -- ------------------------------------------------------------------
  -- Acercarse al objetivo: Cargar (fuera de combate) / Interceptar (combate)
  if c.hostile and not CF.TargetsMe() then
    if not c.combat then add(N.Charge, 3) else add(N.Intercept, 3) end
  end
  if CF.EnemyCasting() then
    if IsSpellInRange(N.Pummel, "target") == 1 then add(N.Pummel, 3) end
    if IsSpellInRange(N.ShieldBash, "target") == 1 then add(N.ShieldBash, 3) end
  end
  if c.combat then
    -- Provocar en grupo si el objetivo no te ataca (solo tanque)
    if spec == 3 and CF.Grouped() and c.hostile and not CF.TargetsMe()
       and IsSpellInRange(N.Taunt, "target") == 1 then
      add(N.Taunt, 3)
    end
    if spec == 3 and CF.TargetsMe() then add(N.ShieldBlock, c.php < 0.70 and 3 or 2) end
    if c.php < 0.35 then add(N.EnragedRegeneration, 3) end
    if spec == 3 then
      if c.php < 0.35 then add(N.LastStand, 3) end
      if c.php < 0.25 then add(N.ShieldWall, 3) end
    end
  end
end

local function filler(c, N)
  if c.spec == 1 then return First(N.Slam, N.HeroicStrike) end
  if c.spec == 3 then return First(N.Devastate, N.HeroicStrike) end
  return First(N.HeroicStrike, N.Slam)
end

local SIM = {
  Bloodthirst = { cd = 4 }, MortalStrike = { cd = 6 }, Whirlwind = { cd = 10 },
  Overpower = { cd = 5, once = true }, Slam = { instant = "Bloodsurge" },
  Execute = { consume = { "SuddenDeath" } },
  Rend = { debuff = { "Rend", dur = 15 } },
  -- Golpe heroico / Hendedura sustituyen al siguiente golpe automático: ~1 por golpe, no sin límite
  HeroicStrike = { gcd = 0, cd = 2.5 }, Cleave = { gcd = 0, cd = 2.5 },
  Recklessness = { gcd = 0, cd = 300, buff = { "Recklessness", dur = 12 } },
  DeathWish = { cd = 180, buff = { "DeathWish", dur = 30 } },
  Bladestorm = { cd = 90, cast = 6 },
  ShieldSlam = { cd = 6 }, Revenge = { cd = 5, once = true }, Devastate = {},
  ThunderClap = { cd = 6 }, Shockwave = { cd = 17 }, ConcussionBlow = { cd = 30 },
  -- Golpe de la victoria solo se puede usar tras matar a un enemigo (reactiva)
  VictoryRush = { cd = 1, reactive = true }, Bloodrage = { gcd = 0, cd = 60 },
}
CF.Register("WARRIOR", {
  sim = SIM,
  -- La ira se genera sobre todo con los golpes automáticos. Proyección del HUD: ~6/s.
  -- Simulador de escenarios (más realista: golpes automáticos, Rabia sangrienta, talentos):
  -- ~12/s con arma a dos manos (Armas) y ~10/s con dos armas o escudo.
  simTick = function(V, dt)
    local rate = 6
    if V.simMode then rate = (CF.spec == 2 or CF.spec == 3) and 10 or 12 end
    V:Gain(1, rate * dt)
  end,
  ids = {
    HeroicStrike = 78,   MortalStrike = 12294,  Bloodthirst = 23881,
    Whirlwind = 1680,    Slam = 1464,           Execute = 5308,
    Rend = 772,          Overpower = 7384,      VictoryRush = 34428,
    Bloodrage = 2687,    Recklessness = 1719,   DeathWish = 12292,
    Bladestorm = 46924,  Pummel = 6552,         EnragedRegeneration = 55694,
    Cleave = 845,        SweepingStrikes = 12328,  ThunderClap = 6343,
    ShieldSlam = 23922,  Revenge = 6572,        Devastate = 20243,
    BattleStance = 2457, DefensiveStance = 71,  BerserkerStance = 2458,
    BattleShout = 6673,  CommandingShout = 469,

    TasteForBlood = 60503, SuddenDeath = 52437, Bloodsurge = 46916,

    -- Añadidos en la revisión de profundidad
    BerserkerRage = 18499, Charge = 11578,      Intercept = 20252,
    ShieldBash = 72,       ShieldBlock = 2565,  ShieldWall = 871,
    LastStand = 12975,     DemoralizingShout = 1160, Taunt = 355,
    Shockwave = 46968,     ConcussionBlow = 12809,
  },
  multidot = { [0] = { "Rend" }, [1] = { "Rend" } },
  evaluate = evaluate,
  filler = filler,
})
