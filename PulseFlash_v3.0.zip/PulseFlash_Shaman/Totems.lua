local PF = PulseFlash

do local c = select(2, UnitClass("player")); if c and c ~= "SHAMAN" then return end end

local IDS = {
  Windfury = 8512,  WrathOfAir = 3738,  GraceOfAir = 8835,
  StrengthOfEarth = 8075,  Stoneskin = 8071,
  Searing = 3599,  Magma = 8190,  TotemOfWrath = 30706,  Flametongue = 8227,
  ManaSpring = 5675,  HealingStream = 5394,
}

local HASTE_AURA_IDS = { 55610, 50887 }

local MELEE = { WARRIOR = true, ROGUE = true, DEATHKNIGHT = true }
local CASTER = { MAGE = true, WARLOCK = true }
local AGILITY = { HUNTER = true }

function PF.TotemPresent(slot)
  local have, name = GetTotemInfo(slot)
  if not have then return false end
  if name ~= nil and name == "" then return false end
  return true
end

function PF.TotemKnown(n)
  if not n then return false end
  return (PF.Known(n) or GetSpellInfo(n) ~= nil) and true or false
end

function PF.TotemReady(n)
  local s, d = GetSpellCooldown(n)
  if s and s > 0 and d and d > 1.6 and (s + d - GetTime()) > 0.5 then return false end
  return true
end

local names = {}
local function N(key)
  local n = names[key]
  if n == nil then n = GetSpellInfo(IDS[key]) or false; names[key] = n end
  return n or nil
end

local function First(...)
  for i = 1, select("#", ...) do
    local n = N((select(i, ...)))
    if n and PF.TotemKnown(n) then return n end
  end
  return nil
end

local cache, cacheAt = nil, -10
local function Group()
  local now = GetTime()
  if cache and now - cacheAt < 2 then return cache end
  local g = { melee = 0, casters = 0, agility = 0 }
  local n, prefix = GetNumRaidMembers(), "raid"
  if n == 0 then n, prefix = GetNumPartyMembers(), "party" end
  for i = 1, n do
    local u = prefix .. i
    if UnitExists(u) and not UnitIsUnit(u, "player") then
      local _, cls = UnitClass(u)
      if MELEE[cls] then g.melee = g.melee + 1 end
      if CASTER[cls] then g.casters = g.casters + 1 end
      if AGILITY[cls] then g.agility = g.agility + 1 end
    end
  end
  cache, cacheAt = g, now
  return g
end

local function OtherMeleeHaste()
  for _, id in ipairs(HASTE_AURA_IDS) do
    local n = GetSpellInfo(id)
    if n and PF.Aura("player", n) then return true end
  end
  local wf = N("Windfury")
  if wf and PF.Aura("player", wf) then
    local have, tn = GetTotemInfo(4)
    if not (have and tn and tn:find(wf, 1, true) == 1) then return true end
  end
  return false
end

function PF.TotemChoice(slot, spec)
  spec = spec or PF.spec or 0
  local g = Group()
  if slot == 1 then
    if spec == 1 then return First("TotemOfWrath", "Flametongue", "Searing", "Magma") end
    if spec == 2 then
      if PF.AoE and PF.AoE(3) then return First("Magma", "Searing") end
      return First("Searing", "Magma")
    end
    if spec == 3 then return First("Flametongue", "Searing", "Magma") end
    return First("Searing", "Magma", "Flametongue")
  elseif slot == 2 then
    if spec == 2 or g.melee > 0 or g.agility > 0 then return First("StrengthOfEarth", "Stoneskin") end
    return First("Stoneskin", "StrengthOfEarth")
  elseif slot == 3 then
    return First("ManaSpring", "HealingStream")
  elseif slot == 4 then
    local meleeOnly = g.melee >= 1 and g.casters == 0
    if (spec == 2 or meleeOnly) and not OtherMeleeHaste() then
      return First("Windfury", "GraceOfAir", "WrathOfAir")
    end
    return First("WrathOfAir", "GraceOfAir", "Windfury")
  end
  return nil
end

function PF.TotemPlan(spec)
  local plan, any = {}, false
  for slot = 1, 4 do
    if not PF.TotemPresent(slot) then
      local t = PF.TotemChoice(slot, spec)
      if t then plan[slot] = t; any = true end
    end
  end
  return any and plan or nil
end

function PF.TotemAlertList(spec)
  if UnitIsDeadOrGhost("player") or (IsMounted and IsMounted()) then return nil end
  local inInstance = IsInInstance()
  local grouped = (GetNumRaidMembers() > 0) or (GetNumPartyMembers() > 0)
  if not (InCombatLockdown() or inInstance or (grouped and not IsResting())) then return nil end
  local plan = PF.TotemPlan(spec)
  if not plan then return nil end
  local out = {}
  for slot = 1, 4 do
    local t = plan[slot]
    if t and PF.TotemKnown(t) and not PF.IsCasting(t) and not PF.Pending(t) and PF.TotemReady(t) then
      out[#out + 1] = { slot = slot, spell = t }
    end
  end
  return #out > 0 and out or nil
end

function PF.TotemDebug()
  local DB = PF.db or {}
  local g = Group()
  PF.Msg(string.format("totems | avisos=%s HUDbuffos=%s rama=%s | grupo: melee=%d lanzadores=%d agilidad=%d",
    tostring(DB.totem ~= false), tostring(DB.bhud and DB.bhud.enabled ~= false), tostring(PF.spec),
    g.melee, g.casters, g.agility))
  for slot = 1, 4 do
    local have, name, start, dur = GetTotemInfo(slot)
    local choice = PF.TotemChoice(slot, PF.spec)
    PF.Msg(string.format("ranura %d | GetTotemInfo: have=%s nombre=%s dur=%s -> %s | recomendado=%s aprendido=%s listo=%s",
      slot, tostring(have), tostring(name), tostring(dur), PF.TotemPresent(slot) and "PUESTO" or "VACÍA",
      tostring(choice), tostring(PF.TotemKnown(choice)), tostring(choice and PF.TotemReady(choice))))
  end
end
