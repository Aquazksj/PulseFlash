local CF = PulseFlash

do local c = select(2, UnitClass("player")); if c and c ~= "SHAMAN" then return end end
local Aura, Known, First = CF.Aura, CF.Known, CF.First
local Maintain, Cast = CF.Maintain, CF.Cast

-- Umbrales
local MAELSTROM_STACKS = 5        -- Arma Maelstrom: gastar a 5 cargas (instantáneo)
local ELE_FS_REFRESH = 3.0        -- Elemental: renovar Choque de llamas con esto restante
local LAVA_BURST_MIN_FS = 2.5     -- Ráfaga de lava solo con Choque de llamas aguantando
local EARTH_SHOCK_MIN_FS = 6.5    -- Mejora: Choque de tierra solo con FS de sobra
local ELE_CHAIN_MIN_MANA = 0.25
local DOT_MIN_LIFE = 8            -- no poner Choque de llamas si el objetivo muere antes

-- Nova de fuego exige un tótem de fuego activo (ranura 1)
local function FireTotemUp()
  return (GetTotemInfo and GetTotemInfo(1)) and true or false
end

-- Choque de llamas con ventana propia (el DoT es corto: 12 s)
local function FlameShock(c, add, N, fsLeft, window)
  if not N.FlameShock then return end
  if fsLeft and fsLeft > window then return end
  if CF.IsCasting(N.FlameShock) or c.casting == N.FlameShock or CF.Pending(N.FlameShock) then return end
  add(N.FlameShock, 1)
end

local function evaluate(c, add, N)
  local spec = c.spec
  local fs = Aura("target", N.FlameShock, true, true)
  local worth = c.worth and CF.Lives(DOT_MIN_LIFE)

  if spec == 2 then
    -- ------------------------------------------------------------------
    -- Mejora (WotLK): Arma Maelstrom a 5 > Choque de llamas > Latigazo >
    -- Lava > Choque de tierra > Nova de fuego
    -- ------------------------------------------------------------------
    -- Mantenimiento primero: Choque de llamas caído o por caer
    if worth then FlameShock(c, add, N, fs, 2.0) end

    local mw, mwStacks = Aura("player", N.MaelstromWeapon)
    if mw and mwStacks >= MAELSTROM_STACKS then
      -- con 5 cargas el hechizo es instantáneo: permitido en movimiento
      Cast(add, CF.AoE(3) and N.ChainLightning or N.LightningBolt, 1, true)
    end

    add(N.Stormstrike, 1)
    add(N.LavaLash, 1)

    if not c.worth or (fs and fs > EARTH_SHOCK_MIN_FS) then add(N.EarthShock, 1) end
    if CF.AoE(3) then
      if FireTotemUp() then add(N.FireNova, 1) end
      Cast(add, N.ChainLightning, 1)
    end
    -- Nova de fuego como relleno de prioridad baja si hay tótem de fuego
    if FireTotemUp() then add(N.FireNova, 1) end

    -- Con menos de 5 cargas, solo rellenar si no hay nada mejor (lo hace el filler)
    if c.combat and c.bigCD then
      if CF.CDok(c, 180) then add(N.FeralSpirit, 2) end
      if CF.CDok(c, 300) then add(N.FireElementalTotem, 2) end
    end
  else
    -- ------------------------------------------------------------------
    -- Elemental / sin rama: Choque de llamas > Ráfaga de lava > Cadena de rayos
    -- ------------------------------------------------------------------
    if worth then
      FlameShock(c, add, N, fs, spec == 1 and ELE_FS_REFRESH or 2.0)
    end
    -- Ráfaga de lava con Choque de llamas aguantando (crítico garantizado)
    if fs and fs > LAVA_BURST_MIN_FS and c.casting ~= N.LavaBurst then
      Cast(add, N.LavaBurst, 1)
    end
    -- Cadena de rayos en cooldown (Elemental) o en AoE
    if (spec == 1 and (c.manaPct > ELE_CHAIN_MIN_MANA or c.burn)) or CF.AoE(2) then
      Cast(add, N.ChainLightning, 1)
    end
    -- En movimiento Choque de tierra es el único daño instantáneo restante
    if CF.Moving() then add(N.EarthShock, 1) end

    if c.combat and c.bigCD then
      if CF.CDok(c, 180) then add(N.ElementalMastery, 2) end
      if CF.CDok(c, 300) then add(N.FireElementalTotem, 2) end
    end
  end

  -- ------------------------------------------------------------------
  -- Utilidad (prioridad 3)
  -- ------------------------------------------------------------------
  if CF.EnemyCasting() then
    local kick = Known(N.WindShear) and N.WindShear or N.EarthShock
    if IsSpellInRange(kick, "target") == 1 then add(kick, 3) end
  end
  if c.combat then
    if c.php < 0.50 or c.manaPct < 0.25 then add(N.ShamanisticRage, 3) end
    if c.manaPct < 0.25 then add(N.Thunderstorm, 3) end
    if c.php < 0.40 then add(N.AstralShift, 3) end
  end
end

local function filler(c, N)
  -- En movimiento solo valen los instantáneos que estén listos
  if CF.Moving() then return CF.ReadyFirst(N.EarthShock, N.FlameShock) end
  return First(N.LightningBolt)
end

local function Shock(V, N, cd) V:SetCD(N.FlameShock, cd or 6); V:SetCD(N.EarthShock, cd or 6) end
local SIM = {
  FlameShock = { debuff = { "FlameShock", dur = 12 }, fn = function(V, N) V:SetCD(N.EarthShock, 6) end, cd = 6 },
  EarthShock = { cd = 6, fn = function(V, N) V:SetCD(N.FlameShock, 6) end },
  LavaBurst = { cd = 8 },
  LightningBolt = {}, ChainLightning = { cd = 6 },
  Stormstrike = { cd = 8 }, LavaLash = { cd = 6 }, FireNova = { cd = 10 },
  FeralSpirit = { cd = 180 }, ElementalMastery = { gcd = 0, cd = 180 },
  FireElementalTotem = { cd = 600 }, Thunderstorm = { cd = 45 },
}
CF.Register("SHAMAN", {
  sim = SIM,
  ids = {
    LightningBolt = 403,     ChainLightning = 421,     FlameShock = 8050,
    EarthShock = 8042,       LavaBurst = 51505,        Stormstrike = 17364,
    LavaLash = 60103,        LightningShield = 324,    WaterShield = 52127,
    WindShear = 57994,       ShamanisticRage = 30823,  FeralSpirit = 51533,
    ElementalMastery = 16166, Thunderstorm = 51490,    FireElementalTotem = 2894,
    MaelstromWeapon = 53817,
    WindfuryWeapon = 8232, FlametongueWeapon = 8024, RockbiterWeapon = 8017,

    -- Añadidos en la revisión de profundidad
    FireNova = 1535,         AstralShift = 51479,
  },
  multidot = { [0] = { "FlameShock" }, [1] = { "FlameShock" }, [2] = { "FlameShock" } },
  evaluate = evaluate,
  filler = filler,
})
