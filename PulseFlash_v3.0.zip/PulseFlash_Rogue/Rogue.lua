local CF = PulseFlash

do local c = select(2, UnitClass("player")); if c and c ~= "ROGUE" then return end end
local Aura, Known, Dot, First = CF.Aura, CF.Known, CF.Dot, CF.First

-- Nombre del tipo de arma "Dagas" por idioma (para saber si hay dagas equipadas)
local DAGGER = {
  enUS = "Daggers", enGB = "Daggers", esES = "Dagas", esMX = "Dagas",
  frFR = "Dagues", deDE = "Dolche", ptBR = "Adagas", ruRU = "Кинжалы",
  zhCN = "匕首", zhTW = "匕首", koKR = "단검",
}

local mhDagger, ohDagger = false, false
local lastPoisonMsg = 0
local ctcTalent = false

-- Umbrales de la rotación
local SND_MIN_LIFE = 6          -- no mantener Cuchillada si el objetivo muere antes
local RUPTURE_MIN_LIFE = 10     -- no poner Ruptura si el objetivo muere antes
local EXECUTE_HP = 0.15         -- remate anticipado con pocos puntos de combo

local function CheckWeapons()
  local wanted = DAGGER[GetLocale()]
  local function isDagger(slot)
    local link = GetInventoryItemLink("player", slot)
    if not link then return false end
    if not wanted then return true end
    return select(7, GetItemInfo(link)) == wanted
  end
  mhDagger, ohDagger = isDagger(16), isDagger(17)
end

local function RefreshTalents()
  ctcTalent = CF.HasTalent(CF.N.CutToTheChase)
end

local WeaponEnchants = CF.WeaponEnchants

-- Aviso de venenos ausentes / a punto de acabarse (solo fuera de combate)
local function PoisonCheck(c)
  if not CF.db.poison or c.level < 20 or c.combat or UnitIsDeadOrGhost("player") then return end
  if GetTime() - lastPoisonMsg < 90 then return end
  local hasMH, mhExp, _, _, hasOH, ohExp = WeaponEnchants()
  local needMH = (not hasMH) or (mhExp and mhExp < 120000)
  local needOH = OffhandHasWeapon() and ((not hasOH) or (ohExp and ohExp < 120000))
  if needMH or needOH then
    lastPoisonMsg = GetTime()
    CF.Msg(CF.T("poisonsMissing"))
  end
end

local function InStealth(N)
  return Aura("player", N.Stealth) or Aura("player", N.Vanish) or Aura("player", N.ShadowDance)
end

-- Shadowstep: te coloca detrás del objetivo; solo tiene sentido si usas dagas,
-- el juego te ha avisado de que no estás detrás y el objetivo no te está mirando.
local function Step(c, add, N)
  if c.hostile and mhDagger and not c.behind and not CF.TargetsMe()
     and Known(N.Shadowstep) and IsSpellInRange(N.Shadowstep, "target") == 1 then
    add(N.Shadowstep, 1)
  end
end

local function evaluate(c, add, N)
  local cp, energy, lvl, spec = c.cp, c.energy, c.level, c.spec
  local behind = mhDagger and c.behind

  local maxMode = CF.db and CF.db.rot and CF.db.rot.max
  local ar = Aura("player", N.AdrenalineRush)
  local regen = ar and 20 or 10
  local dance = Aura("player", N.ShadowDance)

  -- ------------------------------------------------------------------
  -- 1) Sigilo / Danza de sombras: aperturas
  -- ------------------------------------------------------------------
  if InStealth(N) and not dance then
    if spec == 3 and cp == 0 then add(N.Premeditation, 2) end
    Step(c, add, N)
    -- Asesinato con Sed de sangre: Garrote primero para tener sangrado activo
    if spec == 1 and behind and Known(N.HungerForBlood) then add(N.Garrote, 1) end
    if behind then add(N.Ambush, 1) end
    if spec == 1 and mhDagger and ohDagger then add(N.Mutilate, 1) end
    if c.behind then add(N.Garrote, 1) end
    if not c.boss then add(N.CheapShot, 1) end
    add(N.SinisterStrike, 1)
    return
  end

  -- ------------------------------------------------------------------
  -- 2) Estado del combate
  -- ------------------------------------------------------------------
  local sndLeft = Aura("player", N.SliceAndDice)
  local ruptLeft = Aura("target", N.Rupture, true, true)
  local bleed = ruptLeft or Aura("target", N.Garrote, true, true)
  local hfbLeft = Aura("player", N.HungerForBlood)
  local hemoLeft = Aura("target", N.Hemorrhage, true)
  local dpUp = Aura("target", N.DeadlyPoison, true, true, true)

  -- Puntos de combo a partir de los cuales se remata según el nivel
  local finishCP = (lvl >= 60 and 5) or (lvl >= 30 and 4) or 3
  if spec == 1 and finishCP > 4 then finishCP = 4 end
  local finish = cp >= finishCP or (cp >= 2 and c.hp < EXECUTE_HP and not c.boss)
  local envenom = (spec == 1 and dpUp and Known(N.Envenom)) and N.Envenom or nil
  -- Envenenar: con el beneficio aún activo se construye en vez de renovarlo,
  -- salvo que la energía esté cerca del tope o los puntos de combo desbordarían.
  local envLeft = envenom and Aura("player", N.Envenom) or nil
  local holdEnv = envLeft and envLeft > 1.5 and energy < 85 and cp < 5

  -- ------------------------------------------------------------------
  -- 3) Mantenimiento: Cuchillada, Sed de sangre, Ruptura
  -- ------------------------------------------------------------------
  -- Con "Cut to the Chase" Envenenar ya refresca Cuchillada: no hace falta separarla.
  if cp >= 1 and (sndLeft or CF.Lives(SND_MIN_LIFE))
     and not (ctcTalent and envenom and finish and sndLeft) then
    Dot(add, c, N.SliceAndDice, sndLeft, 6)
  end
  if bleed then Dot(add, c, N.HungerForBlood, hfbLeft, 8) end
  if c.worth and finish and (ruptLeft or CF.Lives(RUPTURE_MIN_LIFE)) then
    if spec == 1 then
      -- Asesinato: Ruptura solo como fuente de sangrado para Sed de sangre
      if Known(N.HungerForBlood) and not bleed then add(N.Rupture, 1) end
    else
      Dot(add, c, N.Rupture, ruptLeft)
    end
  end

  -- ------------------------------------------------------------------
  -- 4) Modo "máximo daño": acumular energía antes de renovar un efecto
  -- ------------------------------------------------------------------
  local pooled = false
  if maxMode and not dance then
    local gen = (spec == 1 and mhDagger and ohDagger and Known(N.Mutilate) and N.Mutilate)
                or (behind and Known(N.Backstab) and N.Backstab) or N.SinisterStrike
    local spendCost = CF.Cost(finish and (envenom or N.Eviscerate) or gen)
    local function Pool(spell, left, needCP)
      if pooled or not spell or not left or cp < needCP or not Known(spell) then return end
      local t = left - 2.0
      if t <= 0 or t > CF.POOL_MAX_T then return end
      if not CF.CanSpend(spendCost, CF.Cost(spell), t, regen) then
        pooled = add(spell, 1, t)
      end
    end
    Pool(N.SliceAndDice, sndLeft, 1)
    if c.worth and spec ~= 1 then Pool(N.Rupture, ruptLeft, finishCP) end
  end

  -- ------------------------------------------------------------------
  -- 5) Remates
  -- ------------------------------------------------------------------
  if finish and not holdEnv then
    if envenom then add(envenom, 1, maxMode and CF.HoldEta(envenom, regen) or nil) end
    add(N.Eviscerate, 1, maxMode and not envenom and CF.HoldEta(N.Eviscerate, regen) or nil)
  end

  -- ------------------------------------------------------------------
  -- 6) Generadores
  -- ------------------------------------------------------------------
  local capped = cp >= 5 and Known(N.Eviscerate) and not holdEnv
  if not capped then
    Step(c, add, N)

    if dance then
      if behind then add(N.Ambush, 1) end
      if not bleed then add(N.Garrote, 1) end
    end
    -- Abanico de cuchillas con 3 o más enemigos (gasta energía de sobra)
    if CF.AoE(3) then add(N.FanOfKnives, 1) end

    -- Subtlety: mantener Hemorragia (debuff de daño) antes de los generadores
    if spec == 3 and ((not hemoLeft or hemoLeft < 3) or not behind) then add(N.Hemorrhage, 1) end

    local held = false
    local function build(spell, preferred)
      local hold = (maxMode and preferred and not held) and CF.HoldEta(spell, regen) or nil
      if add(spell, 1, hold) and hold then held = true end
    end
    if spec == 1 and mhDagger and ohDagger then build(N.Mutilate, true) end
    if behind then build(N.Backstab, spec == 3) end
    add(N.SinisterStrike, 1)
    add(N.Hemorrhage, 1)
  end

  -- ------------------------------------------------------------------
  -- 7) Cooldowns (prioridad 2) y utilidad (prioridad 3)
  -- ------------------------------------------------------------------
  if c.combat then
    local bf = Aura("player", N.BladeFlurry)

    if finish and c.bigCD then add(N.ColdBlood, 2) end
    -- Torbellino de cuchillas: con 2+ enemigos, o en jefes (Combate) con cooldowns
    if not bf and (CF.AoE(2) or (spec == 2 and c.bigCD)) then add(N.BladeFlurry, 2) end

    -- Matanza solo con poca energía, Cuchillada activa y sin Descarga de adrenalina
    local bfDone = (not Known(N.BladeFlurry)) or bf or CF.CD(N.BladeFlurry) > 0
    if c.bigCD and energy < 40 and sndLeft and sndLeft >= 3 and not ar and bfDone
       and CF.CDok(c, 120) then
      add(N.KillingSpree, 2)
    end
    if c.bigCD and ((not Known(N.KillingSpree)) or CF.CD(N.KillingSpree) > 0) and CF.CDok(c, 180) then
      add(N.AdrenalineRush, 2)
    end
    if c.bigCD and spec == 3 and energy >= 60 and not dance then add(N.ShadowDance, 2) end

    -- Preparación: solo cuando las dos grandes herramientas de Sutileza están en cooldown
    if c.bigCD and spec == 3 and Known(N.Preparation) and CF.CDok(c, 480)
       and CF.CD(N.Vanish) > 0 and (not Known(N.Shadowstep) or CF.CD(N.Shadowstep) > 0) then
      add(N.Preparation, 2)
    end
  end

  if CF.EnemyCasting() and IsSpellInRange(N.Kick, "target") == 1 then
    add(N.Kick, 3)
  end
  if c.combat then
    -- Amenaza: Finta cuando el jefe te tiene como objetivo en grupo
    if c.boss and CF.Grouped() and CF.TargetsMe() then add(N.Feint, 3) end
    if c.php < 0.50 then add(N.Evasion, 3) end
    if c.php < 0.35 then add(N.CloakOfShadows, 3) end
    if c.php < 0.20 then add(N.Vanish, 3) end
  end
end

local function filler(c, N)
  if InStealth(N) then
    if c.behind then
      if mhDagger and Known(N.Ambush) then return N.Ambush end
      if Known(N.Garrote) then return N.Garrote end
    end
    return First((not c.boss) and N.CheapShot or nil, N.SinisterStrike)
  end
  if c.cp >= 5 and Known(N.Eviscerate) then
    if c.spec == 1 and Known(N.Envenom) and Aura("target", N.DeadlyPoison, true, true, true) then
      return N.Envenom
    end
    return N.Eviscerate
  end
  return First(N.SinisterStrike)
end

-- ---------------------------------------------------------------------------
-- Efectos para la proyección de la cola (ver Project.lua)
-- ---------------------------------------------------------------------------
local function VStealth(V, N)
  return V:Aura("player", N.Stealth) or V:Aura("player", N.Vanish) or V:Aura("player", N.ShadowDance)
end
local function EndStealth(V, N)
  if not V:Aura("player", N.ShadowDance) then
    V:Remove("player", false, N.Stealth); V:Remove("player", false, N.Vanish)
  end
end
local function SndDur(cp)
  local r = CF.TalentRank(CF.N.ImprovedSliceAndDice or "")
  return (6 + 3 * cp) * (1 + 0.15 * r)
end

local SIM = {
  SinisterStrike = { cp = 1 },
  Backstab = { cp = 1 },
  Mutilate = { cp = 2 },
  Hemorrhage = { cp = 1, debuff = { "Hemorrhage", dur = 15 } },
  Ambush = { cp = 2, use = VStealth, fn = EndStealth },
  Garrote = { cp = 1, use = VStealth, debuff = { "Garrote", dur = 18 }, fn = EndStealth },
  CheapShot = { cp = 2, use = VStealth, fn = EndStealth },
  FanOfKnives = {},
  Eviscerate = { fin = true },
  Envenom = { fin = true, buff = { "Envenom", dur = function(cp) return cp end } },
  SliceAndDice = { fin = true, buff = { "SliceAndDice", dur = SndDur } },
  Rupture = { fin = true, debuff = { "Rupture", dur = function(cp) return 6 + 2 * cp end } },
  HungerForBlood = { buff = { "HungerForBlood", dur = 60 } },
  ColdBlood = { gcd = 0, cd = 180, buff = { "ColdBlood" } },
  AdrenalineRush = { gcd = 0, cd = 180, buff = { "AdrenalineRush", dur = 15 } },
  BladeFlurry = { gcd = 0, cd = 120, buff = { "BladeFlurry", dur = 15 } },
  KillingSpree = { cd = 120, cast = 2 },
  ShadowDance = { gcd = 0, cd = 60, buff = { "ShadowDance", dur = 6 } },
  Premeditation = { gcd = 0, cd = 20, cp = 2, use = VStealth },
  Vanish = { cd = 180, buff = { "Stealth", dur = 20 } },
  Shadowstep = { gcd = 0, cd = 30 },
  Preparation = { gcd = 0, cd = 480, fn = function(V, N)
    V:SetCD(N.Vanish, 0); V:SetCD(N.Shadowstep, 0); V:SetCD(N.ColdBlood, 0)
  end },
  Kick = { gcd = 0, cd = 10 },
  Feint = {}, Evasion = {}, CloakOfShadows = {},
}

CF.Register("ROGUE", {
  sim = SIM,
  gcd = function() return 1.0 end,
  regen = function(V) return V:Aura("player", CF.N.AdrenalineRush) and 20 or 10 end,
  ids = {
    SinisterStrike = 1752,  Backstab = 53,        Eviscerate = 2098,
    SliceAndDice = 5171,    Rupture = 1943,       Mutilate = 1329,
    Envenom = 32645,        Hemorrhage = 16511,   HungerForBlood = 51662,
    Garrote = 703,          Ambush = 8676,        CheapShot = 1833,
    ColdBlood = 14177,      BladeFlurry = 13877,  AdrenalineRush = 13750,
    KillingSpree = 51690,   ShadowDance = 51713,  Premeditation = 14183,
    Kick = 1766,            Vanish = 1856,        Stealth = 1784,
    DeadlyPoison = 2823,    FanOfKnives = 51723,  Evasion = 5277,
    CloakOfShadows = 31224, CutToTheChase = 51669,

    -- Añadidos en la revisión de profundidad
    Shadowstep = 36554,     Preparation = 14185,  Feint = 48659,
    ImprovedSliceAndDice = 14165,
  },

  positional = { "Backstab", "Ambush", "Garrote" },
  init = function() CheckWeapons(); RefreshTalents() end,
  onEquipment = function() CheckWeapons(); RefreshTalents() end,
  slow = function(c) CheckWeapons(); RefreshTalents(); PoisonCheck(c) end,
  evaluate = evaluate,
  filler = filler,
})
