local PF = PulseFlash

local panel = CreateFrame("Frame", "PulseFlashOptionsPanel", UIParent)
panel.name = "PulseFlash"

local relabels = {}

local function Label(font, x, y, w)
  local fs = panel:CreateFontString(nil, "ARTWORK", font)
  fs:SetPoint("TOPLEFT", panel, "TOPLEFT", x, y)
  if w then fs:SetWidth(w) end
  fs:SetJustifyH("LEFT")
  return fs
end

local title = Label("GameFontNormalLarge", 16, -16)
title:SetText("PulseFlash")

local by = Label("GameFontHighlightSmall", 16, -42, 560)
relabels[#relabels + 1] = function()
  local author = GetAddOnMetadata and GetAddOnMetadata("PulseFlash", "Author") or "?"
  local ver = GetAddOnMetadata and GetAddOnMetadata("PulseFlash", "Version") or "?"
  by:SetText(PF.T("o_by", author, ver))
end

local desc = Label("GameFontHighlight", 16, -62, 560)
desc:SetHeight(48)
desc:SetJustifyV("TOP")
relabels[#relabels + 1] = function() desc:SetText(PF.T("o_desc")) end

local hint = Label("GameFontHighlightSmall", 16, -118, 560)
hint:SetHeight(32)
hint:SetJustifyV("TOP")
relabels[#relabels + 1] = function() hint:SetText(PF.T("o_hint")) end

local open = CreateFrame("Button", "PulseFlashOptOpen", panel, "UIPanelButtonTemplate")
open:SetPoint("TOPLEFT", panel, "TOPLEFT", 16, -160)
open:SetWidth(190); open:SetHeight(26)
relabels[#relabels + 1] = function() open:SetText(PF.T("o_open")) end

-- Enlace de CurseForge (seleccionable para copiar con Ctrl+C)
local curLabel = Label("GameFontNormalSmall", 16, -200)
curLabel:SetText("CurseForge:")
local curEdit = CreateFrame("EditBox", "PulseFlashOptCurse", panel, "InputBoxTemplate")
curEdit:SetPoint("TOPLEFT", panel, "TOPLEFT", 22, -216)
curEdit:SetWidth(400); curEdit:SetHeight(20)
curEdit:SetAutoFocus(false)
local CURSE_URL = "https://www.curseforge.com/wow/addons/pulseflash"
curEdit:SetText(CURSE_URL)
curEdit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
curEdit:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
curEdit:SetScript("OnTextChanged", function(self) if self:GetText() ~= CURSE_URL then self:SetText(CURSE_URL) end end)

-- Abre el panel completo ENCIMA de la ventana de Interfaz. No se ocultan marcos de
-- Blizzard desde el addon (HideUIPanel desde código de addon provoca "taint" y
-- bloqueos de acciones); el panel usa estrato FULLSCREEN_DIALOG para quedar delante.
local function OpenSettings()
  local ok, err = pcall(function()
    if PF.OpenConfig then PF.OpenConfig() end
  end)
  if not ok then PF.Msg("|cffff4040Error:|r " .. tostring(err)) end
end
open:SetScript("OnClick", OpenSettings)

local function Refresh()
  for i = 1, #relabels do relabels[i]() end
end

panel.refresh = Refresh
panel.okay = function() end
panel.cancel = function() end
panel.default = function() end
-- Seleccionar "PulseFlash" en Interfaz > AddOns solo muestra este panel pequeño;
-- la configuracion completa se abre unicamente con el boton de arriba.
panel:SetScript("OnShow", function() Refresh() end)
panel:Hide()

if PF.OnLangChange then PF.OnLangChange(function() if panel:IsShown() then Refresh() end end) end

InterfaceOptions_AddCategory(panel)
