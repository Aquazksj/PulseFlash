local PF = PulseFlash

local btn
local ICON = "Interface\\AddOns\\PulseFlash\\Media\\icon"

local function UpdatePosition()
  local angle = math.rad(PF.db.minimap.angle or 215)
  local radius = (Minimap:GetWidth() / 2) + 5
  btn:ClearAllPoints()
  btn:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function OnDragUpdate()
  local mx, my = Minimap:GetCenter()
  local cx, cy = GetCursorPosition()
  local scale = Minimap:GetEffectiveScale()
  cx, cy = cx / scale, cy / scale
  PF.db.minimap.angle = math.deg(math.atan2(cy - my, cx - mx)) % 360
  UpdatePosition()
end

local function ShowTooltip(self)
  GameTooltip:SetOwner(self, "ANCHOR_LEFT")
  GameTooltip:AddLine("|cff40d9ffPulseFlash|r")
  GameTooltip:AddLine(PF.T("mm_left"), 0.8, 0.8, 0.8)
  local H = PF.db and PF.db.hud
  GameTooltip:AddLine((H and not H.locked) and PF.T("mm_right_lock") or PF.T("mm_right_unlock"), 0.8, 0.8, 0.8)
  GameTooltip:AddLine(PF.T("mm_shift") .. (PF.hudTest and PF.T("mm_active") or ""), 0.8, 0.8, 0.8)
  GameTooltip:AddLine(PF.T("mm_drag"), 0.8, 0.8, 0.8)
  GameTooltip:Show()
end

function PF.Minimap_Init()
  if btn then return end
  if type(PF.db.minimap) ~= "table" then PF.db.minimap = {} end
  if type(PF.db.minimap.angle) ~= "number" then PF.db.minimap.angle = 215 end

  btn = CreateFrame("Button", "PulseFlashMinimapButton", Minimap)
  btn:SetFrameStrata("MEDIUM")
  btn:SetFrameLevel(8)
  btn:SetWidth(31); btn:SetHeight(31)
  btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  btn:RegisterForDrag("LeftButton")
  btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

  local bg = btn:CreateTexture(nil, "BACKGROUND")
  bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
  bg:SetWidth(20); bg:SetHeight(20)
  bg:SetPoint("TOPLEFT", btn, "TOPLEFT", 7, -5)
  bg:SetVertexColor(0.06, 0.06, 0.08, 1)

  btn.icon = btn:CreateTexture(nil, "ARTWORK")
  btn.icon:SetTexture(ICON)
  btn.icon:SetWidth(17); btn.icon:SetHeight(17)
  btn.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  btn.icon:SetPoint("TOPLEFT", btn, "TOPLEFT", 7, -6)

  local ring = btn:CreateTexture(nil, "OVERLAY")
  ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  ring:SetWidth(53); ring:SetHeight(53)
  ring:SetPoint("TOPLEFT", btn, "TOPLEFT", 0, 0)
  ring:SetVertexColor(0.30, 0.30, 0.34)

  btn:SetScript("OnMouseDown", function(self) self.icon:SetPoint("TOPLEFT", self, "TOPLEFT", 8, -7) end)
  btn:SetScript("OnMouseUp", function(self) self.icon:SetPoint("TOPLEFT", self, "TOPLEFT", 7, -6) end)

  btn:SetScript("OnClick", function(_, button)
    if button == "LeftButton" then
      if IsShiftKeyDown() then PF.ToggleHUDTest() else PF.ToggleConfig() end
    elseif button == "RightButton" then
      PF.ToggleHUDLock()
    end
    if GameTooltip:IsOwned(btn) then ShowTooltip(btn) end
  end)

  btn:SetScript("OnDragStart", function(self)
    GameTooltip:Hide()
    self:SetScript("OnUpdate", OnDragUpdate)
  end)
  btn:SetScript("OnDragStop", function(self)
    self:SetScript("OnUpdate", nil)
  end)

  btn:SetScript("OnEnter", ShowTooltip)
  btn:SetScript("OnLeave", function() GameTooltip:Hide() end)

  UpdatePosition()
end
