local PF = PulseFlash

local SLOTS = { 13, 14 }
local cache = {}

local DPS_WORDS = {
  "attack power", "spell power", "haste", "critical", "crit", "strength", "agility", "intellect",
  "damage", "poder de ataque", "poder con hechizos", "poder de hechizo", "celeridad", "crítico",
  "critico", "fuerza", "agilidad", "intelecto", "daño", "dano",
}

local SKIP_WORDS = {
  "stun", "fear", "root", "snare", "polymorph", "sleep", "charm", "incapacit", "movement impairing",
  "immun", "remove", "dispel", "heal", "health", "armor", "block", "dodge", "parry", "resist",
  "absorb", "aturd", "miedo", "inmoviliz", "ralentiz", "polimorf", "incapacit", "inmun", "elimina",
  "disipa", "cura", "salud", "armadura", "bloqu", "esquiv", "parada", "resisten", "absorbe",
}

local tip

local function UseText(slot)
  if not tip then
    tip = CreateFrame("GameTooltip", "PulseFlashTrinketScan", nil, "GameTooltipTemplate")
    tip:SetOwner(UIParent, "ANCHOR_NONE")
  end
  tip:ClearLines()
  tip:SetInventoryItem("player", slot)
  local trigger = (ITEM_SPELL_TRIGGER_ONUSE or "Use:"):lower()
  local text
  for i = 2, tip:NumLines() do
    local fs = _G["PulseFlashTrinketScanTextLeft" .. i]
    local line = fs and fs:GetText()
    if line and line:lower():find(trigger, 1, true) == 1 then
      text = (text and (text .. " ") or "") .. line:lower()
    end
  end
  return text
end

local function HasAny(text, words)
  for i = 1, #words do
    if text:find(words[i], 1, true) then return true end
  end
  return false
end

local function IsDamageTrinket(id, slot)
  if cache[id] ~= nil then return cache[id] end
  local text = UseText(slot)
  if text == nil then

    if tip and tip:NumLines() > 1 then cache[id] = false end
    return false
  end
  cache[id] = HasAny(text, DPS_WORDS) and not HasAny(text, SKIP_WORDS)
  return cache[id]
end

function PF.AddTrinkets(add)
  for _, slot in ipairs(SLOTS) do
    local id = GetInventoryItemID("player", slot)
    if id and IsDamageTrinket(id, slot) then add(PF.Item(id), 2) end
  end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
f:SetScript("OnEvent", function() wipe(cache) end)
