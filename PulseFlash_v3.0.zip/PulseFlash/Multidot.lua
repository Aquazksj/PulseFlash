local PF = PulseFlash

do
  local c = select(2, UnitClass("player"))
  if c == "DEATHKNIGHT" or c == "PALADIN" or c == "ROGUE" then
    function PF.Multidot_Supported() return false end
    function PF.Multidot_Toggle() PF.Msg(PF.T("md_only")) end
    return
  end
end

local ACTIVE_WINDOW = 8
local MIN_HP_WORTH = 0.20
local SHOW_DELAY = 0.3
local HOLD = 0.8
local MAX_TRACKED = 40
local HP_SCAN = 0.5
local HP_FRESH = 2.0
local MIN_DEFAULT = 3

local band = bit.band
local HOSTILE = COMBATLOG_OBJECT_REACTION_HOSTILE or 0x40
local NPC = COMBATLOG_OBJECT_TYPE_NPC or 0x800
local GROUP = (COMBATLOG_OBJECT_AFFILIATION_MINE or 0x1) + (COMBATLOG_OBJECT_AFFILIATION_PARTY or 0x2)
              + (COMBATLOG_OBJECT_AFFILIATION_RAID or 0x4)

local module, class
local enemies, dots, immune, hpCache = {}, {}, {}, {}
local trackedSet = {}
local nEnemies = 0
local playerGUID
local frame
local trueSince, lastTrue, shown, lastText = nil, nil, false, nil
local scanAt = 0
local tokens

local function Hostile(flags) return flags and band(flags, HOSTILE) ~= 0 and band(flags, NPC) ~= 0 end
local function InGroup(flags) return flags and band(flags, GROUP) ~= 0 end

local function Reset()
  wipe(enemies); wipe(dots); wipe(immune); wipe(hpCache)
  nEnemies = 0
  trueSince, lastTrue, shown, lastText = nil, nil, false, nil
  PF.multiInfo = nil
end

local function Forget(guid)
  if enemies[guid] then enemies[guid] = nil; nEnemies = nEnemies - 1 end
  dots[guid] = nil
  hpCache[guid] = nil
end

local function Seen(guid, name, now)
  local e = enemies[guid]
  if e then
    e.last = now
    return
  end
  if nEnemies >= MAX_TRACKED then
    local oldG, oldT
    for g, x in pairs(enemies) do
      if not oldT or x.last < oldT then oldG, oldT = g, x.last end
    end
    if oldG then Forget(oldG) end
  end
  enemies[guid] = { name = name or "?", first = now, last = now }
  nEnemies = nEnemies + 1
end

local PULL_SUB = {
  SWING_DAMAGE = true, RANGE_DAMAGE = true, SPELL_DAMAGE = true, SPELL_PERIODIC_DAMAGE = true,
  SPELL_BUILDING_DAMAGE = true, ENVIRONMENTAL_DAMAGE = true,
  SWING_MISSED = true, RANGE_MISSED = true, SPELL_MISSED = true, SPELL_PERIODIC_MISSED = true,
  SPELL_BUILDING_MISSED = true, DAMAGE_SHIELD_MISSED = true,
}

local function OnLog(timestamp, sub, sGUID, sName, sFlags, dGUID, dName, dFlags, spellId, spellName, school, missType)
  if not sub then return end
  if sub == "UNIT_DIED" or sub == "PARTY_KILL" or sub == "UNIT_DESTROYED" then
    if dGUID then Forget(dGUID) end
    return
  end
  local pull = PULL_SUB[sub]
  local mine = (sGUID == playerGUID and dGUID and spellName and trackedSet[spellName]) and true or false
  if not pull and not mine then return end
  local now = GetTime()

  if pull then
    if InGroup(sFlags) and Hostile(dFlags) then Seen(dGUID, dName, now)
    elseif Hostile(sFlags) and InGroup(dFlags) then Seen(sGUID, sName, now) end
  end

  if mine and Hostile(dFlags) then
    if sub == "SPELL_AURA_APPLIED" or sub == "SPELL_AURA_REFRESH" or sub == "SPELL_PERIODIC_DAMAGE" then
      Seen(dGUID, dName, now)
      local d = dots[dGUID]
      if not d then d = {}; dots[dGUID] = d end
      d[spellName] = now
    elseif sub == "SPELL_AURA_REMOVED" then
      local d = dots[dGUID]
      if d then d[spellName] = nil end
    elseif sub == "SPELL_MISSED" and missType == "IMMUNE" then
      immune[dGUID .. spellName] = true
    end
  end
end

local function Apply()
  if not frame then return end
  local DB = PF.db
  local on = module and module.multidot and DB and DB.multidot ~= false
  if on then
    frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
    frame:RegisterEvent("PLAYER_REGEN_DISABLED")
    frame:RegisterEvent("PLAYER_REGEN_ENABLED")
  else
    frame:UnregisterAllEvents()
    Reset()
  end
end

function PF.Multidot_Supported() return (module and module.multidot) and true or false end

function PF.Multidot_Set(v)
  if not PF.db then return end
  PF.db.multidot = v and true or false
  Apply()
end

function PF.Multidot_Toggle()
  if not PF.Multidot_Supported() then
    PF.Msg(PF.T("md_only"))
    return
  end
  PF.Multidot_Set(not (PF.db.multidot ~= false))
  PF.Msg(PF.T("t_multidot") .. ": " .. (PF.db.multidot and PF.T("ON_M") or PF.T("OFF_M")))
end

function PF.Multidot_Init(cls)
  class = cls
  module = PF.modules and PF.modules[cls]
  if not module or not module.multidot then return end
  if PF.db.multidot == nil then PF.db.multidot = true end
  if tonumber(PF.db.multidotMin) == nil then PF.db.multidotMin = MIN_DEFAULT end
  playerGUID = UnitGUID("player")
  wipe(trackedSet)
  for spec, list in pairs(module.multidot) do
    if type(spec) == "number" and type(list) == "table" then
      for _, key in ipairs(list) do
        local n = PF.N[key]
        if n then trackedSet[n] = true end
      end
    end
  end
  frame = CreateFrame("Frame")
  frame:SetScript("OnEvent", function(_, event, ...)
    if event == "COMBAT_LOG_EVENT_UNFILTERED" then
      OnLog(...)
    else
      Reset()
      playerGUID = UnitGUID("player") or playerGUID
    end
  end)
  Apply()
end

local specCache, specCacheAt = {}, {}
local function SpecList(c)
  local spec = c.spec
  local keys = module.multidot[spec]
  if not keys then return nil end
  local now = GetTime()
  local at = specCacheAt[spec]
  if at and now - at < 1.0 then return specCache[spec] or nil end
  local out
  for _, key in ipairs(keys) do
    local n = PF.N[key]
    if n and PF.Known(n) and not (module.multidotSkip and module.multidotSkip(key)) then
      out = out or {}
      out[#out + 1] = n
    end
  end
  specCache[spec], specCacheAt[spec] = out or false, now
  return out
end

local function BuildTokens()
  tokens = { "target", "focus", "mouseover", "pettarget", "targettarget" }
  for i = 1, 4 do tokens[#tokens + 1] = "party" .. i .. "target" end
  for i = 1, 40 do tokens[#tokens + 1] = "raid" .. i .. "target" end
end

local function ScanHealth(now)
  if now - scanAt < HP_SCAN then return end
  scanAt = now
  if not tokens then BuildTokens() end
  for _, u in ipairs(tokens) do
    local g = UnitExists(u) and UnitGUID(u)
    if g and enemies[g] then
      if UnitIsDead(u) then
        Forget(g)
      else
        local m = UnitHealthMax(u)
        if m and m > 0 then
          local h = hpCache[g]
          if h then h.pct, h.t = UnitHealth(u) / m, now
          else hpCache[g] = { pct = UnitHealth(u) / m, t = now } end
        end
      end
    end
  end
end

function PF.Multidot_Eval(c)
  local DB = PF.db
  if not module or not module.multidot or not DB or DB.multidot == false then return nil end
  if not c.combat or not c.hostile or c.boss then
    trueSince, lastTrue, shown = nil, nil, false
    return nil
  end
  local list = SpecList(c)
  if not list then return nil end
  local now = GetTime()
  local tg = UnitGUID("target")

  local covered = true
  if tg then
    local d = dots[tg]
    for _, name in ipairs(list) do
      if PF.HasDebuff(name) then
        if not d then d = {}; dots[tg] = d end
        d[name] = now
      elseif d and d[name] then
        d[name] = nil
      end
      if c.worth and not (d and d[name]) and not PF.Pending(name) and not PF.IsCasting(name)
         and c.casting ~= name and not immune[tg .. name] then
        covered = false
      end
    end
  end
  if not covered then
    trueSince, shown = nil, false
    return nil
  end

  for g, e in pairs(enemies) do
    if now - e.last > ACTIVE_WINDOW then Forget(g) end
  end
  local total = nEnemies + ((tg and not enemies[tg]) and 1 or 0)
  local minE = tonumber(DB.multidotMin) or MIN_DEFAULT
  local text
  if total >= minE then
    ScanHealth(now)
    local best, bestName, missing = nil, nil, 0
    for g, e in pairs(enemies) do
      if g ~= tg then
        local h = hpCache[g]
        local nearDead = h and (now - h.t) < HP_FRESH and h.pct < MIN_HP_WORTH
        if not nearDead then
          local d = dots[g]
          for _, name in ipairs(list) do
            if not (d and d[name]) and not immune[g .. name] then
              missing = missing + 1
              if not best or e.first < best.first then best, bestName = e, name end
              break
            end
          end
        end
      end
    end
    if missing > 0 and best then
      text = PF.T("md_msg", missing, best.name, bestName)
    end
  end

  if text then
    if not trueSince then trueSince = now end
    lastTrue, lastText = now, text
    if now - trueSince >= SHOW_DELAY then shown = true end
  else
    trueSince = nil
    if shown and lastTrue and (now - lastTrue) >= HOLD then shown = false end
  end
  return shown and (text or lastText) or nil
end
