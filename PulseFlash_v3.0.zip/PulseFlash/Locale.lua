PulseFlash = PulseFlash or {}
local PF = PulseFlash

PF.LANGS = { "en", "es", "ru", "pt", "de", "fr" }
PF.LANG_NAMES = { en = "English", es = "Español", ru = "Русский", pt = "Português", de = "Deutsch", fr = "Français" }
PF.LANG_SET = {}
for _, code in ipairs(PF.LANGS) do PF.LANG_SET[code] = true end

local CLIENT_LANG = { esES = "es", esMX = "es", ruRU = "ru", ptBR = "pt", ptPT = "pt", deDE = "de", frFR = "fr" }
PF.DEFAULT_LANG = CLIENT_LANG[GetLocale and GetLocale() or ""] or "en"

PF.LANG_FONT = { ru = "Fonts\\ARIALN.TTF" }
PF.langCallbacks = {}

local S = { es = {}, en = {}, ru = {}, pt = {}, de = {}, fr = {} }
PF.STRINGS = S
local ES, EN = S.es, S.en

function PF.GetLang()
  local db = PulseFlashDB
  local l = db and db.lang
  if not PF.LANG_SET[l] then l = PF.DEFAULT_LANG end
  return l
end

function PF.T(key, ...)
  local s = S[PF.GetLang()][key] or EN[key] or ES[key] or key
  if select("#", ...) > 0 then return format(s, ...) end
  return s
end

function PF.LT(t)
  if type(t) ~= "table" then return t end
  return t[PF.GetLang()] or t.en or t.es
end

local fontRegs = setmetatable({}, { __mode = "k" })

function PF.LangFont(default)
  return PF.LANG_FONT[PF.GetLang()] or default
end

function PF.SetLFont(fs, path, size, flags, fixed)
  fontRegs[fs] = { path, size, flags, fixed }
  fs:SetFont(fixed and path or PF.LangFont(path), size, flags or "")
end

function PF.ApplyFonts()
  for fs, r in pairs(fontRegs) do
    fs:SetFont(r[4] and r[1] or PF.LangFont(r[1]), r[2], r[3] or "")
  end
end

-- Los idiomas es/ru/pt/de/fr viven en addons de carga bajo demanda
-- (PulseFlash_es, _ru, _pt, _de, _fr): solo se cargan si ese idioma esta en uso.
PF.packs = {}
local PACK = { es = true, ru = true, pt = true, de = true, fr = true }
function PF.LoadLangPack(l)
  if PACK[l] and not PF.packs[l] and LoadAddOn then LoadAddOn("PulseFlash_" .. l) end
end

function PF.SetLang(l)
  if not PF.LANG_SET[l] then return false end
  PF.LoadLangPack(l)
  if PulseFlashDB then PulseFlashDB.lang = l end
  PF.ApplyFonts()
  for _, fn in ipairs(PF.langCallbacks) do pcall(fn) end
  return true
end

function PF.OnLangChange(fn)
  PF.langCallbacks[#PF.langCallbacks + 1] = fn
end

EN.ON_M   = "|cff00ff00enabled|r"
EN.OFF_M  = "|cffff4040disabled|r"
EN.ON_F   = "|cff00ff00enabled|r"
EN.OFF_F  = "|cffff4040disabled|r"
EN.aoe_is = "AoE: %s"
EN.aoe_on = "Auto AoE: %d enemies"
EN.aoe_off = "AoE off (few enemies left)"
EN.t_timers = "Effect timers"
EN.t_precision = "Extra precision"
EN.on     = "on"
EN.off    = "off"
EN.noModule      = "there is no module for your class."
EN.enabled       = "enabled"
EN.disabled      = "disabled"
EN.profileNotLoaded = "your profile is not loaded yet."
EN.modeOnly      = "max damage mode only exists for Rogue and Feral Druid."
EN.modeUsage     = "usage: /pf mode normal | max"
EN.modeIs        = "Rotation mode: %s"
EN.MODE_MAX      = "|cffffd100MAX DAMAGE (test)|r"
EN.MODE_NORMAL   = "|cff00ff00NORMAL|r"
EN.comboOnly     = "the combo bar only exists for Rogue and Druid."
EN.t_aoe         = "AoE mode"
EN.t_bearweave   = "Cat + Bear (bearweave)"
EN.t_poison      = "Poison reminder"
EN.t_stone       = "Spellstone (Warlock)"
EN.t_hud         = "Floating HUD"
EN.t_proj        = "Projected queue"
EN.t_alerts      = "Red layer (defensives / interrupts)"
EN.t_pet         = "Pet alerts"
EN.t_totem       = "Totem alert (Shaman)"
EN.t_range       = "Range opacity (0.35 when out of range)"
EN.t_racial      = "Racial alerts (blue defensive / orange offensive)"
EN.cdsBoss       = "Cooldowns over 1 min and trinkets: |cffffd100boss|r targets only"
EN.cdsAlways     = "Cooldowns over 1 min and trinkets: |cffffd100always|r (any target)"
EN.phase_opener = "OPENER"
EN.phase_burn   = "BURN PHASE"
EN.phase_final  = "FINISH"
EN.t_roles = "Heal advisor"
EN.tankOnly = "Tank mode only exists for Death Knight."
EN.tankOn        = "|cffff8000TANK MODE ENABLED|r: diseases (Icy Touch, Plague Strike), Pestilence, Rune Strike and Death Strike to heal."
EN.tankOff       = "|cff00ff00TANK MODE DISABLED|r: normal rotation for your spec."
EN.tankLogin     = "|cffff8000Tank mode ACTIVE|r (Death Knight). Use /pf tank to go back to the normal rotation."
EN.role_healer   = "|cffffd100Healer|r role detected: the HUD recommends heals based on target and group health (/pf roles turns this off)."
EN.upd_version = "installed version: %s"
EN.t_bhud        = "Buff HUD"
EN.noConfig      = "Config.lua was not found."
EN.scaleSet      = "HUD scale: %.2f"
EN.scaleUsage    = "usage: /pf scale %.1f - %.1f  (current: %.2f)"
EN.hudReset      = "HUD: position and scale restored"
EN.iccOnly       = "ICC/Raid mode only exists for Warlock."
EN.iccOn         = "|cffff8000ICC/RAID MODE ENABLED|r: |cffffd100%s|r replaces |cffffd100%s|r in the main priority."
EN.iccUnknown    = "you don't know %s yet: %s is kept in the meantime."
EN.iccOff        = "|cff00ff00STANDARD MODE ENABLED|r: normal rotation with |cffffd100%s|r."
EN.iccLogin      = "|cffff8000ICC/Raid mode ACTIVE|r (Curse of Doom). Use /pf icc to go back to standard mode."
EN.posUsage      = "usage: /pf position screen | chat | both | off"
EN.posLabel_screen = "screen only"
EN.posLabel_chat   = "chat only"
EN.posLabel_both   = "screen + chat"
EN.posLabel_off    = "disabled"
EN.posIs         = "Position alert (abilities that require being behind the target): %s"
EN.posNoClass    = "your class has no positional abilities; the option is saved but will not be used."
EN.posText       = "GET BEHIND THE TARGET!"
EN.posChat       = "(that ability requires you to be behind the target)"
EN.numIs         = "number at: %s"
EN.numCenter = "the center"
EN.numCorner = "the corner"
EN.langIs        = "Language: %s"
EN.langUsage     = "usage: /pf lang es | en | ru | pt | de | fr"
EN.noModuleClass = "no module for your class (%s): the addon stays inactive."
EN.welcome       = "|cffffd100[PulseFlash]|r by Aquazksj: Welcome, %s! %s module loaded and ready to use. (type /pf)"
EN.error         = "|cffff4040error:|r %s"
EN.hudUnlocked   = "Damage HUD |cffffd100unlocked|r: drag it with the mouse. Right-click the minimap button (or /pf lock) to lock it."
EN.hudLocked     = "Damage HUD |cff00ff00locked|r at x=%d, y=%d"
EN.hudPreview    = "Damage HUD preview: %s"
EN.bhudDrag      = "|cff40d9ffPulseFlash|r - Buff HUD: drag to move  (/pf lock to lock)"
EN.hudDrag       = "|cffffd100PulseFlash|r - drag to move  (/pf lock to lock)"
EN.t_multidot = "Multidot"
EN.md_only        = "Multidot only exists for classes with DoTs (Warlock, Shadow Priest, Druid, Mage, Hunter, Shaman and Arms Warrior)."
EN.md_msg         = "|cff59d9ffMULTIDOT:|r switch target (%d without DoT) - %s: %s"
EN.o_desc         = "Strict priority rotation with a 3-icon damage HUD, buff HUD, alerts, healers, Death Knight tank mode, automatic multidot and per-character, per-spec profiles."
EN.o_open = "Open settings"
EN.o_hint         = "Opening this entry opens the full PulseFlash settings by itself. If it does not open, use the button."
EN.o_by = "Author: %s  -  version %s"
EN.boss_on        = "target marked as BOSS (cooldowns and boss phases apply)."
EN.boss_off       = "boss mark removed from the target."
EN.boss_none      = "you have no hostile target to mark as boss."
EN.hs_classic = "Origin"
EN.hs_classic_d   = "Three equal icons in a row: now, next and utility. The original look."
EN.hs_queue = "Apex"
EN.hs_queue_d     = "One large icon for what to press now and two small stacked ones for what comes next. Very compact, with priority-colored borders."
EN.hs_line = "Cascade"
EN.hs_line_d      = "Dark strip with the current icon highlighted and the next ones smaller, joined by arrows: now > next > after."
EN.hs_serenity = "Serenity"
EN.hs_serenity_d  = "Light rounded frame with a dark shadow. Three icons for now, next and utility; when you use priority 1 the queue slides smoothly to the next icon."
EN.hs_assistant = "Oracle"
EN.hs_assistant_d = "Dark panel with a glowing main icon, the ability name beside it and the next two with a countdown. Animated ring when it changes."
EN.hs_use = "Use the item!"
EN.hs_sample = "Main ability"
EN.helpLine      = "commands: /pf (alias /pulseflash) on | off | aoe | mode | combo | num | poisons | stone | buffs | bufflock | cds | roles | tank | multidot | boss | version | alerts | sim | pet | totem | range | racials | keys | alias | icc | position | hud | move/lock | scale <0.5-2.0> | config | lang | reset | debug"
EN.dbg_class     = "class %s | spec %d | level %d | spells in book: %d"
EN.dbg_hp        = "  target health: %d%%"
EN.dbg_alerts    = "  active parallel alerts (buttons): %d"
EN.dbg_hud       = "  HUD: %s | %s | x=%d y=%d scale=%.2f"
EN.dbg_active   = "active"
EN.dbg_inactive = "inactive"
EN.dbg_locked   = "locked"
EN.dbg_unlocked = "unlocked"
EN.dbg_flags     = "  range: %s | racials: %s | ICC: %s | position: %s"
EN.dbg_behind    = "  behind the target: %s"
EN.dbg_yes = "yes"
EN.dbg_front = "NO (facing it)"
EN.dbg_rot       = "  rotation mode: %s | hold: %s"
EN.dbg_rotMax = "MAX DAMAGE"
EN.dbg_rotNormal = "normal"
EN.dbg_prebuffs  = "  missing buffs: %s"
EN.dbg_cand      = "  cand t%d %s [state %s]"
EN.dbg_slot      = "  slot %d: %s"
EN.noSpec = "No specialization"
EN.group1 = "Primary"
EN.group2 = "Secondary"
EN.cloneLabel    = "%s  |cff9a9aa5(%s · Group %d: %s)|r"
EN.cloned        = "settings cloned from |cffffd100%s|r (group %d)."
EN.profileSwitched = "profile loaded: |cffffd100%s|r · group %d (%s)"
EN.comboDrag     = "|cffffd100PulseFlash|r - drag the combo bar"
EN.comboLockedMsg = "Combo bar |cff00ff00locked|r"
EN.comboUnlockedMsg = "Combo bar |cffffd100unlocked|r: drag it with the mouse."
EN.comboPreview  = "Combo bar preview: %s"
EN.comboIs       = "Combo bar: %s"
EN.poisonsMissing = "|cffff4040poisons missing|r on your weapons."
EN.mm_left       = "|cffffffffLeft-click:|r settings panel"
EN.mm_right_lock = "|cffffffffRight-click:|r lock HUD |cff40d9ff(unlocked)|r"
EN.mm_right_unlock = "|cffffffffRight-click:|r unlock HUD"
EN.mm_shift      = "|cffffffffShift + left-click:|r HUD preview"
EN.mm_active     = " |cff00ff00(active)|r"
EN.mm_drag       = "|cffffffffDrag:|r move the button"
EN.snd_none = "None"
EN.snd_raid = "Raid warning"
EN.snd_boss = "Boss warning"
EN.snd_ping = "Map ping"
EN.snd_ready = "Ready check"
EN.snd_auction = "Chime"
EN.snd_alarm2 = "Soft alarm"
EN.snd_alarm3 = "Alarm"
EN.snd_tell = "Whisper"
EN.snd_level = "Level up"
EN.snd_pvp = "PvP warning"
EN.snd_bell = "Bell"
EN.snd_alarm1 = "Short alarm"
EN.snd_pvpa = "PvP warning (Alliance)"
EN.snd_coin = "Coins"
EN.snd_invite = "Invitation"
EN.snd_talent = "Talents"
EN.snd_aclose = "Auction closed"
EN.snd_bellh = "Horde bell"
EN.snd_belln = "Night elf bell"
EN.snd_bellt = "Tribal bell"
EN.bhudUnlocked  = "Buff HUD |cffffd100unlocked|r: drag it with the mouse. /pf bufflock (or its tab button) to lock it."
EN.bhudLocked    = "Buff HUD |cff00ff00locked|r at x=%d, y=%d"
EN.bhudPreview   = "Buff HUD preview: %s"
