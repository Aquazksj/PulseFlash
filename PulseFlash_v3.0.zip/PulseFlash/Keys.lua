local PF = PulseFlash

local MODS = { "ALT-", "CTRL-", "SHIFT-" }

function PF.KeyCost(key)
  local cost = #key
  for i = 1, #MODS do
    if key:find(MODS[i], 1, true) then cost = cost + 100 end
  end
  return cost
end

function PF.BestKey(...)
  local best, bestCost
  for i = 1, select("#", ...) do
    local k = select(i, ...)
    if type(k) == "string" and k ~= "" then
      local c = PF.KeyCost(k)
      if not bestCost or c < bestCost then best, bestCost = k, c end
    end
  end
  return best, bestCost
end

function PF.TextCost(text)
  local cost, s = #text, text
  while s:match("^%a%-.") do cost = cost + 100; s = s:sub(3) end
  return cost
end

function PF.NormKey(s)
  s = tostring(s or ""):upper()
  local out = ""
  while true do
    local m = s:match("^([ACS])%-.")
    if not m then break end
    out = out .. (m == "A" and "ALT-" or m == "C" and "CTRL-" or "SHIFT-")
    s = s:sub(3)
  end
  return out .. s
end

local BASE = {}
for c = 65, 90 do BASE[#BASE + 1] = string.char(c) end
for i = 0, 9 do BASE[#BASE + 1] = tostring(i) end
for i = 1, 12 do BASE[#BASE + 1] = "F" .. i end
for i = 0, 9 do BASE[#BASE + 1] = "NUMPAD" .. i end
for _, k in ipairs({ "NUMPADDECIMAL", "NUMPADPLUS", "NUMPADMINUS", "NUMPADMULTIPLY", "NUMPADDIVIDE",
                     "-", "=", "[", "]", "\\", ";", "'", ",", ".", "/", "`",
                     "SPACE", "TAB", "BACKSPACE", "INSERT", "DELETE", "HOME", "END", "PAGEUP", "PAGEDOWN",
                     "UP", "DOWN", "LEFT", "RIGHT",
                     "BUTTON3", "BUTTON4", "BUTTON5", "MOUSEWHEELUP", "MOUSEWHEELDOWN" }) do
  BASE[#BASE + 1] = k
end
local PREFIX = { "", "ALT-", "CTRL-", "SHIFT-", "ALT-CTRL-", "ALT-SHIFT-", "CTRL-SHIFT-", "ALT-CTRL-SHIFT-" }

local byCmd = {}
local mapAt, mapEpoch = -100, -1
local MAP_TTL = 8

local function RebuildMap()
  for _, list in pairs(byCmd) do wipe(list) end
  for p = 1, #PREFIX do
    local pre = PREFIX[p]
    for i = 1, #BASE do
      local key = pre .. BASE[i]
      local act = GetBindingAction(key, true)
      if act and act ~= "" then
        local list = byCmd[act]
        if not list then list = {}; byCmd[act] = list end
        list[#list + 1] = key
      end
    end
  end
end

local function KeyMap(epoch)
  local now = GetTime()
  if epoch ~= mapEpoch or now - mapAt > MAP_TTL then
    mapEpoch, mapAt = epoch, now
    RebuildMap()
  end
  return byCmd
end
PF.KeyMap = KeyMap

local function Add(out, k)
  if type(k) ~= "string" or k == "" then return end
  for i = 1, #out do if out[i] == k then return end end
  out[#out + 1] = k
end

local function AddAll(out, ...)
  for i = 1, select("#", ...) do Add(out, (select(i, ...))) end
end

function PF.ButtonKeys(out, name, cmd, epoch)
  wipe(out)
  local map = KeyMap(epoch)
  local click = "CLICK " .. name .. ":LeftButton"
  local l
  if cmd then
    AddAll(out, GetBindingKey(cmd))
    l = map[cmd]
    if l then for i = 1, #l do Add(out, l[i]) end end
  end
  AddAll(out, GetBindingKey(click))
  l = map[click]
  if l then for i = 1, #l do Add(out, l[i]) end end
  return out
end

function PF.ScreenHotkey(btn)
  local name = btn.GetName and btn:GetName()
  local fs = btn.HotKey or btn.hotkey or (name and _G[name .. "HotKey"])
  local t = fs and fs.GetText and fs:GetText()
  if type(t) ~= "string" then return nil end
  t = strtrim(t)
  if t == "" or t == RANGE_INDICATOR then return nil end
  return t
end
