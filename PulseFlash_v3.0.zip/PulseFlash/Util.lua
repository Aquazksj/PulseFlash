-- Util.lua
-- Utilidades compartidas por los módulos de clase (WoW 3.3.5a).
-- Aquí vive todo lo que antes cada clase repetía a su manera:
--   * CF.CD(spell)            cooldown real restante (ignora el GCD)
--   * CF.CastTime(spell)      tiempo de casteo actual en segundos (con celeridad)
--   * CF.Moving()             el jugador se está moviendo
--   * CF.CanCastNow(spell)    ¿se puede lanzar ahora teniendo en cuenta el movimiento?
--   * CF.ReadyFirst(...)      primer hechizo conocido y sin cooldown
--   * CF.Cast(...)            como add(), pero omite hechizos con casteo si te mueves
--   * CF.Maintain(...)        mantiene un DoT/debuff propio con ventana según el casteo
--   * CF.TTD() / CF.Lives(s)  estimación de vida restante del objetivo
--   * CF.AnyAura(...)         primer aura presente de una lista de nombres
--   * CF.Grouped()            ¿estás en grupo o banda?
--   * CF.TargetsMe()          ¿el objetivo te tiene a ti como objetivo?

local CF = PulseFlash
local GetTime = GetTime
local math = math

-- ---------------------------------------------------------------------------
-- Cooldown real
-- ---------------------------------------------------------------------------
-- GetSpellCooldown devuelve también el GCD; descartamos duraciones <= 1.6 s
-- para quedarnos solo con cooldowns "de verdad".
function CF.CD(spell)
  if not spell then return 0 end
  if CF.V then return CF.V:CD(spell) end
  local s, d = GetSpellCooldown(spell)
  if not s or s == 0 or not d or d <= 1.6 then return 0 end
  local left = s + d - GetTime()
  return left > 0 and left or 0
end

-- ---------------------------------------------------------------------------
-- Tiempo de casteo (en segundos). Se cachea 1 s porque la celeridad cambia poco.
-- ---------------------------------------------------------------------------
local ctCache = {}
function CF.CastTime(spell)
  if not spell then return 0 end
  local now = GetTime()
  local e = ctCache[spell]
  if e and now - e.at < 1 then return e.v end
  local ms = select(7, GetSpellInfo(spell))
  local v = (tonumber(ms) or 0) / 1000
  if not e then e = {}; ctCache[spell] = e end
  e.at, e.v = now, v
  return v
end

-- ---------------------------------------------------------------------------
-- Movimiento del jugador (una sola consulta por frame)
-- ---------------------------------------------------------------------------
local mvAt, mvVal = -1, false
function CF.Moving()
  if CF.V and CF.V.simMode then return false end   -- simulador: personaje quieto
  local now = GetTime()
  if now ~= mvAt then
    mvAt = now
    if type(GetUnitSpeed) == "function" then
      mvVal = ((GetUnitSpeed("player") or 0) > 0) and not (IsFalling and IsFalling()) or false
    else
      mvVal = false
    end
  end
  return mvVal
end

-- ¿Se puede lanzar ya? Los hechizos instantáneos siempre; los de casteo solo si
-- estás quieto. 'free' marca un procs que vuelve instantáneo el hechizo
-- (Hot Streak, Nightfall, Maelstrom Weapon a 5 cargas, etc.).
function CF.CanCastNow(spell, free)
  if free or not CF.Moving() then return true end
  return CF.CastTime(spell) <= 0
end

-- Equivalente a add(), pero omite los hechizos con casteo cuando te mueves.
function CF.Cast(add, spell, tier, free, hold)
  if not spell then return false end
  if not CF.CanCastNow(spell, free) then return false end
  return add(spell, tier or 1, hold)
end

-- ---------------------------------------------------------------------------
-- Mantenimiento de DoTs / debuffs propios
-- ---------------------------------------------------------------------------
-- 'left' es el tiempo restante devuelto por Aura() (nil si no está puesto).
-- La ventana de refresco es la mayor entre la configurada por el usuario y el
-- tiempo de casteo del hechizo + 'extra' (viaje del proyectil / latencia).
-- Con exact=true se usa solo casteo + extra.
function CF.Maintain(add, c, spell, left, extra, tier, exact)
  if not spell then return false end
  -- Temporizadores: solo con tiempos REALES. Durante la proyección / el simulador 'left'
  -- es tiempo virtual (ya descontado V.t o renovado por un lanzamiento simulado) y
  -- falseaba los segundos que muestra el panel de efectos bajo el HUD.
  if CF.NoteDot and not CF.V then CF.NoteDot(spell, left) end
  local user = tonumber(CF.db and CF.db.dotWindow) or 4.0
  local window = CF.CastTime(spell) + (extra or 0.4)
  -- 'exact' ignora la ventana global: para efectos que no conviene refrescar antes
  -- de tiempo (p. ej. Aflicción inestable, que se renueva justo al terminar).
  if not exact and window < user then window = user end
  if left and left > window then return false end
  if CF.IsCasting(spell) or c.casting == spell or CF.Pending(spell) then return false end
  if not CF.CanCastNow(spell) then return false end
  return add(spell, tier or 1)
end

-- ---------------------------------------------------------------------------
-- Estimación de vida restante del objetivo (TTD)
-- ---------------------------------------------------------------------------
-- Muestrea la vida del objetivo cada ~0.5 s en una ventana de 10 s y extrapola.
-- Devuelve nil mientras no haya datos fiables (en ese caso CF.Lives devuelve true,
-- así nunca se bloquea una recomendación por falta de información).
local TTD_WINDOW = 10
local ttdGuid, ttdN, ttdAt = nil, 0, 0
local ttdT, ttdH = {}, {}

local function TTDSample()
  local now = GetTime()
  if now - ttdAt < 0.5 then return end
  ttdAt = now
  if not UnitExists("target") or UnitIsDead("target") or not UnitCanAttack("player", "target") then
    ttdGuid, ttdN = nil, 0
    return
  end
  local g = UnitGUID("target")
  if g ~= ttdGuid then ttdGuid, ttdN = g, 0 end
  local hm = UnitHealthMax("target")
  if not hm or hm <= 0 then return end
  ttdN = ttdN + 1
  ttdT[ttdN], ttdH[ttdN] = now, UnitHealth("target")

  local first = 1
  while first < ttdN and now - ttdT[first] > TTD_WINDOW do first = first + 1 end
  if first > 1 then
    local n = 0
    for i = first, ttdN do
      n = n + 1
      ttdT[n], ttdH[n] = ttdT[i], ttdH[i]
    end
    ttdN = n
  end
end

function CF.TTD()
  -- Simulador: vida restante desconocida (= se permite todo), para que el resultado no
  -- dependa de la vida del objetivo real que tengas seleccionado.
  if CF.V and CF.V.simMode then return nil end
  TTDSample()
  if ttdN < 3 then return nil end
  local dt = ttdT[ttdN] - ttdT[1]
  if dt < 3 then return nil end
  local lost = ttdH[1] - ttdH[ttdN]
  if lost <= 0 then return nil end
  local v = ttdH[ttdN] / (lost / dt)
  -- En proyección el objetivo ya ha vivido V.t segundos más
  if CF.V then v = v - CF.V.t; if v < 0 then v = 0 end end
  return v
end

-- ¿El objetivo vivirá al menos 'sec' segundos? (true si no se sabe)
function CF.Lives(sec)
  local t = CF.TTD()
  return (not t) or t >= sec
end

-- ---------------------------------------------------------------------------
-- Varios
-- ---------------------------------------------------------------------------
-- Devuelve el tiempo restante del primer aura presente de la lista.
function CF.AnyAura(unit, harmful, mine, ...)
  for i = 1, select("#", ...) do
    local name = select(i, ...)
    if name then
      local left, n = CF.Aura(unit, name, harmful, mine)
      if left then return left, n, name end
    end
  end
  return nil
end

function CF.Grouped()
  return ((GetNumRaidMembers and GetNumRaidMembers() or 0) > 0)
      or ((GetNumPartyMembers and GetNumPartyMembers() or 0) > 0)
end

function CF.TargetsMe()
  return UnitExists("target") and UnitExists("targettarget") and UnitIsUnit("targettarget", "player") or false
end

-- ¿Hay un lanzamiento enemigo que interrumpir?
function CF.EnemyCasting()
  if CF.V and CF.V.simMode then return false end   -- simulador: nada que interrumpir
  return (UnitCastingInfo("target") or UnitChannelInfo("target")) and true or false
end

-- Primer hechizo conocido de la lista que NO esté en cooldown (para los
-- "filler" de movimiento: no tiene sentido mostrar un instantáneo en cooldown).
function CF.ReadyFirst(...)
  for i = 1, select("#", ...) do
    local n = select(i, ...)
    if n and CF.Known(n) and CF.CD(n) <= 0 then return n end
  end
  return nil
end

-- ---------------------------------------------------------------------------
-- Área: umbrales por habilidad
-- ---------------------------------------------------------------------------
-- CF.AoE(n): ¿conviene una habilidad de área con n o más enemigos?
--   AoE manual => siempre; objetivo único forzado a mano => nunca;
--   en cualquier otro caso se decide por el conteo real de enemigos.
-- CF.Enemies(): enemigos activos (mínimo 1 con objetivo hostil).
-- Extras.lua redefine ambas con el conteo completo; estas versiones son el
-- respaldo si ese archivo no estuviera cargado.
function CF.AoE(n) return CF.db and CF.db.aoe and true or false end
function CF.Enemies() return 1 end
