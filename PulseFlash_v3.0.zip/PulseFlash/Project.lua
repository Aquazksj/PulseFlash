-- Project.lua
-- Proyección de la cola (simulación hacia delante), con la rotación real de la clase.
--
-- Idea: con la habilidad que el motor recomienda ahora (s1) se "lanza" en un
-- estado virtual (recursos, puntos de combo, auras, cooldowns, runas, tiempo),
-- y se vuelve a ejecutar la rotación REAL de la clase sobre ese estado para
-- saber cuál sería la siguiente, y la siguiente. Así los iconos 2 y 3 del HUD
-- reflejan lo que de verdad toca después (p. ej. tras Cuchillada, los puntos
-- de combo vuelven a 0 y ya no se recomienda otro remate).
--
-- Cómo funciona por dentro:
--   * PF.V es el estado virtual. Mientras está activo, PF.Aura, PF.State,
--     CF.CD, PF.Pow, PF.IsCasting, PF.Pending y CF.TTD leen de él (ver Core.lua
--     y Util.lua); fuera de la proyección PF.V es nil y todo es real.
--   * Cada clase describe los efectos de sus hechizos en la tabla `sim` de su
--     módulo (coste, puntos de combo, auras, cooldowns...). Un hechizo sin
--     entrada en `sim` se trata de forma genérica: gasta su coste y ocupa un GCD.
--   * Todo va dentro de pcall: ante cualquier fallo se vuelve al comportamiento
--     anterior (cola heurística). Se apaga con /pf sim.
local PF = PulseFlash
local GetTime = GetTime
local min, max = math.min, math.max
local wipe = wipe or function(t) for k in pairs(t) do t[k] = nil end end

local V = {}
V.__index = V

local EMPTY = { any = {}, mine = {} }
local READY_TOL = 0.05
local MANA_REGEN = 0.007         -- fracción del maná máximo por segundo (solo simulador)

-- ---------------------------------------------------------------------------
-- Auras: lectura real (caché del motor) + capa de cambios virtuales
-- ---------------------------------------------------------------------------
-- ov[clave][nombre] = registro virtual | false (eliminado)
local function SetKey(unit, harmful)
  if unit == "player" then return harmful and "pd" or "pb" end
  if unit == "target" then return harmful and "td" or "tb" end
  if unit == "pet" and not harmful then return "nb" end
  return nil
end

local function RealRec(self, key, name, mine)
  local real = self.real[key]
  if real == nil then
    local unit = (key == "pb" or key == "pd") and "player" or (key == "nb" and "pet" or "target")
    real = PF.AuraList(unit, (key == "pd" or key == "td")) or EMPTY
    self.real[key] = real
  end
  return (mine and real.mine or real.any)[name], real
end

function V:Aura(unit, name, harmful, mine, prefix)
  local key = SetKey(unit, harmful)
  if not key then return nil end
  local ov = self.ov[key]
  local rec, left, count, dur
  if not prefix then
    local o = ov[name]
    if o == false then return nil end
    if o then
      left, count, dur = o.left, o.count, o.duration
      if mine and not o.mine then o = nil end
    end
    if not o then
      local r = RealRec(self, key, name, mine)
      if not r then return nil end
      local exp = r.expires
      left = (exp and exp > 0) and (exp - self.now0) or 9999
      count = (r.count and r.count > 0) and r.count or 1
      dur = r.duration
    end
  else
    local len = #name
    local found
    for n, o in pairs(ov) do
      if o and n:sub(1, len) == name and (not mine or o.mine) then
        found = o; break
      end
    end
    if found then
      left, count, dur = found.left, found.count, found.duration
    else
      local _, real = RealRec(self, key, name, mine)
      if not real then return nil end
      for i = 1, (real.n or 0) do
        local r = real[i]
        if r.name:sub(1, len) == name and (not mine or r.caster == "player") and ov[r.name] ~= false then
          local exp = r.expires
          left = (exp and exp > 0) and (exp - self.now0) or 9999
          count = (r.count and r.count > 0) and r.count or 1
          dur = r.duration
          found = r; break
        end
      end
      if not found then return nil end
    end
  end
  if left < 9000 then
    left = left - self.t
    if left <= 0 then return nil end
  end
  return left, count, dur, GetTime() + (left < 9000 and left or 0)
end

function V:Apply(unit, harmful, name, dur, count, mine)
  local key = SetKey(unit, harmful)
  if not key or not name then return end
  local ov = self.ov[key]
  local left = dur and (dur + self.t) or 9999
  local prev = ov[name]
  local c = count
  if not c then c = (prev and prev.count) or 1 end
  ov[name] = { left = left, count = c, duration = dur, mine = (mine ~= false) }
end

-- Suma cargas (p. ej. Arma Maelstrom, Explosión arcana) y renueva la duración
function V:AddStack(unit, harmful, name, n, maxStacks, dur)
  if not name then return end
  local left, cur = self:Aura(unit, name, harmful, false)
  local nc = min(maxStacks or 99, (left and cur or 0) + (n or 1))
  local d = dur
  if not d and left and left < 9000 then d = left end
  self:Apply(unit, harmful, name, d, nc, true)
end

function V:Remove(unit, harmful, name)
  local key = SetKey(unit, harmful)
  if key and name then self.ov[key][name] = false end
end

-- ---------------------------------------------------------------------------
-- Cooldowns, recursos y runas
-- ---------------------------------------------------------------------------
local function RealCD(spell)
  local s, d = GetSpellCooldown(spell)
  if not s or s == 0 or not d or d <= 1.6 then return 0 end
  local left = s + d - GetTime()
  return left > 0 and left or 0
end

function V:CD(spell)
  local at = self.cdAt[spell]
  if at == nil then at = RealCD(spell); self.cdAt[spell] = at end
  local left = at - self.t
  return left > 0 and left or 0
end

function V:SetCD(spell, secs)
  self.cdAt[spell] = self.t + (secs or 0)
end

function V:Spend(ptype, amount)
  if not ptype or not amount or amount <= 0 then return end
  self.res[ptype] = max(0, (self.res[ptype] or 0) - amount)
end

function V:Gain(ptype, amount)
  if not ptype or not amount then return end
  local cap = self.resMax[ptype] or 100
  self.res[ptype] = min(cap, (self.res[ptype] or 0) + amount)
end

-- Runas: 1 sangre, 2 profano, 3 escarcha, 4 muerte. r.at = instante (tiempo virtual) en que está lista
function V:RuneReady(i)
  local r = self.runes[i]
  return r and (r.at - self.t) <= READY_TOL
end

-- ¿Se pueden pagar estas runas? cost = { b = n, u = n, f = n }; la muerte sustituye a cualquiera.
function V:CanRunes(cost)
  if not cost then return true end
  local have = { 0, 0, 0, 0 }
  for i = 1, 6 do
    local r = self.runes[i]
    if r and (r.at - self.t) <= READY_TOL then have[r.type] = have[r.type] + 1 end
  end
  local need = { cost.b or 0, cost.u or 0, cost.f or 0 }
  local lack = 0
  for k = 1, 3 do lack = lack + max(0, need[k] - have[k]) end
  return lack <= have[4]
end

-- Gasta las runas (primero las del tipo, luego muertes). 'convert' = lista de tipos que pasan a muerte.
function V:SpendRunes(cost, convert)
  if not cost then return end
  local order = { { 1, cost.b or 0 }, { 2, cost.u or 0 }, { 3, cost.f or 0 } }
  local function take(kind)
    local best, bi
    for i = 1, 6 do
      local r = self.runes[i]
      if r and r.type == kind and (r.at - self.t) <= READY_TOL then best, bi = r, i; break end
    end
    if not best then return false end
    -- dos runas por tipo recargan en serie: la siguiente empieza cuando termina la anterior
    local partnerAt = 0
    for j = 1, 6 do
      local o = self.runes[j]
      if o and j ~= bi and o.pair == best.pair then partnerAt = max(partnerAt, o.at) end
    end
    best.at = max(self.t, partnerAt) + (self.runeCD or 10)
    if convert and convert[kind] then best.type = 4 end
    return true
  end
  for _, e in ipairs(order) do
    for _ = 1, e[2] do
      if not take(e[1]) then take(4) end
    end
  end
end

-- ---------------------------------------------------------------------------
-- Avance del tiempo
-- ---------------------------------------------------------------------------
function V:Advance(dt)
  if not dt or dt <= 0 then return end
  local mod = self.mod
  local regen = mod.regen and mod.regen(self) or 10
  if self.res[3] and self.resMax[3] and self.resMax[3] > 0 then
    self.res[3] = min(self.resMax[3], self.res[3] + regen * dt)
  end
  -- Maná: solo en el simulador de escenarios (la proyección del HUD dura 2 pasos).
  -- Sin esto un lanzador se quedaba sin maná a mitad del escenario y todo fallaba.
  if self.simMode and self.resMax[0] and self.resMax[0] > 0 then
    self.res[0] = min(self.resMax[0], (self.res[0] or 0) + self.resMax[0] * MANA_REGEN * dt)
  end
  if mod.simTick then mod.simTick(self, dt) end
  self.t = self.t + dt
end

-- ---------------------------------------------------------------------------
-- Estado de un hechizo en el mundo virtual (0 no lo conoces, 1 no disponible,
-- 2 sin recurso ahora mismo, 3 listo)
-- ---------------------------------------------------------------------------
function V:State(n)
  if self.spent[n] then return 1 end
  local e = self.byName[n]
  if self:CD(n) > READY_TOL then return 1 end
  -- Habilidades reactivas (Golpe de la victoria, Mordedura de mangosta, Golpe de runa...):
  -- en el juego solo se pueden usar tras una muerte, esquiva o parada. El simulador no
  -- genera esos eventos, así que nunca las ve disponibles (si no, se repetirían sin fin).
  if self.simMode and e and e.reactive and not e.use then return 1 end
  local ok
  if e and e.fin then
    ok = self.cp >= 1
  elseif e and e.use then
    ok = e.use(self, PF.N) and true or false
  elseif self.simMode then
    ok = true                                  -- simulador: sin consultar el mundo real
  else
    local usable, nomana = IsUsableSpell(n)
    ok = usable or nomana
  end
  if not ok then return 1 end
  if e and e.runes and not self:CanRunes(e.runes) then return 2 end
  local cost, pt = PF.Cost(n), PF.PowerType(n)
  if cost and pt and pt ~= 5 and (self.res[pt] or 0) < cost then return 2 end
  return 3
end

-- ---------------------------------------------------------------------------
-- Aplicar los efectos de lanzar un hechizo
-- ---------------------------------------------------------------------------
local function Val(x, V, cp)
  if type(x) == "function" then return x(cp, V) end
  return x
end

local function ApplyList(self, unit, harmful, list, cp)
  if not list then return end
  local N = PF.N
  -- una sola entrada { "Clave", dur = ..., stacks = ..., add = true }
  if list[1] and type(list[1]) == "string" then list = { list } end
  for _, it in ipairs(list) do
    local name = N[it[1]]
    if name then
      if it.add then
        self:AddStack(unit, harmful, name, it.add, it.max, Val(it.dur, self, cp))
      else
        self:Apply(unit, harmful, name, Val(it.dur, self, cp), it.stacks, it.mine)
      end
    end
  end
end

-- Procs "naturales" del simulador de escenarios (solo simMode).
-- Cada módulo puede declarar mod.simProcs = { { aura = "Clave", from = { "Clave", ... },
-- chance = 0..1, dur = s, stacks = n, spec = rama, when = function(V) end }, ... }.
-- Es determinista: cada lanzamiento de la lista suma 'chance' a un acumulador y, al llegar a 1,
-- se concede el proc (misma frecuencia media que el azar, resultado repetible). Sin esto una
-- rotación basada en procs (Escarcha, Fuego, Arcano, Demonología...) se quedaba en puro relleno.
function V:RollProcs(spell)
  local list = self.mod.simProcs
  if not list then return end
  local N = PF.N
  local spec = self.c0.spec
  self.procAcc = self.procAcc or {}
  for i, p in ipairs(list) do
    if not p.spec or p.spec == spec then
      local hit = false
      for _, k in ipairs(p.from) do if N[k] == spell then hit = true; break end end
      local an = N[p.aura]
      if hit and an and (not p.when or p.when(self)) then
        local acc = (self.procAcc[i] or (p.start or 0)) + p.chance
        if acc >= 1 then
          acc = acc - 1
          self:Apply("player", false, an, p.dur, p.stacks or 1, true)
          self.grantedBy = self.grantedBy or {}
          self.grantedBy[an] = (self.grantedBy[an] or 0) + 1
        end
        self.procAcc[i] = acc
      end
    end
  end
end

function V:Cast(n)
  local N = PF.N
  local mod = self.mod
  local e = self.byName[n] or {}
  local cp0 = self.cp
  local freed, instant = false, false

  -- Procs que hacen gratis o instantáneo el hechizo
  if e.free then
    local an = N[e.free]
    if an and self:Aura("player", an, false, false) then freed = true; instant = e.freeInstant ~= false; self:Remove("player", false, an) end
  end
  if e.instant then
    local list = type(e.instant) == "table" and e.instant or { e.instant }
    for _, k in ipairs(list) do
      local an = N[k]
      if an and self:Aura("player", an, false, false) then
        instant = true
        local left, cnt = self:Aura("player", an, false, false)
        if e.instantStack and cnt and cnt > 1 then
          self:Apply("player", false, an, left < 9000 and left or nil, cnt - 1, true)
        else
          self:Remove("player", false, an)
        end
        break
      end
    end
  end

  local cost, pt = PF.Cost(n), PF.PowerType(n)
  if cost and pt and pt ~= 5 and not freed then self:Spend(pt, cost) end
  if e.cost and not freed then self:Spend(e.costType or pt or 3, e.cost) end
  if e.runes and not freed then self:SpendRunes(e.runes, e.convert) end

  if e.fin then self.cp = 0 end
  if e.cp then self.cp = min(5, self.cp + e.cp) end
  if e.gain then for t, v in pairs(e.gain) do self:Gain(t, v) end end

  -- Lo que se gasta (procs, cargas, auras del objetivo) se gasta AL EMPEZAR el lanzamiento
  if e.consume then
    for _, k in ipairs(e.consume) do
      local an = N[k]
      if an then
        local left, cnt = self:Aura("player", an, false, false)
        if left and e.consumeStack and cnt and cnt > 1 then
          self:Apply("player", false, an, left < 9000 and left or nil, cnt - 1, true)
        elseif left then
          self:Remove("player", false, an)
        end
      end
    end
  end
  if e.dconsume then
    for _, k in ipairs(e.dconsume) do self:Remove("target", true, N[k]) end
  end

  -- Tiempo que ocupa: el mayor entre el GCD y el casteo
  local gcd = e.gcd
  if gcd == nil then gcd = mod.gcd and mod.gcd(self) or 1.5 end
  local ct = 0
  if not instant then
    ct = e.cast
    if ct == nil then ct = PF.CastTime and PF.CastTime(n) or 0 end
  end
  ct = ct or 0

  -- Lo que se APLICA (DoTs, buffs, cooldown, efectos) llega al TERMINAR el casteo, como en
  -- el juego. Antes se aplicaba al empezar: un DoT con casteo (Inmolar 2 s, Aflicción
  -- inestable 1,5 s...) duraba en la simulación el casteo de menos y el tiempo restante
  -- que veía la rotación estaba descalibrado en esos segundos.
  if ct > 0 then self:Advance(ct) end
  ApplyList(self, "player", false, e.buff, cp0)
  ApplyList(self, "target", true, e.debuff, cp0)
  ApplyList(self, "pet", false, e.petbuff, cp0)
  ApplyList(self, "target", false, e.tbuff, cp0)
  if e.once then self.spent[n] = true end
  if e.cd then self:SetCD(n, Val(e.cd, self, cp0)) end
  if e.fn then e.fn(self, N, n, cp0) end
  if self.simMode then self:RollProcs(n) end   -- el proc llega al terminar el lanzamiento

  -- si el GCD dura más que el casteo, el resto se espera
  local rest = max(gcd, ct) - ct
  if rest > 0 then self:Advance(rest) end
end

-- ---------------------------------------------------------------------------
-- Contexto virtual y elección del siguiente paso
-- ---------------------------------------------------------------------------
function V:Ctx()
  local vc = self.vc
  wipe(vc)
  for k, v in pairs(self.c0) do vc[k] = v end
  vc.cp = self.cp
  vc.energy = self.res[3] or 0
  vc.rage = self.res[1] or 0
  vc.runic = self.res[6] or 0
  vc.mana = self.res[0] or 0
  local mm = self.resMax[0] or 0
  vc.manaPct = (mm > 0) and ((self.res[0] or 0) / mm) or 1
  vc.casting = nil
  if self.casts > 0 then vc.combat = true end
  return vc
end

function V:Pick()
  local mod = self.mod
  local vc = self:Ctx()
  local n = 0
  local sp, ti, ho = self.cSpell, self.cTier, self.cHold
  local function vadd(spell, tier, hold)
    if spell and PF.Known(spell) then
      if PF.IsPositional(spell) and not vc.behind then return false end
      n = n + 1
      sp[n], ti[n], ho[n] = spell, tier, hold
      return true
    end
    return false
  end
  if vc.hostile then
    if mod.upkeep then pcall(mod.upkeep, vc, vadd, PF.N) end
    local ok, err = pcall(mod.evaluate, vc, vadd, PF.N)
    if not ok then
      if PF.lastProjErr ~= err then PF.lastProjErr = err; if PF.Msg then PF.Msg("sim: " .. tostring(err)) end end
      return nil
    end
  end
  self.nC = n
  self.waitFor = nil
  local pick, hold
  for i = 1, n do
    if ti[i] == 1 then
      local s = sp[i]
      local st = self:State(s)
      if st == 3 then pick = s; break end   -- sin filtrar por alcance: siempre la correcta
      if st == 2 and ho[i] then pick, hold = s, ho[i]; break end
    end
  end
  if not pick and mod.filler and vc.hostile then
    local f = mod.filler(vc, PF.N)
    if f and PF.Known(f) then
      -- HUD: el relleno se muestra siempre (atenuado si no se puede usar).
      -- Simulador: un relleno en enfriamiento o sin recurso NO se lanza; se espera
      -- (antes se "lanzaba" igualmente, reiniciaba su enfriamiento y la secuencia
      -- repetía siempre la misma habilidad, marcando "no ejecutable").
      if self.simMode and self:State(f) ~= 3 then
        self.waitFor = f
      else
        pick = f
      end
    end
  end
  return pick, hold
end

-- ---------------------------------------------------------------------------
-- Construcción del estado virtual
-- ---------------------------------------------------------------------------
local byNameCache, byNameFor = nil, nil
local function ByName(mod)
  if byNameFor ~= mod or not byNameCache then
    byNameFor, byNameCache = mod, {}
    for key, e in pairs(mod.sim or {}) do
      local name = PF.N[key]
      if name then byNameCache[name] = e end
    end
  end
  return byNameCache
end

local function NewV(c, mod)
  local now = GetTime()
  local v = setmetatable({}, V)
  v.mod, v.c0, v.vc = mod, c, {}
  v.now0, v.t, v.casts = now, 0, 0
  v.real, v.cdAt, v.spent = {}, {}, {}
  v.cSpell, v.cTier, v.cHold = {}, {}, {}
  v.ov = { pb = {}, pd = {}, tb = {}, td = {}, nb = {} }
  v.byName = ByName(mod)
  v.cp = c.cp or 0
  v.res, v.resMax = {}, {}
  for _, t in ipairs { 0, 1, 3, 6 } do
    v.res[t] = UnitPower("player", t) or 0
    v.resMax[t] = UnitPowerMax("player", t) or 0
  end
  if GetRuneCooldown then
    v.runes = {}
    for i = 1, 6 do
      local start, dur, ready = GetRuneCooldown(i)
      local left = (ready or not start or not dur or dur <= 0) and 0 or (start + dur - now)
      v.runes[i] = { at = max(0, left), type = GetRuneType and GetRuneType(i) or 1, pair = math.ceil(i / 2) }
    end
  else
    v.runes = {}
  end
  if mod.simInit then mod.simInit(v) end
  return v
end

-- Lectura de runas para los módulos (real o virtual): devuelve (segundos hasta estar lista, tipo)
function PF.RuneInfo(i)
  local V = PF.V
  if V then
    local r = V.runes[i]
    if not r then return 0, 0 end
    return max(0, r.at - V.t), r.type
  end
  local start, dur, ready = GetRuneCooldown(i)
  local left = (ready or not start or not dur or dur <= 0) and 0 or (start + dur - GetTime())
  return left > 0 and left or 0, GetRuneType and GetRuneType(i) or 0
end

function PF.ProjOn()
  return PF.db and PF.db.proj ~= false and PF.module and PF.module.sim ~= false
end

-- ---------------------------------------------------------------------------
-- Proyección: devuelve los siguientes 'steps' hechizos tras s1
-- ---------------------------------------------------------------------------
local function Run(c, s1, steps, mod)
  local v = NewV(c, mod)
  PF.V = v
  local out, cur = {}, s1
  for i = 1, steps do
    v:Cast(cur)
    v.casts = v.casts + 1
    local nxt, hold = v:Pick()
    if not nxt then break end
    if hold and hold > 0 then v:Advance(hold) end
    out[i] = nxt
    cur = nxt
  end
  return out
end

function PF.Project(c, s1, steps)
  local mod = PF.module
  if not (mod and s1 and c and c.hostile) then return nil end
  local ok, out = pcall(Run, c, s1, steps or 2, mod)
  PF.V = nil
  if not ok then
    if PF.Msg and PF.lastProjErr ~= out then PF.lastProjErr = out; PF.Msg("sim: " .. tostring(out)) end
    return nil
  end
  return out[1], out[2]
end

-- Lo usa el addon PulseFlash_Sim (simulador de escenarios): estado virtual y el
-- constructor de la proyeccion, sin tocar nada del mundo real.
PF.SimNewV = NewV
PF.SimEmptyAuras = EMPTY
