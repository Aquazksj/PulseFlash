local PF = PulseFlash
local DB

local floor, ipairs, pairs, type = math.floor, ipairs, pairs, type

PF.profileCallbacks = {}

local function DeepCopy(src)
  if type(src) ~= "table" then return src end
  local out = {}
  for k, v in pairs(src) do out[k] = DeepCopy(v) end
  return out
end

local function Fill(t, defaults)
  for k, v in pairs(defaults) do
    if t[k] == nil then
      t[k] = DeepCopy(v)
    elseif type(v) == "table" and type(t[k]) == "table" then
      Fill(t[k], v)
    end
  end
end

local function Clamp(v, lo, hi, default)
  v = tonumber(v)
  if not v then return default end
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

local MODES  = { combat = true, target = true, always = true }
local STYLES = { glow = true, size = true }

local function Sanitize(p)
  if type(p.hud) ~= "table" then p.hud = {} end
  if type(p.bhud) ~= "table" then p.bhud = {} end
  if type(p.fx) ~= "table" then p.fx = {} end
  if type(p.sound) ~= "table" then p.sound = {} end
  if type(p.rot) ~= "table" then p.rot = {} end
  if type(p.combo) ~= "table" then p.combo = {} end
  Fill(p.hud, PF.HUD_DEFAULT)
  Fill(p.bhud, PF.BHUD_DEFAULT or {})
  Fill(p.fx, PF.FX_DEFAULT)
  Fill(p.sound, { enabled = true, procs = {} })
  if type(p.sound.procs) ~= "table" then p.sound.procs = {} end
  local h, f = p.hud, p.fx
  h.scale = Clamp(h.scale, PF.HUD_SCALE_MIN, PF.HUD_SCALE_MAX, PF.HUD_DEFAULT.scale)
  h.alphaCombat = Clamp(h.alphaCombat, 0.1, 1, 1)
  h.alphaOOC = Clamp(h.alphaOOC, 0.1, 1, 1)
  h.alphaChannel = Clamp(h.alphaChannel, 0.1, 1, PF.HUD_DEFAULT.alphaChannel)
  h.x = tonumber(h.x) or PF.HUD_DEFAULT.x
  h.y = tonumber(h.y) or PF.HUD_DEFAULT.y
  if not MODES[h.mode] then h.mode = PF.HUD_DEFAULT.mode end
  if not (PF.HUD_STYLES and PF.HUD_STYLES[h.style]) then h.style = PF.HUD_DEFAULT.style end
  f.period = Clamp(f.period, 0.1, 1.0, PF.FX_DEFAULT.period)
  f.intensity = Clamp(f.intensity, 0.1, 1.0, PF.FX_DEFAULT.intensity)
  if not STYLES[f.style] then f.style = PF.FX_DEFAULT.style end

  local bd, b = PF.BHUD_DEFAULT or {}, p.bhud
  b.scale = Clamp(b.scale, PF.HUD_SCALE_MIN, PF.HUD_SCALE_MAX, bd.scale or 1)
  b.alphaCombat = Clamp(b.alphaCombat, 0.1, 1, 1)
  b.alphaOOC = Clamp(b.alphaOOC, 0.1, 1, 1)
  b.x = tonumber(b.x) or bd.x or 0
  b.y = tonumber(b.y) or bd.y or 300
  b.enabled = b.enabled and true or false
  b.combat = b.combat and true or false
  b.pulse = b.pulse and true or false
  b.glow = b.glow and true or false

  Fill(p.rot, PF.ROT_DEFAULT)
  p.rot.max = p.rot.max and true or false
  if PF.COMBO_DEFAULT then
    Fill(p.combo, PF.COMBO_DEFAULT)
    if PF.ComboSanitize then PF.ComboSanitize(p.combo) end
  end
end

function PF.GetCharKey()
  return (UnitName("player") or "?") .. "-" .. (GetRealmName() or "?")
end

function PF.GetSpecInfo()
  local group = (GetActiveTalentGroup and GetActiveTalentGroup()) or 1
  if group ~= 1 and group ~= 2 then group = 1 end
  local bestTab, bestName, bestPts = 0, nil, 0
  for i = 1, (GetNumTalentTabs and GetNumTalentTabs() or 0) do

    local name, _, pts = GetTalentTabInfo(i, false, false, group)
    if pts and pts > bestPts then bestTab, bestName, bestPts = i, name, pts end
  end
  if bestPts < 5 then return group, 0, PF.T("noSpec") end
  return group, bestTab, bestName
end

function PF.GroupLabel(group)
  return (group == 2) and PF.T("group2") or PF.T("group1")
end

local function NewProfile(charData, group)
  local seed
  for g, other in pairs(charData.specs) do
    if g ~= group and type(other) == "table" then seed = other; break end
  end
  local p = {}
  local src = seed or DB.legacy or {}
  p.hud = DeepCopy(src.hud or {})
  p.bhud = DeepCopy(src.bhud or {})
  p.fx = DeepCopy(src.fx or {})
  p.sound = DeepCopy(src.sound or {})
  p.rot = DeepCopy(src.rot or {})
  p.combo = DeepCopy(src.combo or {})
  Sanitize(p)
  return p
end

function PF.ActivateProfile(p)
  Sanitize(p)
  local old = DB.hud
  if old and old ~= p.hud and old.locked ~= nil then
    p.hud.locked = old.locked
  end
  if DB.bhud and DB.bhud ~= p.bhud and DB.bhud.locked ~= nil then
    p.bhud.locked = DB.bhud.locked
  end
  if DB.combo and DB.combo ~= p.combo and DB.combo.locked ~= nil then
    p.combo.locked = DB.combo.locked
  end
  PF.profile = p
  DB.hud, DB.bhud, DB.fx, DB.sound, DB.rot, DB.combo = p.hud, p.bhud, p.fx, p.sound, p.rot, p.combo
  PF.ApplyProfile()
end

function PF.ApplyProfile()
  if PF.HUDApplyPos then PF.HUDApplyPos() end
  if PF.HUDApplyLock then PF.HUDApplyLock() end
  if PF.BuffHUDApply then PF.BuffHUDApply() end
  if PF.ComboBarApply then PF.ComboBarApply() end
  for _, fn in ipairs(PF.profileCallbacks) do pcall(fn) end
end

function PF.RegisterProfileCallback(fn)
  PF.profileCallbacks[#PF.profileCallbacks + 1] = fn
end

function PF.LoadActiveProfile()
  local group, tab, specName = PF.GetSpecInfo()
  local key = PF.GetCharKey()
  local _, class = UnitClass("player")
  local c = DB.chars[key]
  if type(c) ~= "table" then c = {}; DB.chars[key] = c end
  if type(c.specs) ~= "table" then c.specs = {} end
  c.class = class
  local p = c.specs[group]
  if type(p) ~= "table" then p = NewProfile(c, group); c.specs[group] = p end
  p.specName, p.specTab = specName, tab
  local changed = (PF.activeKey ~= key) or (PF.activeGroup ~= group)
  PF.activeKey, PF.activeGroup = key, group
  PF.ActivateProfile(p)
  return changed
end

local function ApplyInto(src)
  local p = PF.profile
  if not p or type(src) ~= "table" then return false end
  p.hud = DeepCopy(src.hud or {})
  p.bhud = DeepCopy(src.bhud or {})
  p.fx = DeepCopy(src.fx or {})
  p.sound = DeepCopy(src.sound or {})
  p.rot = DeepCopy(src.rot or {})
  p.combo = DeepCopy(src.combo or {})
  PF.ActivateProfile(p)
  return true
end

function PF.ListProfiles()
  local list = {}
  for key, c in pairs(DB.chars) do
    if type(c) == "table" and type(c.specs) == "table" then
      local cls = (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[c.class or ""]) or c.class or "?"
      for group, p in pairs(c.specs) do
        if type(p) == "table" and not (key == PF.activeKey and group == PF.activeGroup) then
          list[#list + 1] = {
            key = key, group = group,
            label = PF.T("cloneLabel", key, cls, group, p.specName or "?"),
          }
        end
      end
    end
  end
  table.sort(list, function(a, b)
    if a.key ~= b.key then return a.key < b.key end
    return a.group < b.group
  end)
  return list
end

function PF.CloneProfile(key, group)
  local c = DB.chars[key]
  local src = c and c.specs and c.specs[group]
  if ApplyInto(src) then
    PF.Msg(PF.T("cloned", key, group))
    return true
  end
  return false
end

function PF.Profiles_Init(db)
  DB = db
  if type(DB.chars) ~= "table" then DB.chars = {} end

  if type(DB.legacy) ~= "table" then
    DB.legacy = { hud = DeepCopy(DB.hud or {}), fx = {}, sound = {} }
  end
  PF.LoadActiveProfile()

  local f = CreateFrame("Frame")
  f:RegisterEvent("PLAYER_ENTERING_WORLD")
  f:RegisterEvent("PLAYER_TALENT_UPDATE")
  f:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
  f:SetScript("OnEvent", function(_, event)
    if not DB then return end
    local group = PF.GetSpecInfo()
    if group ~= PF.activeGroup then
      PF.LoadActiveProfile()
      local p = PF.profile
      PF.Msg(PF.T("profileSwitched", PF.activeKey, PF.activeGroup, p and p.specName or "?"))
    elseif PF.profile then

      local _, tab, name = PF.GetSpecInfo()
      PF.profile.specName, PF.profile.specTab = name, tab
      if PF.RefreshConfig then PF.RefreshConfig() end
    end
  end)
end
