local PF = PulseFlash

local BOSS_VS_PLAYER = 5.5
local BOSS_VS_ELITE = 3.0
local MAX_SEEN = 24

local eliteSeen, eliteSet, eliteZone = {}, {}, nil
local forcedGUID = nil

function PF.ToggleBossMark()
  if not (UnitExists("target") and UnitCanAttack("player", "target")) then return nil end
  local g = UnitGUID("target")
  if forcedGUID == g then forcedGUID = nil; return false end
  forcedGUID = g
  return true
end

-- Muñeco de entrenamiento: se reconoce por el nombre (el cliente no marca nada especial).
-- Cubre los idiomas del addon: Training Dummy / Muñeco / Übungspuppe / Mannequin / Boneco / Манекен.
local DUMMY_NAMES = { "dummy", "mu\195\177eco", "puppe", "mannequin", "boneco", "манекен", "Манекен" }
function PF.IsDummy(unit)
  unit = unit or "target"
  if not (UnitExists(unit) and UnitCanAttack("player", unit)) then return false end
  local n = UnitName(unit)
  if not n then return false end
  local l = n:lower()
  for _, key in ipairs(DUMMY_NAMES) do
    if l:find(key, 1, true) or n:find(key, 1, true) then return true end
  end
  return false
end

function PF.DetectBoss(level, tl, tc)
  if tl == -1 or tc == "worldboss" then return true end
  if PF.IsDummy("target") then return true end      -- dummys: mismo trato (y análisis) que un jefe
  if forcedGUID and UnitGUID("target") == forcedGUID then return true end
  for i = 1, 4 do
    local u = "boss" .. i
    if UnitExists(u) and UnitIsUnit("target", u) then return true end
  end
  if tc ~= "elite" and tc ~= "rareelite" then return false end
  if tc == "elite" and tl >= level + 2 then return true end

  local zone = GetRealZoneText and GetRealZoneText() or ""
  if zone ~= eliteZone then
    eliteZone = zone
    for i = #eliteSeen, 1, -1 do eliteSeen[i] = nil end
    for k in pairs(eliteSet) do eliteSet[k] = nil end
  end

  local _, kind = IsInInstance()
  if kind == "raid" then return false end
  local hm, pm = UnitHealthMax("target"), UnitHealthMax("player")
  if not hm or hm <= 0 or not pm or pm <= 0 then return false end
  if hm >= pm * BOSS_VS_PLAYER then return true end

  local n = #eliteSeen
  if n > 0 then
    local ref = eliteSeen[math.floor(n / 4) + 1]
    if hm >= ref * BOSS_VS_ELITE then return true end
  end
  if not eliteSet[hm] then
    eliteSet[hm] = true
    eliteSeen[#eliteSeen + 1] = hm
    table.sort(eliteSeen)
    if #eliteSeen > MAX_SEEN then
      local drop = table.remove(eliteSeen)
      eliteSet[drop] = nil
    end
  end
  return false
end

-- Jefe real: nivel ??, worldboss, unidad boss1-4 o marcado a mano con /pf boss.
-- A diferencia de DetectBoss, NO cuenta el trash elite de mayor nivel.
function PF.IsTrueBoss()
  if not (UnitExists("target") and UnitCanAttack("player", "target")) then return false end
  if UnitLevel("target") == -1 or UnitClassification("target") == "worldboss" then return true end
  if forcedGUID and UnitGUID("target") == forcedGUID then return true end
  if PF.IsDummy("target") then return true end
  for i = 1, 4 do
    local u = "boss" .. i
    if UnitExists(u) and UnitIsUnit("target", u) then return true end
  end
  return false
end
