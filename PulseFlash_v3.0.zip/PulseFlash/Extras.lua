-- PulseFlash - Extras.lua
-- Funciones de precision integradas en el nucleo (antes en PulseFlash_Plus y PulseFlash_Beta):
--   1. Estabilidad: la sugerencia no parpadea entre dos habilidades.
--   2. Cuenta atras real: segundos que faltan de una reutilizacion verdadera.
--   3. Latencia: la habilidad que termina de lanzarse dentro del retardo de red se da por hecha.
--   4. AoE automatico segun el numero de enemigos + clic izquierdo en el HUD para alternar AoE.
--   5. Temporizadores de efectos (DoTs) bajo el HUD.
-- Todo se apaga junto con el interruptor "Precision extra" (PF.db.plusOff).
local PF = PulseFlash

local GetTime = GetTime
local floor, format = math.floor, string.format
local pairs, select, tonumber = pairs, select, tonumber
local bor = bit and bit.band

local function Off() return PF.db and PF.db.plusOff end

------------------------------------------------------------------------------
-- 1. Estabilidad: evita que la sugerencia parpadee cuando el estado de dos
--    habilidades cambia en menos de 0.12 s. Si la anterior deja de ser valida
--    (en reutilizacion, sin recurso, fuera de rango) cambia al instante.
------------------------------------------------------------------------------
local HOLD = 0.12
local shown, cand, candSince
local AutoAoe   -- se define mas abajo

function PF.Keep(s1, s2, n, spells, tiers, exec)
  if Off() then return s1, s2 end
  local now = GetTime()
  if s1 ~= cand then cand, candSince = s1, now end
  local a, b, held = s1, s2, false
  if shown and shown ~= s1 and (now - candSince) < HOLD then
    for i = 1, n do
      if spells[i] == shown and tiers[i] == 1 and exec[i] then
        a, b, held = shown, s1, true
        break
      end
    end
  end
  if not held then shown = s1 end
  AutoAoe(now)
  return a, b
end

------------------------------------------------------------------------------
-- 2. Cuenta atras real: el nucleo da por lista una habilidad con <= 1.5 s de
--    reutilizacion (el GCD). Si lo que falta es una reutilizacion verdadera,
--    se muestra cuantos segundos faltan para poder pulsarla.
------------------------------------------------------------------------------
function PF.MainWait(spell)
  if Off() or not spell or spell:find("^item:") then return nil end
  local s, d = GetSpellCooldown(spell)
  if s and s > 0 and d and d > 1.6 then
    local rem = s + d - GetTime()
    if rem > 0.15 and rem <= 1.5 then return format("%.1f", rem) end
  end
  return nil
end

------------------------------------------------------------------------------
-- 3. Latencia: se mide el retardo real entre pulsar y que el servidor acepte el
--    lanzamiento (media suavizada). Si el hechizo en curso termina antes de
--    ese retardo, se considera ya lanzado y se sugiere el siguiente.
------------------------------------------------------------------------------
local measured, measuredAt
local sentAt, lagMarked = {}, {}

local function NetLag()
  local _, _, lat = GetNetStats()
  return (lat or 0) / 1000
end

function PF.Lag()
  local lag
  if measured and (GetTime() - measuredAt) < 120 then lag = measured else lag = NetLag() end
  if lag < 0.02 then lag = 0.02 elseif lag > 0.4 then lag = 0.4 end
  return lag
end

local function Sample(x)
  if x <= 0 or x >= 1 then return end
  measured = measured and (measured * 0.7 + x * 0.3) or x
  measuredAt = GetTime()
end

-- Devuelve el nombre del hechizo si lo que se esta lanzando acaba dentro del retardo.
function PF.CastInLag()
  if Off() then return nil end
  local now = GetTime()
  local name, _, _, _, _, endTime = UnitCastingInfo("player")
  if not name then name, _, _, _, _, endTime = UnitChannelInfo("player") end
  if not name or not endTime then return nil end
  if endTime / 1000 - now > PF.Lag() then return nil end
  local t = PF.lastCast[name]
  if not t or now - t > 1 then PF.lastCast[name] = now; lagMarked[name] = true end
  return name
end

local lagFrame = CreateFrame("Frame")
lagFrame:RegisterEvent("UNIT_SPELLCAST_SENT")
lagFrame:RegisterEvent("UNIT_SPELLCAST_START")
lagFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
lagFrame:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
lagFrame:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
lagFrame:RegisterEvent("UNIT_SPELLCAST_FAILED")
lagFrame:SetScript("OnEvent", function(_, event, unit, spell)
  if unit ~= "player" or not spell then return end
  if event == "UNIT_SPELLCAST_SENT" then
    sentAt[spell] = GetTime()
  elseif event == "UNIT_SPELLCAST_INTERRUPTED" or event == "UNIT_SPELLCAST_FAILED" then
    sentAt[spell] = nil
    if lagMarked[spell] then lagMarked[spell] = nil; PF.lastCast[spell] = nil end
  else
    local t0 = sentAt[spell]
    if t0 then
      sentAt[spell] = nil
      Sample(GetTime() - t0)
    end
    if event == "UNIT_SPELLCAST_SUCCEEDED" then lagMarked[spell] = nil end
  end
end)

------------------------------------------------------------------------------
-- 4. AoE automatico segun el numero de enemigos (se cuentan por el registro de
--    combate). Se activa con 3 o mas y se apaga cuando queda uno o termina el
--    combate. Si se cambia el AoE a mano, el automatico se aparta 20 s.
------------------------------------------------------------------------------
local inCombat = false
local playerGUID
local HOSTILE = COMBATLOG_OBJECT_REACTION_HOSTILE or 0x40
local NPC = COMBATLOG_OBJECT_TYPE_NPC or 0x800
local enemies, nEnemies = {}, 0
local ACTIVE, MAXE = 6, 40
local autoSet, aoeSince, lowSince = false, nil, nil
local lastTarget, manualUntil = 0, 0

local function opt(k)
  local v = PF.db and PF.db[k]
  if v == nil then return true end
  return v
end

local function SeenEnemy(guid, now)
  local e = enemies[guid]
  if e then e.last = now; return end
  if nEnemies >= MAXE then return end
  enemies[guid] = { last = now }
  nEnemies = nEnemies + 1
end

local function ForgetEnemy(guid)
  if enemies[guid] then enemies[guid] = nil; nEnemies = nEnemies - 1 end
end

-- Unidades que pueden delatar a un enemigo en combate (3.3.5a no tiene placas de
-- nombre como tokens): objetivo, foco, ratón, objetivo del objetivo, de la
-- mascota y de los miembros del grupo o banda.
local function ConsiderUnit(u, now)
  if u and UnitExists(u) and UnitCanAttack("player", u) and not UnitIsDeadOrGhost(u)
     and UnitAffectingCombat(u) then
    local g = UnitGUID(u)
    if g then SeenEnemy(g, now) end
  end
end

local lastScan = 0
local function ScanUnits(now)
  if now - lastScan < 0.5 then return end
  lastScan = now
  ConsiderUnit("target", now); ConsiderUnit("focus", now); ConsiderUnit("mouseover", now)
  ConsiderUnit("targettarget", now); ConsiderUnit("pettarget", now)
  local raid = (GetNumRaidMembers and GetNumRaidMembers()) or 0
  if raid > 0 then
    for i = 1, math.min(raid, 10) do ConsiderUnit("raid" .. i .. "target", now) end
  else
    local party = (GetNumPartyMembers and GetNumPartyMembers()) or 0
    for i = 1, math.min(party, 4) do ConsiderUnit("party" .. i .. "target", now) end
  end
end

-- Enemigos activos: los vistos en el registro de combate (golpeados o atacantes
-- del jugador, su mascota y su grupo) más los que delatan las unidades anteriores.
function PF.EnemyCount()
  local now = GetTime()
  if inCombat then ScanUnits(now) end
  for g, e in pairs(enemies) do
    if now - e.last > ACTIVE then enemies[g] = nil; nEnemies = nEnemies - 1 end
  end
  return nEnemies
end

-- Número de enemigos a efectos de rotación (mínimo 1 si hay un objetivo hostil)
function PF.Enemies()
  local n = PF.EnemyCount()
  if n < 1 and UnitExists("target") and UnitCanAttack("player", "target")
     and not UnitIsDead("target") then n = 1 end
  return n
end

-- Estado manual del AoE: true = el usuario lo activó (se respeta siempre);
-- stUntil = el usuario lo desactivó a mano: objetivo único forzado hasta ese momento.
PF.aoeManual = false
PF.stUntil = 0

-- ¿Conviene usar habilidades de área con 'n' o más enemigos?
--   * AoE activado a mano: sí, siempre.
--   * Objetivo único forzado a mano (20 s): no.
--   * Si no, por conteo real de enemigos (es el modo automático).
function PF.AoE(n)
  if PF.V and PF.V.simMode then return false end   -- simulador: objetivo único
  local db = PF.db
  if not db then return false end
  if db.aoe and PF.aoeManual then return true end
  if GetTime() < (PF.stUntil or 0) then return false end
  if db.plusAoe == false or db.plusOff then return db.aoe and true or false end
  return PF.Enemies() >= (n or 3)
end

-- Aviso breve bajo los temporizadores (solo lo usa el AoE automatico)
local toastText, toastCol, toastUntil

function PF.Toast(text, r, g, b, secs)
  toastText, toastCol = text, { r or 1, g or 0.82, b or 0.2 }
  toastUntil = GetTime() + (secs or 3)
end

function PF.ManualAoe()
  autoSet, aoeSince, lowSince = false, nil, nil
  manualUntil = GetTime() + 20
  local on = PF.db and PF.db.aoe
  PF.aoeManual = on and true or false
  PF.stUntil = (not on) and (GetTime() + 20) or 0
  PF.Toast(PF.T("aoe_is", on and PF.T("on") or PF.T("off")),
    on and 0.45 or 1, on and 1 or 0.82, on and 0.55 or 0.2, 2.5)
end

AutoAoe = function(now)
  if not inCombat or now - lastTarget < 0.5 then return end
  lastTarget = now
  if not (opt("plusAoe") and PF.db) or now < manualUntil then return end
  local n = PF.EnemyCount()
  local db = PF.db
  if db.aoe == false and autoSet then autoSet = false end
  local minE = tonumber(db.plusAoeMin) or 3
  if n >= minE then
    lowSince = nil
    aoeSince = aoeSince or now
    if not db.aoe and now - aoeSince >= 1.2 then
      db.aoe = true; autoSet = true; PF.aoeManual = false
      PF.Toast(PF.T("aoe_on", n), 0.45, 1, 0.55, 3)
      if PF.RefreshConfig then PF.RefreshConfig() end
    end
  elseif n <= 1 then
    aoeSince = nil
    lowSince = lowSince or now
    if db.aoe and autoSet and now - lowSince >= 3 then
      db.aoe = false; autoSet = false
      PF.Toast(PF.T("aoe_off"), 1, 0.82, 0.2, 3)
      if PF.RefreshConfig then PF.RefreshConfig() end
    end
  else
    aoeSince = nil
  end
end

local ENEMY_SUB = {
  SWING_DAMAGE = true, RANGE_DAMAGE = true, SPELL_DAMAGE = true, SPELL_PERIODIC_DAMAGE = true,
  SWING_MISSED = true, RANGE_MISSED = true, SPELL_MISSED = true, SPELL_PERIODIC_MISSED = true,
}

local FRIENDLY = 0x07   -- afiliación: propio / grupo / banda (incluye mascotas propias)

local function IsHostileNpc(flags)
  return flags and bor(flags, HOSTILE) ~= 0 and bor(flags, NPC) ~= 0
end
local function IsFriendlySide(flags)
  return flags and bor(flags, FRIENDLY) ~= 0
end

local function OnLog(_, sub, sGUID, _, sFlags, dGUID, _, dFlags)
  if ENEMY_SUB[sub] then
    -- el jugador, su mascota o su grupo golpean a un enemigo, o el enemigo los golpea
    if IsHostileNpc(dFlags) and IsFriendlySide(sFlags) then
      SeenEnemy(dGUID, GetTime())
    elseif IsHostileNpc(sFlags) and IsFriendlySide(dFlags) then
      SeenEnemy(sGUID, GetTime())
    end
  elseif sub == "UNIT_DIED" or sub == "PARTY_KILL" then
    if dGUID then ForgetEnemy(dGUID) end
  end
end

local aoeFrame = CreateFrame("Frame")
aoeFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
aoeFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
aoeFrame:SetScript("OnEvent", function(self, event, ...)
  if event == "COMBAT_LOG_EVENT_UNFILTERED" then
    if not Off() then OnLog(...) end
  elseif event == "PLAYER_REGEN_DISABLED" then
    playerGUID = UnitGUID("player")
    inCombat = true
    for k in pairs(enemies) do enemies[k] = nil end
    nEnemies = 0
    self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
  else
    inCombat = false
    self:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
    for k in pairs(enemies) do enemies[k] = nil end
    nEnemies = 0
    aoeSince, lowSince = nil, nil
    -- el AoE automatico no se queda activo fuera de combate
    if autoSet and PF.db and PF.db.aoe then PF.db.aoe = false end
    autoSet = false
  end
end)

------------------------------------------------------------------------------
-- Clic izquierdo sobre el HUD = /pf aoe (solo con el HUD bloqueado) y aviso.
-- Lo llama el nucleo al final de cada actualizacion del HUD.
------------------------------------------------------------------------------
local clickHooked = false
local function ClickSync(hud)
  if not hud or not PF.db or not PF.db.hud then return end
  if not clickHooked then
    clickHooked = true
    hud:SetScript("OnMouseUp", function(_, button)
      if button ~= "LeftButton" or Off() then return end
      if not (PF.db.hud and PF.db.hud.locked) or PF.db.plusClick ~= true then return end
      local cmd = SlashCmdList and SlashCmdList["PULSEFLASH"]
      if cmd then cmd("aoe") end
    end)
  end
  local want = (not Off()) and PF.db.plusClick == true and PF.db.hud.locked
  local has = hud:IsMouseEnabled() and true or false
  if want and not has then hud:EnableMouse(true)
  elseif (not want) and has and PF.db.hud.locked then hud:EnableMouse(false) end
end

------------------------------------------------------------------------------
-- 5. Temporizadores de efectos (DoTs): iconos bajo el HUD con los segundos que
--    les quedan a los efectos a punto de caerse. Se alimentan de PF.Dot.
------------------------------------------------------------------------------
local NOTE_TTL = 1.5       -- s que un temporizador sigue visible sin que el modulo lo reevalue
local seen = {}            -- [hechizo] = { exp = tiempo de caida, at = ultima vez visto }

function PF.NoteDot(spell, left)
  if Off() or PF.V then return end      -- nunca anotar tiempos virtuales (proyección / simulador)
  local now = GetTime()
  local e = seen[spell]
  if not e then e = {}; seen[spell] = e end
  e.at = now
  e.exp = (left and left > 0) and (now + left) or nil
end

local MAXC = 3
local ICON, CELL, FSZ = 18, 50, 12      -- tamano base (se multiplica por el tamano elegido)
local DEF_Y = -16                       -- distancia por defecto bajo el HUD
local strip, lastDraw, hudRef = nil, 0, nil
local moving, dragging, prevTest = false, false, nil

local function Scale() return (PF.db and PF.db.plusScale) or 1.5 end

local function ApplyPos()
  if not (strip and hudRef) then return end
  local sc = Scale()
  strip:SetScale(sc)
  strip:ClearAllPoints()
  strip:SetPoint("TOP", hudRef, "BOTTOM", ((PF.db.plusX or 0)) / sc, ((PF.db.plusY or DEF_Y)) / sc)
end

local function BuildStrip(hud)
  hudRef = hud
  strip = CreateFrame("Frame", nil, hud)
  strip:SetWidth(CELL * MAXC); strip:SetHeight(ICON + 2)
  strip.c = {}
  for i = 1, MAXC do
    local f = CreateFrame("Frame", nil, strip)
    f:SetWidth(CELL - 4); f:SetHeight(ICON)
    f.tex = f:CreateTexture(nil, "ARTWORK")
    f.tex:SetWidth(ICON); f.tex:SetHeight(ICON)
    f.tex:SetPoint("LEFT", f, "LEFT", 0, 0)
    f.tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    f.txt = f:CreateFontString(nil, "OVERLAY")
    PF.SetLFont(f.txt, "Fonts\\FRIZQT__.TTF", FSZ, "OUTLINE")
    f.txt:SetPoint("LEFT", f.tex, "RIGHT", 3, 0)
    f:Hide()
    strip.c[i] = f
  end
  strip.toast = strip:CreateFontString(nil, "OVERLAY")
  PF.SetLFont(strip.toast, "Fonts\\FRIZQT__.TTF", 12, "OUTLINE")
  strip.toast:SetJustifyH("LEFT")
  -- capa de arrastre (solo activa en modo "mover")
  local h = CreateFrame("Frame", nil, strip)
  h:SetAllPoints(strip)
  h.bg = h:CreateTexture(nil, "BACKGROUND")
  h.bg:SetAllPoints(h)
  h.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
  h.bg:SetVertexColor(1, 0.82, 0, 0.35)
  h:EnableMouse(true)
  h:SetFrameLevel(strip:GetFrameLevel() + 8)
  local sx, sy, cx0, cy0
  h:SetScript("OnMouseDown", function()
    cx0, cy0 = GetCursorPosition()
    sx, sy = PF.db.plusX or 0, PF.db.plusY or DEF_Y
    dragging = true
  end)
  h:SetScript("OnMouseUp", function() dragging = false end)
  h:SetScript("OnUpdate", function()
    if not dragging then return end
    local cx, cy = GetCursorPosition()
    local es = hudRef:GetEffectiveScale()
    PF.db.plusX = floor(sx + (cx - cx0) / es + 0.5)
    PF.db.plusY = floor(sy + (cy - cy0) / es + 0.5)
    ApplyPos()
  end)
  h:Hide()
  strip.drag = h
  ApplyPos()
end

local scratch = {}
local SAMPLE = { { 12, "Interface\\Icons\\INV_Misc_QuestionMark" }, { 4, "Interface\\Icons\\INV_Misc_QuestionMark" }, { 1.5, "Interface\\Icons\\INV_Misc_QuestionMark" } }

local function PaintCell(f, tex, rem, pos)
  f.tex:SetTexture(tex)
  if not rem or rem <= 0 then
    f.txt:SetText("--"); f.txt:SetTextColor(1, 0.25, 0.25)
  else
    f.txt:SetText(rem < 10 and format("%.1f", rem) or format("%d", floor(rem)))
    if rem <= 2 then f.txt:SetTextColor(1, 0.25, 0.25)
    elseif rem <= 5 then f.txt:SetTextColor(1, 0.82, 0)
    else f.txt:SetTextColor(0.45, 1, 0.55) end
  end
  f:ClearAllPoints()
  f:SetPoint("LEFT", strip, "LEFT", (pos - 1) * CELL, 0)
  f:Show()
end

-- Lo llama el nucleo al final de cada actualizacion del HUD.
function PF.ExtrasDraw(hud)
  ClickSync(hud)
  if Off() or not hud or not hud:IsShown() then
    if strip then strip:Hide() end
    return
  end
  local timersOn = PF.db.plusTimers ~= false
  local now = GetTime()
  if now - lastDraw < 0.1 and not moving then return end
  lastDraw = now
  if not strip then BuildStrip(hud) end

  local n = 0
  for spell, e in pairs(seen) do
    if now - e.at <= NOTE_TTL then
      n = n + 1
      scratch[n] = spell
    else
      seen[spell] = nil
    end
  end
  for i = #scratch, n + 1, -1 do scratch[i] = nil end
  table.sort(scratch, function(a, b)
    local ea, eb = seen[a], seen[b]
    local ra = ea and ea.exp and (ea.exp - now) or -1
    local rb = eb and eb.exp and (eb.exp - now) or -1
    if ra ~= rb then return ra < rb end
    return a < b
  end)

  local shownN = 0
  for i = 1, n do
    if shownN >= MAXC then break end
    local spell = scratch[i]
    local e = seen[spell]
    local tex = timersOn and e and PF.Texture(spell)
    if tex then
      shownN = shownN + 1
      PaintCell(strip.c[shownN], tex, e.exp and (e.exp - now) or nil, shownN)
    end
  end
  for i = n, 1, -1 do scratch[i] = nil end
  if shownN == 0 and moving then          -- ejemplo para poder colocarlo
    for i = 1, MAXC do PaintCell(strip.c[i], SAMPLE[i][2], SAMPLE[i][1], i) end
    shownN = MAXC
  end
  for i = shownN + 1, MAXC do strip.c[i]:Hide() end

  local hasToast = toastText and toastUntil and now < toastUntil
  if hasToast then
    strip.toast:ClearAllPoints()
    strip.toast:SetPoint("TOPLEFT", strip, "TOPLEFT", 0, -(ICON + 4))
    strip.toast:SetText(toastText); strip.toast:SetTextColor(toastCol[1], toastCol[2], toastCol[3])
    strip.toast:SetAlpha(math.min(1, (toastUntil - now) / 0.6))
  else
    strip.toast:SetText("")
  end
  strip:SetWidth(math.max(shownN * CELL - 4, hasToast and CELL * MAXC or 1))
  strip:SetHeight(ICON + 2 + (hasToast and 16 or 0))
  if shownN > 0 or hasToast then strip:Show() else strip:Hide() end
end

-- Interfaz para el panel de configuracion
function PF.TimersScale() return Scale() end
function PF.SetTimersScale(v)
  if not PF.db then return end
  PF.db.plusScale = v
  ApplyPos()
end
function PF.TimersMoving() return moving end
function PF.SetTimersMove(on)
  if not PF.db then return end
  if on and not moving then
    moving = true
    prevTest = PF.hudTest
    PF.hudTest = true                       -- vista previa para ver el HUD mientras lo colocas
    PF.db.plusTimers = true
    if strip then strip.drag:Show() end
  elseif not on and moving then
    moving, dragging = false, false
    if strip then strip.drag:Hide() end
    PF.hudTest = prevTest and true or false
  end
  if strip and moving then strip.drag:Show() end
  if PF.RefreshConfig then PF.RefreshConfig() end
end
function PF.ResetTimersPos()
  if not PF.db then return end
  PF.db.plusX, PF.db.plusY, PF.db.plusScale = nil, nil, nil
  ApplyPos()
end

------------------------------------------------------------------------------
-- /pf plus on | off | timers  (precision extra / temporizadores de efectos)
------------------------------------------------------------------------------
function PF.PrecisionCommand(arg)
  local db = PF.db
  if not db then return end
  if arg == "timers" then
    db.plusTimers = (db.plusTimers == false)
    PF.Msg(PF.T("t_timers") .. ": " .. (db.plusTimers ~= false and PF.T("ON_M") or PF.T("OFF_M")))
    if PF.RefreshConfig then PF.RefreshConfig() end
    return
  end
  if arg == "on" then db.plusOff = nil
  elseif arg == "off" then db.plusOff = true
  else db.plusOff = (not db.plusOff) or nil end
  PF.Msg(PF.T("t_precision") .. ": " .. (db.plusOff and PF.T("OFF_M") or PF.T("ON_M")))
  if PF.RefreshConfig then PF.RefreshConfig() end
end
