local PF = PulseFlash

PF.SOUNDS = {
  { id = "none",    name = "Ninguno" },
  { id = "raid",    name = "Alerta de banda",   sound = "RaidWarning" },
  { id = "boss",    name = "Aviso de jefe",     sound = "RaidBossEmoteWarning" },
  { id = "ping",    name = "Ping de mapa",      sound = "MapPing" },
  { id = "ready",   name = "Control de listos", sound = "ReadyCheck" },
  { id = "auction", name = "Campanilla",        sound = "AuctionWindowOpen" },
  { id = "alarm2",  name = "Alarma suave",      sound = "AlarmClockWarning2" },
  { id = "alarm3",  name = "Alarma",            sound = "AlarmClockWarning3" },
  { id = "tell",    name = "Susurro",           sound = "TellMessage" },
  { id = "level",   name = "Nivel",             sound = "LevelUp" },
  { id = "pvp",     name = "Aviso JcJ",         sound = "PVPWarningHorde" },
  { id = "bell",    name = "Campana",           file = "Sound\\Doodad\\BellTollAlliance.wav" },
  { id = "alarm1",  name = "Alarma corta",      sound = "AlarmClockWarning1" },
  { id = "pvpa",    name = "Aviso JcJ (Alianza)", sound = "PVPWarningAlliance" },
  { id = "coin",    name = "Monedas",           sound = "LOOTWINDOWCOINSOUND" },
  { id = "invite",  name = "Invitaci\195\179n",    sound = "igPlayerInvite" },
  { id = "talent",  name = "Talentos",          sound = "TalentScreenOpen" },
  { id = "aclose",  name = "Subasta cerrada",   sound = "AuctionWindowClose" },
  { id = "bellh",   name = "Campana de la Horda", file = "Sound\\Doodad\\BellTollHorde.wav" },
  { id = "belln",   name = "Campana elfa",      file = "Sound\\Doodad\\BellTollNightElf.wav" },
  { id = "bellt",   name = "Campana tribal",    file = "Sound\\Doodad\\BellTollTribal.wav" },
}
local byId, indexOf = {}, {}
for i, s in ipairs(PF.SOUNDS) do byId[s.id] = s; indexOf[s.id] = i end

local DEFAULT_ORDER = { "raid", "ping", "ready", "alarm2", "auction", "tell" }

function PF.PlaySoundEntry(id)
  local s = byId[id]
  if not s or id == "none" then return end
  if s.file then pcall(PlaySoundFile, s.file)
  elseif s.sound then pcall(PlaySound, s.sound) end
end

function PF.SoundName(id)
  local s = byId[id] or byId.none
  local key = "snd_" .. s.id
  local t = PF.T(key)
  return (t ~= key) and t or s.name
end

function PF.SoundCycle(id, step)
  local n = #PF.SOUNDS
  local i = ((indexOf[id] or 1) - 1 + step) % n + 1
  return PF.SOUNDS[i].id
end

local PROCS = {
  DEATHKNIGHT = { { key = "KillingMachine" }, { key = "Rime" } },
  DRUID       = { { key = "EclipseLunar" }, { key = "EclipseSolar" }, { key = "Clearcasting" } },
  HUNTER      = { { key = "LockAndLoad" } },
  MAGE        = { { key = "HotStreak" }, { key = "MissileBarrage" }, { key = "BrainFreeze" },
                  { key = "FingersOfFrost" } },
  PALADIN     = { { key = "ArtOfWar" } },
  SHAMAN      = { { key = "MaelstromWeapon", stacks = 5 } },
  WARLOCK     = { { key = "ShadowTrance" }, { key = "Backlash" }, { key = "Decimation" },
                  { key = "MoltenCore" }, { key = "Eradication" } },
  PRIEST      = { { key = "SurgeOfLight", id = 33151 }, { key = "Serendipity", id = 63735 } },
  WARRIOR     = { { key = "TasteForBlood" }, { key = "SuddenDeath" }, { key = "Bloodsurge" } },

}

PF.procList = {}

function PF.GetProcSound(proc)
  local S = PF.db and PF.db.sound
  local v = S and S.procs and S.procs[proc.key]
  if v and byId[v] then return v end
  return proc.default
end

function PF.SetProcSound(proc, id)
  local S = PF.db and PF.db.sound
  if S and byId[id] then S.procs[proc.key] = id end
end

local state = {}
local lastPlayed = 0
local MIN_GAP = 0.4

local function Scan(silent)
  local S = PF.db and PF.db.sound
  for _, proc in ipairs(PF.procList) do
    local left, count = PF.Aura("player", proc.name)
    local active = (left ~= nil) and (count >= (proc.stacks or 1))
    if active and not state[proc.key] and not silent and PF.db.enabled then
      if PF.Alerts then PF.Alerts.Show(proc) end
      if S and S.enabled then
        local now = GetTime()
        if now - lastPlayed >= MIN_GAP then
          lastPlayed = now
          PF.PlaySoundEntry(PF.GetProcSound(proc))
        end
      end
    end
    state[proc.key] = active
  end
end

local myClass

-- Procs de la clase + avisos personalizados que el usuario agrego por nombre
local function BuildList()
  wipe(PF.procList)
  local n = 0
  for _, def in ipairs(PROCS[myClass] or {}) do
    local name = PF.N[def.key] or (def.id and (GetSpellInfo(def.id)))
    if name then
      n = n + 1
      PF.procList[n] = {
        key = def.key, name = name, stacks = def.stacks,
        default = DEFAULT_ORDER[(n - 1) % #DEFAULT_ORDER + 1],
      }
    end
  end
  local A = PF.db and PF.db.alert
  if A and A.custom then
    for _, nm in ipairs(A.custom) do
      n = n + 1
      PF.procList[n] = { key = "c_" .. nm, name = nm, custom = true,
                         default = DEFAULT_ORDER[(n - 1) % #DEFAULT_ORDER + 1] }
    end
  end
end

function PF.Sounds_Rebuild()
  BuildList()
  Scan(true)
end

function PF.Sounds_Init(class)
  myClass = class
  if PF.Alerts then PF.Alerts.Cfg() end   -- crea la configuracion y recorta los avisos al maximo
  BuildList()
  if class then PROCS = { [class] = PROCS[class] } end

  local f = CreateFrame("Frame")
  f:RegisterEvent("UNIT_AURA")
  f:RegisterEvent("PLAYER_ENTERING_WORLD")
  f:SetScript("OnEvent", function(_, event, unit)
    if event == "UNIT_AURA" then
      if unit == "player" then Scan(false) end
    else
      Scan(true)
    end
  end)
  PF.RegisterProfileCallback(function() Scan(true) end)
  Scan(true)
end

------------------------------------------------------------------------------
-- Avisos en pantalla cuando aparece un proc (icono + nombre).
-- Antes vivian en PulseFlash_Plus/Alerts.lua; Scan() los llama con PF.Alerts.Show.
------------------------------------------------------------------------------
do
local A = {}
PF.Alerts = A

local GetTime, floor = GetTime, math.floor
local ROWS, ROW_H, ICON = 3, 48, 40
local FADE_IN, FADE_OUT, POP = 0.12, 0.5, 0.18
local DEFAULT_Y = 230
local MAX_CUSTOM = 4          -- avisos personalizados como maximo
A.MAX_CUSTOM = MAX_CUSTOM

local function Cfg()
  local d = PF.db
  if not d then return nil end
  local a = d.alert
  if not a then a = {}; d.alert = a end
  if a.enabled == nil then a.enabled = true end
  if a.scale == nil then a.scale = 1.0 end
  if a.dur == nil then a.dur = 2.5 end
  if a.icon == nil then a.icon = true end
  if a.text == nil then a.text = true end
  if not a.off then a.off = {} end
  if not a.custom then a.custom = {} end
  while #a.custom > MAX_CUSTOM do table.remove(a.custom) end
  return a
end
A.Cfg = Cfg

local root, rows, moving, dragging
local TEXT_COL = { 1, 0.82, 0.1 }

local function ApplyPos()
  if not root then return end
  local a = Cfg()
  local s = a.scale
  root:SetScale(s)
  root:ClearAllPoints()
  root:SetPoint("CENTER", UIParent, "CENTER", (a.x or 0) / s, (a.y or DEFAULT_Y) / s)
end

local function Layout(row, a)
  row.icon:ClearAllPoints(); row.text:ClearAllPoints()
  local showI, showT = a.icon, a.text
  if not showI and not showT then showI = true end
  if showI then
    row.icon:Show()
    row.icon:SetPoint("LEFT", row, "LEFT", 0, 0)
  else
    row.icon:Hide()
  end
  if showT then
    row.text:Show()
    if showI then row.text:SetPoint("LEFT", row.icon, "RIGHT", 10, 0)
    else row.text:SetPoint("LEFT", row, "LEFT", 0, 0) end
  else
    row.text:Hide()
  end
end

local function Build()
  if root then return end
  root = CreateFrame("Frame", "PulseFlashProcAlert", UIParent)
  root:SetWidth(320); root:SetHeight(ROW_H * ROWS)
  root:SetFrameStrata("HIGH")
  rows = {}
  for i = 1, ROWS do
    local r = CreateFrame("Frame", nil, root)
    r:SetWidth(300); r:SetHeight(ICON)
    r:SetPoint("TOP", root, "TOP", 0, -((i - 1) * ROW_H))
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetWidth(ICON); r.icon:SetHeight(ICON)
    r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    r.text = r:CreateFontString(nil, "OVERLAY")
    PF.SetLFont(r.text, "Fonts\\FRIZQT__.TTF", 24, "OUTLINE")
    r.text:SetTextColor(TEXT_COL[1], TEXT_COL[2], TEXT_COL[3])
    r.text:SetJustifyH("LEFT")
    r.s = {}
    r:Hide()
    rows[i] = r
  end
  -- capa de arrastre (modo mover)
  local h = CreateFrame("Frame", nil, root)
  h:SetAllPoints(root)
  h:SetFrameLevel(root:GetFrameLevel() + 20)
  h.bg = h:CreateTexture(nil, "BACKGROUND")
  h.bg:SetAllPoints(h)
  h.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
  h.bg:SetVertexColor(1, 0.82, 0, 0.30)
  h:EnableMouse(true)
  local sx, sy, cx0, cy0
  h:SetScript("OnMouseDown", function()
    local a = Cfg()
    cx0, cy0 = GetCursorPosition()
    sx, sy = a.x or 0, a.y or DEFAULT_Y
    dragging = true
  end)
  h:SetScript("OnMouseUp", function() dragging = false end)
  h:SetScript("OnUpdate", function()
    if not dragging then return end
    local a = Cfg()
    local cx, cy = GetCursorPosition()
    local es = UIParent:GetEffectiveScale()
    a.x = floor(sx + (cx - cx0) / es + 0.5)
    a.y = floor(sy + (cy - cy0) / es + 0.5)
    ApplyPos()
  end)
  h:Hide()
  root.drag = h

  root:SetScript("OnUpdate", function()
    local now = GetTime()
    local a = Cfg()
    local any = false
    for i = 1, ROWS do
      local r = rows[i]
      if r.s.t0 then
        local t = now - r.s.t0
        local left = r.s.dur - t
        if left <= 0 then
          r.s.t0 = nil; r:Hide()
        else
          any = true
          local al = 1
          if t < FADE_IN then al = t / FADE_IN end
          if left < FADE_OUT then al = left / FADE_OUT end
          r:SetAlpha(al)
          r:SetScale(t < POP and (1.35 - 0.35 * (t / POP)) or 1)
        end
      end
    end
    if not any and not moving then root:Hide() end
  end)
  ApplyPos()
  root:Hide()
end

local function Fill(r, name, icon, dur)
  local a = Cfg()
  r.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
  r.text:SetText(name or "")
  Layout(r, a)
  r.s.t0, r.s.dur = GetTime(), dur
  r:SetAlpha(0)
  r:Show()
end

local function FreeRow()
  local oldest, ot
  for i = 1, ROWS do
    local r = rows[i]
    if not r.s.t0 then return r end
    if not ot or r.s.t0 < ot then oldest, ot = r, r.s.t0 end
  end
  return oldest
end

-- Se llama desde Scan (arriba) cuando un proc pasa a estar activo.
function A.Show(proc)
  local a = Cfg()
  if not a or not a.enabled or a.off[proc.key] then return end
  Build()
  local _, _, icon = UnitBuff("player", proc.name)
  if not icon and PF.Texture then icon = PF.Texture(proc.name) end
  Fill(FreeRow(), proc.name, icon, a.dur)
  ApplyPos()
  root:Show()
end

function A.Test(name)
  local a = Cfg()
  if not a then return end
  Build()
  local icon = name and select(3, UnitBuff("player", name)) or nil
  if not icon and name and PF.Texture then icon = PF.Texture(name) end
  Fill(FreeRow(), name or "Proc", icon, a.dur)
  ApplyPos()
  root:Show()
end

function A.SetScale(v)
  local a = Cfg(); if not a then return end
  a.scale = v
  ApplyPos()
end
function A.IsMoving() return moving and true or false end
function A.SetMove(on)
  local a = Cfg(); if not a then return end
  Build()
  if on and not moving then
    moving = true
    for i = 1, ROWS do
      Fill(rows[i], i == 1 and "Proc" or "", "Interface\\Icons\\INV_Misc_QuestionMark", 1e9)
      rows[i]:SetAlpha(1); rows[i]:SetScale(1)
      if i > 1 then rows[i]:Hide(); rows[i].s.t0 = nil end
    end
    ApplyPos()
    root.drag:Show(); root:Show()
  elseif not on and moving then
    moving, dragging = false, false
    root.drag:Hide()
    for i = 1, ROWS do rows[i].s.t0 = nil; rows[i]:Hide() end
    root:Hide()
  end
  if PF.RefreshConfig then PF.RefreshConfig() end
end
function A.ResetPos()
  local a = Cfg(); if not a then return end
  a.x, a.y, a.scale = nil, nil, 1.0
  ApplyPos()
end

-- Avisos personalizados: nombres exactos de buffs (cualquier clase)
function A.AddCustom(name)
  local a = Cfg(); if not a then return false end
  name = (name or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if name == "" or #a.custom >= MAX_CUSTOM then return false end
  for _, n in ipairs(a.custom) do if n == name then return false end end
  a.custom[#a.custom + 1] = name
  if PF.Sounds_Rebuild then PF.Sounds_Rebuild() end
  return true
end
function A.RemoveCustom(i)
  local a = Cfg(); if not a or not a.custom[i] then return end
  table.remove(a.custom, i)
  if PF.Sounds_Rebuild then PF.Sounds_Rebuild() end
end

function A._state() return rows, root end
end
