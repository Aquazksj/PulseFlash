local PF = PulseFlash

local DB
local floor, ipairs, pairs, wipe = math.floor, ipairs, pairs, wipe

local BHUD_DEFAULT = { enabled = true, locked = true, x = 0, y = 300, scale = 1.0,
                       alphaCombat = 1.0, alphaOOC = 1.0, combat = true, pulse = true, glow = true }
PF.BHUD_DEFAULT = BHUD_DEFAULT

local PULSE_PERIOD, PULSE_MIN = 1.2, 0.35

local ICON, GAP, MAX_ICONS = 40, 4, 8
local EDGE = "Interface\\Buttons\\WHITE8X8"
local MEDIA = "Interface\\AddOns\\PulseFlash\\Media\\"

local GLOW_SIZE, RING_FROM, RING_TO, RING_TIME = ICON * 1.64, ICON * 1.23, ICON * 2.82, 0.55
local SPELLSTONES = { 41196, 22646, 13603, 13602, 5522 }

local IDS = {
  HUNTER = { Hawk = 13165, Dragonhawk = 61847, Viper = 34074, Monkey = 13163, Beast = 13161,
             Wild = 20043, Cheetah = 5118, Pack = 13159, Trueshot = 19506 },
  DEATHKNIGHT = { Horn = 57330, BoneShield = 49222, Blood = 48266, Frost = 48263, Unholy = 48265 },
  WARRIOR = { BattleShout = 6673, CommandingShout = 469,
              BattleStance = 2457, BerserkerStance = 2458, DefensiveStance = 71 },
  PALADIN = {

    Vengeance = 31801, Corruption = 53736, Command = 20375, Righteousness = 21084,
    Light = 20165, Wisdom = 20166, Justice = 20164,

    Devotion = 465, Retribution = 7294, Concentration = 19746, Sanctity = 20218,
    Crusader = 32223, FireRes = 19891, FrostRes = 19888, ShadowRes = 19876,

    Kings = 20217, Might = 19740, BWisdom = 19742, Sanctuary = 20911, RighteousFury = 25780,
    GreaterKings = 25898, GreaterMight = 25782, GreaterBWisdom = 25894, GreaterSanctuary = 25899,
  },
  SHAMAN = { WaterShield = 52127, LightningShield = 324, Windfury = 8232, Flametongue = 8024,
             Rockbiter = 8017,

             Searing = 3599, Magma = 8190, TotemOfWrath = 30706,
             StrengthOfEarth = 8075, Stoneskin = 8071,
             ManaSpring = 5675, HealingStream = 5394,
             WindfuryTotem = 8512, WrathOfAir = 3738 },
  PRIEST = { InnerFire = 588, Fortitude = 1243, PrayerFortitude = 21562,
             DivineSpirit = 14752, PrayerSpirit = 27681, ShadowProt = 976,
             PrayerShadowProt = 27683, Shadowform = 15473, VampiricEmbrace = 15286 },
  ROGUE = { DeadlyPoison = 2823, InstantPoison = 8681 },
  DRUID = { MarkOfWild = 1126, GiftOfWild = 21849, Thorns = 467, Omen = 16864 },
  MAGE = { Molten = 30482, MageArmor = 6117, IceArmor = 7302, FrostArmor = 168,
           ArcaneIntellect = 1459, ArcaneBrilliance = 23028 },
  WARLOCK = { FelArmor = 28176, DemonArmor = 706, DemonSkin = 687, CreateSpellstone = 2362 },
}

local B = {}
local list = {}
local ctx = {}
local check

local function Active(mine, refresh, ...)
  for i = 1, select("#", ...) do
    local n = select(i, ...)
    if n then
      local left = PF.Aura("player", n, false, mine)
      if left and left > (refresh or 0) then return true end
    end
  end
  return false
end

local function Need(spell)
  if not spell or #list >= MAX_ICONS then return end
  if not PF.Known(spell) then return end
  if PF.IsCasting(spell) or PF.Pending(spell) then return end
  if spell:find("^item:") and UnitCastingInfo("player") then return end
  if PF.State(spell) < 2 then return end
  for i = 1, #list do if list[i] == spell then return end end
  list[#list + 1] = spell
end

local function NeedTotem(spell)
  if not spell or #list >= MAX_ICONS then return end
  if PF.IsCasting(spell) or PF.Pending(spell) then return end
  if PF.TotemReady and not PF.TotemReady(spell) then return end
  for i = 1, #list do if list[i] == spell then return end end
  list[#list + 1] = spell
end

local function Want(cast, mine, refresh, ...)
  if not Active(mine, refresh, ...) then Need(cast) end
end

local poisonCache = {}
local function BestPoison(poisonName)
  if not poisonName then return nil end
  local e = poisonCache[poisonName]
  if e and (GetTime() - e.t) < 2 then return e.item end
  local bestID, bestLvl = nil, -1
  for bag = 0, 4 do
    for slot = 1, (GetContainerNumSlots(bag) or 0) do
      local link = GetContainerItemLink(bag, slot)
      if link then
        local name, _, _, _, minLevel = GetItemInfo(link)
        if name and name:sub(1, #poisonName) == poisonName then
          local id = tonumber(link:match("item:(%d+)"))
          if id and (minLevel or 0) > bestLvl then bestID, bestLvl = id, (minLevel or 0) end
        end
      end
    end
  end
  local item = bestID and PF.Item(bestID) or nil
  poisonCache[poisonName] = { t = GetTime(), item = item }
  return item
end

local function PickKey(...)
  for i = 1, select("#", ...) do
    local k = select(i, ...)
    if B[k] and PF.Known(B[k]) then return k end
  end
  return nil
end

local CHECK = {}

CHECK.HUNTER = function(c)

  local dps = PF.First(B.Dragonhawk, B.Hawk)
  local viper = B.Viper and PF.Aura("player", B.Viper)

  if not Active(false, 0, B.Hawk, B.Dragonhawk, B.Viper, B.Monkey, B.Wild, B.Cheetah) then
    Need(PF.First(B.Dragonhawk, B.Hawk, B.Monkey))
  elseif c.combat and not c.burn and c.manaPct <= 0.25 and not viper and PF.Known(B.Viper) then
    Need(B.Viper)
  elseif viper and c.manaPct >= 0.80 and dps then
    Need(dps)
  end
  Want(B.Trueshot, false, 0, B.Trueshot)
end

CHECK.MAGE = function(c)
  local hasMolten = PF.Aura("player", B.Molten)
  local hasMageArmor = PF.Aura("player", B.MageArmor)
  local any = hasMolten or hasMageArmor or PF.Aura("player", B.IceArmor) or PF.Aura("player", B.FrostArmor)
  if not any then
    Need(PF.First(B.Molten, B.MageArmor, B.IceArmor, B.FrostArmor))
  elseif c.combat and not c.burn and c.manaPct <= 0.25 and not hasMageArmor and PF.Known(B.MageArmor) then
    Need(B.MageArmor)
  elseif hasMageArmor and c.manaPct >= 0.80 and PF.Known(B.Molten) then
    Need(B.Molten)
  end
  Want(B.ArcaneIntellect, false, 0, B.ArcaneIntellect, B.ArcaneBrilliance)
end

CHECK.WARLOCK = function(c)
  Want(PF.First(B.FelArmor, B.DemonArmor, B.DemonSkin), false, 30, B.FelArmor, B.DemonArmor, B.DemonSkin)

  if DB.stone then
    local hasMH, mhExp = PF.WeaponEnchants()
    if (not hasMH) or (mhExp and mhExp < 120000) then
      local stone
      for i = 1, #SPELLSTONES do
        if (GetItemCount(SPELLSTONES[i]) or 0) > 0 then stone = PF.Item(SPELLSTONES[i]); break end
      end
      if stone then Need(stone)
      elseif not c.combat then Need(B.CreateSpellstone) end
    end
  end
end

CHECK.PRIEST = function(c)
  Want(B.Fortitude, false, 0, B.Fortitude, B.PrayerFortitude)
  Want(B.DivineSpirit, false, 0, B.DivineSpirit, B.PrayerSpirit)
  Want(B.ShadowProt, false, 0, B.ShadowProt, B.PrayerShadowProt)
  Want(B.InnerFire, false, 0, B.InnerFire)
  if c.spec == 3 then Want(B.VampiricEmbrace, false, 0, B.VampiricEmbrace) end

  if c.spec == 3 then Want(B.Shadowform, false, 0, B.Shadowform) end
end

CHECK.PALADIN = function(c)

  if c.spec == 2 then Want(B.RighteousFury, true, 0, B.RighteousFury) end

  if not Active(true, 0, B.Vengeance, B.Corruption, B.Command, B.Righteousness,
                B.Light, B.Wisdom, B.Justice) then
    Need(PF.First(B.Vengeance, B.Corruption, B.Command, B.Righteousness))
  end

  local spec = c.spec
  local want
  if spec == 3 then want = PF.First(B.Sanctity, B.Retribution, B.Devotion)
  elseif spec == 2 then want = PF.First(B.Devotion, B.Retribution)
  else want = PF.First(B.Concentration, B.Devotion, B.Retribution) end
  if want then
    if spec == 3 then
      Want(want, true, 0, want)
    else
      Want(want, true, 0, B.Devotion, B.Retribution, B.Concentration, B.Sanctity,
           B.Crusader, B.FireRes, B.FrostRes, B.ShadowRes)
    end
  end

  local key
  if spec == 1 then key = PickKey("BWisdom", "Might")
  elseif spec == 2 then key = PickKey("Kings", "Sanctuary", "Might")
  else key = PickKey("Might", "BWisdom") end
  if key then
    Want(B[key], false, 0,
         B.Kings, B.GreaterKings, B.BWisdom, B.GreaterBWisdom,
         B.Might, B.GreaterMight, B.Sanctuary, B.GreaterSanctuary)
  end
end

CHECK.SHAMAN = function(c)

  if not Active(true, 0, B.WaterShield, B.LightningShield) then
    if c.spec == 2 then Need(PF.First(B.LightningShield, B.WaterShield))
    else Need(PF.First(B.WaterShield, B.LightningShield)) end
  end

  local hasMH, mhExp, _, _, hasOH, ohExp = PF.WeaponEnchants()
  if GetInventoryItemLink("player", 16) and ((not hasMH) or (mhExp and mhExp < 60000)) then
    Need(PF.First(c.spec == 2 and B.Windfury or B.Flametongue, B.Flametongue, B.Rockbiter))
  end
  if c.spec == 2 and OffhandHasWeapon and OffhandHasWeapon() and ((not hasOH) or (ohExp and ohExp < 60000)) then
    Need(PF.First(B.Flametongue, B.Rockbiter))
  end

  for slot = 1, 4 do
    if not PF.TotemPresent(slot) then NeedTotem(PF.TotemChoice and PF.TotemChoice(slot, c.spec)) end
  end
end

CHECK.WARRIOR = function(c)

  if c.spec == 3 then
    if GetShapeshiftForm() ~= 2 then Need(B.DefensiveStance) end
  else
    local berserk = (c.spec == 2 and PF.Known(B.BerserkerStance)) and true or false
    if GetShapeshiftForm() ~= (berserk and 3 or 1) then
      Need(berserk and B.BerserkerStance or B.BattleStance)
    end
  end

  local shout = (c.spec == 3) and PF.First(B.CommandingShout, B.BattleShout) or PF.First(B.BattleShout, B.CommandingShout)
  Want(shout, false, 10, B.BattleShout, B.CommandingShout)
end

CHECK.DEATHKNIGHT = function(c)

  -- Solo avisa si no tienes NINGUNA presencia; si llevas otra, se respeta.
  if not Active(false, 0, B.Blood, B.Frost, B.Unholy) then
    local want
    if DB.dkTank and PF.Known(B.Frost) then want = B.Frost
    elseif c.spec == 1 then want = PF.First(B.Frost, B.Blood)
    elseif c.spec == 3 and PF.Known(B.Unholy) then want = B.Unholy
    else want = PF.First(B.Blood, B.Unholy) end
    if want then Need(want) end
  end
  Want(B.Horn, false, 10, B.Horn)
  Want(B.BoneShield, false, 0, B.BoneShield)
end

CHECK.DRUID = function(c)
  Want(B.MarkOfWild, false, 0, B.MarkOfWild, B.GiftOfWild)
  Want(B.Thorns, false, 0, B.Thorns)
  Want(B.Omen, false, 0, B.Omen)
end

CHECK.ROGUE = function(c)
  if not DB.poison or c.level < 20 then return end
  local hasMH, mhExp, _, _, hasOH, ohExp = PF.WeaponEnchants()
  local deadly, instant = BestPoison(B.DeadlyPoison), BestPoison(B.InstantPoison)
  if GetInventoryItemLink("player", 16) and ((not hasMH) or (mhExp and mhExp < 120000)) then
    Need((c.spec == 1) and (deadly or instant) or (instant or deadly))
  end
  if OffhandHasWeapon and OffhandHasWeapon() and ((not hasOH) or (ohExp and ohExp < 120000)) then
    Need((c.spec == 1) and (instant or deadly) or (deadly or instant))
  end
end

local function Compute()
  wipe(list)
  if not (DB and DB.enabled and check) then return list end
  if UnitIsDeadOrGhost("player") or (IsMounted and IsMounted())
     or (UnitInVehicle and UnitInVehicle("player")) then
    return list
  end
  ctx.level = UnitLevel("player")
  ctx.combat = UnitAffectingCombat("player") and true or false
  ctx.spec = PF.spec
  ctx.burn = PF.burn and true or false
  local mm = UnitPowerMax("player", 0) or 0
  ctx.manaPct = (mm > 0) and ((UnitPower("player", 0) or 0) / mm) or 1
  local ok, err = pcall(check, ctx)
  if not ok and err ~= PF.lastErr then
    PF.lastErr = err
    PF.Msg(PF.T("error", tostring(err)))
  end
  return list
end

function PF.BuffList() return list end

local hud, icons = nil, {}

local function MakeIcon(parent)
  local f = CreateFrame("Frame", nil, parent)
  f:SetWidth(ICON); f:SetHeight(ICON)
  f:SetBackdrop({ bgFile = EDGE, edgeFile = EDGE, edgeSize = 1,
                  insets = { left = 1, right = 1, top = 1, bottom = 1 } })
  f:SetBackdropColor(0, 0, 0, 1)
  f:SetBackdropBorderColor(0.05, 0.05, 0.05, 1)
  f.icon = f:CreateTexture(nil, "ARTWORK")
  f.icon:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1)
  f.icon:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 1)
  f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  f.top = CreateFrame("Frame", nil, f)
  f.top:SetAllPoints(f)
  f.top:SetFrameLevel(f:GetFrameLevel() + 4)
  f.glow = f.top:CreateTexture(nil, "ARTWORK")
  f.glow:SetTexture(MEDIA .. "glow_sq.tga"); f.glow:SetBlendMode("ADD")
  f.glow:SetVertexColor(1.00, 0.82, 0.10)
  f.glow:SetWidth(GLOW_SIZE); f.glow:SetHeight(GLOW_SIZE)
  f.glow:SetPoint("CENTER", f, "CENTER", 0, 0)
  f.ring = f.top:CreateTexture(nil, "ARTWORK")
  f.ring:SetTexture(MEDIA .. "pulse_ring.tga"); f.ring:SetBlendMode("ADD")
  f.ring:SetVertexColor(1.00, 0.88, 0.35)
  f.ring:SetPoint("CENTER", f, "CENTER", 0, 0)
  f.ring:Hide()
  f:Hide()
  return f
end

local function ApplyPos()
  if not (hud and DB and DB.bhud) then return end
  local H = DB.bhud
  hud:SetScale(H.scale)
  hud:ClearAllPoints()
  hud:SetPoint("CENTER", UIParent, "CENTER", H.x / H.scale, H.y / H.scale)
end

local function SavePos()
  local cx, cy = hud:GetCenter()
  local ucx, ucy = UIParent:GetCenter()
  if not (cx and ucx) then return end
  local hs = hud:GetScale()
  DB.bhud.x = floor(cx * hs - ucx + 0.5)
  DB.bhud.y = floor(cy * hs - ucy + 0.5)
end

local function ApplyLock()
  if not (hud and DB and DB.bhud) then return end
  if DB.bhud.locked then
    hud:EnableMouse(false)
    hud.drag:Hide()
  else
    hud:EnableMouse(true)
    hud.drag:Show()
  end
end

local function Build()
  if hud then return end
  hud = CreateFrame("Frame", "PulseFlashBuffHUD", UIParent)
  hud:SetFrameStrata("MEDIUM")
  hud:SetClampedToScreen(true)
  hud:SetMovable(true)
  hud:SetUserPlaced(false)
  hud:RegisterForDrag("LeftButton")
  hud:SetWidth(ICON * 3 + GAP * 2); hud:SetHeight(ICON)
  for i = 1, MAX_ICONS do icons[i] = MakeIcon(hud) end

  hud.drag = CreateFrame("Frame", nil, hud)
  hud.drag:SetPoint("TOPLEFT", hud, "TOPLEFT", -4, 4)
  hud.drag:SetPoint("BOTTOMRIGHT", hud, "BOTTOMRIGHT", 4, -4)
  hud.drag:SetFrameLevel(hud:GetFrameLevel() + 10)
  hud.drag:SetBackdrop({ bgFile = EDGE, edgeFile = EDGE, edgeSize = 2,
                         insets = { left = 2, right = 2, top = 2, bottom = 2 } })
  hud.drag:SetBackdropColor(0.25, 0.85, 1.00, 0.20)
  hud.drag:SetBackdropBorderColor(0.25, 0.85, 1.00, 1)
  hud.drag.text = hud.drag:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  hud.drag.text:SetPoint("BOTTOM", hud.drag, "TOP", 0, 4)
  hud.drag.text:SetText(PF.T("bhudDrag"))
  PF.OnLangChange(function() hud.drag.text:SetText(PF.T("bhudDrag")) end)
  hud.drag:Hide()

  hud:SetScript("OnDragStart", function(self)
    if DB.bhud and not DB.bhud.locked then self:StartMoving() end
  end)
  hud:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    SavePos()
    ApplyPos()
  end)
  hud.base, hud.pulse = 1, false
  local t, T = 0, 0
  hud:SetScript("OnUpdate", function(self, dt)
    if self.pulse then
      t = (t + dt) % PULSE_PERIOD
      local k = 0.5 + 0.5 * math.cos(2 * math.pi * t / PULSE_PERIOD)
      self:SetAlpha(self.base * (PULSE_MIN + (1 - PULSE_MIN) * k))
    end
    if not self.glowOn then return end
    T = T + dt
    local g0 = 0.72 + 0.28 * math.sin(T * 3.4)
    for i = 1, MAX_ICONS do
      local f = icons[i]
      if f:IsShown() then
        local g = g0
        if f.pt then
          f.pt = f.pt + dt
          local k = f.pt / RING_TIME
          if k >= 1 then
            f.pt = nil; f.ring:Hide()
          else
            local e = 1 - (1 - k) * (1 - k)
            local sz = RING_FROM + (RING_TO - RING_FROM) * e
            f.ring:SetWidth(sz); f.ring:SetHeight(sz); f.ring:SetAlpha(0.9 * (1 - k))
            g = g + 0.8 * (1 - math.min(1, f.pt / 0.45))
          end
        end
        f.glow:SetAlpha(math.min(1, g))
      end
    end
  end)
  ApplyPos()
  ApplyLock()
  hud:Hide()
end

local layoutN
local function Layout(n)
  if layoutN == n then return end
  layoutN = n
  local total = n * ICON + math.max(n - 1, 0) * GAP
  local w = math.max(total, ICON * 3 + GAP * 2)
  hud:SetWidth(w)
  local x0 = (w - total) / 2
  for i = 1, MAX_ICONS do
    local f = icons[i]
    if i <= n then
      f:ClearAllPoints()
      f:SetPoint("LEFT", hud, "LEFT", x0 + (i - 1) * (ICON + GAP), 0)
    else
      f.spell = nil
      f:Hide()
    end
  end
end

local function Refresh()
  if not hud then return end
  local H = DB and DB.bhud
  if not H or not DB.enabled or (not H.enabled and not PF.bhudTest) then
    hud:Hide()
    return
  end
  local inCombat = UnitAffectingCombat("player") and true or false
  Compute()
  local n = #list
  if n > 0 and inCombat and not H.combat and not PF.bhudTest then n = 0 end

  local sample
  if n == 0 and PF.bhudTest then
    sample = {}
    for k = 1, 40 do
      local tex = GetSpellTexture(k, "spell")
      local dup = false
      for j = 1, #sample do if sample[j] == tex then dup = true end end
      if tex and not dup then sample[#sample + 1] = tex end
      if #sample == 5 then break end
    end
    n = #sample
  end

  if n == 0 and H.locked then
    hud:Hide()
    return
  end
  if H.locked then
    hud.base = inCombat and (H.alphaCombat or 1) or (H.alphaOOC or 1)
  else
    hud.base = 1
  end
  hud.pulse = H.pulse and H.locked
  if not hud.pulse then hud:SetAlpha(hud.base) end
  Layout(n)
  local wasShown = hud:IsShown()
  local glowOn = H.glow and true or false
  hud.glowOn = glowOn
  for i = 1, n do
    local f = icons[i]
    local spell = (not sample) and list[i] or nil
    local tex = sample and sample[i] or (spell and PF.Texture(spell))
    if tex then
      local isNew = (not f:IsShown()) or f.spell ~= spell or not wasShown
      f.spell = spell
      f.icon:SetTexture(tex)
      f:Show()
      if glowOn then
        f.glow:Show()
        if isNew then
          f.pt = 0
          f.ring:SetWidth(RING_FROM); f.ring:SetHeight(RING_FROM); f.ring:SetAlpha(0.9); f.ring:Show()
        end
      else
        f.glow:Hide(); f.ring:Hide(); f.pt = nil
      end
    else
      f.spell = nil
      f:Hide()
    end
  end
  hud:Show()
end

function PF.BuffHUDApplyPos() ApplyPos() end
function PF.BuffHUDApplyLock() ApplyLock() end
function PF.BuffHUDApply() ApplyPos(); ApplyLock() end

function PF.ToggleBuffHUDLock()
  if not (DB and DB.bhud) then return end
  if DB.bhud.locked then
    DB.bhud.enabled = true
    DB.bhud.locked = false
    PF.Msg(PF.T("bhudUnlocked"))
  else
    DB.bhud.locked = true
    PF.Msg(PF.T("bhudLocked", DB.bhud.x, DB.bhud.y))
  end
  ApplyLock()
  if PF.RefreshConfig then PF.RefreshConfig() end
end

function PF.ToggleBuffHUDTest()
  PF.bhudTest = not PF.bhudTest
  PF.Msg(PF.T("bhudPreview", PF.bhudTest and PF.T("ON_F") or PF.T("OFF_F")))
  if PF.RefreshConfig then PF.RefreshConfig() end
end

function PF.ToggleBuffHUD()
  if not (DB and DB.bhud) then return end
  DB.bhud.enabled = not DB.bhud.enabled
  PF.Msg(PF.T("t_bhud") .. ": " .. (DB.bhud.enabled and PF.T("ON_M") or PF.T("OFF_M")))
  if PF.RefreshConfig then PF.RefreshConfig() end
end

function PF.BuffHUD_Init(class)
  DB = PF.db
  wipe(B)
  for k, id in pairs(IDS[class] or {}) do B[k] = GetSpellInfo(id) end
  check = CHECK[class]
  Build()
  local acc = 0
  local driver = CreateFrame("Frame")
  driver:SetScript("OnUpdate", function(_, dt)
    acc = acc + dt
    if acc < 0.25 then return end
    acc = 0
    local ok, err = pcall(Refresh)
    if not ok and err ~= PF.lastErr then
      PF.lastErr = err
      PF.Msg(PF.T("error", tostring(err)))
    end
  end)
end
