local PF = PulseFlash

-- Modulos de carga bajo demanda: no ocupan memoria hasta que se usan.
--   PulseFlash_Config   -> panel de configuracion (/pf config, boton del minimapa)
--   PulseFlash_Loadout  -> pestana "Barra recomendada" (la carga el propio panel)
--   PulseFlash_Sim      -> simulador de escenarios (pestana Simulador)
--   PulseFlash_<Clase>  -> reglas de rotacion: solo se carga la de TU clase
--   PulseFlash_Healer   -> asesor de sanacion (Sacerdote, Paladin, Chaman, Druida)
--   PulseFlash_ComboBar -> barra de combos (Picaro, Druida)
--   PulseFlash_APL      -> APL personalizado (solo si esta activado o se abre /pf apl)

local function Ensure(addon, flag)
  if PF[flag] then return true end
  if LoadAddOn then LoadAddOn(addon) end
  return PF[flag] and true or false
end

local function OpenStub() end
local function ToggleStub() end

function PF.OpenConfig()
  if not Ensure("PulseFlash_Config", "configLoaded") then PF.Msg(PF.T("noConfig")); return end
  if PF.OpenConfig ~= OpenStub then PF.OpenConfig() end
end
OpenStub = PF.OpenConfig

function PF.ToggleConfig()
  if not Ensure("PulseFlash_Config", "configLoaded") then PF.Msg(PF.T("noConfig")); return end
  if PF.ToggleConfig ~= ToggleStub then PF.ToggleConfig() end
end
ToggleStub = PF.ToggleConfig

-- ---------------------------------------------------------------------------
-- Modulos de clase: cada clase carga solo sus propios archivos
-- ---------------------------------------------------------------------------
local CLASS_ADDONS = {
  WARRIOR     = { "PulseFlash_Warrior" },
  PALADIN     = { "PulseFlash_Paladin", "PulseFlash_Healer" },
  HUNTER      = { "PulseFlash_Hunter" },
  ROGUE       = { "PulseFlash_Rogue", "PulseFlash_ComboBar" },
  PRIEST      = { "PulseFlash_Priest", "PulseFlash_Healer" },
  DEATHKNIGHT = { "PulseFlash_DeathKnight" },
  SHAMAN      = { "PulseFlash_Shaman", "PulseFlash_Healer" },
  MAGE        = { "PulseFlash_Mage" },
  WARLOCK     = { "PulseFlash_Warlock" },
  DRUID       = { "PulseFlash_Druid", "PulseFlash_Healer", "PulseFlash_ComboBar" },
}

function PF.LoadClassModules(class)
  local list = CLASS_ADDONS[class]
  if not list or not LoadAddOn then return end
  for i = 1, #list do
    if not IsAddOnLoaded(list[i]) then LoadAddOn(list[i]) end
  end
end

-- ---------------------------------------------------------------------------
-- APL personalizado: se carga al arrancar solo si el jugador lo tiene activado.
-- Mientras no este cargado, estas funciones lo cargan al primer uso.
-- ---------------------------------------------------------------------------
local function LazyStub(addon, name, fallback)
  local stub
  stub = function(...)
    if IsAddOnLoaded(addon) or not LoadAddOn then return fallback end
    LoadAddOn(addon)
    local real = PF[name]
    if real and real ~= stub then return real(...) end
    return fallback
  end
  PF[name] = stub
end

LazyStub("PulseFlash_APL", "APL_Command")
LazyStub("PulseFlash_APL", "APL_Edit")

-- Core llama a PF.APL_Active() en cada ciclo: mientras el modulo no este cargado
-- no hay APL activo y no hace falta cargarlo (no cuesta nada).
function PF.APL_Active() return false end

function PF.LoadDeferred(db)
  if db and type(db.apl) == "table" and db.apl.enabled and not IsAddOnLoaded("PulseFlash_APL") then
    LoadAddOn("PulseFlash_APL")
  end
end

-- /pf mem: memoria de cada modulo de PulseFlash (cargados y sin cargar)
function PF.MemReport()
  collectgarbage()
  UpdateAddOnMemoryUsage()
  local total, n = 0, GetNumAddOns()
  for i = 1, n do
    local name = GetAddOnInfo(i)
    if name and name:find("^PulseFlash") then
      if IsAddOnLoaded(name) then
        local kb = GetAddOnMemoryUsage(name)
        total = total + kb
        PF.Msg(string.format("%s: %.0f KB", name, kb))
      else
        PF.Msg(name .. ": " .. "-")
      end
    end
  end
  PF.Msg(string.format("Total: %.0f KB", total))
end

-- ---------------------------------------------------------------------------
-- Analisis de combate: se carga al empezar el primer combate (si no esta desactivado)
-- ---------------------------------------------------------------------------
do
  local an = CreateFrame("Frame")
  an:RegisterEvent("PLAYER_REGEN_DISABLED")
  an:SetScript("OnEvent", function(self)
    local db = PF.db
    if not db or db.enabled == false or db.anOff then return end
    self:UnregisterAllEvents()
    if not LoadAddOn then return end
    if not IsAddOnLoaded("PulseFlash_Analysis") then LoadAddOn("PulseFlash_Analysis") end
    if PF.Analysis and PF.Analysis.Begin and UnitAffectingCombat("player") then PF.Analysis.Begin() end
  end)
end
