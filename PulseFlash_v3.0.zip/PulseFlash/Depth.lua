-- Depth.lua
-- Utilidades de profundidad compartidas por las rotaciones (WoW 3.3.5a):
--   * CF.HasGlyph(hechizo)   ¿hay un glifo de ese hechizo? (por nombre localizado, válido en todos los idiomas)
--   * CF.TalentRank(talento) rango del talento (0 si no lo tienes)
--   * CF.CDok(c, baseCD)     ¿merece la pena gastar ahora un cooldown largo? (no al final del combate)
--   * CF.Mode()              "single" / "cleave" / "aoe" según el número de enemigos
--   * CF.IsUndeadOrDemon()   el objetivo es muerto viviente o demonio
--   * CF.PowerAfter(...)     energía/recurso estimado dentro de t segundos
local CF = PulseFlash
local GetTime = GetTime

-- ---------------------------------------------------------------------------
-- Glifos (se consultan como mucho cada 3 s)
-- ---------------------------------------------------------------------------
local glyphCache, glyphAt = {}, -10
function CF.HasGlyph(spellName)
  if not spellName then return false end
  local now = GetTime()
  if now - glyphAt > 3 then
    for k in pairs(glyphCache) do glyphCache[k] = nil end
    glyphAt = now
  end
  local v = glyphCache[spellName]
  if v == nil then
    v = false
    if GetNumGlyphSockets and GetGlyphSocketInfo then
      for i = 1, GetNumGlyphSockets() do
        local enabled, _, glyphSpellID = GetGlyphSocketInfo(i)
        if enabled and glyphSpellID then
          local gname = GetSpellInfo(glyphSpellID)
          if gname and gname:find(spellName, 1, true) then v = true; break end
        end
      end
    end
    glyphCache[spellName] = v
  end
  return v
end

-- ---------------------------------------------------------------------------
-- Rango de un talento (caché de 5 s)
-- ---------------------------------------------------------------------------
local talentCache, talentAt = {}, -10
function CF.TalentRank(name)
  if not name or not GetNumTalentTabs or not GetTalentInfo then return 0 end
  local now = GetTime()
  if now - talentAt > 5 then
    for k in pairs(talentCache) do talentCache[k] = nil end
    talentAt = now
  end
  local v = talentCache[name]
  if v == nil then
    v = 0
    for tab = 1, GetNumTalentTabs() do
      for i = 1, (GetNumTalents and GetNumTalents(tab) or 0) do
        local n, _, _, _, rank = GetTalentInfo(tab, i)
        if n == name then v = rank or 0; break end
      end
      if v > 0 then break end
    end
    talentCache[name] = v
  end
  return v
end

-- ---------------------------------------------------------------------------
-- Política de cooldowns largos
--   * Cooldown de 60 s o menos: siempre.
--   * Más largo: solo si el objetivo vivirá lo suficiente (por defecto 25 s),
--     o si estamos en fase de remate de un jefe (c.burn) y aún quedan 8 s.
--   * Sin estimación fiable de vida (TTD desconocido) se permite.
--   * "Cooldowns siempre" (db.cdAlways) lo salta en dianas normales.
-- ---------------------------------------------------------------------------
function CF.CDok(c, baseCD, minTTD)
  if not baseCD or baseCD <= 60 then return true end
  local t = CF.TTD and CF.TTD() or nil
  if not t then return true end
  local need = minTTD or tonumber(CF.db and CF.db.cdHold) or 25
  if t >= need then return true end
  if c and c.burn and t >= 8 then return true end
  return false
end

-- ---------------------------------------------------------------------------
-- Modo de objetivo (único / cleave 2-3 / área 4+)
-- ---------------------------------------------------------------------------
function CF.Mode()
  if CF.AoE(4) then return "aoe" end
  if CF.AoE(2) then return "cleave" end
  return "single"
end

-- ---------------------------------------------------------------------------
-- Tipo de criatura del objetivo
-- ---------------------------------------------------------------------------
local UNDEAD_DEMON = {
  Undead = true, Demon = true,
  ["No-muerto"] = true, Demonio = true, ["Mort-vivant"] = true, ["Démon"] = true,
  Untot = true, ["Dämon"] = true, ["Morto-vivo"] = true, ["Demônio"] = true,
  ["Нежить"] = true, ["Демон"] = true,
}
function CF.IsUndeadOrDemon()
  if CF.V and CF.V.simMode then return false end   -- simulador: no depende del objetivo real
  if not (UnitExists("target") and UnitCreatureType) then return false end
  local t = UnitCreatureType("target")
  return (t and UNDEAD_DEMON[t]) and true or false
end

-- ---------------------------------------------------------------------------
-- Recurso estimado dentro de t segundos (energía: 10 por segundo por defecto)
-- ---------------------------------------------------------------------------
function CF.PowerAfter(current, regen, t, max)
  local v = (current or 0) + (regen or 10) * (t or 0)
  if max and v > max then v = max end
  return v
end
