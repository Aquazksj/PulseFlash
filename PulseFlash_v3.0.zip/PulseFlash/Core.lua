local wipe = table.wipe or function(t) for k in pairs(t) do t[k] = nil end end
local GetTime = GetTime
local pairs, select, math = pairs, select, math

PulseFlash = PulseFlash or {}
local PF = PulseFlash
PF.modules = {}
PF.N = {}
PF.spec = 0
PF.notBehindUntil = 0
PF.bookCount = 0
PF.lastCast = {}
PF.holdSpell, PF.holdEta = nil, nil

ClassFlash = PF

local DB, module
local knownSet = {}
local buttons, glows, want, active = {}, {}, {}, {}
local wantSpell = {}
local ctx = {}
local posSet = {}
local cSpell, cTier, cState, cExec, nC = {}, {}, {}, {}, 0
local cHold = {}
local slotSpell = {}
local lastFiller

local TIER_COLOR = {
  [1] = { 1.00, 0.82, 0.00 },
  [2] = { 0.25, 0.85, 1.00 },
  [3] = { 0.20, 1.00, 0.30 },
}
local GCD_TOL = 1.5
local DOT_REFRESH = 4.0      -- por defecto; se cambia en Extras > "Refresco de DoTs" (PF.db.dotWindow)

function PF.Msg(s)
  DEFAULT_CHAT_FRAME:AddMessage("|cffffd100PulseFlash:|r " .. s)
end

function PF.Register(class, mod)
  PF.modules[class] = mod
end

function PF.ScanBook()
  wipe(knownSet)
  local count = 0
  for tab = 1, GetNumSpellTabs() do
    local _, _, offset, num = GetSpellTabInfo(tab)
    for i = offset + 1, offset + num do
      local name = GetSpellName(i, BOOKTYPE_SPELL)
      if name then
        if not knownSet[name] then count = count + 1 end
        knownSet[name] = true
      end
    end
  end
  PF.bookCount = count
end

function PF.Item(id) return "item:" .. id end
local itemIdCache = {}
local function ItemID(n)
  if not n then return nil end
  local v = itemIdCache[n]
  if v == nil then
    v = tonumber(n:match("^item:(%d+)$")) or false
    itemIdCache[n] = v
  end
  return v or nil
end

function PF.Known(n)
  if not n then return false end
  local id = ItemID(n)
  if id then return (GetItemCount(id) or 0) > 0 or (IsEquippedItem and IsEquippedItem(id)) or false end
  if knownSet[n] then return true end
  if PF.bookCount == 0 then return GetSpellTexture(n) ~= nil end
  return false
end

function PF.Texture(n)
  local id = ItemID(n)
  if id then return GetItemIcon(id) end
  return GetSpellTexture(n)
end

function PF.First(...)
  for i = 1, select("#", ...) do
    local n = select(i, ...)
    if n and PF.Known(n) then return n end
  end
  return nil
end

function PF.State(n)
  if not PF.Known(n) then return 0 end
  local V = PF.V
  if V then return V:State(n) end
  local itemID = ItemID(n)
  if itemID then
    local is, id = GetItemCooldown(itemID)
    if is and is > 0 and id and id > 0 and (is + id - GetTime()) > GCD_TOL then return 1 end
    return 3
  end
  local s, d = GetSpellCooldown(n)
  if s and s > 0 and d and d > 0 and (s + d - GetTime()) > GCD_TOL then return 1 end
  local usable, nomana = IsUsableSpell(n)
  if usable then return 3 end
  if nomana then return 2 end
  return 1
end

local AURA_TTL = 0.05
local auraCache = { {}, {} }

function PF.InvalidateAuras()
  for k = 1, 2 do
    for _, c in pairs(auraCache[k]) do c.at = -1 end
  end
end

local function AuraSet(unit, harmful)
  local k = harmful and 2 or 1
  local c = auraCache[k][unit]
  if not c then c = { at = -1, any = {}, mine = {}, n = 0 }; auraCache[k][unit] = c end
  local now = GetTime()
  if now - c.at > AURA_TTL then
    c.at = now
    wipe(c.any); wipe(c.mine)
    local fn = harmful and UnitDebuff or UnitBuff
    local n = 0
    for i = 1, 40 do
      local name, _, _, count, dtype, duration, expires, caster = fn(unit, i)
      if not name then break end
      n = n + 1
      local r = c[n]
      if not r then r = {}; c[n] = r end
      r.name, r.count, r.duration, r.expires, r.caster, r.dtype = name, count, duration, expires, caster, dtype
      if not c.any[name] then c.any[name] = r end
      if caster == "player" and not c.mine[name] then c.mine[name] = r end
    end
    c.n = n
  end
  return c
end

-- Lista cacheada de auras (la usa Project.lua para tomar la instantánea)
function PF.AuraList(unit, harmful) return AuraSet(unit, harmful) end

local function AuraResult(r)
  local expires = r.expires
  local left = (expires and expires > 0) and (expires - GetTime()) or 9999

  return left, ((r.count and r.count > 0) and r.count or 1), r.duration, expires
end

function PF.HasDebuff(name)
  if not name then return nil end
  if PF.V then return PF.V:Aura("target", name, true, true) end
  local r = AuraSet("target", true).mine[name]
  if r then return AuraResult(r) end
  return nil
end
PF.UnitDebuffCheck = PF.HasDebuff

function PF.Aura(unit, name, harmful, mine, prefix)
  if not name then return nil end
  local V = PF.V
  if V then return V:Aura(unit, name, harmful, mine, prefix) end
  local c = AuraSet(unit, harmful)
  if not prefix then
    local r = (mine and c.mine or c.any)[name]
    if r then return AuraResult(r) end
    return nil
  end
  local len = #name
  for i = 1, c.n do
    local r = c[i]
    if r.name:sub(1, len) == name and (not mine or r.caster == "player") then return AuraResult(r) end
  end
  return nil
end

function PF.IsCasting(spell)
  if not spell then return false end
  if PF.V then return false end

  if PF.CastInLag and PF.CastInLag() == spell then return false end
  local cast = UnitCastingInfo("player")
  if cast and cast == spell then return true end
  local chan = UnitChannelInfo("player")
  return (chan and chan == spell) and true or false
end

local netAt, netLat = -10, 0
local function NetLat()
  local now = GetTime()
  if now - netAt > 0.5 then
    netAt = now
    local _, _, l = GetNetStats()
    netLat = l or 0
  end
  return netLat
end

function PF.Pending(spell)
  if PF.V then return false end
  local t = spell and PF.lastCast[spell]
  if not t then return false end
  local lat = NetLat()
  if PF.Lag and not (PF.db and PF.db.plusOff) then lat = PF.Lag() * 1000 end
  local grace = 0.5 + 2 * ((lat or 0) / 1000)
  if grace > 1.5 then grace = 1.5 end
  return (GetTime() - t) < grace
end

function PF.Dot(add, c, spell, left, soon, urgent)
  if not spell then return end
  if PF.NoteDot and not PF.V then PF.NoteDot(spell, left) end
  local window = tonumber(PF.db and PF.db.dotWindow) or DOT_REFRESH
  if left and left > window then return end
  if PF.IsCasting(spell) or c.casting == spell then return end
  if PF.Pending(spell) then return end
  add(spell, 1)
end

function PF.Proc(add, buff, spell, minStacks)
  if not buff or not spell then return end
  local left, n = PF.Aura("player", buff)
  if left and n >= (minStacks or 1) then add(spell, 1) end
end

function PF.HasTalent(name)
  if not name or not GetNumTalentTabs or not GetTalentInfo then return false end
  for tab = 1, GetNumTalentTabs() do
    for i = 1, (GetNumTalents and GetNumTalents(tab) or 0) do
      local n, _, _, _, rank = GetTalentInfo(tab, i)
      if n == name then return (rank or 0) > 0 end
    end
  end
  return false
end

function PF.IsPositional(spell) return spell and posSet[spell] and true or false end

function PF.DetectSpec()
  local best, pts = 0, 0
  for i = 1, 3 do
    local _, _, p = GetTalentTabInfo(i)
    if p and p > pts then best, pts = i, p end
  end
  if pts < 5 then best = 0 end
  PF.spec = best
end

local function pack(...) return select("#", ...), ... end
function PF.WeaponEnchants()
  local n, a, b, c, d, e, f, g, h = pack(GetWeaponEnchantInfo())
  if n >= 8 then return a, b, c, d, e, f, g, h end
  return a, b, c, nil, d, e, f, nil
end

local OPENER_TIME, BURN_HP, FINAL_HP = 12, 0.35, 0.10
local fightStart = nil

local function BuildContext()
  local c = ctx
  c.level = UnitLevel("player")
  c.combat = UnitAffectingCombat("player") and true or false
  c.spec = PF.spec
  c.hostile = (UnitExists("target") and UnitCanAttack("player", "target")
               and not UnitIsDead("target")) and true or false

  local tl = c.hostile and UnitLevel("target") or 0
  local tc = c.hostile and UnitClassification("target") or nil
  if c.hostile then
    if PF.DetectBoss then
      c.boss = PF.DetectBoss(c.level, tl, tc) and true or false
    else
      c.boss = (tl == -1 or tc == "worldboss" or (tc == "elite" and tl >= c.level + 2)) and true or false
    end
  else
    c.boss = false
  end

  c.bigCD = (c.boss or (DB and DB.cdAlways)) and true or false
  local hm = UnitHealthMax("target")
  c.hp = (c.hostile and hm and hm > 0) and (UnitHealth("target") / hm) or 1
  c.worth = c.hostile and (c.boss or c.hp > 0.20) or false

  if c.combat then
    if not fightStart then fightStart = GetTime() end
  else
    fightStart = nil
  end
  c.fightTime = fightStart and (GetTime() - fightStart) or 0
  c.phase = nil
  if c.boss and c.combat then
    if c.hp <= FINAL_HP then c.phase = "final"
    elseif c.hp <= BURN_HP then c.phase = "burn"
    elseif c.fightTime < OPENER_TIME then c.phase = "opener"
    else c.phase = "main" end
  end
  c.burn = (c.phase == "burn" or c.phase == "final")
  PF.phase, PF.burn = c.phase, c.burn
  local pm = UnitHealthMax("player")
  c.php = (pm and pm > 0) and (UnitHealth("player") / pm) or 1
  c.mana = UnitPower("player", 0) or 0
  local mm = UnitPowerMax("player", 0) or 0
  c.manaPct = (mm > 0) and (c.mana / mm) or 1
  c.rage = UnitPower("player", 1) or 0
  c.energy = UnitPower("player", 3) or 0
  c.runic = UnitPower("player", 6) or 0
  c.cp = GetComboPoints("player", "target") or 0

  c.enemies = PF.Enemies and PF.Enemies() or (c.hostile and 1 or 0)
  c.behind = (GetTime() > PF.notBehindUntil) and not UnitIsUnit("targettarget", "player")
  c.casting = UnitCastingInfo("player") or UnitChannelInfo("player")
  if c.casting and PF.CastInLag and PF.CastInLag() then c.casting = nil end
  return c
end

local rangeUnit = "target"

local function add(spell, tier, hold)
  if spell and PF.Known(spell) then
    if posSet[spell] and not ctx.behind then return false end
    nC = nC + 1
    cSpell[nC] = spell
    cTier[nC] = tier
    cHold[nC] = hold
    return true
  end
  return false
end

local HOLD_MAX_WAIT = 2.0
local POOL_MAX_T = 6.0

local costCache, ptypeCache = {}, {}
function PF.Cost(spell)
  if not spell then return nil end
  local cost = costCache[spell]
  if cost == nil then
    cost = tonumber((select(4, GetSpellInfo(spell))))
    cost = (cost and cost > 0) and cost or false
    costCache[spell] = cost
  end
  return cost or nil
end

-- Tipo de recurso del hechizo: 0 maná, 1 ira, 3 energía, 6 poder rúnico
function PF.PowerType(spell)
  if not spell then return nil end
  local t = ptypeCache[spell]
  if t == nil then
    t = tonumber((select(6, GetSpellInfo(spell)))) or false
    ptypeCache[spell] = t
  end
  return t or nil
end

-- Recurso actual del jugador (en proyeccion devuelve el recurso virtual)
function PF.Pow(t)
  local V = PF.V
  if V then return V.res[t] or 0 end
  return UnitPower("player", t) or 0
end

function PF.HoldEta(spell, regen, maxWait)
  if not spell or PF.State(spell) ~= 2 then return nil end
  local cost = PF.Cost(spell)
  if not cost then return nil end
  local deficit = cost - PF.Pow(3)
  if deficit <= 0 then return nil end
  local eta = deficit / ((regen and regen > 0) and regen or 10)
  if eta > (maxWait or HOLD_MAX_WAIT) then return nil end
  return eta
end

function PF.CanSpend(spendCost, refreshCost, t, regen)
  if not spendCost or not refreshCost then return true end
  local e = PF.Pow(3)
  local after = e - spendCost
  if after < 0 then after = 0 end
  return (after + (regen or 10) * t) >= refreshCost
end
PF.POOL_MAX_T = POOL_MAX_T

local function Resolve(c)
  for i = 1, nC do
    local sp = cSpell[i]
    local st = PF.State(sp)
    cState[i] = st
    local isItem = ItemID(sp) ~= nil
    -- La recomendacion NO depende del alcance: el HUD siempre muestra la habilidad
    -- correcta (se atenua si esta fuera de rango). Solo los utiles (tier 3: interrupciones,
    -- provocaciones...) siguen exigiendo estar a alcance.
    cExec[i] = (st == 3) and (isItem or cTier[i] ~= 3 or IsSpellInRange(sp, rangeUnit) ~= 0)
  end

  local s1, s3, q1, t2
  PF.holdSpell, PF.holdEta = nil, nil

  for i = 1, nC do
    if cTier[i] == 1 and (cExec[i] or (cHold[i] and cState[i] >= 2)) then
      s1 = cSpell[i]

      if cHold[i] then PF.holdSpell, PF.holdEta = s1, cHold[i] end
      break
    end
  end
  for i = 1, nC do
    if cTier[i] == 3 and cExec[i] then s3 = cSpell[i]; break end
  end

  local aplOn = PF.APL_Active and PF.APL_Active()
  local filler = c.hostile and not c.healMode and not aplOn and module.filler and module.filler(c, PF.N) or nil
  if filler and not PF.Known(filler) then filler = nil end
  lastFiller = filler

  if not s1 then s1 = filler end

  for i = 1, nC do
    local sp = cSpell[i]
    if sp ~= s1 and cState[i] >= 2 then
      if cTier[i] == 2 then
        if not t2 then t2 = sp end
      elseif cTier[i] == 1 and not q1 then
        q1 = sp
      end
    end
  end

  if not c.hostile and not c.healMode then return s1, nil, nil end
  local s2 = t2 or q1
  if not s2 and filler and filler ~= s1 then s2 = filler end
  if s2 and s2 == s3 then s2 = nil end
  return s1, s2, s3
end

local function BuildButtons()
  local prefixes = {
    "ActionButton", "MultiBarBottomLeftButton", "MultiBarBottomRightButton",
    "MultiBarRightButton", "MultiBarLeftButton",
    "BonusActionButton",
    "MultiCastActionButton",
  }
  for _, p in pairs(prefixes) do
    for i = 1, 12 do
      local b = _G[p .. i]
      if b then buttons[#buttons + 1] = b end
    end
  end
end

local function GetGlow(btn)
  local g = glows[btn]
  if g then return g end
  g = CreateFrame("Frame", nil, btn)
  g:SetFrameLevel(btn:GetFrameLevel() + 5)
  g:SetAllPoints(btn)

  g.fill = g:CreateTexture(nil, "OVERLAY")
  g.fill:SetTexture("Interface\\Buttons\\CheckButtonHilight")
  g.fill:SetBlendMode("ADD")
  g.fill:SetAllPoints(g)

  g.tex = g:CreateTexture(nil, "OVERLAY")
  g.tex:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
  g.tex:SetBlendMode("ADD")
  g.tex:SetPoint("CENTER", g, "CENTER", 0, 0)
  g.tex:SetWidth(btn:GetWidth() * 1.75)
  g.tex:SetHeight(btn:GetHeight() * 1.75)

  g.num = g:CreateFontString(nil, "OVERLAY")
  g.num:SetFont("Fonts\\FRIZQT__.TTF", 18, "THICKOUTLINE")

  glows[btn] = g
  return g
end

local RANGE_ALPHA_OUT, RANGE_ALPHA_IN = 0.35, 1.0

local rangeMemo, rangeMemoAt = {}, -10
local function RangeAlpha(spell)
  if not spell or not (DB and DB.range) then return RANGE_ALPHA_IN end
  local now = GetTime()
  if now ~= rangeMemoAt then wipe(rangeMemo); rangeMemoAt = now end
  local v = rangeMemo[spell]
  if v then return v end
  local r
  local id = ItemID(spell)
  local ru = PF.rangeUnit or "target"
  if id then r = IsItemInRange(id, ru) else r = IsSpellInRange(spell, ru) end
  v = (r == 0) and RANGE_ALPHA_OUT or RANGE_ALPHA_IN
  rangeMemo[spell] = v
  return v
end
PF.RangeAlpha = RangeAlpha

local function BtnAction(b)
  return b.action or (b.GetAttribute and tonumber(b:GetAttribute("action")))
end

local keyEpoch = 0
local IDX_TTL = 1.0
local texIndex, texLists = {}, {}
local btnVis = {}
local lowerCache = {}
local texCache = {}
local idxEpoch, idxAt = -1, -100

local function Lower(t)
  local l = lowerCache[t]
  if not l then l = t:lower(); lowerCache[t] = l end
  return l
end

local function TexLower(spell)
  local t = texCache[spell]
  if t then return t end
  local tex = PF.Texture(spell)
  if not tex then return false end
  t = Lower(tex)
  texCache[spell] = t
  return t
end

local function EnsureIndex()
  local now = GetTime()
  if idxEpoch == keyEpoch and now - idxAt < IDX_TTL then return end
  idxEpoch, idxAt = keyEpoch, now
  for k, l in pairs(texIndex) do
    wipe(l)
    texLists[#texLists + 1] = l
    texIndex[k] = nil
  end
  for i = 1, #buttons do
    local b = buttons[i]
    local a = BtnAction(b)
    if a and HasAction(a) then
      local t = GetActionTexture(a)
      if t then
        t = Lower(t)
        local l = texIndex[t]
        if not l then
          l = texLists[#texLists]
          if l then texLists[#texLists] = nil else l = {} end
          texIndex[t] = l
        end
        l[#l + 1] = b
        btnVis[b] = b:IsVisible() and true or false
      end
    end
  end
end

local function ApplyFlash(spell, tier)
  if not spell then return end
  local tex = TexLower(spell)
  if not tex then return end
  local l = texIndex[tex]
  if not l then return end
  for i = 1, #l do
    local b = l[i]
    if btnVis[b] and not want[b] then want[b] = tier; wantSpell[b] = spell end
  end
end

local function Refresh()
  for b in pairs(active) do
    if not want[b] then
      glows[b]:Hide()
      active[b] = nil
    end
  end
  local pos = DB and DB.numPos or "TOPLEFT"
  for b, tier in pairs(want) do
    local g = GetGlow(b)

    if g.tier ~= tier or g.posMode ~= pos then
      local col = TIER_COLOR[tier]
      g.tex:SetVertexColor(col[1], col[2], col[3])
      g.fill:SetVertexColor(col[1], col[2], col[3])
      g.num:SetTextColor(col[1], col[2], col[3])
      g.num:SetText(tostring(tier))
      g.num:ClearAllPoints()
      if pos == "CENTER" then
        g.num:SetPoint("CENTER", g, "CENTER", 0, 0)
      else
        g.num:SetPoint("TOPLEFT", g, "TOPLEFT", 3, -3)
      end
      g.tier, g.posMode = tier, pos
    end
    local ra = RangeAlpha(wantSpell[b])
    if g.range ~= ra then
      g.range = ra
      g.num:SetAlpha(ra)
    end
    if not active[b] then
      g:Show()
      active[b] = true
    end
  end
end

local ALERT_COLOR = {
  red     = { 1.00, 0.10, 0.10 },
  magenta = { 0.90, 0.25, 1.00 },
  blue    = { 0.25, 0.55, 1.00 },
  orange  = { 1.00, 0.50, 0.00 },
}
local ALERT_IDS = {
  WARRIOR     = { def = { 55694, 12975, 871 },      int = { 6552, 72 } },
  PALADIN     = { def = { 642, 498 },               int = { 853 } },
  HUNTER      = { def = { 19263, 5384 },            int = { 34490, 19503 },
                  pet = { all = { 883 }, revive = 982 } },
  ROGUE       = { def = { 5277, 31224, 1856 },      int = { 1766 } },
  PRIEST      = { def = { 47585, 19236, 17 },       int = { 15487 } },
  SHAMAN      = { def = { 30823, 331 },             int = { 57994 }, totem = 66842 },
  MAGE        = { def = { 45438, 1463 },            int = { 2139 } },
  WARLOCK     = { def = { 6789 },                   int = { 6789 },
                  pet = { [1] = { 691, 697, 688, 712 }, [2] = { 30146, 691, 697, 688 },
                          [3] = { 688, 697, 691, 712 }, all = { 688, 697, 691, 712 } } },
  DRUID       = { def = { 61336, 22812 },           int = { 5211 } },
  DEATHKNIGHT = { def = { 48792, 48707, 55233 },    int = { 47528, 47476 },
                  pet = { [3] = { 46584 } } },
}

local HEALTHSTONES = { 5512, 5511, 5510, 5509, 9421, 19004, 19005, 19006, 19007, 19008, 19009,
                       19010, 19011, 19012, 19013, 22103, 22104, 22105, 36889, 36890, 36891,
                       36892, 36893, 36894 }

local A = {}
local alertWant, alertGlows, alertActive = {}, {}, {}

local function Names(ids)
  local t = {}
  for i = 1, #(ids or {}) do
    local n = GetSpellInfo(ids[i])
    if n then t[#t + 1] = n end
  end
  return t
end

local RACIALS = {
  Orc      = { id = 20572, kind = "burst" },
  Troll    = { id = 26297, kind = "burst" },
  BloodElf = { id = 28730, kind = "power" },
  Draenei  = { id = 28880, kind = "heal" },
  Tauren   = { id = 20549, kind = "panic" },
  NightElf = { id = 58984, kind = "panic" },
  Scourge  = { id = 7744,  kind = "control" },
  Human    = { id = 59752, kind = "control" },
  Gnome    = { id = 20589, kind = "snare" },
  Dwarf    = { id = 20594, kind = "cleanse" },
}

local SNARE_IDS = { 122, 339, 1715, 5116, 8056, 116, 120, 2974, 3409, 45524, 12494, 18223,
                    3600, 31589, 1604, 15407, 55095, 20184, 58179, 12323 }

local BLEED_IDS = { 772, 1822, 1079, 703, 1943, 12721, 33745, 9007 }
local snareSet, bleedSet = {}, {}

function PF.BuildAlerts(class)
  wipe(A)
  wipe(snareSet); wipe(bleedSet)
  for i = 1, #SNARE_IDS do
    local n = GetSpellInfo(SNARE_IDS[i]); if n then snareSet[n] = true end
  end
  for i = 1, #BLEED_IDS do
    local n = GetSpellInfo(BLEED_IDS[i]); if n then bleedSet[n] = true end
  end
  local _, race = UnitRace("player")
  local rc = race and RACIALS[race]
  if rc then A.racial = { name = GetSpellInfo(rc.id), kind = rc.kind } end
  local d = ALERT_IDS[class]
  if not d then return end
  A.def, A.int = Names(d.def), Names(d.int)
  A.totem = d.totem and GetSpellInfo(d.totem) or nil
  if d.pet then
    A.pet = { revive = d.pet.revive and GetSpellInfo(d.pet.revive) or nil }
    for k, v in pairs(d.pet) do
      if type(v) == "table" then A.pet[k] = Names(v) end
    end
  end
end

local function GetAlertGlow(btn)
  local g = alertGlows[btn]
  if g then return g end
  g = CreateFrame("Frame", nil, btn)
  g:SetFrameLevel(btn:GetFrameLevel() + 8)
  g:SetAllPoints(btn)
  g.fill = g:CreateTexture(nil, "OVERLAY")
  g.fill:SetTexture("Interface\\Buttons\\CheckButtonHilight")
  g.fill:SetBlendMode("ADD")
  g.fill:SetAllPoints(g)
  g.tex = g:CreateTexture(nil, "OVERLAY")
  g.tex:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
  g.tex:SetBlendMode("ADD")
  g.tex:SetPoint("CENTER", g, "CENTER", 0, 0)
  g.tex:SetWidth(btn:GetWidth() * 1.55)
  g.tex:SetHeight(btn:GetHeight() * 1.55)
  alertGlows[btn] = g
  return g
end

local function ApplyAlert(spell, key)
  if not spell then return false end
  local tex = TexLower(spell)
  if not tex then return false end
  local l = texIndex[tex]
  if not l then return false end
  local hit = false
  for i = 1, #l do
    local b = l[i]
    if btnVis[b] then
      hit = true
      if not alertWant[b] then alertWant[b] = key end
    end
  end
  return hit
end

local function AlertRefresh()
  for b in pairs(alertActive) do
    if not alertWant[b] then
      alertGlows[b]:Hide()
      alertActive[b] = nil
    end
  end
  for b, key in pairs(alertWant) do
    local g = GetAlertGlow(b)
    if g.key ~= key then
      local col = ALERT_COLOR[key]
      g.tex:SetVertexColor(col[1], col[2], col[3])
      g.fill:SetVertexColor(col[1], col[2], col[3])
      g.key = key
    end
    if not alertActive[b] then
      g:Show()
      alertActive[b] = true
    end
  end
end

local function FirstReady(list, checkRange)
  if not list then return nil end
  for i = 1, #list do
    local sp = list[i]
    if PF.Known(sp) and not PF.IsCasting(sp) and PF.State(sp) == 3
       and (not checkRange or IsSpellInRange(sp, PF.rangeUnit or "target") ~= 0) then
      return sp
    end
  end
  return nil
end

local function ReadyHealthstone()
  for i = 1, #HEALTHSTONES do
    local id = HEALTHSTONES[i]
    if (GetItemCount(id) or 0) > 0 then
      local item = PF.Item(id)
      if PF.State(item) == 3 then return item end
    end
  end
  return nil
end

local function TargetInterruptible()
  if not (UnitExists("target") and UnitCanAttack("player", "target")) then return false end
  local cn, _, _, _, _, _, _, _, castNI = UnitCastingInfo("target")
  if cn then return not castNI end
  local ch, _, _, _, _, _, _, chanNI = UnitChannelInfo("target")
  if ch then return not chanNI end
  return false
end

local function AlertSurvival()
  local hm = UnitHealthMax("player")
  if not hm or hm <= 0 or UnitHealth("player") / hm > 0.30 then return end
  ApplyAlert(FirstReady(A.def), "red")
  ApplyAlert(ReadyHealthstone(), "red")
end

local function AlertInterrupt()
  if not TargetInterruptible() then return end
  ApplyAlert(FirstReady(A.int, true), "red")
end

local function AlertPetSummon(c)
  local p = A.pet
  if not p or not InCombatLockdown() then return end
  if UnitInVehicle and UnitInVehicle("player") then return end
  local dead = UnitIsDead("pet")
  if HasPetUI() and not dead then return end
  local sp
  if dead and p.revive then
    if PF.Known(p.revive) and not PF.IsCasting(p.revive) and not PF.Pending(p.revive)
       and PF.State(p.revive) == 3 then sp = p.revive end
  else
    local list = p[c.spec] or p.all
    if list then
      for i = 1, #list do
        local n = list[i]
        if PF.Known(n) and not PF.IsCasting(n) and not PF.Pending(n) and PF.State(n) == 3 then
          sp = n; break
        end
      end
    end
  end
  ApplyAlert(sp, "magenta")
end

local function AlertPetStance()
  if InCombatLockdown() or not HasPetUI() or UnitIsDead("pet") then return end
  local aggressive, defBtn, pasBtn = false, nil, nil
  for i = 1, (NUM_PET_ACTION_SLOTS or 10) do
    local name, _, _, _, isActive = GetPetActionInfo(i)
    if name == "PET_MODE_AGGRESSIVE" then
      if isActive then aggressive = true end
    elseif name == "PET_MODE_DEFENSIVE" then
      defBtn = _G["PetActionButton" .. i]
    elseif name == "PET_MODE_PASSIVE" then
      pasBtn = _G["PetActionButton" .. i]
    end
  end
  if aggressive then
    local b = defBtn or pasBtn
    if b and b:IsVisible() and not want[b] then want[b] = 2 end
  end
end

local function AlertTotem()
  if not A.totem or not PF.TotemAlertList then return end
  local list = PF.TotemAlertList(PF.spec)
  if not list then return end
  local shown = false
  for i = 1, #list do
    local item = list[i]
    if ApplyAlert(item.spell, "magenta") then
      shown = true
    else

      for n = 1, 4 do
        local sb = _G["MultiCastSlotButton" .. n]
        if sb and sb:IsVisible() and (sb.slot == item.slot or (sb.GetID and sb:GetID() == item.slot)) then
          if not alertWant[sb] then alertWant[sb] = "magenta" end
          shown = true
        end
      end
    end
  end
  if not shown and PF.Known(A.totem) and not PF.IsCasting(A.totem)
     and not PF.Pending(A.totem) and PF.State(A.totem) == 3 then
    ApplyAlert(A.totem, "magenta")
  end
end

local function PlayerDebuffMatch(set, types)
  local c = AuraSet("player", true)
  for i = 1, c.n do
    local r = c[i]
    if (set and set[r.name]) or (types and r.dtype and types[r.dtype]) then return true end
  end
  return false
end
local POISON_DISEASE = { Poison = true, Disease = true }

local function AlertRacial(c)
  local r = A.racial
  if not r or not r.name or not PF.Known(r.name) then return end
  if PF.IsCasting(r.name) or PF.Pending(r.name) or PF.State(r.name) ~= 3 then return end
  local k, color, ok = r.kind, "blue", false
  if k == "burst" then
    color, ok = "orange", (c.combat and c.hostile and c.worth)
  elseif k == "power" then
    color = "orange"
    if c.combat then
      local pt = UnitPowerType("player")
      if pt == 0 then ok = c.manaPct < 0.35
      elseif pt == 3 then ok = c.energy < 30
      elseif pt == 6 then ok = c.runic < 40 end
    end
  elseif k == "heal" then ok = c.combat and c.php < 0.50
  elseif k == "panic" then ok = c.combat and c.php < 0.35
  elseif k == "control" then ok = HasFullControl and not HasFullControl()
  elseif k == "snare" then ok = PlayerDebuffMatch(snareSet, nil)
  elseif k == "cleanse" then ok = PlayerDebuffMatch(bleedSet, POISON_DISEASE)
  end
  if ok then ApplyAlert(r.name, color) end
end

local function ComputeAlerts(c)
  if DB.racial then AlertRacial(c) end
  if DB.alerts then
    AlertSurvival()
    AlertInterrupt()
  end
  if DB.pet then
    AlertPetSummon(c)
    AlertPetStance()
  end
  if DB.totem then AlertTotem() end
end

local HUD_DEFAULT = { enabled = true, locked = true, x = 0, y = -120, scale = 1.0,
                      alphaCombat = 1.0, alphaOOC = 1.0, alphaChannel = 0.4, mode = "target",
                      style = "classic", icons = 3 }
local HUD_SCALE_MIN, HUD_SCALE_MAX = 0.5, 2.0

local FX_DEFAULT = { period = 0.9, intensity = 1.0, style = "glow" }

local ROT_DEFAULT = { max = false }
PF.HUD_DEFAULT, PF.FX_DEFAULT, PF.ROT_DEFAULT = HUD_DEFAULT, FX_DEFAULT, ROT_DEFAULT
PF.HUD_SCALE_MIN, PF.HUD_SCALE_MAX = HUD_SCALE_MIN, HUD_SCALE_MAX
local EDGE = "Interface\\Buttons\\WHITE8X8"
local ICON, GAP = 46, 3
local KEY_REFRESH = 2
local KEY_EVENTS = {
  ACTIONBAR_SLOT_CHANGED = true, UPDATE_BINDINGS = true, ACTIONBAR_PAGE_CHANGED = true,
  UPDATE_BONUS_ACTIONBAR = true, UPDATE_SHAPESHIFT_FORM = true, UPDATE_MULTI_CAST_ACTIONBAR = true,
  PLAYER_ENTERING_WORLD = true, ACTIVE_TALENT_GROUP_CHANGED = true,
}
local hud

local BIND_PREFIX = {
  ActionButton = "ACTIONBUTTON",
  MultiBarBottomLeftButton = "MULTIACTIONBAR1BUTTON",
  MultiBarBottomRightButton = "MULTIACTIONBAR2BUTTON",
  MultiBarRightButton = "MULTIACTIONBAR3BUTTON",
  MultiBarLeftButton = "MULTIACTIONBAR4BUTTON",
  BonusActionButton = "BONUSACTIONBUTTON",
}

local keyBuf = {}
local kfText, kfCost

local function KeyOffer(text, cost)
  if text and text ~= "" and (not kfCost or cost < kfCost) then kfText, kfCost = text, cost end
end

local function KeyFor(spell)
  if not spell then return "" end
  local tex = TexLower(spell)
  if not tex then return "" end
  EnsureIndex()
  local alias = DB and DB.keyAlias
  kfText, kfCost = nil, nil
  local list = texIndex[tex]
  if list then
    for i = 1, #list do
      local b = list[i]
      local name = b:GetName()
      if name then
        local vis = btnVis[b]
        local prefix, idx = name:match("^(.-)(%d+)$")
        local cmd = prefix and BIND_PREFIX[prefix]
        PF.ButtonKeys(keyBuf, name, cmd and (cmd .. idx), keyEpoch)
        for j = 1, #keyBuf do
          local k = keyBuf[j]
          local c = PF.KeyCost(k)
          if vis or c < 100 then
            KeyOffer((alias and alias[k]) or GetBindingText(k, "KEY_", 1) or k, vis and c or c + 40)
          end
        end
        if vis then
          local st = PF.ScreenHotkey(b)
          if st then KeyOffer(st, PF.TextCost(st)) end
        end
      end
    end
  end
  local r = kfText or ""

  if alias and r ~= "" and alias[PF.NormKey(r)] then r = alias[PF.NormKey(r)] end
  return r
end

function PF.KeyDebug()
  local any = false
  local buf = {}
  for n = 1, 3 do
    local spell = slotSpell[n]
    if spell then
      any = true
      PF.Msg(string.format("icono %d: %s -> el HUD muestra '%s'", n, tostring(spell), KeyFor(spell)))
      local tex = (PF.Texture(spell) or ""):lower()
      for i = 1, #buttons do
        local bt = buttons[i]
        local act = BtnAction(bt)
        if act and HasAction(act) then
          local t = GetActionTexture(act)
          if t and t:lower() == tex then
            local name = bt:GetName() or "?"
            local prefix, idx = name:match("^(.-)(%d+)$")
            local cmd = prefix and BIND_PREFIX[prefix]
            PF.ButtonKeys(buf, name, cmd and (cmd .. idx), keyEpoch)
            PF.Msg(string.format("   %s  accion=%s  visible=%s  teclas=[%s]  barra muestra='%s'", name, tostring(act),
              tostring(bt:IsVisible() and true or false), table.concat(buf, ", "), PF.ScreenHotkey(bt) or ""))
          end
        end
      end
    end
  end
  if not any then PF.Msg("sin iconos en el HUD: pon un objetivo hostil o usa /pf modo") end
end

function PF.KeyAliasCommand(arg)
  DB.keyAlias = DB.keyAlias or {}
  local a, b = (arg or ""):match("^(%S*)%s*(.-)$")
  if a == "" then
    local n = 0
    for k, v in pairs(DB.keyAlias) do n = n + 1; PF.Msg(string.format("alias: %s -> %s", k, v)) end
    if n == 0 then PF.Msg("alias: ninguno. Uso: /pf alias c-6 Q  (donde el juego vea CTRL-6, mostrar Q)  |  /pf alias reset") end
    return
  end
  if a == "reset" or a == "borrar" or a == "clear" then
    wipe(DB.keyAlias)
    PF.Msg("alias: borrados todos")
  elseif b == "" then
    local k = PF.NormKey(a)
    DB.keyAlias[k] = nil
    PF.Msg("alias: quitado " .. k)
  else
    local k = PF.NormKey(a)
    DB.keyAlias[k] = b:upper()
    PF.Msg(string.format("alias: %s -> %s", k, b:upper()))
  end
  keyEpoch = keyEpoch + 1
end

local function MakeIcon(parent)
  local f = CreateFrame("Frame", nil, parent)
  f:SetWidth(ICON); f:SetHeight(ICON)
  f:SetBackdrop({ bgFile = EDGE, edgeFile = EDGE, edgeSize = 1,
                  insets = { left = 1, right = 1, top = 1, bottom = 1 } })
  f:SetBackdropColor(0, 0, 0, 1)
  f:SetBackdropBorderColor(0.05, 0.05, 0.05, 1)
  f.icon = f:CreateTexture(nil, "ARTWORK")
  f.icon:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1)
  f.icon:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 1)
  f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  f.cd = CreateFrame("Cooldown", nil, f, "CooldownFrameTemplate")
  f.cd:SetAllPoints(f.icon)
  f.top = CreateFrame("Frame", nil, f)
  f.top:SetAllPoints(f)
  f.top:SetFrameLevel(f:GetFrameLevel() + 4)
  f.key = f.top:CreateFontString(nil, "OVERLAY")
  f.key:SetFont("Fonts\\ARIALN.TTF", 13, "OUTLINE")
  f.key:SetTextColor(1, 1, 1)
  f.key:SetPoint("TOPRIGHT", f, "TOPRIGHT", -2, -2)
  f.wait = f.top:CreateFontString(nil, "OVERLAY")
  f.wait:SetFont("Fonts\\ARIALN.TTF", 16, "OUTLINE")
  f.wait:SetTextColor(1, 0.82, 0)
  f.wait:SetPoint("BOTTOM", f, "BOTTOM", 0, 3)
  return f
end

local function HUDApplyPos()
  local H = DB.hud
  hud:SetScale(H.scale)
  hud:ClearAllPoints()
  hud:SetPoint("CENTER", UIParent, "CENTER", H.x / H.scale, H.y / H.scale)
end

local function HUDSavePos()
  local cx, cy = hud:GetCenter()
  local ucx, ucy = UIParent:GetCenter()
  if not (cx and ucx) then return end
  local hs = hud:GetScale()
  DB.hud.x = math.floor(cx * hs - ucx + 0.5)
  DB.hud.y = math.floor(cy * hs - ucy + 0.5)
end

function PF.HUDApplyLock()
  if not hud then return end
  if DB.hud.locked then
    hud:EnableMouse(false)
    hud.drag:Hide()
  else
    hud:EnableMouse(true)
    hud.drag:Show()
  end
end

function PF.BuildHUD()
  if hud then return end
  hud = CreateFrame("Frame", "PulseFlashHUD", UIParent)
  hud:SetFrameStrata("MEDIUM")
  hud:SetClampedToScreen(true)
  hud:SetMovable(true)
  hud:SetUserPlaced(false)
  hud:RegisterForDrag("LeftButton")
  hud:SetWidth(ICON * 3 + GAP * 2)
  hud:SetHeight(ICON)

  hud.main = MakeIcon(hud)
  hud.main:SetPoint("LEFT", hud, "LEFT", 0, 0)
  hud.q1 = MakeIcon(hud)
  hud.q1:SetPoint("LEFT", hud.main, "RIGHT", GAP, 0)
  hud.q2 = MakeIcon(hud)
  hud.q2:SetPoint("LEFT", hud.q1, "RIGHT", GAP, 0)

  hud.main:Hide(); hud.q1:Hide(); hud.q2:Hide()
  hud.decor = PF.HUDMakeDecor and PF.HUDMakeDecor(hud)

  hud.phaseText = hud:CreateFontString(nil, "OVERLAY")
  PF.SetLFont(hud.phaseText, "Fonts\\FRIZQT__.TTF", 9, "OUTLINE")
  hud.phaseText:SetPoint("BOTTOM", hud, "TOP", 0, 3)

  hud.infoText = hud:CreateFontString(nil, "OVERLAY")
  PF.SetLFont(hud.infoText, "Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
  hud.infoText:SetPoint("TOP", hud, "BOTTOM", 0, -3)
  hud.infoText:SetTextColor(0.45, 1.00, 0.55)

  hud.drag = CreateFrame("Frame", nil, hud)
  hud.drag:SetPoint("TOPLEFT", hud, "TOPLEFT", -4, 4)
  hud.drag:SetPoint("BOTTOMRIGHT", hud, "BOTTOMRIGHT", 4, -4)
  hud.drag:SetFrameLevel(hud:GetFrameLevel() + 10)
  hud.drag:SetBackdrop({ bgFile = EDGE, edgeFile = EDGE, edgeSize = 2,
                         insets = { left = 2, right = 2, top = 2, bottom = 2 } })
  hud.drag:SetBackdropColor(1.00, 0.82, 0.00, 0.20)
  hud.drag:SetBackdropBorderColor(1.00, 0.82, 0.00, 1)
  hud.drag.text = hud.drag:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  hud.drag.text:SetPoint("BOTTOM", hud.drag, "TOP", 0, 4)
  hud.drag.text:SetText(PF.T("hudDrag"))
  PF.OnLangChange(function() hud.drag.text:SetText(PF.T("hudDrag")); hud.phKey = nil end)
  hud.drag:Hide()

  hud:SetScript("OnDragStart", function(self)
    if not DB.hud.locked then self:StartMoving() end
  end)
  hud:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    HUDSavePos()
    HUDApplyPos()
  end)

  HUDApplyPos()
  PF.HUDApplyLock()
  hud:Hide()
end

local function HUDApplyStyle()
  if not hud or not PF.HUDLayout or not (DB and DB.hud) then return end
  local id = DB.hud.style or "classic"
  if hud.styleId == id then return end
  hud.styleId = id
  hud.styleInfo = PF.HUD_STYLES and PF.HUD_STYLES[id] or nil
  PF.HUDLayout(id, hud, hud.main, hud.q1, hud.q2, hud.decor)
end
PF.HUDApplyStyle = HUDApplyStyle
PF.HUDMakeIcon = MakeIcon

local function HUDSetIcon(f, spell, keep)
  if not spell then
    if keep then
      if f.spell or not f:IsShown() then
        f.spell, f.keyAt = nil, nil
        f.icon:SetTexture(nil)
        f.key:SetText("")
        f:Show()
      end
      return
    end
    if f.spell or f:IsShown() then
      f.spell, f.keyAt = nil, nil
      f:Hide()
    end
    return
  end
  local now = GetTime()
  if f.spell ~= spell or not f:IsShown() then
    f.spell = spell
    f.keyAt = nil
    local tex = PF.Texture(spell)
    if not tex then
      f.spell = nil
      f:Hide()
      return
    end
    f.icon:SetTexture(tex)
    f.icon:SetAlpha(1)
    f:Show()
  end
  if not f.keyAt or f.keyEpoch ~= keyEpoch or now - f.keyAt > KEY_REFRESH then
    f.keyAt, f.keyEpoch = now, keyEpoch
    f.key:SetText(KeyFor(spell))
  end
end

local function HUDSetCooldown(f, spell)
  local start, dur = 0, 0
  if spell then
    local id = ItemID(spell)
    if id then start, dur = GetItemCooldown(id)
    else start, dur = GetSpellCooldown(spell) end
  end
  start, dur = start or 0, dur or 0
  if f.cs ~= start or f.cdur ~= dur then
    f.cs, f.cdur = start, dur
    if start > 0 and dur > 0 then CooldownFrame_SetTimer(f.cd, start, dur, 1)
    else CooldownFrame_SetTimer(f.cd, 0, 0, 0) end
  end
end

local function HUDSetSample(f, tex)
  f.spell, f.keyAt = nil, nil
  if not tex then f:Hide(); return end
  f.icon:SetTexture(tex)
  f.icon:SetAlpha(1)
  f.key:SetText("")
  f:Show()
  HUDSetCooldown(f, nil)
end

function PF.UpdateHUD(main, q1, q2)
  if not hud then return end
  local H = DB and DB.hud
  if not H or not DB.enabled or (not H.enabled and not PF.hudTest) then
    hud:Hide()
    return
  end
  HUDApplyStyle()

  -- numero de iconos visibles (1 = solo principal, 2 = + siguiente, 3 = todos)
  local nIcons = tonumber(H.icons) or 3
  if nIcons < 3 then q2 = nil end
  if nIcons < 2 then q1 = nil end

  local inCombat = UnitAffectingCombat("player") and true or false
  local mode = H.mode or "target"
  local visible = PF.hudTest or not H.locked
  if not visible then
    if mode == "combat" then
      visible = inCombat
    elseif mode == "target" then
      visible = (UnitExists("target") and UnitCanAttack("player", "target")
                 and not UnitIsDead("target")) and true or false
    else
      visible = true
    end
  end

  if not visible or (not main and H.locked and not PF.hudTest) then
    hud:Hide()
    return
  end

  if H.locked then
    local a = inCombat and (H.alphaCombat or 1) or (H.alphaOOC or 1)
    if PF.chanIdle and not PF.hudTest then a = a * (H.alphaChannel or HUD_DEFAULT.alphaChannel) end
    hud:SetAlpha(a)
  else
    hud:SetAlpha(1)
  end

  local ph = PF.phase
  if ph ~= "opener" and ph ~= "burn" and ph ~= "final" then ph = false end
  if hud.phKey ~= ph then
    hud.phKey = ph
    if ph then
      hud.phaseText:SetText(PF.T("phase_" .. ph))
      if ph == "opener" then hud.phaseText:SetTextColor(1.00, 0.82, 0.00)
      elseif ph == "burn" then hud.phaseText:SetTextColor(1.00, 0.50, 0.10)
      else hud.phaseText:SetTextColor(1.00, 0.25, 0.25) end
    else
      hud.phaseText:SetText("")
    end
  end

  local info, ikind = "", 0
  if PF.healInfo then info, ikind = PF.healInfo, 1
  elseif PF.multiInfo then info, ikind = PF.multiInfo, 2 end
  if hud.infoKind ~= ikind then
    hud.infoKind = ikind
    if ikind == 1 then hud.infoText:SetTextColor(0.45, 1.00, 0.55)
    elseif ikind == 2 then hud.infoText:SetTextColor(0.35, 0.85, 1.00) end
  end
  if hud.infoStr ~= info then
    hud.infoStr = info
    hud.infoText:SetText(info)
  end
  local wasShown = hud:IsShown()
  hud:Show()
  local st = hud.styleInfo
  local keep = st and st.keepEmpty and true or false
  local p1, p2, p3 = hud.main.spell, hud.q1.spell, hud.q2.spell
  local waitTxt = ""
  if main then
    HUDSetIcon(hud.main, main, keep)
    HUDSetIcon(hud.q1, q1, keep)
    HUDSetIcon(hud.q2, q2, keep)
    HUDSetCooldown(hud.main, main)
    HUDSetCooldown(hud.q1, q1)
    HUDSetCooldown(hud.q2, q2)

    hud.main.icon:SetAlpha(RangeAlpha(main))

    if PF.holdSpell and PF.holdSpell == main and PF.holdEta then
      waitTxt = format("%.1f", PF.holdEta)
    end
    if q1 then hud.q1.icon:SetAlpha(RangeAlpha(q1)) end
    if q2 then hud.q2.icon:SetAlpha(RangeAlpha(q2)) end
  elseif PF.hudTest then

    local t = PF.hudSampleTex
    if not t then
      t = {}
      for n = 1, 40 do
        local tex = GetSpellTexture(n, "spell")
        if tex then
          local dup = false
          for i = 1, #t do if t[i] == tex then dup = true end end
          if not dup then t[#t + 1] = tex end
        end
        if #t == 6 then break end
      end
      if #t >= 3 then PF.hudSampleTex = t end
    end
    HUDSetSample(hud.main, t[1])
    if nIcons >= 2 then HUDSetSample(hud.q1, t[2]) else HUDSetIcon(hud.q1, nil, keep) end
    if nIcons >= 3 then HUDSetSample(hud.q2, t[3]) else HUDSetIcon(hud.q2, nil, keep) end
  else

    HUDSetIcon(hud.main, nil, keep)
    HUDSetIcon(hud.q1, nil, keep)
    HUDSetIcon(hud.q2, nil, keep)
  end
  if waitTxt == "" and main and PF.MainWait then waitTxt = PF.MainWait(main) or "" end
  if hud.main.waitStr ~= waitTxt then
    hud.main.waitStr = waitTxt
    hud.main.wait:SetText(waitTxt)
  end

  if st and st.slide and PF.HUDSlide and hud.decor then
    if main and wasShown then PF.HUDSlide(hud.decor, p1, p2, p3)
    elseif hud.decor.slideStop then hud.decor.slideStop() end
  end

  if st and st.panel and PF.HUDPanel and hud.decor then PF.HUDPanel(hud.decor, main, wasShown) end
  if hud.decor then hud.decor.Sync(hud.q1, hud.q2) end
  if PF.ExtrasDraw then PF.ExtrasDraw(hud) end
end

local function HUDSetLocked(v)
  DB.hud.locked = v and true or false
  PF.HUDApplyLock()
end

function PF.HUDApplyPos()
  if hud and DB then HUDApplyPos() end
end

function PF.ToggleHUDLock()
  if not DB then return end
  if DB.hud.locked then
    DB.hud.enabled = true
    HUDSetLocked(false)
    PF.Msg(PF.T("hudUnlocked"))
  else
    HUDSetLocked(true)
    PF.Msg(PF.T("hudLocked", DB.hud.x, DB.hud.y))
  end
  if PF.RefreshConfig then PF.RefreshConfig() end
end

function PF.ToggleHUDTest()
  PF.hudTest = not PF.hudTest
  PF.Msg(PF.T("hudPreview", PF.hudTest and PF.T("ON_F") or PF.T("OFF_F")))
  if PF.RefreshConfig then PF.RefreshConfig() end
end

local pbClass
local roleAnnounced = {}

local function Report(err)
  if err ~= PF.lastErr then
    PF.lastErr = err
    PF.Msg(PF.T("error", tostring(err)))
  end
end

local function Update()
  PF.holdSpell, PF.holdEta = nil, nil
  PF.multiInfo = nil
  EnsureIndex()
  wipe(want)
  wipe(wantSpell)
  wipe(alertWant)
  wipe(slotSpell)
  local hq1, hq2
  if DB.enabled and module and not UnitIsDeadOrGhost("player")
     and not (IsMounted and IsMounted()) then
    local c = BuildContext()
    nC = 0

    c.role = PF.GetRole and PF.GetRole(pbClass, c.spec) or "dps"
    PF.role = c.role
    if c.role ~= "dps" and not roleAnnounced[c.role] then
      roleAnnounced[c.role] = true
      PF.Msg(PF.T("role_" .. c.role))
    end
    local isDps = (c.role == "dps")
    local isHealer = (c.role == "healer")
    rangeUnit, PF.rangeUnit = "target", nil
    PF.healInfo = nil
    if isHealer and PF.HealerEval then
      c.healMode = true
      local okH2, errH2 = pcall(PF.HealerEval, c, add)
      if not okH2 then Report(errH2) end
      if c.healUnit then rangeUnit, PF.rangeUnit = c.healUnit, c.healUnit end
    end
    if isDps and module.upkeep then
      local okU, errU = pcall(module.upkeep, c, add, PF.N)
      if not okU then Report(errU) end
    end
    if c.hostile and isDps then
      local evalFn = (PF.APL_Active and PF.APL_Active()) and PF.APL_Evaluate or module.evaluate
      local ok, err = pcall(evalFn, c, add, PF.N)
      if not ok then Report(err) end

      if c.combat and c.bigCD and PF.AddTrinkets then
        local okT, errT = pcall(PF.AddTrinkets, add)
        if not okT then Report(errT) end
      end
    end
    local s1, s2, s3
    local resolved = false
    if (isDps and (c.hostile or nC > 0)) or (isHealer and nC > 0) then
      local ok2, r1, r2, r3 = pcall(Resolve, c)
      if ok2 then
        s1, s2, s3 = r1, r2, r3; resolved = true
        if PF.Keep and s1 then s1, s2 = PF.Keep(s1, s2, nC, cSpell, cTier, cExec) end
      else Report(r1) end
    end
    slotSpell[1], slotSpell[2], slotSpell[3] = s1, s2, s3

    if isDps and c.hostile and PF.Multidot_Eval then
      local okM, mdText = pcall(PF.Multidot_Eval, c)
      if okM then PF.multiInfo = mdText else Report(mdText) end
    end

    local chan = UnitChannelInfo("player")
    if chan and PF.CastInLag and PF.CastInLag() then chan = nil end
    PF.chanIdle = (isDps and chan and (s1 == nil or s1 == lastFiller or s1 == chan)) and true or false

    hq1 = s2
    if resolved then
      for i = 1, nC do
        local sp = cSpell[i]
        if (cTier[i] == 1 or cTier[i] == 2) and (cState[i] or 0) >= 2 and sp ~= s1 and sp ~= hq1 then
          hq2 = sp; break
        end
      end
      if not hq2 and lastFiller and lastFiller ~= s1 and lastFiller ~= hq1 then hq2 = lastFiller end
      -- Proyección: la cola refleja el efecto real de s1 (recursos, combos, auras).
      -- Un cooldown listo (nivel 2) mantiene la ranura 2; la proyección rellena el resto.
      if s1 and c.hostile and isDps and PF.ProjOn and PF.ProjOn() then
        local p1, p2 = PF.Project(c, s1, 2)
        if p1 then
          local s2cd = false
          for i = 1, nC do if cSpell[i] == s2 and cTier[i] == 2 then s2cd = true; break end end
          if s2cd then hq1, hq2 = s2, p1 else hq1, hq2 = p1, p2 or hq2 end
        end
      end
    end
    ApplyFlash(s1, 1)
    ApplyFlash(s2, 2)
    ApplyFlash(s3, 3)

    local okA, errA = pcall(ComputeAlerts, c)
    if not okA then Report(errA) end
  end
  Refresh()
  AlertRefresh()

  local okH, errH = pcall(PF.UpdateHUD, slotSpell[1], hq1, hq2)
  if not okH then Report(errH) end
end

local driver = CreateFrame("Frame")
local acc, slow, pulseAcc = 0, 0, 0
driver:SetScript("OnUpdate", function(_, dt)
  if not DB then return end

  pulseAcc = pulseAcc + dt
  if pulseAcc >= 0.033 then
    pulseAcc = 0
    if next(active) ~= nil or next(alertActive) ~= nil then

    local fx = DB.fx or FX_DEFAULT
    local period = fx.period or FX_DEFAULT.period
    if period < 0.1 then period = 0.1 end
    local inten = fx.intensity or FX_DEFAULT.intensity
    local wave = math.sin(GetTime() * (6.2832 / period))
    local sizeStyle = (fx.style == "size")
    for b in pairs(active) do
      local g = glows[b]
      local ra = g.range or 1
      local w, h = g:GetWidth(), g:GetHeight()
      if sizeStyle then

        local f = 1.50 + 0.30 * (0.5 + 0.5 * wave)
        g.tex:SetWidth(w * f); g.tex:SetHeight(h * f)
        g.tex:SetAlpha(0.9 * inten * ra)
        g.fill:SetAlpha(0.35 * inten * ra)
      else

        local a = 0.55 + 0.45 * wave
        g.tex:SetWidth(w * 1.75); g.tex:SetHeight(h * 1.75)
        g.tex:SetAlpha(a * inten * ra)
        g.fill:SetAlpha(a * 0.5 * inten * ra)
      end
    end

    local ar = 0.55 + 0.45 * math.sin(GetTime() * 12)
    for b in pairs(alertActive) do
      local g = alertGlows[b]
      g.tex:SetAlpha(ar)
      g.fill:SetAlpha(ar * 0.5)
    end
    end
  end

  slow = slow + dt
  if slow > 2 then
    slow = 0
    wipe(costCache)
    if PF.Healer_SyncLog then PF.Healer_SyncLog() end
    PF.DetectSpec()
    if module.slow then pcall(module.slow, BuildContext()) end
  end

  acc = acc + dt
  if acc < 0.1 then return end

  if acc < 0.3 and not UnitAffectingCombat("player") and not UnitExists("target") then return end
  acc = 0
  Update()
end)

local POS_COOLDOWN = 3
local POS_SHOW = 2.5
local posFrame, posUntil, lastPosAlert = nil, 0, -100

local function PosFrame()
  if posFrame then return posFrame end
  local f = CreateFrame("Frame", "PulseFlashPosAlert", UIParent)
  f:SetWidth(520); f:SetHeight(50)
  f:SetPoint("CENTER", UIParent, "CENTER", 0, 170)
  f:SetFrameStrata("HIGH")
  f.text = f:CreateFontString(nil, "OVERLAY")
  PF.SetLFont(f.text, "Fonts\\FRIZQT__.TTF", 28, "OUTLINE")
  f.text:SetPoint("CENTER", f, "CENTER", 0, 0)
  f.text:SetTextColor(1, 0.25, 0.1)
  f.text:SetText(PF.T("posText"))
  PF.OnLangChange(function() f.text:SetText(PF.T("posText")) end)
  f:SetScript("OnUpdate", function(self)
    local left = posUntil - GetTime()
    if left <= 0 then self:Hide(); return end
    self:SetAlpha(left < 0.6 and (left / 0.6) or 1)
  end)
  f:Hide()
  posFrame = f
  return f
end

function PF.PositionAlert()
  if not DB then return end
  local mode = DB.posalert
  if not mode or mode == "off" then return end
  local now = GetTime()
  if now - lastPosAlert < POS_COOLDOWN then return end
  lastPosAlert = now
  if mode == "both" or mode == "screen" then
    local f = PosFrame()
    f.text:SetText(PF.T("posText"))
    posUntil = now + POS_SHOW
    f:SetAlpha(1)
    f:Show()
    PlaySound("RaidWarning")
  end
  if mode == "both" or mode == "chat" then
    PF.Msg("|cffff4040" .. PF.T("posText") .. "|r " .. PF.T("posChat"))
  end
end

local function Toggle(key, labelKey)
  DB[key] = not DB[key]
  PF.Msg(PF.T(labelKey) .. ": " .. (DB[key] and PF.T("ON_M") or PF.T("OFF_M")))
end

local ALIAS = {
  mode = "modo", poisons = "venenos", poison = "venenos", stone = "piedra",
  alerts = "alertas", pet = "mascota", prebuff = "buffs", buff = "buffs", buffmove = "bufflock", ver = "version", bosscd = "cds", rol = "roles", role = "roles", tanque = "tank", range = "rango", racials = "raciales", keys = "teclas", keyalias = "alias", multi = "multidot", dots = "multidot", multidots = "multidot",
  position = "posicion", ["posición"] = "posicion",
  settings = "config", menu = "config", options = "config", opciones = "config",
  idioma = "lang", language = "lang", combos = "combo",
}

SLASH_PULSEFLASH1 = "/pf"
SLASH_PULSEFLASH2 = "/pulseflash"
SlashCmdList["PULSEFLASH"] = function(msg)
  local arg
  msg, arg = strlower(strtrim(msg or "")):match("^(%S*)%s*(.-)$")
  msg = ALIAS[msg] or msg

  if msg == "lang" then
    local LANG_ALIAS = {
      es = "es", esp = "es", spanish = "es", ["español"] = "es", espanol = "es",
      en = "en", eng = "en", english = "en", ["inglés"] = "en", ingles = "en",
      ru = "ru", rus = "ru", russian = "ru", ["русский"] = "ru", ruso = "ru",
      pt = "pt", por = "pt", portuguese = "pt", ["português"] = "pt", portugues = "pt", ["portugués"] = "pt",
      de = "de", ger = "de", deu = "de", german = "de", deutsch = "de", aleman = "de", ["alemán"] = "de",
      fr = "fr", fra = "fr", french = "fr", ["français"] = "fr", francais = "fr", frances = "fr", ["francés"] = "fr",
    }
    local l = LANG_ALIAS[arg]
    if arg == "" then
      local cur = PF.GetLang()
      for i, code in ipairs(PF.LANGS) do
        if code == cur then l = PF.LANGS[i % #PF.LANGS + 1]; break end
      end
    end
    if not l then PF.Msg(PF.T("langUsage")); return end
    PF.SetLang(l)
    PF.Msg(PF.T("langIs", PF.LANG_NAMES[l]))
    return
  end
  if not DB then PF.Msg(PF.T("noModule")); return end
  if msg == "on" then DB.enabled = true; PF.Msg(PF.T("enabled"))
  elseif msg == "off" then DB.enabled = false; PF.Msg(PF.T("disabled"))
  elseif msg == "aoe" then
    Toggle("aoe", "t_aoe")
    if PF.ManualAoe then PF.ManualAoe() end
  elseif msg == "modo" then
    local R = DB.rot
    if not R then PF.Msg(PF.T("profileNotLoaded")); return end
    if pbClass ~= "ROGUE" and pbClass ~= "DRUID" then
      PF.Msg(PF.T("modeOnly"))
      return
    end
    if arg == "max" or arg == "maximo" or arg == "máximo" then R.max = true
    elseif arg == "normal" then R.max = false
    elseif arg == "" then R.max = not R.max
    else PF.Msg(PF.T("modeUsage")); return end
    PF.Msg(PF.T("modeIs", R.max and PF.T("MODE_MAX") or PF.T("MODE_NORMAL")))
    if PF.RefreshConfig then PF.RefreshConfig() end
  elseif msg == "combo" then
    if PF.ToggleComboBar then PF.ToggleComboBar() else PF.Msg(PF.T("comboOnly")) end
  elseif msg == "apl" then PF.APL_Command(arg)
  elseif msg == "venenos" then Toggle("poison", "t_poison")
  elseif msg == "bearweave" or msg == "weave" then Toggle("bearweave", "t_bearweave")
  elseif msg == "piedra" then Toggle("stone", "t_stone")
  elseif msg == "hud" then
    DB.hud.enabled = not DB.hud.enabled
    PF.Msg(PF.T("t_hud") .. ": " .. (DB.hud.enabled and PF.T("ON_M") or PF.T("OFF_M")))
  elseif msg == "move" or msg == "lock" then
    PF.ToggleHUDLock()
  elseif msg == "config" then
    if PF.ToggleConfig then PF.ToggleConfig() else PF.Msg(PF.T("noConfig")) end
  elseif msg == "scale" then
    local v = tonumber((string.gsub(arg or "", ",", ".")))
    if v and v >= HUD_SCALE_MIN and v <= HUD_SCALE_MAX then
      DB.hud.scale = v
      HUDApplyPos()
      PF.Msg(PF.T("scaleSet", v))
      if PF.RefreshConfig then PF.RefreshConfig() end
    else
      PF.Msg(PF.T("scaleUsage", HUD_SCALE_MIN, HUD_SCALE_MAX, DB.hud.scale))
    end
  elseif msg == "reset" then
    DB.hud.x, DB.hud.y, DB.hud.scale = HUD_DEFAULT.x, HUD_DEFAULT.y, HUD_DEFAULT.scale
    HUDApplyPos()
    if DB.bhud and PF.BHUD_DEFAULT then
      DB.bhud.x, DB.bhud.y, DB.bhud.scale = PF.BHUD_DEFAULT.x, PF.BHUD_DEFAULT.y, PF.BHUD_DEFAULT.scale
      if PF.BuffHUDApplyPos then PF.BuffHUDApplyPos() end
    end
    if PF.RefreshConfig then PF.RefreshConfig() end
    PF.Msg(PF.T("hudReset"))
  elseif msg == "alertas" then Toggle("alerts", "t_alerts")
  elseif msg == "sim" then
    DB.proj = (DB.proj == false)
    PF.Msg(PF.T("t_proj") .. ": " .. (DB.proj ~= false and PF.T("ON_M") or PF.T("OFF_M")))
  elseif msg == "mascota" then Toggle("pet", "t_pet")
  elseif msg == "totem" then Toggle("totem", "t_totem")
  elseif msg == "rango" then Toggle("range", "t_range")
  elseif msg == "raciales" then Toggle("racial", "t_racial")
  elseif msg == "icc" then

    if pbClass ~= "WARLOCK" then
      PF.Msg(PF.T("iccOnly"))
    else
      DB.icc = not DB.icc
      local doom = PF.N.CurseOfDoom or "Curse of Doom"
      local agony = PF.N.CurseOfAgony or "Curse of Agony"
      if DB.icc then
        PF.Msg(PF.T("iccOn", doom, agony))
        if not PF.Known(doom) then
          PF.Msg(PF.T("iccUnknown", doom, agony))
        end
      else
        PF.Msg(PF.T("iccOff", agony))
      end
    end
  elseif msg == "version" then
    PF.Msg(PF.T("upd_version", (GetAddOnMetadata and GetAddOnMetadata("PulseFlash", "Version")) or "?"))
  elseif msg == "bufflock" then
    if PF.ToggleBuffHUDLock then PF.ToggleBuffHUDLock() end
  elseif msg == "roles" then Toggle("roleLimit", "t_roles")
  elseif msg == "multidot" then PF.Multidot_Toggle()
  elseif msg == "mem" then if PF.MemReport then PF.MemReport() end
  elseif msg == "totems" then if PF.TotemDebug then PF.TotemDebug() end
  elseif msg == "teclas" then PF.KeyDebug()
  elseif msg == "alias" then PF.KeyAliasCommand(arg)
  elseif msg == "plus" then
    if PF.PrecisionCommand then PF.PrecisionCommand(arg) end
  elseif msg == "boss" then
    local r = PF.ToggleBossMark and PF.ToggleBossMark()
    if r == nil then PF.Msg(PF.T("boss_none")) else PF.Msg(PF.T(r and "boss_on" or "boss_off")) end
  elseif msg == "tank" then

    if pbClass ~= "DEATHKNIGHT" then
      PF.Msg(PF.T("tankOnly"))
    else
      DB.dkTank = not DB.dkTank
      PF.Msg(PF.T(DB.dkTank and "tankOn" or "tankOff"))
    end
  elseif msg == "cds" then
    DB.cdAlways = not DB.cdAlways
    PF.Msg(PF.T(DB.cdAlways and "cdsAlways" or "cdsBoss"))
  elseif msg == "buffs" then
    if PF.ToggleBuffHUD then PF.ToggleBuffHUD() end
  elseif msg == "posicion" then
    local MODES = { pantalla = "screen", screen = "screen", chat = "chat", ambos = "both", both = "both", off = "off" }
    if arg and arg ~= "" then
      if MODES[arg] then DB.posalert = MODES[arg]
      else PF.Msg(PF.T("posUsage")); return end
    else
      DB.posalert = (DB.posalert == "off") and "both" or "off"
    end
    PF.Msg(PF.T("posIs", PF.T("posLabel_" .. tostring(DB.posalert))))
    if not (module and module.positional) then
      PF.Msg(PF.T("posNoClass"))
    end
  elseif msg == "num" then
    DB.numPos = (DB.numPos == "CENTER") and "TOPLEFT" or "CENTER"
    PF.Msg(PF.T("numIs", DB.numPos == "CENTER" and PF.T("numCenter") or PF.T("numCorner")))
  elseif msg == "debug" then
    local _, class = UnitClass("player")
    PF.ScanBook()
    PF.Msg(PF.T("dbg_class", class, PF.spec, UnitLevel("player"), PF.bookCount))
    PF.Msg(PF.T("dbg_hp", math.floor((ctx.hp or 1) * 100 + 0.5)))
    for i = 1, 3 do
      PF.Msg(PF.T("dbg_slot", i, slotSpell[i] or "-"))
    end
    local na = 0
    for _ in pairs(alertActive) do na = na + 1 end
    PF.Msg(PF.T("dbg_alerts", na))
    PF.Msg(PF.T("dbg_hud",
      DB.hud.enabled and PF.T("dbg_active") or PF.T("dbg_inactive"),
      DB.hud.locked and PF.T("dbg_locked") or PF.T("dbg_unlocked"),
      DB.hud.x, DB.hud.y, DB.hud.scale))
    PF.Msg(PF.T("dbg_flags", DB.range and "on" or "off",
      DB.racial and "on" or "off", DB.icc and "on" or "off", tostring(DB.posalert)))
    PF.Msg(PF.T("dbg_behind", ctx.behind and PF.T("dbg_yes") or PF.T("dbg_front")))
    PF.Msg(PF.T("dbg_rot", (DB.rot and DB.rot.max) and PF.T("dbg_rotMax") or PF.T("dbg_rotNormal"),
      PF.holdSpell and format("%s (%.1f s)", PF.holdSpell, PF.holdEta or 0) or "-"))
    local bl = PF.BuffList and PF.BuffList() or {}
    PF.Msg(PF.T("dbg_prebuffs", #bl > 0 and table.concat(bl, ", ") or "-"))
    for i = 1, math.min(nC, 14) do
      PF.Msg(PF.T("dbg_cand", cTier[i], cSpell[i], tostring(cState[i])))
    end
  else
    PF.Msg(PF.T("helpLine"))
  end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function(self, event, a1, a2)
  if event == "PLAYER_LOGIN" then
    local classLoc, class = UnitClass("player")
    if PF.LoadClassModules then PF.LoadClassModules(class) end
    module = PF.modules[class]
    PF.module = module
    if not module then
      PF.Msg(PF.T("noModuleClass", tostring(classLoc or class)))
      return
    end

    PulseFlashDB = PulseFlashDB or {}
    DB = PulseFlashDB

    if type(ClassFlashDB) == "table" and ClassFlashDB ~= DB and next(DB) == nil then
      for k, v in pairs(ClassFlashDB) do DB[k] = v end
    end
    PF.db = DB
    if PF.LoadDeferred then PF.LoadDeferred(DB) end
    PF.LoadLangPack(PF.GetLang())
    PF.ApplyFonts()
    if DB.enabled == nil then DB.enabled = true end
    if DB.aoe == nil then DB.aoe = false end
    if DB.poison == nil then DB.poison = true end
    if DB.stone == nil then DB.stone = true end
    if DB.numPos == nil then DB.numPos = "TOPLEFT" end
    if DB.alerts == nil then DB.alerts = true end
    if DB.pet == nil then DB.pet = true end
    if DB.totem == nil then DB.totem = true end
    if DB.range == nil then DB.range = true end
    if DB.racial == nil then DB.racial = true end
    if DB.icc == nil then DB.icc = false end
    -- restos de funciones retiradas (Beta y aviso de version)
    DB.beta, DB.update, DB.updateCheck = nil, nil, nil
    if DB.dkTank == nil then DB.dkTank = false end
    if DB.posalert == nil then DB.posalert = "both" end

    if type(DB.hud) ~= "table" then DB.hud = {} end
    for k, v in pairs(HUD_DEFAULT) do
      if DB.hud[k] == nil then DB.hud[k] = v end
    end
    if type(DB.hud.scale) ~= "number" or DB.hud.scale < HUD_SCALE_MIN or DB.hud.scale > HUD_SCALE_MAX then
      DB.hud.scale = HUD_DEFAULT.scale
    end
    DB.hud.x, DB.hud.y = tonumber(DB.hud.x) or HUD_DEFAULT.x, tonumber(DB.hud.y) or HUD_DEFAULT.y

    if PF.Profiles_Init then PF.Profiles_Init(DB) end
    PF.BuildHUD()

    for k, id in pairs(module.ids) do PF.N[k] = GetSpellInfo(id) end
    wipe(posSet)
    for _, key in ipairs(module.positional or {}) do
      local n = PF.N[key]
      if n then posSet[n] = true end
    end
    pbClass = class
    PF.BuildAlerts(class)
    BuildButtons()
    PF.ScanBook()
    PF.DetectSpec()
    if module.init then module.init() end

    if PF.Sounds_Init then PF.Sounds_Init(class) end
    if PF.Minimap_Init then PF.Minimap_Init() end

    if PF.ComboBar_Init then PF.ComboBar_Init(class) end

    if PF.BuffHUD_Init then PF.BuffHUD_Init(class) end

    if PF.Roles_Init then PF.Roles_Init() end
    if PF.Multidot_Init then PF.Multidot_Init(class) end
    if PF.Healer_Init then PF.Healer_Init(class) end

    self:RegisterEvent("PLAYER_ENTERING_WORLD")
    self:RegisterEvent("SPELLS_CHANGED")
    self:RegisterEvent("LEARNED_SPELL_IN_TAB")
    self:RegisterEvent("PLAYER_TALENT_UPDATE")
    self:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
    self:RegisterEvent("CHARACTER_POINTS_CHANGED")
    self:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
    self:RegisterEvent("PLAYER_TARGET_CHANGED")
    self:RegisterEvent("UI_ERROR_MESSAGE")
    self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")

    for ev in pairs(KEY_EVENTS) do
      if ev ~= "PLAYER_ENTERING_WORLD" and ev ~= "ACTIVE_TALENT_GROUP_CHANGED" then self:RegisterEvent(ev) end
    end

    if class == "WARLOCK" and DB.icc then
      PF.Msg(PF.T("iccLogin"))
    end
    if class == "DEATHKNIGHT" and DB.dkTank then
      PF.Msg(PF.T("tankLogin"))
    end
    DEFAULT_CHAT_FRAME:AddMessage(PF.T("welcome", UnitName("player") or "?", classLoc or class))
    collectgarbage()

  elseif KEY_EVENTS[event] and event ~= "PLAYER_ENTERING_WORLD" and event ~= "ACTIVE_TALENT_GROUP_CHANGED" then
    keyEpoch = keyEpoch + 1

  elseif event == "UNIT_SPELLCAST_SUCCEEDED" then

    if a1 == "player" and a2 then
      PF.lastCast[a2] = GetTime()
      if posSet[a2] then PF.notBehindUntil = 0 end
    end

  elseif event == "UI_ERROR_MESSAGE" then

    if ERR_BADATTACKFACING and (a1 == ERR_BADATTACKFACING or a2 == ERR_BADATTACKFACING) then
      PF.notBehindUntil = GetTime() + 4
    end

    if SPELL_FAILED_NOT_BEHIND and (a1 == SPELL_FAILED_NOT_BEHIND or a2 == SPELL_FAILED_NOT_BEHIND) then
      PF.notBehindUntil = GetTime() + 4
      if module and module.positional then PF.PositionAlert() end
    end

  elseif event == "PLAYER_TARGET_CHANGED" then
    PF.InvalidateAuras()
    PF.notBehindUntil = 0
    wipe(PF.lastCast)

  elseif event == "PLAYER_EQUIPMENT_CHANGED" then
    if module.onEquipment then module.onEquipment() end

  else
    keyEpoch = keyEpoch + 1
    wipe(texCache)
    wipe(costCache)
    PF.ScanBook()
    PF.DetectSpec()
    if module.onEquipment then module.onEquipment() end
  end
end)
