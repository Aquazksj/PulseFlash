-- PulseFlash: Cazador (Bestias / Puntería / Supervivencia) - 3.3.5a
--
-- Supervivencia: Disparo mortal (<20 %) > Picadura de serpiente (se renueva) > Flecha negra (a cada
--   enfriamiento) > Disparo explosivo (Cargar y apuntar: sin coste) > Disparo arcano (con maná) > Disparo firme.
-- Puntería: Picadura de serpiente solo si falta (Disparo quimera la renueva) > Disparo quimera > Disparo
--   apuntado > Disparo arcano (solo con mucho maná) > Disparo firme.
-- Bestias: Disparo mortal > Picadura de serpiente (se renueva) > Orden de matar > Disparo apuntado > Disparo arcano
--   (con maná) > Disparo firme.
-- Modo área (/pf aoe): Multidisparo primero. Con maná bajo se dejan los disparos caros y queda el Disparo
--   firme (el Aspecto de la víbora lo recomienda el HUD de buffos). Curar mascota si baja del 50 %.
local CF = PulseFlash
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

local ARCANE_MIN_MANA = 0.30      -- Disparo arcano / Multidisparo solo con más maná que esto (salvo ejecución)
local ARCANE_MIN_MANA_MM = 0.50   -- en Puntería el Arcano es secundario: solo con mucho maná
local MEND_PET_HP = 0.50          -- Curar mascota por debajo de esta vida de la mascota

local function PetHurt()
  if not UnitExists("pet") or UnitIsDead("pet") then return false end
  local m = UnitHealthMax("pet")
  return m and m > 0 and (UnitHealth("pet") / m) < MEND_PET_HP
end

local function evaluate(c, add, N)
  local spec = c.spec
  local mana = c.manaPct

  -- 1) Procs: Cargar y apuntar (Supervivencia: Disparo explosivo gratis; otras ramas: Arcano)
  Proc(add, N.LockAndLoad, spec == 3 and N.ExplosiveShot or N.ArcaneShot)

  -- Rematar
  if c.hp < 0.20 then add(N.KillShot, 1) end

  -- 2) Mantenimiento de la Picadura de serpiente
  if c.worth then
    local ss = Aura("target", N.SerpentSting, true, true)
    if spec == 2 and Known(N.ChimeraShot) then
      if not ss then Dot(add, c, N.SerpentSting, nil) end      -- Quimera la renueva: solo si falta
    else
      Dot(add, c, N.SerpentSting, ss)                           -- Bestias / Supervivencia / sin rama: se renueva
    end
  end

  -- 3) Rotación por rama (lo que no sea ejecutable se salta)
  if CF.db.aoe and (mana > ARCANE_MIN_MANA or c.burn) then add(N.MultiShot, 1) end
  if spec == 3 then            -- Supervivencia
    if c.worth then add(N.BlackArrow, 1) end                   -- a cada enfriamiento (30 s)
    add(N.ExplosiveShot, 1)
    if mana > ARCANE_MIN_MANA or c.burn then add(N.ArcaneShot, 1) end
  elseif spec == 2 then        -- Puntería
    add(N.ChimeraShot, 1)
    add(N.AimedShot, 1)
    if mana > ARCANE_MIN_MANA_MM or c.burn then add(N.ArcaneShot, 1) end
  elseif spec == 1 then        -- Bestias
    add(N.KillCommand, 1)
    add(N.AimedShot, 1)
    if mana > ARCANE_MIN_MANA or c.burn then add(N.ArcaneShot, 1) end
  else                         -- sin rama (leveling)
    add(N.KillCommand, 1)
    add(N.ArcaneShot, 1)
  end

  -- Cooldowns y marca (cola)
  if c.worth and not Aura("target", N.HuntersMark, true) then add(N.HuntersMark, 2) end
  if c.combat and c.bigCD then                 -- Fuego rápido / Ira bestial: solo contra jefes
    add(N.RapidFire, 2)
    if spec == 1 then add(N.BestialWrath, 2) end
  end

  -- Interrupción / defensivos (verde)
  if (UnitCastingInfo("target") or UnitChannelInfo("target"))
     and IsSpellInRange(N.SilencingShot, "target") == 1 then
    add(N.SilencingShot, 3)
  end
  if c.combat and c.php < 0.30 then add(N.Deterrence, 3) end
  -- Curar mascota si está herida y no tiene ya el efecto (usa el nombre localizado del buff)
  if c.combat and PetHurt() and not Aura("pet", N.MendPet) and not CF.Pending(N.MendPet) then
    add(N.MendPet, 3)
  end
end

-- Relleno infinito: Disparo firme (antes del 62: Disparo arcano / Ataque de Raptor)
local function filler(c, N)
  return First(N.SteadyShot, N.ArcaneShot, N.RaptorStrike)
end

CF.Register("HUNTER", {
  ids = {
    SteadyShot = 56641,  ArcaneShot = 3044,    AimedShot = 19434,
    MultiShot = 2643,    SerpentSting = 1978,  ChimeraShot = 53209,
    ExplosiveShot = 53301, BlackArrow = 3674,  KillShot = 53351,
    KillCommand = 34026, RaptorStrike = 2973,  HuntersMark = 1130,
    RapidFire = 3045,    BestialWrath = 19574, SilencingShot = 34490,
    Deterrence = 19263,  MendPet = 48990,
    AspectViper = 34074, AspectHawk = 13165,   AspectDragonhawk = 61847,
    -- proc (buff)
    LockAndLoad = 56343,
  },
  multidot = { [0] = { "SerpentSting" }, [1] = { "SerpentSting" }, [2] = { "SerpentSting" }, [3] = { "SerpentSting" } },
  evaluate = evaluate,
  filler = filler,
})
