--[[
  PulseFlash 2.0 (antes ClassFlash) - WoW 3.3.5a (WotLK) - rotación estricta por prioridades
  Autor: Aquazksj

  ======================================================================
  ARCHIVOS
    Core.lua ........... motor, resplandor de barras, avisos, HUD de daño, comandos, eventos
    BuffHUD.lua ........ SEGUNDO HUD, solo buffos (aspectos, bendiciones, armaduras, venenos...)
    <Clase>.lua ........ un módulo por clase: ids de hechizos, evaluate(), filler() y, opcional,
                         upkeep(), init(), onEquipment(), slow(). Se registran con PF.Register().

  ÍNDICE DE SECCIONES DE ESTE ARCHIVO (en orden)
    1. Estado interno y utilidades          7. Resaltado de las barras de acción + opacidad por rango
    2. Libro de hechizos / objetos          8. Avisos paralelos (rojo, mascotas, tótems, RACIALES)
    3. Auras (buffs / debuffs / DoTs)       9. HUD flotante (3 iconos + tecla + cooldown + rango)
    4. Contexto (recursos y estado)        10. Update(): une todo cada 0.1 s
    5. Motor: add() / Resolve()            11. Bucle principal (OnUpdate)
    6. (buffos: ahora en BuffHUD.lua)      12. Comandos /pf y eventos / inicialización

  ======================================================================
  REGLAS
   1. Con un objetivo hostil seleccionado el brillo NUNCA se apaga: si ninguna
      habilidad de la lista es ejecutable, brilla en dorado el hechizo de
      relleno (spam base) de la rama.
   2. Orden de evaluación de cada módulo: procs -> mantenimiento de DoTs /
      debuffs / CDs (falta o expira en <= 2.0 s) -> resto de la rotación -> relleno.
   3. Una habilidad no ejecutable (falta recurso, está en cooldown, requiere
      posición o postura, fuera de rango) se SALTA: pasa la siguiente de la lista.
   4. Un DoT/debuff PROPIO ya aplicado (o que se está lanzando / acaba de lanzarse)
      se considera cubierto: no se vuelve a iluminar y la prioridad cae al relleno.
   5. BUFFOS: ya NO aparecen en el HUD de daño ni en el resplandor de las barras. Los buffos
      que faltan (aspecto / sello / bendición / armadura / veneno / grito...) los muestra el
      SEGUNDO HUD (BuffHUD.lua). Los módulos de clase solo recomiendan habilidades de daño.
   6. AVISOS PARALELOS (no bloquean ni alteran la rotación; capa propia sobre el botón):
        ROJO     = vida <= 30% (defensivo de clase / piedra de salud) y casteo enemigo
                   interrumpible (habilidad de corte de tu clase)
        MAGENTA  = invocar/revivir mascota y Llamada de los elementos (en combate)
        CIAN "2" = mascota en postura Agresiva: botón Defensivo/Pasivo (fuera de combate)
   7. HUD FLOTANTE CENTRAL: tres iconos (prioridad 1 + cola) con la tecla asignada y el
      cooldown. Solo LEE el resultado de la rotación: no altera ni desactiva el resplandor
      de las barras. Posición, escala y estado van en PulseFlashDB.hud.
   8. OPACIDAD POR RANGO: el brillo de las barras y los iconos del HUD bajan a alpha 0.35
      si el objetivo está FUERA de alcance de esa habilidad y vuelven a 1.0 en rango
      (o cuando el rango no aplica: hechizos propios, sin objetivo...). "/pf rango".
   9. RACIALES (capa de avisos): resplandor AZUL = racial defensivo / dispel ante una
      amenaza (vida baja, debuff, pérdida de control) | NARANJA = racial ofensivo de ráfaga
      o de recurso. Solo se ilumina si el racial está en una barra. "/pf raciales".
  11. POSICIÓN (Pícaro / Druida feral): las habilidades que exigen estar DETRÁS del objetivo
      (Puñalada trapera, Emboscada, Garrote, Destrozar, Devastar) nunca se recomiendan si el
      objetivo te mira de frente o si el juego acaba de rechazarlas. Si intentas lanzar una y
      falla por posición, aviso en pantalla y/o chat. "/pf posicion [pantalla|chat|ambos|off]".
  10. BRUJO - MODO ICC/BANDA: "/pf icc" cambia Maldición de agonía por Maldición de
      apocalipsis en la prioridad principal (ver Warlock.lua). Apagado por defecto.

  ======================================================================
  COLORES / NÚMEROS
     1 = dorado (pulsa esto ya) | 2 = cian (siguiente en cola) | 3 = verde (interrupción / defensivo)

  COMANDOS: /pf  (alias: /pulseflash)   -> "/pf" sin argumentos lista todos
]]

local wipe = table.wipe or function(t) for k in pairs(t) do t[k] = nil end end
local GetTime = GetTime
local pairs, select, math = pairs, select, math

PulseFlash = PulseFlash or {}
local PF = PulseFlash
PF.modules = {}
PF.N = {}                 -- nombres localizados de hechizos (los rellena cada módulo)
PF.spec = 0               -- 0 = sin spec clara, 1/2/3 = pestaña de talentos principal
PF.notBehindUntil = 0     -- hasta cuándo "no estás detrás" (error de posición)
PF.bookCount = 0
PF.lastCast = {}          -- [hechizo] = instante del último cast exitoso del jugador
PF.holdSpell, PF.holdEta = nil, nil   -- habilidad por la que se espera y segundos que faltan (la lee el HUD)

-- Compatibilidad: los módulos antiguos hacen "local CF = ClassFlash"
ClassFlash = PF

local DB, module
local knownSet = {}
local buttons, glows, want, active = {}, {}, {}, {}
local wantSpell = {}       -- [botón] = hechizo que lo ilumina (para la opacidad por rango)
local ctx = {}
local posSet = {}           -- [hechizo] = true: exige estar DETRÁS del objetivo (lo declara cada módulo en "positional")
local cSpell, cTier, cState, cExec, nC = {}, {}, {}, {}, 0
local cHold = {}            -- [i] = segundos de espera si la entrada es una "espera" (modo máximo daño)
local slotSpell = {}
local lastFiller            -- relleno calculado en el último Resolve (lo usa la cola del HUD)

local TIER_COLOR = {
  [1] = { 1.00, 0.82, 0.00 },   -- GOLD
  [2] = { 0.25, 0.85, 1.00 },   -- CYAN
  [3] = { 0.20, 1.00, 0.30 },   -- VERDE
}
local GCD_TOL = 1.5           -- un cooldown con menos de esto cuenta como "listo"
local DOT_REFRESH = 2.0       -- un DoT/debuff propio solo se (re)aplica si falta o le quedan <= 2.0 s

function PF.Msg(s)
  DEFAULT_CHAT_FRAME:AddMessage("|cffffd100PulseFlash:|r " .. s)
end

function PF.Register(class, mod)
  PF.modules[class] = mod
end

----------------------------------------------------------------------
-- Libro de hechizos (IsSpellKnown no existe en 3.3.5: se escanean las pestañas)
----------------------------------------------------------------------
function PF.ScanBook()
  wipe(knownSet)
  local count = 0
  for tab = 1, GetNumSpellTabs() do
    local _, _, offset, num = GetSpellTabInfo(tab)
    for i = offset + 1, offset + num do
      local name = GetSpellName(i, BOOKTYPE_SPELL)
      if name then
        if not knownSet[name] then count = count + 1 end
        knownSet[name] = true
      end
    end
  end
  PF.bookCount = count
end

-- Objetos del inventario (piedras, etc.): se identifican como "item:ID"
function PF.Item(id) return "item:" .. id end
local function ItemID(n)
  return n and tonumber(n:match("^item:(%d+)$"))
end

function PF.Known(n)
  if not n then return false end
  local id = ItemID(n)
  if id then return (GetItemCount(id) or 0) > 0 or (IsEquippedItem and IsEquippedItem(id)) or false end
  if knownSet[n] then return true end
  if PF.bookCount == 0 then return GetSpellTexture(n) ~= nil end  -- libro aún sin cargar
  return false
end

-- Icono del hechizo u objeto (para localizar su botón en las barras)
function PF.Texture(n)
  local id = ItemID(n)
  if id then return GetItemIcon(id) end
  return GetSpellTexture(n)
end

-- Primer hechizo de la lista que tengas aprendido
function PF.First(...)
  for i = 1, select("#", ...) do
    local n = select(i, ...)
    if n and PF.Known(n) then return n end
  end
  return nil
end

-- 0 = desconocido | 1 = en cooldown / no usable (postura, posición, requisito)
-- 2 = listo pero falta recurso | 3 = lanzable ahora
function PF.State(n)
  if not PF.Known(n) then return 0 end
  local itemID = ItemID(n)
  if itemID then
    local is, id = GetItemCooldown(itemID)
    if is and is > 0 and id and id > 0 and (is + id - GetTime()) > GCD_TOL then return 1 end
    return 3
  end
  local s, d = GetSpellCooldown(n)
  if s and s > 0 and d and d > 0 and (s + d - GetTime()) > GCD_TOL then return 1 end
  local usable, nomana = IsUsableSpell(n)
  if usable then return 3 end
  if nomana then return 2 end
  return 1
end

----------------------------------------------------------------------
-- Auras
----------------------------------------------------------------------
-- DEBUFF PROPIO en el objetivo (estricto): recorre UnitDebuff("target", 1..40)
-- y solo acepta el debuff con ese nombre cuyo lanzador sea EXACTAMENTE "player".
-- Devuelve: segundos restantes, cargas, duración total, instante de expiración
-- (nil si no existe). Debuffs sin duración devuelven 9999 segundos.
function PF.HasDebuff(name)
  if not name then return nil end
  for i = 1, 40 do
    local n, _, _, count, _, duration, expires, caster = UnitDebuff("target", i)
    if not n then return nil end
    if n == name and caster == "player" then
      local left = (expires and expires > 0) and (expires - GetTime()) or 9999
      return left, ((count and count > 0) and count or 1), duration, expires
    end
  end
  return nil
end
PF.UnitDebuffCheck = PF.HasDebuff

-- Segundos restantes del aura (nil si no está) y número de cargas
function PF.Aura(unit, name, harmful, mine, prefix)
  if not name then return nil end
  if harmful and mine and not prefix and unit == "target" then
    return PF.HasDebuff(name)                 -- ruta estricta de DoTs propios
  end
  local fn = harmful and UnitDebuff or UnitBuff
  for i = 1, 40 do
    local n, _, _, count, _, duration, expires, caster = fn(unit, i)
    if not n then return nil end
    if (n == name or (prefix and n:sub(1, #name) == name)) and (not mine or caster == "player") then
      local left = (expires and expires > 0) and (expires - GetTime()) or 9999
      -- devuelve: segundos restantes, cargas, duración total, instante de expiración
      return left, ((count and count > 0) and count or 1), duration, expires
    end
  end
  return nil
end

-- ¿El jugador está lanzando / canalizando ese hechizo ahora mismo?
function PF.IsCasting(spell)
  if not spell then return false end
  local cast = UnitCastingInfo("player")
  if cast and cast == spell then return true end
  local chan = UnitChannelInfo("player")
  return (chan and chan == spell) and true or false
end

-- ¿Se lanzó ese hechizo hace un instante (el aura aún no llega por latencia)?
function PF.Pending(spell)
  local t = spell and PF.lastCast[spell]
  if not t then return false end
  local _, _, lat = GetNetStats()
  local grace = 0.5 + 2 * ((lat or 0) / 1000)
  if grace > 1.5 then grace = 1.5 end
  return (GetTime() - t) < grace
end

-- DoT / debuff de mantenimiento (prioridad 1 = dorado):
--   * solo se sugiere si NO existe, o si le quedan <= 2.0 s
--   * si ya lo estás lanzando (UnitCastingInfo/ChannelInfo) o acabas de lanzarlo,
--     se da por cubierto y NO se ilumina
--   * cubierto -> no se añade nada: la prioridad cae a la rotación / relleno
-- (los parámetros "soon" y "urgent" se conservan por compatibilidad y se ignoran)
function PF.Dot(add, c, spell, left, soon, urgent)
  if not spell then return end
  if left and left > DOT_REFRESH then return end      -- activo y con tiempo: cubierto
  if PF.IsCasting(spell) or c.casting == spell then return end
  if PF.Pending(spell) then return end
  add(spell, 1)
end

-- Proc: si el buff propio está activo (con las cargas mínimas), esa habilidad es prioridad 1
function PF.Proc(add, buff, spell, minStacks)
  if not buff or not spell then return end
  local left, n = PF.Aura("player", buff)
  if left and n >= (minStacks or 1) then add(spell, 1) end
end

-- ¿Tienes puntos en ese talento? (por nombre localizado; false si la API no está disponible)
function PF.HasTalent(name)
  if not name or not GetNumTalentTabs or not GetTalentInfo then return false end
  for tab = 1, GetNumTalentTabs() do
    for i = 1, (GetNumTalents and GetNumTalents(tab) or 0) do
      local n, _, _, _, rank = GetTalentInfo(tab, i)
      if n == name then return (rank or 0) > 0 end
    end
  end
  return false
end

-- ¿Esa habilidad exige estar detrás del objetivo?
function PF.IsPositional(spell) return spell and posSet[spell] and true or false end

function PF.DetectSpec()
  local best, pts = 0, 0
  for i = 1, 3 do
    local _, _, p = GetTalentTabInfo(i)
    if p and p > pts then best, pts = i, p end
  end
  if pts < 5 then best = 0 end
  PF.spec = best
end

----------------------------------------------------------------------
-- Contexto: recursos y estado en este instante
----------------------------------------------------------------------
-- GetWeaponEnchantInfo en WotLK: (hasMH, mhExp, mhCharges, mhID, hasOH, ohExp, ohCharges, ohID).
-- Si el cliente devuelve solo 6 valores (sin los IDs) también se adapta.
local function pack(...) return select("#", ...), ... end
function PF.WeaponEnchants()
  local n, a, b, c, d, e, f, g, h = pack(GetWeaponEnchantInfo())
  if n >= 8 then return a, b, c, d, e, f, g, h end
  return a, b, c, nil, d, e, f, nil
end

-- Fases del jefe (solo contra jefes y en combate), según el tiempo de pelea y la vida del jefe:
--   opener = primeros OPENER_TIME s | main = resto | burn = jefe <= BURN_HP | final = jefe <= FINAL_HP
-- En "burn"/"final" (c.burn) ya no hace falta ahorrar maná ni ira: los módulos dejan de conservar.
local OPENER_TIME, BURN_HP, FINAL_HP = 12, 0.35, 0.10
local fightStart = nil

local function BuildContext()
  local c = ctx
  c.level = UnitLevel("player")
  c.combat = UnitAffectingCombat("player") and true or false
  c.spec = PF.spec
  c.hostile = (UnitExists("target") and UnitCanAttack("player", "target")
               and not UnitIsDead("target")) and true or false
  -- Jefe (Boss.lua): calavera, clasificación de jefe, marco de jefe, marca manual o élite con mucha vida
  local tl = c.hostile and UnitLevel("target") or 0
  local tc = c.hostile and UnitClassification("target") or nil
  if c.hostile then
    if PF.DetectBoss then
      c.boss = PF.DetectBoss(c.level, tl, tc) and true or false
    else
      c.boss = (tl == -1 or tc == "worldboss" or (tc == "elite" and tl >= c.level + 2)) and true or false
    end
  else
    c.boss = false
  end
  -- Cooldowns de más de 1 minuto y trinkets: solo contra jefes (o siempre con /pf cds)
  c.bigCD = (c.boss or (DB and DB.cdAlways)) and true or false
  local hm = UnitHealthMax("target")
  c.hp = (c.hostile and hm and hm > 0) and (UnitHealth("target") / hm) or 1
  c.worth = c.hostile and (c.boss or c.hp > 0.20) or false   -- merece la pena aplicar DoTs
  -- Cronómetro de la pelea y fase del jefe
  if c.combat then
    if not fightStart then fightStart = GetTime() end
  else
    fightStart = nil
  end
  c.fightTime = fightStart and (GetTime() - fightStart) or 0
  c.phase = nil
  if c.boss and c.combat then
    if c.hp <= FINAL_HP then c.phase = "final"
    elseif c.hp <= BURN_HP then c.phase = "burn"
    elseif c.fightTime < OPENER_TIME then c.phase = "opener"
    else c.phase = "main" end
  end
  c.burn = (c.phase == "burn" or c.phase == "final")
  PF.phase, PF.burn = c.phase, c.burn
  local pm = UnitHealthMax("player")
  c.php = (pm and pm > 0) and (UnitHealth("player") / pm) or 1
  c.mana = UnitPower("player", 0) or 0
  local mm = UnitPowerMax("player", 0) or 0
  c.manaPct = (mm > 0) and (c.mana / mm) or 1
  c.rage = UnitPower("player", 1) or 0
  c.energy = UnitPower("player", 3) or 0
  c.runic = UnitPower("player", 6) or 0
  c.cp = GetComboPoints("player", "target") or 0
  -- "Detrás": sin error reciente de posición y el objetivo no te está atacando a ti
  c.behind = (GetTime() > PF.notBehindUntil) and not UnitIsUnit("targettarget", "player")
  c.casting = UnitCastingInfo("player") or UnitChannelInfo("player")
  return c
end

----------------------------------------------------------------------
-- Motor: los módulos llaman add(hechizo, tier) en orden de prioridad
--   tier 1: rotación (procs, mantenimiento urgente, habilidades de la rama)
--   tier 2: cola (cooldowns ofensivos, utilidades)
--   tier 3: interrupción / defensivo / utilidad
----------------------------------------------------------------------
-- add(hechizo, tier [, espera])
--   espera (opcional, segundos): marca la entrada como "ESPERA" del modo máximo daño. Una entrada
--   con espera se elige para el slot 1 aunque aún no sea lanzable (falta energía o aún no toca
--   refrescarla): el addon le dice al jugador "espera por esto" en vez de gastar la energía en
--   una habilidad peor. Los módulos antiguos llaman add(spell, tier) y no cambian en nada.
-- Devuelve true si la habilidad se añadió a la lista.
local rangeUnit = "target"        -- unidad a la que se comprueba el rango (aliado a sanar o el objetivo)

local function add(spell, tier, hold)
  if spell and PF.Known(spell) then
    if posSet[spell] and not ctx.behind then return false end   -- de frente: no se recomienda
    nC = nC + 1
    cSpell[nC] = spell
    cTier[nC] = tier
    cHold[nC] = hold
    return true
  end
  return false
end

----------------------------------------------------------------------
-- Ayudas para el modo MÁXIMO DAÑO (Pícaro / Druida feral): energía y esperas
----------------------------------------------------------------------
local HOLD_MAX_WAIT = 2.0      -- no se espera más de estos segundos por una habilidad mejor
local POOL_MAX_T = 6.0         -- solo se acumula energía para refrescos que vencen en menos de esto

-- Coste de energía de un hechizo según GetSpellInfo (nil si no se conoce)
function PF.Cost(spell)
  if not spell then return nil end
  local cost = select(4, GetSpellInfo(spell))
  cost = tonumber(cost)
  if cost and cost > 0 then return cost end
  return nil
end

-- Segundos hasta tener energía para ese hechizo, SOLO si ahora mismo solo falta energía y la espera
-- es corta (<= maxWait). nil = no esperar (ya es lanzable, está en cooldown o falta demasiado).
function PF.HoldEta(spell, regen, maxWait)
  if not spell or PF.State(spell) ~= 2 then return nil end
  local cost = PF.Cost(spell)
  if not cost then return nil end
  local deficit = cost - (UnitPower("player", 3) or 0)
  if deficit <= 0 then return nil end
  local eta = deficit / ((regen and regen > 0) and regen or 10)
  if eta > (maxWait or HOLD_MAX_WAIT) then return nil end
  return eta
end

-- Acumulación de energía: ¿puedo gastar `spendCost` ahora sin quedarme sin energía para lanzar
-- `refreshCost` dentro de `t` segundos (cuando vence el DoT / buff)? Con coste desconocido: true.
function PF.CanSpend(spendCost, refreshCost, t, regen)
  if not spendCost or not refreshCost then return true end
  local e = UnitPower("player", 3) or 0
  local after = e - spendCost
  if after < 0 then after = 0 end
  return (after + (regen or 10) * t) >= refreshCost
end
PF.POOL_MAX_T = POOL_MAX_T

-- Resolve(): decide qué brilla en 1 (dorado), 2 (cian) y 3 (verde).
--  * 1 = primera habilidad tier 1 EJECUTABLE (se saltan las que no lo son).
--        Si no hay ninguna (p. ej. todos los DoTs cubiertos), el relleno
--        infinito de la rama (siempre dorado).
--  * 2 = lo siguiente en cola: tier 2 explícito, o la siguiente tier 1 pendiente
--        (esperando recurso); si no hay nada, el relleno.
--  * 3 = primera tier 3 ejecutable (interrupción / defensivo).
local function Resolve(c)
  for i = 1, nC do
    local sp = cSpell[i]
    local st = PF.State(sp)
    cState[i] = st
    local isItem = sp:find("^item:") ~= nil
    cExec[i] = (st == 3) and (isItem or IsSpellInRange(sp, rangeUnit) ~= 0)
  end

  local s1, s3, q1, t2
  PF.holdSpell, PF.holdEta = nil, nil
  for i = 1, nC do
    if cTier[i] == 1 and (cExec[i] or (cHold[i] and cState[i] >= 2)) then
      s1 = cSpell[i]
      -- ESPERA (modo máximo daño): la entrada manda aunque aún no sea lanzable (falta energía)
      -- o aún no toque refrescarla (acumulando energía); el HUD muestra la cuenta atrás
      if cHold[i] then PF.holdSpell, PF.holdEta = s1, cHold[i] end
      break
    end
  end
  for i = 1, nC do
    if cTier[i] == 3 and cExec[i] then s3 = cSpell[i]; break end
  end

  local filler = c.hostile and not c.healMode and module.filler and module.filler(c, PF.N) or nil
  if filler and not PF.Known(filler) then filler = nil end
  lastFiller = filler
  if not s1 then s1 = filler end                     -- relleno infinito: nunca se apaga

  for i = 1, nC do
    local sp = cSpell[i]
    if sp ~= s1 and cState[i] >= 2 then
      if cTier[i] == 2 then
        if not t2 then t2 = sp end
      elseif cTier[i] == 1 and not q1 then
        q1 = sp
      end
    end
  end

  if not c.hostile and not c.healMode then return s1, nil, nil end   -- sin objetivo: solo mantenimiento en dorado
  local s2 = t2 or q1
  if not s2 and filler and filler ~= s1 then s2 = filler end
  if s2 and s2 == s3 then s2 = nil end
  return s1, s2, s3
end


----------------------------------------------------------------------
-- Resaltado en las barras de acción por defecto
----------------------------------------------------------------------
local function BuildButtons()
  local prefixes = {
    "ActionButton", "MultiBarBottomLeftButton", "MultiBarBottomRightButton",
    "MultiBarRightButton", "MultiBarLeftButton",
    "BonusActionButton",      -- barra de formas/posturas (lechúcico, gato, sigilo, Sombras...)
    "MultiCastActionButton",  -- barra de tótems del Chamán
  }
  for _, p in pairs(prefixes) do
    for i = 1, 12 do
      local b = _G[p .. i]
      if b then buttons[#buttons + 1] = b end
    end
  end
end

local function GetGlow(btn)
  local g = glows[btn]
  if g then return g end
  g = CreateFrame("Frame", nil, btn)
  g:SetFrameLevel(btn:GetFrameLevel() + 5)
  g:SetAllPoints(btn)

  g.fill = g:CreateTexture(nil, "OVERLAY")
  g.fill:SetTexture("Interface\\Buttons\\CheckButtonHilight")
  g.fill:SetBlendMode("ADD")
  g.fill:SetAllPoints(g)

  g.tex = g:CreateTexture(nil, "OVERLAY")
  g.tex:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
  g.tex:SetBlendMode("ADD")
  g.tex:SetPoint("CENTER", g, "CENTER", 0, 0)
  g.tex:SetWidth(btn:GetWidth() * 1.75)
  g.tex:SetHeight(btn:GetHeight() * 1.75)

  g.num = g:CreateFontString(nil, "OVERLAY")
  g.num:SetFont("Fonts\\FRIZQT__.TTF", 18, "THICKOUTLINE")

  glows[btn] = g
  return g
end

----------------------------------------------------------------------
-- Opacidad por rango: 0.35 si el objetivo está fuera de alcance, 1.0 en rango.
-- IsSpellInRange / IsItemInRange devuelven 1 (en rango), 0 (fuera) o nil (no aplica:
-- sin objetivo, hechizo propio...). Solo "0" atenúa.
----------------------------------------------------------------------
local RANGE_ALPHA_OUT, RANGE_ALPHA_IN = 0.35, 1.0

local function RangeAlpha(spell)
  if not spell or not (DB and DB.range) then return RANGE_ALPHA_IN end
  local r
  local id = ItemID(spell)
  local ru = PF.rangeUnit or "target"
  if id then r = IsItemInRange(id, ru) else r = IsSpellInRange(spell, ru) end
  if r == 0 then return RANGE_ALPHA_OUT end
  return RANGE_ALPHA_IN
end
PF.RangeAlpha = RangeAlpha

-- Acción de un botón (los de la barra de tótems pueden exponerla solo como atributo "action")
local function BtnAction(b)
  return b.action or (b.GetAttribute and tonumber(b:GetAttribute("action")))
end

local function ApplyFlash(spell, tier)
  if not spell then return end
  local tex = PF.Texture(spell)
  if not tex then return end
  tex = tex:lower()
  for i = 1, #buttons do
    local b = buttons[i]
    local a = BtnAction(b)
    if a and b:IsVisible() and HasAction(a) and not want[b] then
      local t = GetActionTexture(a)
      if t and t:lower() == tex then want[b] = tier; wantSpell[b] = spell end
    end
  end
end

local function Refresh()
  for b in pairs(active) do
    if not want[b] then
      glows[b]:Hide()
      active[b] = nil
    end
  end
  local pos = DB and DB.numPos or "TOPLEFT"
  for b, tier in pairs(want) do
    local g = GetGlow(b)
    local col = TIER_COLOR[tier]
    g.tex:SetVertexColor(col[1], col[2], col[3])
    g.fill:SetVertexColor(col[1], col[2], col[3])
    g.num:SetTextColor(col[1], col[2], col[3])
    g.num:SetText(tostring(tier))
    g.range = RangeAlpha(wantSpell[b])           -- 0.35 fuera de rango / 1.0 en rango
    g.num:SetAlpha(g.range)
    g.num:ClearAllPoints()
    if pos == "CENTER" then
      g.num:SetPoint("CENTER", g, "CENTER", 0, 0)
    else
      g.num:SetPoint("TOPLEFT", g, "TOPLEFT", 3, -3)
    end
    g:Show()
    active[b] = true
  end
end


----------------------------------------------------------------------
-- AVISOS PARALELOS: Capa Roja (supervivencia / interrupción), mascotas y tótems
-- Usan una capa de resplandor propia (alertWant / alertGlows): jamás tocan la lista
-- de la rotación (want / cSpell), así que no la interrumpen ni la bloquean.
----------------------------------------------------------------------
local ALERT_COLOR = {
  red     = { 1.00, 0.10, 0.10 },
  magenta = { 0.90, 0.25, 1.00 },
  blue    = { 0.25, 0.55, 1.00 },      -- raciales defensivos / dispel
  orange  = { 1.00, 0.50, 0.00 },      -- raciales ofensivos (ráfaga / recurso)
}
local ALERT_IDS = {
  WARRIOR     = { def = { 55694, 12975, 871 },      int = { 6552, 72 } },
  PALADIN     = { def = { 642, 498 },               int = { 853 } },
  HUNTER      = { def = { 19263, 5384 },            int = { 34490, 19503 },
                  pet = { all = { 883 }, revive = 982 } },
  ROGUE       = { def = { 5277, 31224, 1856 },      int = { 1766 } },
  PRIEST      = { def = { 47585, 19236, 17 },       int = { 15487 } },
  SHAMAN      = { def = { 30823, 331 },             int = { 57994 }, totem = 66842 },
  MAGE        = { def = { 45438, 1463 },            int = { 2139 } },
  WARLOCK     = { def = { 6789 },                   int = { 6789 },
                  pet = { [1] = { 691, 697, 688, 712 }, [2] = { 30146, 691, 697, 688 },
                          [3] = { 688, 697, 691, 712 }, all = { 688, 697, 691, 712 } } },
  DRUID       = { def = { 61336, 22812 },           int = { 5211 } },
  DEATHKNIGHT = { def = { 48792, 48707, 55233 },    int = { 47528, 47476 },
                  pet = { [3] = { 46584 } } },
}
-- Piedras de salud (objetos): se detectan en las bolsas y brillan si están en una barra
local HEALTHSTONES = { 5512, 5511, 5510, 5509, 9421, 19004, 19005, 19006, 19007, 19008, 19009,
                       19010, 19011, 19012, 19013, 22103, 22104, 22105, 36889, 36890, 36891,
                       36892, 36893, 36894 }

local A = {}            -- hechizos de la clase (nombres localizados)
local alertWant, alertGlows, alertActive = {}, {}, {}

local function Names(ids)
  local t = {}
  for i = 1, #(ids or {}) do
    local n = GetSpellInfo(ids[i])
    if n then t[#t + 1] = n end
  end
  return t
end

----------------------------------------------------------------------
-- RACIALES: un racial activo por raza. "kind" decide cuándo y de qué color se ilumina.
--   burst   (naranja) ráfaga ofensiva: en combate con un objetivo que lo merezca
--   power   (naranja) recurso (Torrente arcano): en combate con el recurso bajo
--   heal    (azul)    curación (Ofrenda de los naaru): en combate con vida < 50%
--   panic   (azul)    huida / aturdimiento (Pisotón, Fusión con las sombras): vida < 35%
--   control (azul)    Voluntad de los Renegados / Cada hombre por sí mismo: sin control
--   snare   (azul)    Artista del escape: ralentizado o inmovilizado (lista de debuffs)
--   cleanse (azul)    Forma de piedra: veneno, enfermedad o sangrado en ti
----------------------------------------------------------------------
local RACIALS = {
  Orc      = { id = 20572, kind = "burst" },     -- Furia sangrienta
  Troll    = { id = 26297, kind = "burst" },     -- Berserker
  BloodElf = { id = 28730, kind = "power" },     -- Torrente arcano
  Draenei  = { id = 28880, kind = "heal" },      -- Ofrenda de los naaru
  Tauren   = { id = 20549, kind = "panic" },     -- Pisotón de guerra
  NightElf = { id = 58984, kind = "panic" },     -- Fusión con las sombras
  Scourge  = { id = 7744,  kind = "control" },   -- Voluntad de los Renegados
  Human    = { id = 59752, kind = "control" },   -- Cada hombre por sí mismo
  Gnome    = { id = 20589, kind = "snare" },     -- Artista del escape
  Dwarf    = { id = 20594, kind = "cleanse" },   -- Forma de piedra
}
-- Debuffs de ralentización / inmovilización (Artista del escape)
local SNARE_IDS = { 122, 339, 1715, 5116, 8056, 116, 120, 2974, 3409, 45524, 12494, 18223,
                    3600, 31589, 1604, 15407, 55095, 20184, 58179, 12323 }
-- Sangrados (Forma de piedra); veneno y enfermedad se detectan por el tipo de debuff
local BLEED_IDS = { 772, 1822, 1079, 703, 1943, 12721, 33745, 9007 }
local snareSet, bleedSet = {}, {}

function PF.BuildAlerts(class)
  wipe(A)
  wipe(snareSet); wipe(bleedSet)
  for i = 1, #SNARE_IDS do
    local n = GetSpellInfo(SNARE_IDS[i]); if n then snareSet[n] = true end
  end
  for i = 1, #BLEED_IDS do
    local n = GetSpellInfo(BLEED_IDS[i]); if n then bleedSet[n] = true end
  end
  local _, race = UnitRace("player")
  local rc = race and RACIALS[race]
  if rc then A.racial = { name = GetSpellInfo(rc.id), kind = rc.kind } end
  local d = ALERT_IDS[class]
  if not d then return end
  A.def, A.int = Names(d.def), Names(d.int)
  A.totem = d.totem and GetSpellInfo(d.totem) or nil
  if d.pet then
    A.pet = { revive = d.pet.revive and GetSpellInfo(d.pet.revive) or nil }
    for k, v in pairs(d.pet) do
      if type(v) == "table" then A.pet[k] = Names(v) end
    end
  end
end

local function GetAlertGlow(btn)
  local g = alertGlows[btn]
  if g then return g end
  g = CreateFrame("Frame", nil, btn)
  g:SetFrameLevel(btn:GetFrameLevel() + 8)
  g:SetAllPoints(btn)
  g.fill = g:CreateTexture(nil, "OVERLAY")
  g.fill:SetTexture("Interface\\Buttons\\CheckButtonHilight")
  g.fill:SetBlendMode("ADD")
  g.fill:SetAllPoints(g)
  g.tex = g:CreateTexture(nil, "OVERLAY")
  g.tex:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
  g.tex:SetBlendMode("ADD")
  g.tex:SetPoint("CENTER", g, "CENTER", 0, 0)
  g.tex:SetWidth(btn:GetWidth() * 1.55)
  g.tex:SetHeight(btn:GetHeight() * 1.55)
  alertGlows[btn] = g
  return g
end

-- Marca en la capa de avisos el/los botones cuyo icono coincide con el hechizo u objeto
-- Devuelve true si algún botón visible tiene ese hechizo / objeto
local function ApplyAlert(spell, key)
  if not spell then return false end
  local tex = PF.Texture(spell)
  if not tex then return false end
  tex = tex:lower()
  local hit = false
  for i = 1, #buttons do
    local b = buttons[i]
    local a = BtnAction(b)
    if a and b:IsVisible() and HasAction(a) then
      local t = GetActionTexture(a)
      if t and t:lower() == tex then
        hit = true
        if not alertWant[b] then alertWant[b] = key end
      end
    end
  end
  return hit
end

local function AlertRefresh()
  for b in pairs(alertActive) do
    if not alertWant[b] then
      alertGlows[b]:Hide()
      alertActive[b] = nil
    end
  end
  for b, key in pairs(alertWant) do
    local g = GetAlertGlow(b)
    local col = ALERT_COLOR[key]
    g.tex:SetVertexColor(col[1], col[2], col[3])
    g.fill:SetVertexColor(col[1], col[2], col[3])
    g:Show()
    alertActive[b] = true
  end
end

-- Primer hechizo de la lista lanzable ahora (y a rango si se pide)
local function FirstReady(list, checkRange)
  if not list then return nil end
  for i = 1, #list do
    local sp = list[i]
    if PF.Known(sp) and not PF.IsCasting(sp) and PF.State(sp) == 3
       and (not checkRange or IsSpellInRange(sp, PF.rangeUnit or "target") ~= 0) then
      return sp
    end
  end
  return nil
end

local function ReadyHealthstone()
  for i = 1, #HEALTHSTONES do
    local id = HEALTHSTONES[i]
    if (GetItemCount(id) or 0) > 0 then
      local item = PF.Item(id)
      if PF.State(item) == 3 then return item end
    end
  end
  return nil
end

-- ¿El objetivo hostil está lanzando/canalizando algo interrumpible?
local function TargetInterruptible()
  if not (UnitExists("target") and UnitCanAttack("player", "target")) then return false end
  if UnitCastingInfo("target") then
    return not select(9, UnitCastingInfo("target"))    -- 9º valor = notInterruptible
  end
  if UnitChannelInfo("target") then
    return not select(8, UnitChannelInfo("target"))    -- 8º valor = notInterruptible
  end
  return false
end

-- Supervivencia: vida <= 30% -> defensivo principal y piedra de salud en ROJO
local function AlertSurvival()
  local hm = UnitHealthMax("player")
  if not hm or hm <= 0 or UnitHealth("player") / hm > 0.30 then return end
  ApplyAlert(FirstReady(A.def), "red")
  ApplyAlert(ReadyHealthstone(), "red")
end

-- Interrupción: casteo interrumpible del objetivo -> habilidad de corte en ROJO
local function AlertInterrupt()
  if not TargetInterruptible() then return end
  ApplyAlert(FirstReady(A.int, true), "red")
end

-- Mascota: en combate sin mascota (o muerta) -> invocar / revivir
local function AlertPetSummon(c)
  local p = A.pet
  if not p or not InCombatLockdown() then return end
  if UnitInVehicle and UnitInVehicle("player") then return end
  local dead = UnitIsDead("pet")
  if HasPetUI() and not dead then return end
  local sp
  if dead and p.revive then
    if PF.Known(p.revive) and not PF.IsCasting(p.revive) and not PF.Pending(p.revive)
       and PF.State(p.revive) == 3 then sp = p.revive end
  else
    local list = p[c.spec] or p.all
    if list then
      for i = 1, #list do
        local n = list[i]
        if PF.Known(n) and not PF.IsCasting(n) and not PF.Pending(n) and PF.State(n) == 3 then
          sp = n; break
        end
      end
    end
  end
  ApplyAlert(sp, "magenta")
end

-- Mascota en postura Agresiva: botón Defensivo (o Pasivo) con prioridad 2 (cian),
-- antes de entrar en combate, para evitar un pull accidental
local function AlertPetStance()
  if InCombatLockdown() or not HasPetUI() or UnitIsDead("pet") then return end
  local aggressive, defBtn, pasBtn = false, nil, nil
  for i = 1, (NUM_PET_ACTION_SLOTS or 10) do
    local name, _, _, _, isActive = GetPetActionInfo(i)
    if name == "PET_MODE_AGGRESSIVE" then
      if isActive then aggressive = true end
    elseif name == "PET_MODE_DEFENSIVE" then
      defBtn = _G["PetActionButton" .. i]
    elseif name == "PET_MODE_PASSIVE" then
      pasBtn = _G["PetActionButton" .. i]
    end
  end
  if aggressive then
    local b = defBtn or pasBtn
    if b and b:IsVisible() and not want[b] then want[b] = 2 end
  end
end

-- Chamán: barra de tótems. Por cada ranura SIN tótem se marca (magenta) el botón del tótem recomendado
-- para tu rama y tu grupo (Totems.lua). Si ese botón no está visible (p. ej. en el desplegable de la barra),
-- se marca el botón de la ranura; y si no hay barra de tótems a la vista, se marca Llamada de los elementos.
local function AlertTotem()
  if not A.totem or not PF.TotemAlertList then return end
  local list = PF.TotemAlertList(PF.spec)
  if not list then return end
  local shown = false
  for i = 1, #list do
    local item = list[i]
    if ApplyAlert(item.spell, "magenta") then
      shown = true
    else
      -- el tótem recomendado no está a la vista: se marca el botón de su ranura en la barra de tótems
      for n = 1, 4 do
        local sb = _G["MultiCastSlotButton" .. n]
        if sb and sb:IsVisible() and (sb.slot == item.slot or (sb.GetID and sb:GetID() == item.slot)) then
          if not alertWant[sb] then alertWant[sb] = "magenta" end
          shown = true
        end
      end
    end
  end
  if not shown and PF.Known(A.totem) and not PF.IsCasting(A.totem)
     and not PF.Pending(A.totem) and PF.State(A.totem) == 3 then
    ApplyAlert(A.totem, "magenta")
  end
end

-- ¿Algún debuff del jugador cumple la condición? (por nombre en un set o por tipo)
local function PlayerDebuffMatch(set, types)
  for i = 1, 40 do
    local n, _, _, _, dtype = UnitDebuff("player", i)
    if not n then return false end
    if (set and set[n]) or (types and dtype and types[dtype]) then return true end
  end
  return false
end
local POISON_DISEASE = { Poison = true, Disease = true }

-- Raciales: azul = defensivo / dispel ante una amenaza, naranja = ofensivo de ráfaga / recurso
local function AlertRacial(c)
  local r = A.racial
  if not r or not r.name or not PF.Known(r.name) then return end
  if PF.IsCasting(r.name) or PF.Pending(r.name) or PF.State(r.name) ~= 3 then return end
  local k, color, ok = r.kind, "blue", false
  if k == "burst" then
    color, ok = "orange", (c.combat and c.hostile and c.worth)
  elseif k == "power" then
    color = "orange"
    if c.combat then
      local pt = UnitPowerType("player")
      if pt == 0 then ok = c.manaPct < 0.35
      elseif pt == 3 then ok = c.energy < 30
      elseif pt == 6 then ok = c.runic < 40 end
    end
  elseif k == "heal" then ok = c.combat and c.php < 0.50
  elseif k == "panic" then ok = c.combat and c.php < 0.35
  elseif k == "control" then ok = HasFullControl and not HasFullControl()
  elseif k == "snare" then ok = PlayerDebuffMatch(snareSet, nil)
  elseif k == "cleanse" then ok = PlayerDebuffMatch(bleedSet, POISON_DISEASE)
  end
  if ok then ApplyAlert(r.name, color) end
end

local function ComputeAlerts(c)
  if DB.racial then AlertRacial(c) end
  if DB.alerts then
    AlertSurvival()
    AlertInterrupt()
  end
  if DB.pet then
    AlertPetSummon(c)
    AlertPetStance()
  end
  if DB.totem then AlertTotem() end
end


----------------------------------------------------------------------
-- HUD FLOTANTE CENTRAL (solo lectura: nunca toca want / alertWant / la rotación)
-- Tres iconos del mismo tamaño, pegados, sin panel de fondo, con la tecla asignada
-- arriba a la derecha de cada uno: [prioridad 1] [cola 1] [cola 2]
----------------------------------------------------------------------
-- Valores por defecto del HUD y del destello. Los perfiles (Profiles.lua) guardan una copia
-- propia por personaje y rama de talentos; DB.hud / DB.fx apuntan siempre al perfil activo.
--   mode: "combat" = solo en combate | "target" = solo con objetivo hostil | "always" = siempre
local HUD_DEFAULT = { enabled = true, locked = true, x = 0, y = -120, scale = 1.0,
                      alphaCombat = 1.0, alphaOOC = 1.0, alphaChannel = 0.4, mode = "target" }
local HUD_SCALE_MIN, HUD_SCALE_MAX = 0.5, 2.0
--   period: segundos de un pulso completo (0.1 - 1.0) | intensity: brillo (0.1 - 1.0)
--   style: "glow" = Glow clásico | "size" = Pulso de tamaño
local FX_DEFAULT = { period = 0.9, intensity = 1.0, style = "glow" }
--   max: false = rotación NORMAL (siempre lo que puedas lanzar ya) | true = MÁXIMO DAÑO (prueba):
--        espera la energía de la habilidad mejor y acumula energía para refrescos (Pícaro / Druida feral)
local ROT_DEFAULT = { max = false }
PF.HUD_DEFAULT, PF.FX_DEFAULT, PF.ROT_DEFAULT = HUD_DEFAULT, FX_DEFAULT, ROT_DEFAULT
PF.HUD_SCALE_MIN, PF.HUD_SCALE_MAX = HUD_SCALE_MIN, HUD_SCALE_MAX
local EDGE = "Interface\\Buttons\\WHITE8X8"
local ICON, GAP = 46, 3
local KEY_REFRESH = 2          -- segundos entre relecturas de la tecla asignada
local hud

local BIND_PREFIX = {
  ActionButton = "ACTIONBUTTON",
  MultiBarBottomLeftButton = "MULTIACTIONBAR1BUTTON",
  MultiBarBottomRightButton = "MULTIACTIONBAR2BUTTON",
  MultiBarRightButton = "MULTIACTIONBAR3BUTTON",
  MultiBarLeftButton = "MULTIACTIONBAR4BUTTON",
  BonusActionButton = "BONUSACTIONBUTTON",
}

-- Tecla (abreviada) del botón de barra que contiene ese hechizo u objeto
local function KeyFor(spell)
  if not spell then return "" end
  local tex = PF.Texture(spell)
  if not tex then return "" end
  tex = tex:lower()
  for i = 1, #buttons do
    local b = buttons[i]
    local a = b.action
    if a and HasAction(a) then
      local t = GetActionTexture(a)
      if t and t:lower() == tex then
        local name = b:GetName()
        local key
        if name then
          local prefix, idx = name:match("^(.-)(%d+)$")
          local cmd = prefix and BIND_PREFIX[prefix]
          if cmd then key = GetBindingKey(cmd .. idx) end
          if not key then key = GetBindingKey("CLICK " .. name .. ":LeftButton") end
        end
        if key then return GetBindingText(key, "KEY_", 1) or key end
      end
    end
  end
  return ""
end

local function MakeIcon(parent)
  local f = CreateFrame("Frame", nil, parent)
  f:SetWidth(ICON); f:SetHeight(ICON)
  f:SetBackdrop({ bgFile = EDGE, edgeFile = EDGE, edgeSize = 1,
                  insets = { left = 1, right = 1, top = 1, bottom = 1 } })
  f:SetBackdropColor(0, 0, 0, 1)
  f:SetBackdropBorderColor(0.05, 0.05, 0.05, 1)       -- borde fino oscuro
  f.icon = f:CreateTexture(nil, "ARTWORK")
  f.icon:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1)
  f.icon:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 1)
  f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)          -- recorta el borde curvo de Blizzard
  f.cd = CreateFrame("Cooldown", nil, f, "CooldownFrameTemplate")
  f.cd:SetAllPoints(f.icon)
  f.top = CreateFrame("Frame", nil, f)                -- capa superior para el texto
  f.top:SetAllPoints(f)
  f.top:SetFrameLevel(f:GetFrameLevel() + 4)
  f.key = f.top:CreateFontString(nil, "OVERLAY")
  f.key:SetFont("Fonts\\ARIALN.TTF", 13, "OUTLINE")
  f.key:SetTextColor(1, 1, 1)
  f.key:SetPoint("TOPRIGHT", f, "TOPRIGHT", -2, -2)
  f.wait = f.top:CreateFontString(nil, "OVERLAY")     -- cuenta atrás de la espera (modo máximo daño)
  f.wait:SetFont("Fonts\\ARIALN.TTF", 16, "OUTLINE")
  f.wait:SetTextColor(1, 0.82, 0)
  f.wait:SetPoint("BOTTOM", f, "BOTTOM", 0, 3)
  return f
end

local function HUDApplyPos()
  local H = DB.hud
  hud:SetScale(H.scale)
  hud:ClearAllPoints()
  hud:SetPoint("CENTER", UIParent, "CENTER", H.x / H.scale, H.y / H.scale)
end

local function HUDSavePos()
  local cx, cy = hud:GetCenter()
  local ucx, ucy = UIParent:GetCenter()
  if not (cx and ucx) then return end
  local hs = hud:GetScale()
  DB.hud.x = math.floor(cx * hs - ucx + 0.5)
  DB.hud.y = math.floor(cy * hs - ucy + 0.5)
end

function PF.HUDApplyLock()
  if not hud then return end
  if DB.hud.locked then
    hud:EnableMouse(false)
    hud.drag:Hide()
  else
    hud:EnableMouse(true)
    hud.drag:Show()
  end
end

function PF.BuildHUD()
  if hud then return end
  hud = CreateFrame("Frame", "PulseFlashHUD", UIParent)
  hud:SetFrameStrata("MEDIUM")
  hud:SetClampedToScreen(true)
  hud:SetMovable(true)
  hud:SetUserPlaced(false)
  hud:RegisterForDrag("LeftButton")
  hud:SetWidth(ICON * 3 + GAP * 2)
  hud:SetHeight(ICON)

  hud.main = MakeIcon(hud)
  hud.main:SetPoint("LEFT", hud, "LEFT", 0, 0)
  hud.q1 = MakeIcon(hud)
  hud.q1:SetPoint("LEFT", hud.main, "RIGHT", GAP, 0)
  hud.q2 = MakeIcon(hud)
  hud.q2:SetPoint("LEFT", hud.q1, "RIGHT", GAP, 0)
  -- Los iconos nacen ocultos: solo se muestran cuando hay una habilidad que activar
  hud.main:Hide(); hud.q1:Hide(); hud.q2:Hide()

  -- Etiqueta pequeña de la fase del jefe (encima del HUD)
  hud.phaseText = hud:CreateFontString(nil, "OVERLAY")
  hud.phaseText:SetFont("Fonts\\FRIZQT__.TTF", 9, "OUTLINE")
  hud.phaseText:SetPoint("BOTTOM", hud, "TOP", 0, 3)
  -- Sanador: a quién sanar (nombre, % y vida que le falta), debajo del HUD
  hud.infoText = hud:CreateFontString(nil, "OVERLAY")
  hud.infoText:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
  hud.infoText:SetPoint("TOP", hud, "BOTTOM", 0, -3)
  hud.infoText:SetTextColor(0.45, 1.00, 0.55)

  -- Marco de arrastre visual (solo desbloqueado)
  hud.drag = CreateFrame("Frame", nil, hud)
  hud.drag:SetPoint("TOPLEFT", hud, "TOPLEFT", -4, 4)
  hud.drag:SetPoint("BOTTOMRIGHT", hud, "BOTTOMRIGHT", 4, -4)
  hud.drag:SetFrameLevel(hud:GetFrameLevel() + 10)
  hud.drag:SetBackdrop({ bgFile = EDGE, edgeFile = EDGE, edgeSize = 2,
                         insets = { left = 2, right = 2, top = 2, bottom = 2 } })
  hud.drag:SetBackdropColor(1.00, 0.82, 0.00, 0.20)
  hud.drag:SetBackdropBorderColor(1.00, 0.82, 0.00, 1)
  hud.drag.text = hud.drag:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  hud.drag.text:SetPoint("BOTTOM", hud.drag, "TOP", 0, 4)
  hud.drag.text:SetText(PF.T("hudDrag"))
  PF.OnLangChange(function() hud.drag.text:SetText(PF.T("hudDrag")) end)
  hud.drag:Hide()

  hud:SetScript("OnDragStart", function(self)
    if not DB.hud.locked then self:StartMoving() end
  end)
  hud:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    HUDSavePos()
    HUDApplyPos()
  end)

  HUDApplyPos()
  PF.HUDApplyLock()
  hud:Hide()
end

local function HUDSetIcon(f, spell)
  if not spell then                       -- sin habilidad: el icono desaparece (nunca un "?")
    if f.spell or f:IsShown() then
      f.spell, f.keyAt = nil, nil
      f:Hide()
    end
    return
  end
  local now = GetTime()
  if f.spell ~= spell or not f:IsShown() then
    f.spell = spell
    f.keyAt = nil
    local tex = PF.Texture(spell)
    if not tex then                       -- habilidad sin icono conocido: no se dibuja
      f.spell = nil
      f:Hide()
      return
    end
    f.icon:SetTexture(tex)
    f.icon:SetAlpha(1)
    f:Show()
  end
  if not f.keyAt or now - f.keyAt > KEY_REFRESH then
    f.keyAt = now
    f.key:SetText(KeyFor(spell))
  end
end

local function HUDSetCooldown(f, spell)
  local start, dur = 0, 0
  if spell then
    local id = spell:match("^item:(%d+)$")
    if id then start, dur = GetItemCooldown(tonumber(id))
    else start, dur = GetSpellCooldown(spell) end
  end
  start, dur = start or 0, dur or 0
  if f.cs ~= start or f.cdur ~= dur then
    f.cs, f.cdur = start, dur
    if start > 0 and dur > 0 then CooldownFrame_SetTimer(f.cd, start, dur, 1)
    else CooldownFrame_SetTimer(f.cd, 0, 0, 0) end
  end
end

-- Iconos de muestra para la "Vista previa" cuando no hay rotación (texturas del libro de hechizos)
local function HUDSetSample(f, tex)
  f.spell, f.keyAt = nil, nil
  if not tex then f:Hide(); return end
  f.icon:SetTexture(tex)
  f.icon:SetAlpha(1)
  f.key:SetText("")
  f:Show()
  HUDSetCooldown(f, nil)
end

-- main = prioridad 1 | q1, q2 = siguientes habilidades en cola
function PF.UpdateHUD(main, q1, q2)
  if not hud then return end
  local H = DB and DB.hud
  if not H or not DB.enabled or (not H.enabled and not PF.hudTest) then
    hud:Hide()
    return
  end
  -- Modo de activación. Desbloqueado o en "vista previa" (PF.hudTest) siempre se ve.
  local inCombat = UnitAffectingCombat("player") and true or false
  local mode = H.mode or "target"
  local visible = PF.hudTest or not H.locked
  if not visible then
    if mode == "combat" then
      visible = inCombat
    elseif mode == "target" then
      visible = (UnitExists("target") and UnitCanAttack("player", "target")
                 and not UnitIsDead("target")) and true or false
    else
      visible = true
    end
  end
  -- Sin nada que activar el HUD no se dibuja, ni siquiera en modo "Siempre". Las únicas
  -- excepciones son desbloqueado (marco de arrastre para poder moverlo) y la vista previa.
  if not visible or (not main and H.locked and not PF.hudTest) then
    hud:Hide()
    return
  end
  -- Opacidad del HUD (en combate / fuera de combate); desbloqueado siempre opaco para poder moverlo
  if H.locked then
    local a = inCombat and (H.alphaCombat or 1) or (H.alphaOOC or 1)
    if PF.chanIdle and not PF.hudTest then a = a * (H.alphaChannel or HUD_DEFAULT.alphaChannel) end
    hud:SetAlpha(a)
  else
    hud:SetAlpha(1)
  end
  -- Etiqueta de fase del jefe sobre el HUD (apertura / ejecución / remate)
  local ph = PF.phase
  if ph == "opener" or ph == "burn" or ph == "final" then
    hud.phaseText:SetText(PF.T("phase_" .. ph))
    if ph == "opener" then hud.phaseText:SetTextColor(1.00, 0.82, 0.00)
    elseif ph == "burn" then hud.phaseText:SetTextColor(1.00, 0.50, 0.10)
    else hud.phaseText:SetTextColor(1.00, 0.25, 0.25) end
  else
    hud.phaseText:SetText("")
  end
  -- Texto bajo el HUD: sanador (a quién sanar, verde) o multidot (cambia de objetivo, celeste)
  if PF.healInfo then
    hud.infoText:SetTextColor(0.45, 1.00, 0.55)
    hud.infoText:SetText(PF.healInfo)
  elseif PF.multiInfo then
    hud.infoText:SetTextColor(0.35, 0.85, 1.00)
    hud.infoText:SetText(PF.multiInfo)
  else
    hud.infoText:SetText("")
  end
  hud:Show()
  if main then
    HUDSetIcon(hud.main, main)
    HUDSetIcon(hud.q1, q1)
    HUDSetIcon(hud.q2, q2)
    HUDSetCooldown(hud.main, main)
    HUDSetCooldown(hud.q1, q1)
    HUDSetCooldown(hud.q2, q2)
    -- opacidad por rango: 0.35 fuera de alcance / 1.0 en rango
    hud.main.icon:SetAlpha(RangeAlpha(main))
    -- modo máximo daño: si se está esperando por esta habilidad, cuenta atrás en segundos
    if PF.holdSpell and PF.holdSpell == main and PF.holdEta then
      hud.main.wait:SetText(format("%.1f", PF.holdEta))
    else
      hud.main.wait:SetText("")
    end
    if q1 then hud.q1.icon:SetAlpha(RangeAlpha(q1)) end
    if q2 then hud.q2.icon:SetAlpha(RangeAlpha(q2)) end
  elseif PF.hudTest then
    -- vista previa sin rotación: iconos de muestra (sin "?")
    local t = {}
    for n = 1, 24 do
      local tex = GetSpellTexture(n, "spell")
      if tex and tex ~= t[1] and tex ~= t[2] then t[#t + 1] = tex end
      if #t == 3 then break end
    end
    HUDSetSample(hud.main, t[1])
    HUDSetSample(hud.q1, t[2])
    HUDSetSample(hud.q2, t[3])
  else
    -- desbloqueado y sin rotación: solo el marco de arrastre, sin iconos
    HUDSetIcon(hud.main, nil)
    HUDSetIcon(hud.q1, nil)
    HUDSetIcon(hud.q2, nil)
  end
  if not main then hud.main.wait:SetText("") end
end

local function HUDSetLocked(v)
  DB.hud.locked = v and true or false
  PF.HUDApplyLock()
end

-- Reposiciona / reescala el HUD con los valores del perfil activo (lo usa Profiles.lua y Config.lua)
function PF.HUDApplyPos()
  if hud and DB then HUDApplyPos() end
end

-- Bloquea / desbloquea el HUD (clic derecho del minimapa y /pf lock)
function PF.ToggleHUDLock()
  if not DB then return end
  if DB.hud.locked then
    DB.hud.enabled = true
    HUDSetLocked(false)
    PF.Msg(PF.T("hudUnlocked"))
  else
    HUDSetLocked(true)
    PF.Msg(PF.T("hudLocked", DB.hud.x, DB.hud.y))
  end
  if PF.RefreshConfig then PF.RefreshConfig() end
end

-- Vista previa del HUD fuera de combate (Mayús + clic izquierdo en el minimapa). No se guarda.
function PF.ToggleHUDTest()
  PF.hudTest = not PF.hudTest
  PF.Msg(PF.T("hudPreview", PF.hudTest and PF.T("ON_F") or PF.T("OFF_F")))
  if PF.RefreshConfig then PF.RefreshConfig() end
end

local pbClass          -- clase del jugador (se asigna en PLAYER_LOGIN)
local roleAnnounced = {}   -- roles (tanque / sanador) de los que ya se avisó por chat en esta sesión

local function Report(err)
  if err ~= PF.lastErr then
    PF.lastErr = err
    PF.Msg(PF.T("error", tostring(err)))
  end
end

local function Update()
  PF.holdSpell, PF.holdEta = nil, nil
  PF.multiInfo = nil
  wipe(want)
  wipe(wantSpell)
  wipe(alertWant)
  wipe(slotSpell)
  local hq1, hq2
  if DB.enabled and module and not UnitIsDeadOrGhost("player")
     and not (IsMounted and IsMounted()) then
    local c = BuildContext()
    nC = 0
    -- Rol: tanque / sanador -> sin recomendaciones de habilidades (solo el HUD de buffos)
    c.role = PF.GetRole and PF.GetRole(pbClass, c.spec) or "dps"
    PF.role = c.role
    if c.role ~= "dps" and not roleAnnounced[c.role] then
      roleAnnounced[c.role] = true
      PF.Msg(PF.T("role_" .. c.role))
    end
    local isDps = (c.role == "dps")
    local isHealer = (c.role == "healer")
    rangeUnit, PF.rangeUnit = "target", nil
    PF.healInfo = nil
    if isHealer and PF.HealerEval then                 -- sanador: asesor de sanaciones (Healer.lua)
      c.healMode = true
      local okH2, errH2 = pcall(PF.HealerEval, c, add)
      if not okH2 then Report(errH2) end
      if c.healUnit then rangeUnit, PF.rangeUnit = c.healUnit, c.healUnit end
    end
    if isDps and module.upkeep then                     -- mantenimiento (Transfusión de vida...): también sin objetivo
      local okU, errU = pcall(module.upkeep, c, add, PF.N)
      if not okU then Report(errU) end
    end
    if c.hostile and isDps then               -- con objetivo hostil: SIEMPRE hay brillo
      local ok, err = pcall(module.evaluate, c, add, PF.N)
      if not ok then Report(err) end
      -- Trinkets de uso activo (cola, tras los cooldowns de clase): solo contra jefes
      if c.combat and c.bigCD and PF.AddTrinkets then
        local okT, errT = pcall(PF.AddTrinkets, add)
        if not okT then Report(errT) end
      end
    end
    local s1, s2, s3
    local resolved = false
    if (isDps and (c.hostile or nC > 0)) or (isHealer and nC > 0) then
      local ok2, r1, r2, r3 = pcall(Resolve, c)
      if ok2 then s1, s2, s3 = r1, r2, r3; resolved = true else Report(r1) end
    end
    slotSpell[1], slotSpell[2], slotSpell[3] = s1, s2, s3
    -- Multidot (Multidot.lua): aviso de cambiar de objetivo para repartir DoTs (solo DPS con objetivo)
    if isDps and c.hostile and PF.Multidot_Eval then
      local okM, mdText = pcall(PF.Multidot_Eval, c)
      if okM then PF.multiInfo = mdText else Report(mdText) end
    end
    -- Canalizando: si lo único que toca es seguir con el canal (la recomendación es el relleno, el
    -- propio hechizo canalizado o nada), el HUD se atenúa; si hay algo prioritario (un DoT que
    -- vence, un proc...) sigue a plena opacidad: es el aviso de que hay que cortar el canal.
    local chan = UnitChannelInfo("player")
    PF.chanIdle = (isDps and chan and (s1 == nil or s1 == lastFiller or s1 == chan)) and true or false
    -- Cola del HUD: 1ª = lo que va en el slot 2; 2ª = siguiente candidata de la rotación
    hq1 = s2
    if resolved then
      for i = 1, nC do
        local sp = cSpell[i]
        if (cTier[i] == 1 or cTier[i] == 2) and (cState[i] or 0) >= 2 and sp ~= s1 and sp ~= hq1 then
          hq2 = sp; break
        end
      end
      if not hq2 and lastFiller and lastFiller ~= s1 and lastFiller ~= hq1 then hq2 = lastFiller end
    end
    ApplyFlash(s1, 1)
    ApplyFlash(s2, 2)
    ApplyFlash(s3, 3)
    -- Avisos paralelos (capa roja / mascotas / tótems): no tocan la rotación
    local okA, errA = pcall(ComputeAlerts, c)
    if not okA then Report(errA) end
  end
  Refresh()
  AlertRefresh()
  -- HUD central: paralelo, solo lee el resultado (las barras ya se actualizaron arriba)
  local okH, errH = pcall(PF.UpdateHUD, slotSpell[1], hq1, hq2)
  if not okH then Report(errH) end
end

----------------------------------------------------------------------
-- Bucle principal
----------------------------------------------------------------------
local driver = CreateFrame("Frame")
local acc, slow = 0, 0
driver:SetScript("OnUpdate", function(_, dt)
  if not DB then return end

  -- Pulso del destello (perfil activo): periodo en segundos, intensidad y estilo
  local fx = DB.fx or FX_DEFAULT
  local period = fx.period or FX_DEFAULT.period
  if period < 0.1 then period = 0.1 end
  local inten = fx.intensity or FX_DEFAULT.intensity
  local wave = math.sin(GetTime() * (6.2832 / period))          -- -1 .. 1
  local sizeStyle = (fx.style == "size")
  for b in pairs(active) do
    local g = glows[b]
    local ra = g.range or 1
    local w, h = g:GetWidth(), g:GetHeight()
    if sizeStyle then
      -- Pulso de tamaño: el borde respira entre 1.50x y 1.80x con brillo casi constante
      local f = 1.50 + 0.30 * (0.5 + 0.5 * wave)
      g.tex:SetWidth(w * f); g.tex:SetHeight(h * f)
      g.tex:SetAlpha(0.9 * inten * ra)
      g.fill:SetAlpha(0.35 * inten * ra)
    else
      -- Glow clásico: tamaño fijo, la transparencia pulsa
      local a = 0.55 + 0.45 * wave
      g.tex:SetWidth(w * 1.75); g.tex:SetHeight(h * 1.75)
      g.tex:SetAlpha(a * inten * ra)
      g.fill:SetAlpha(a * 0.5 * inten * ra)
    end
  end

  local ar = 0.55 + 0.45 * math.sin(GetTime() * 12)    -- pulso rápido de la capa de avisos
  for b in pairs(alertActive) do
    local g = alertGlows[b]
    g.tex:SetAlpha(ar)
    g.fill:SetAlpha(ar * 0.5)
  end

  slow = slow + dt
  if slow > 2 then
    slow = 0
    PF.DetectSpec()
    if module.slow then pcall(module.slow, BuildContext()) end
  end

  acc = acc + dt
  if acc < 0.1 then return end
  acc = 0
  Update()
end)

----------------------------------------------------------------------
-- AVISO DE POSICIÓN (habilidades que exigen estar detrás del objetivo)
-- Se dispara cuando el juego rechaza una habilidad por no estar detrás.
-- Modos (PulseFlashDB.posalert): "both" (pantalla + chat) | "screen" | "chat" | "off".
----------------------------------------------------------------------
local POS_COOLDOWN = 3          -- segundos mínimos entre avisos (evita spam al machacar la tecla)
local POS_SHOW = 2.5            -- segundos que permanece el texto en pantalla
local posFrame, posUntil, lastPosAlert = nil, 0, -100

local function PosFrame()
  if posFrame then return posFrame end
  local f = CreateFrame("Frame", "PulseFlashPosAlert", UIParent)
  f:SetWidth(520); f:SetHeight(50)
  f:SetPoint("CENTER", UIParent, "CENTER", 0, 170)
  f:SetFrameStrata("HIGH")
  f.text = f:CreateFontString(nil, "OVERLAY")
  f.text:SetFont("Fonts\\FRIZQT__.TTF", 28, "OUTLINE")
  f.text:SetPoint("CENTER", f, "CENTER", 0, 0)
  f.text:SetTextColor(1, 0.25, 0.1)
  f.text:SetText(PF.T("posText"))
  f:SetScript("OnUpdate", function(self)
    local left = posUntil - GetTime()
    if left <= 0 then self:Hide(); return end
    self:SetAlpha(left < 0.6 and (left / 0.6) or 1)       -- se desvanece al final
  end)
  f:Hide()
  posFrame = f
  return f
end

function PF.PositionAlert()
  if not DB then return end
  local mode = DB.posalert
  if not mode or mode == "off" then return end
  local now = GetTime()
  if now - lastPosAlert < POS_COOLDOWN then return end
  lastPosAlert = now
  if mode == "both" or mode == "screen" then
    local f = PosFrame()
    f.text:SetText(PF.T("posText"))
    posUntil = now + POS_SHOW
    f:SetAlpha(1)
    f:Show()
    PlaySound("RaidWarning")
  end
  if mode == "both" or mode == "chat" then
    PF.Msg("|cffff4040" .. PF.T("posText") .. "|r " .. PF.T("posChat"))
  end
end

----------------------------------------------------------------------
-- Comandos: /pf  (alias /pulseflash)
----------------------------------------------------------------------
local function Toggle(key, labelKey)
  DB[key] = not DB[key]
  PF.Msg(PF.T(labelKey) .. ": " .. (DB[key] and PF.T("ON_M") or PF.T("OFF_M")))
end

-- Los comandos existen en español y en inglés (cualquiera funciona con cualquier idioma activo)
local ALIAS = {
  mode = "modo", poisons = "venenos", poison = "venenos", stone = "piedra",
  alerts = "alertas", pet = "mascota", prebuff = "buffs", buff = "buffs", buffmove = "bufflock", ver = "version", bosscd = "cds", rol = "roles", role = "roles", tanque = "tank", range = "rango", racials = "raciales", multi = "multidot", dots = "multidot", multidots = "multidot",
  position = "posicion", ["posición"] = "posicion",
  settings = "config", menu = "config", options = "config", opciones = "config",
  idioma = "lang", language = "lang", combos = "combo",
}

SLASH_PULSEFLASH1 = "/pf"
SLASH_PULSEFLASH2 = "/pulseflash"
SlashCmdList["PULSEFLASH"] = function(msg)
  local arg
  msg, arg = strlower(strtrim(msg or "")):match("^(%S*)%s*(.-)$")
  msg = ALIAS[msg] or msg
  -- El idioma se puede cambiar incluso sin módulo de clase
  if msg == "lang" then
    local l = (arg == "es" or arg == "esp" or arg == "spanish" or arg == "español") and "es"
           or (arg == "en" or arg == "eng" or arg == "english" or arg == "inglés" or arg == "ingles") and "en"
           or nil
    if arg == "" then l = (PF.GetLang() == "es") and "en" or "es" end
    if not l then PF.Msg(PF.T("langUsage")); return end
    PF.SetLang(l)
    PF.Msg(PF.T("langIs", PF.LANG_NAMES[l]))
    return
  end
  if not DB then PF.Msg(PF.T("noModule")); return end
  if msg == "on" then DB.enabled = true; PF.Msg(PF.T("enabled"))
  elseif msg == "off" then DB.enabled = false; PF.Msg(PF.T("disabled"))
  elseif msg == "aoe" then Toggle("aoe", "t_aoe")
  elseif msg == "modo" then
    local R = DB.rot
    if not R then PF.Msg(PF.T("profileNotLoaded")); return end
    if pbClass ~= "ROGUE" and pbClass ~= "DRUID" then
      PF.Msg(PF.T("modeOnly"))
      return
    end
    if arg == "max" or arg == "maximo" or arg == "máximo" then R.max = true
    elseif arg == "normal" then R.max = false
    elseif arg == "" then R.max = not R.max
    else PF.Msg(PF.T("modeUsage")); return end
    PF.Msg(PF.T("modeIs", R.max and PF.T("MODE_MAX") or PF.T("MODE_NORMAL")))
    if PF.RefreshConfig then PF.RefreshConfig() end
  elseif msg == "combo" then
    if PF.ToggleComboBar then PF.ToggleComboBar() else PF.Msg(PF.T("comboOnly")) end
  elseif msg == "venenos" then Toggle("poison", "t_poison")
  elseif msg == "piedra" then Toggle("stone", "t_stone")
  elseif msg == "hud" then
    DB.hud.enabled = not DB.hud.enabled
    PF.Msg(PF.T("t_hud") .. ": " .. (DB.hud.enabled and PF.T("ON_M") or PF.T("OFF_M")))
  elseif msg == "move" or msg == "lock" then
    PF.ToggleHUDLock()
  elseif msg == "config" then
    if PF.ToggleConfig then PF.ToggleConfig() else PF.Msg(PF.T("noConfig")) end
  elseif msg == "scale" then
    local v = tonumber((string.gsub(arg or "", ",", ".")))
    if v and v >= HUD_SCALE_MIN and v <= HUD_SCALE_MAX then
      DB.hud.scale = v
      HUDApplyPos()
      PF.Msg(PF.T("scaleSet", v))
      if PF.RefreshConfig then PF.RefreshConfig() end
    else
      PF.Msg(PF.T("scaleUsage", HUD_SCALE_MIN, HUD_SCALE_MAX, DB.hud.scale))
    end
  elseif msg == "reset" then
    DB.hud.x, DB.hud.y, DB.hud.scale = HUD_DEFAULT.x, HUD_DEFAULT.y, HUD_DEFAULT.scale
    HUDApplyPos()
    if DB.bhud and PF.BHUD_DEFAULT then
      DB.bhud.x, DB.bhud.y, DB.bhud.scale = PF.BHUD_DEFAULT.x, PF.BHUD_DEFAULT.y, PF.BHUD_DEFAULT.scale
      if PF.BuffHUDApplyPos then PF.BuffHUDApplyPos() end
    end
    if PF.RefreshConfig then PF.RefreshConfig() end
    PF.Msg(PF.T("hudReset"))
  elseif msg == "alertas" then Toggle("alerts", "t_alerts")
  elseif msg == "mascota" then Toggle("pet", "t_pet")
  elseif msg == "totem" then Toggle("totem", "t_totem")
  elseif msg == "rango" then Toggle("range", "t_range")
  elseif msg == "raciales" then Toggle("racial", "t_racial")
  elseif msg == "icc" then
    -- Modo ICC/Banda (solo Brujo): Maldición de apocalipsis en lugar de Maldición de agonía
    if pbClass ~= "WARLOCK" then
      PF.Msg(PF.T("iccOnly"))
    else
      DB.icc = not DB.icc
      local doom = PF.N.CurseOfDoom or "Curse of Doom"
      local agony = PF.N.CurseOfAgony or "Curse of Agony"
      if DB.icc then
        PF.Msg(PF.T("iccOn", doom, agony))
        if not PF.Known(doom) then
          PF.Msg(PF.T("iccUnknown", doom, agony))
        end
      else
        PF.Msg(PF.T("iccOff", agony))
      end
    end
  elseif msg == "version" then
    if PF.VersionCommand then PF.VersionCommand() end
  elseif msg == "bufflock" then
    if PF.ToggleBuffHUDLock then PF.ToggleBuffHUDLock() end
  elseif msg == "roles" then Toggle("roleLimit", "t_roles")
  elseif msg == "multidot" then PF.Multidot_Toggle()
  elseif msg == "totems" then if PF.TotemDebug then PF.TotemDebug() end
  elseif msg == "boss" then
    local r = PF.ToggleBossMark and PF.ToggleBossMark()
    if r == nil then PF.Msg(PF.T("boss_none")) else PF.Msg(PF.T(r and "boss_on" or "boss_off")) end
  elseif msg == "tank" then
    -- Modo tanque (solo Caballero de la Muerte): rotación exclusiva de tanque
    if pbClass ~= "DEATHKNIGHT" then
      PF.Msg(PF.T("tankOnly"))
    else
      DB.dkTank = not DB.dkTank
      PF.Msg(PF.T(DB.dkTank and "tankOn" or "tankOff"))
    end
  elseif msg == "cds" then
    DB.cdAlways = not DB.cdAlways
    PF.Msg(PF.T(DB.cdAlways and "cdsAlways" or "cdsBoss"))
  elseif msg == "buffs" then
    if PF.ToggleBuffHUD then PF.ToggleBuffHUD() end
  elseif msg == "posicion" then
    local MODES = { pantalla = "screen", screen = "screen", chat = "chat", ambos = "both", both = "both", off = "off" }
    if arg and arg ~= "" then
      if MODES[arg] then DB.posalert = MODES[arg]
      else PF.Msg(PF.T("posUsage")); return end
    else
      DB.posalert = (DB.posalert == "off") and "both" or "off"
    end
    PF.Msg(PF.T("posIs", PF.T("posLabel_" .. tostring(DB.posalert))))
    if not (module and module.positional) then
      PF.Msg(PF.T("posNoClass"))
    end
  elseif msg == "num" then
    DB.numPos = (DB.numPos == "CENTER") and "TOPLEFT" or "CENTER"
    PF.Msg(PF.T("numIs", DB.numPos == "CENTER" and PF.T("numCenter") or PF.T("numCorner")))
  elseif msg == "debug" then
    local _, class = UnitClass("player")
    PF.ScanBook()
    PF.Msg(PF.T("dbg_class", class, PF.spec, UnitLevel("player"), PF.bookCount))
    PF.Msg(PF.T("dbg_hp", math.floor((ctx.hp or 1) * 100 + 0.5)))
    for i = 1, 3 do
      PF.Msg(PF.T("dbg_slot", i, slotSpell[i] or "-"))
    end
    local na = 0
    for _ in pairs(alertActive) do na = na + 1 end
    PF.Msg(PF.T("dbg_alerts", na))
    PF.Msg(PF.T("dbg_hud",
      DB.hud.enabled and PF.T("dbg_active") or PF.T("dbg_inactive"),
      DB.hud.locked and PF.T("dbg_locked") or PF.T("dbg_unlocked"),
      DB.hud.x, DB.hud.y, DB.hud.scale))
    PF.Msg(PF.T("dbg_flags", DB.range and "on" or "off",
      DB.racial and "on" or "off", DB.icc and "on" or "off", tostring(DB.posalert)))
    PF.Msg(PF.T("dbg_behind", ctx.behind and PF.T("dbg_yes") or PF.T("dbg_front")))
    PF.Msg(PF.T("dbg_rot", (DB.rot and DB.rot.max) and PF.T("dbg_rotMax") or PF.T("dbg_rotNormal"),
      PF.holdSpell and format("%s (%.1f s)", PF.holdSpell, PF.holdEta or 0) or "-"))
    local bl = PF.BuffList and PF.BuffList() or {}
    PF.Msg(PF.T("dbg_prebuffs", #bl > 0 and table.concat(bl, ", ") or "-"))
    for i = 1, math.min(nC, 14) do
      PF.Msg(PF.T("dbg_cand", cTier[i], cSpell[i], tostring(cState[i])))
    end
  else
    PF.Msg(PF.T("helpLine"))
  end
end

----------------------------------------------------------------------
-- Eventos / inicialización
----------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function(self, event, a1, a2)
  if event == "PLAYER_LOGIN" then
    local classLoc, class = UnitClass("player")
    module = PF.modules[class]
    if not module then
      PF.Msg(PF.T("noModuleClass", tostring(classLoc or class)))
      return
    end

    PulseFlashDB = PulseFlashDB or {}
    DB = PulseFlashDB
    -- Migración desde la versión anterior (ClassFlashDB), si existe y la nueva está vacía
    if type(ClassFlashDB) == "table" and ClassFlashDB ~= DB and next(DB) == nil then
      for k, v in pairs(ClassFlashDB) do DB[k] = v end
    end
    PF.db = DB
    if DB.enabled == nil then DB.enabled = true end
    if DB.aoe == nil then DB.aoe = false end
    if DB.poison == nil then DB.poison = true end
    if DB.stone == nil then DB.stone = true end
    if DB.numPos == nil then DB.numPos = "TOPLEFT" end
    if DB.alerts == nil then DB.alerts = true end
    if DB.pet == nil then DB.pet = true end
    if DB.totem == nil then DB.totem = true end
    if DB.range == nil then DB.range = true end        -- opacidad por rango
    if DB.racial == nil then DB.racial = true end      -- avisos de raciales
    if DB.icc == nil then DB.icc = false end           -- Brujo: modo ICC/Banda (apagado por defecto)
    if DB.dkTank == nil then DB.dkTank = false end     -- Caballero de la Muerte: modo tanque (apagado por defecto)
    if DB.posalert == nil then DB.posalert = "both" end  -- aviso de posición: pantalla + chat
    -- HUD: se guarda en PulseFlashDB.hud (posición X/Y, escala, activado, bloqueado)
    if type(DB.hud) ~= "table" then DB.hud = {} end
    for k, v in pairs(HUD_DEFAULT) do
      if DB.hud[k] == nil then DB.hud[k] = v end
    end
    if type(DB.hud.scale) ~= "number" or DB.hud.scale < HUD_SCALE_MIN or DB.hud.scale > HUD_SCALE_MAX then
      DB.hud.scale = HUD_DEFAULT.scale
    end
    DB.hud.x, DB.hud.y = tonumber(DB.hud.x) or HUD_DEFAULT.x, tonumber(DB.hud.y) or HUD_DEFAULT.y
    -- Perfiles por personaje y rama (Profiles.lua): reasigna DB.hud / DB.fx / DB.sound al perfil activo
    if PF.Profiles_Init then PF.Profiles_Init(DB) end
    PF.BuildHUD()

    for k, id in pairs(module.ids) do PF.N[k] = GetSpellInfo(id) end
    wipe(posSet)
    for _, key in ipairs(module.positional or {}) do
      local n = PF.N[key]
      if n then posSet[n] = true end
    end
    pbClass = class
    PF.BuildAlerts(class)
    BuildButtons()
    PF.ScanBook()
    PF.DetectSpec()
    if module.init then module.init() end
    -- Sonidos de procs (Sounds.lua, necesita PF.N ya rellenado) y botón del minimapa (Minimap.lua)
    if PF.Sounds_Init then PF.Sounds_Init(class) end
    if PF.Minimap_Init then PF.Minimap_Init() end
    -- Barra de combos (ComboBar.lua): solo Pícaro y Druida
    if PF.ComboBar_Init then PF.ComboBar_Init(class) end
    -- Segundo HUD, solo para buffos (BuffHUD.lua)
    if PF.BuffHUD_Init then PF.BuffHUD_Init(class) end
    -- Aviso de nueva versión por mensajes de addon (Update.lua)
    if PF.Update_Init then PF.Update_Init() end
    if PF.Roles_Init then PF.Roles_Init() end
    if PF.Multidot_Init then PF.Multidot_Init(class) end
    if PF.Healer_Init then PF.Healer_Init(class) end

    self:RegisterEvent("PLAYER_ENTERING_WORLD")
    self:RegisterEvent("SPELLS_CHANGED")
    self:RegisterEvent("LEARNED_SPELL_IN_TAB")
    self:RegisterEvent("PLAYER_TALENT_UPDATE")
    self:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
    self:RegisterEvent("CHARACTER_POINTS_CHANGED")
    self:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
    self:RegisterEvent("PLAYER_TARGET_CHANGED")
    self:RegisterEvent("UI_ERROR_MESSAGE")
    self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")

    if class == "WARLOCK" and DB.icc then
      PF.Msg(PF.T("iccLogin"))
    end
    if class == "DEATHKNIGHT" and DB.dkTank then
      PF.Msg(PF.T("tankLogin"))
    end
    DEFAULT_CHAT_FRAME:AddMessage(PF.T("welcome", UnitName("player") or "?", classLoc or class))

  elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
    -- 3.3.5: arg1 = unidad, arg2 = nombre del hechizo
    if a1 == "player" and a2 then
      PF.lastCast[a2] = GetTime()
      if posSet[a2] then PF.notBehindUntil = 0 end        -- una posicional salió bien: estás detrás
    end

  elseif event == "UI_ERROR_MESSAGE" then
    -- En 3.3.5 el texto llega en arg1; se capturan arg1 y arg2 por compatibilidad.
    if ERR_BADATTACKFACING and (a1 == ERR_BADATTACKFACING or a2 == ERR_BADATTACKFACING) then
      PF.notBehindUntil = GetTime() + 4
    end
    -- "Debes estar detrás de tu objetivo." (SPELL_FAILED_NOT_BEHIND): es el error real de Puñalada
    -- trapera / Emboscada / Garrote / Destrozar / Devastar al lanzarlos de frente
    if SPELL_FAILED_NOT_BEHIND and (a1 == SPELL_FAILED_NOT_BEHIND or a2 == SPELL_FAILED_NOT_BEHIND) then
      PF.notBehindUntil = GetTime() + 4
      if module and module.positional then PF.PositionAlert() end
    end

  elseif event == "PLAYER_TARGET_CHANGED" then
    PF.notBehindUntil = 0
    wipe(PF.lastCast)          -- objetivo nuevo: los DoTs recién lanzados ya no cuentan

  elseif event == "PLAYER_EQUIPMENT_CHANGED" then
    if module.onEquipment then module.onEquipment() end

  else  -- libro / talentos / entrada al mundo
    PF.ScanBook()
    PF.DetectSpec()
    if module.onEquipment then module.onEquipment() end
  end
end)
