--[[
  PulseFlash - Profiles.lua  (WoW 3.3.5a)
  Perfiles completos por personaje y rama de talentos.

  ESTRUCTURA EN PulseFlashDB (SavedVariables de la cuenta):
    DB.chars["Nombre-Reino"] = {
      class = "WARLOCK",
      specs = {                                  -- [1] = talentos primarios, [2] = secundarios
        [1] = { specName = "Destrucción", specTab = 3,
                hud   = { x, y, scale, alphaCombat, alphaOOC, mode, enabled, locked },
                bhud  = { x, y, scale, alphaCombat, alphaOOC, combat, enabled, locked },   -- HUD de buffos
                fx    = { period, intensity, style },
                sound = { enabled, procs = { [clave de proc] = id de sonido } },
                rot   = { max },                   -- modo de rotación (Pícaro / Druida)
                combo = { enabled, x, y, scale... } },  -- barra de combos (Pícaro / Druida)
        [2] = { ... },
      },
    }
    DB.presets["Nombre"]  = { hud, bhud, fx, sound, rot, combo, class }   -- perfiles guardados a mano (Guardar / Cargar)
    DB.legacy             = copia de la config global de versiones anteriores (semilla de perfiles nuevos)

  FUNCIONAMIENTO
    * Los perfiles se guardan solos: DB.hud / DB.fx / DB.sound son REFERENCIAS al perfil activo,
      así que cualquier cambio (slider, arrastrar el HUD...) ya queda escrito en la base de datos.
    * Al cambiar de rama (ACTIVE_TALENT_GROUP_CHANGED) se carga el perfil de esa rama.
    * Un perfil nuevo se siembra con la config de otra rama del mismo personaje o, si no hay,
      con la config global anterior (así nadie pierde su posición del HUD al actualizar).
]]
local PF = PulseFlash
local DB

local floor, ipairs, pairs, type = math.floor, ipairs, pairs, type

PF.profileCallbacks = {}     -- funciones que se llaman cuando cambia / se recarga el perfil activo

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------
local function DeepCopy(src)
  if type(src) ~= "table" then return src end
  local out = {}
  for k, v in pairs(src) do out[k] = DeepCopy(v) end
  return out
end

-- Rellena en "t" las claves que falten con las de "defaults" (recursivo)
local function Fill(t, defaults)
  for k, v in pairs(defaults) do
    if t[k] == nil then
      t[k] = DeepCopy(v)
    elseif type(v) == "table" and type(t[k]) == "table" then
      Fill(t[k], v)
    end
  end
end

local function Clamp(v, lo, hi, default)
  v = tonumber(v)
  if not v then return default end
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

local MODES  = { combat = true, target = true, always = true }
local STYLES = { glow = true, size = true }

-- Deja un perfil completo y con valores válidos
local function Sanitize(p)
  if type(p.hud) ~= "table" then p.hud = {} end
  if type(p.bhud) ~= "table" then p.bhud = {} end
  if type(p.fx) ~= "table" then p.fx = {} end
  if type(p.sound) ~= "table" then p.sound = {} end
  if type(p.rot) ~= "table" then p.rot = {} end
  if type(p.combo) ~= "table" then p.combo = {} end
  Fill(p.hud, PF.HUD_DEFAULT)
  Fill(p.bhud, PF.BHUD_DEFAULT or {})
  Fill(p.fx, PF.FX_DEFAULT)
  Fill(p.sound, { enabled = true, procs = {} })
  if type(p.sound.procs) ~= "table" then p.sound.procs = {} end
  local h, f = p.hud, p.fx
  h.scale = Clamp(h.scale, PF.HUD_SCALE_MIN, PF.HUD_SCALE_MAX, PF.HUD_DEFAULT.scale)
  h.alphaCombat = Clamp(h.alphaCombat, 0.1, 1, 1)
  h.alphaOOC = Clamp(h.alphaOOC, 0.1, 1, 1)
  h.alphaChannel = Clamp(h.alphaChannel, 0.1, 1, PF.HUD_DEFAULT.alphaChannel)
  h.x = tonumber(h.x) or PF.HUD_DEFAULT.x
  h.y = tonumber(h.y) or PF.HUD_DEFAULT.y
  if not MODES[h.mode] then h.mode = PF.HUD_DEFAULT.mode end
  f.period = Clamp(f.period, 0.1, 1.0, PF.FX_DEFAULT.period)
  f.intensity = Clamp(f.intensity, 0.1, 1.0, PF.FX_DEFAULT.intensity)
  if not STYLES[f.style] then f.style = PF.FX_DEFAULT.style end
  -- HUD de buffos (BuffHUD.lua)
  local bd, b = PF.BHUD_DEFAULT or {}, p.bhud
  b.scale = Clamp(b.scale, PF.HUD_SCALE_MIN, PF.HUD_SCALE_MAX, bd.scale or 1)
  b.alphaCombat = Clamp(b.alphaCombat, 0.1, 1, 1)
  b.alphaOOC = Clamp(b.alphaOOC, 0.1, 1, 1)
  b.x = tonumber(b.x) or bd.x or 0
  b.y = tonumber(b.y) or bd.y or 300
  b.enabled = b.enabled and true or false
  b.combat = b.combat and true or false
  b.pulse = b.pulse and true or false
  -- Rotación (modo máximo daño) y barra de combos
  Fill(p.rot, PF.ROT_DEFAULT)
  p.rot.max = p.rot.max and true or false
  if PF.COMBO_DEFAULT then
    Fill(p.combo, PF.COMBO_DEFAULT)
    if PF.ComboSanitize then PF.ComboSanitize(p.combo) end
  end
end

----------------------------------------------------------------------
-- Detección: personaje, clase y especialización (rama de talentos activa)
----------------------------------------------------------------------
function PF.GetCharKey()
  return (UnitName("player") or "?") .. "-" .. (GetRealmName() or "?")
end

-- Devuelve: grupo de talentos activo (1 = primarios, 2 = secundarios), pestaña dominante
-- (1-3, 0 si hay menos de 5 puntos) y su nombre localizado.
function PF.GetSpecInfo()
  local group = (GetActiveTalentGroup and GetActiveTalentGroup()) or 1
  if group ~= 1 and group ~= 2 then group = 1 end
  local bestTab, bestName, bestPts = 0, nil, 0
  for i = 1, (GetNumTalentTabs and GetNumTalentTabs() or 0) do
    -- 3.3.5a: GetTalentTabInfo(tab, inspect, isPet, talentGroup) -> nombre, icono, puntos, fondo
    local name, _, pts = GetTalentTabInfo(i, false, false, group)
    if pts and pts > bestPts then bestTab, bestName, bestPts = i, name, pts end
  end
  if bestPts < 5 then return group, 0, PF.T("noSpec") end
  return group, bestTab, bestName
end

function PF.GroupLabel(group)
  return (group == 2) and PF.T("group2") or PF.T("group1")
end

----------------------------------------------------------------------
-- Creación y activación de perfiles
----------------------------------------------------------------------
-- Perfil nuevo: copia de otra rama del mismo personaje, o de la config global anterior
local function NewProfile(charData, group)
  local seed
  for g, other in pairs(charData.specs) do
    if g ~= group and type(other) == "table" then seed = other; break end
  end
  local p = {}
  local src = seed or DB.legacy or {}
  p.hud = DeepCopy(src.hud or {})
  p.bhud = DeepCopy(src.bhud or {})
  p.fx = DeepCopy(src.fx or {})
  p.sound = DeepCopy(src.sound or {})
  p.rot = DeepCopy(src.rot or {})
  p.combo = DeepCopy(src.combo or {})
  Sanitize(p)
  return p
end

-- Hace "activo" un perfil: DB.hud / DB.bhud / DB.fx / DB.sound / DB.rot / DB.combo pasan a ser referencias a sus tablas
function PF.ActivateProfile(p)
  Sanitize(p)
  local old = DB.hud
  if old and old ~= p.hud and old.locked ~= nil then
    p.hud.locked = old.locked          -- el bloqueo del HUD es un estado de la sesión: se conserva
  end
  if DB.bhud and DB.bhud ~= p.bhud and DB.bhud.locked ~= nil then
    p.bhud.locked = DB.bhud.locked     -- ídem para el HUD de buffos
  end
  if DB.combo and DB.combo ~= p.combo and DB.combo.locked ~= nil then
    p.combo.locked = DB.combo.locked   -- ídem para la barra de combos
  end
  PF.profile = p
  DB.hud, DB.bhud, DB.fx, DB.sound, DB.rot, DB.combo = p.hud, p.bhud, p.fx, p.sound, p.rot, p.combo
  PF.ApplyProfile()
end

-- Aplica el perfil activo a la interfaz (HUD, panel, sonidos...)
function PF.ApplyProfile()
  if PF.HUDApplyPos then PF.HUDApplyPos() end
  if PF.HUDApplyLock then PF.HUDApplyLock() end
  if PF.BuffHUDApply then PF.BuffHUDApply() end
  if PF.ComboBarApply then PF.ComboBarApply() end
  for _, fn in ipairs(PF.profileCallbacks) do pcall(fn) end
end

function PF.RegisterProfileCallback(fn)
  PF.profileCallbacks[#PF.profileCallbacks + 1] = fn
end

-- Detecta personaje + rama y carga (creando si hace falta) su perfil. Devuelve true si cambió.
function PF.LoadActiveProfile()
  local group, tab, specName = PF.GetSpecInfo()
  local key = PF.GetCharKey()
  local _, class = UnitClass("player")
  local c = DB.chars[key]
  if type(c) ~= "table" then c = {}; DB.chars[key] = c end
  if type(c.specs) ~= "table" then c.specs = {} end
  c.class = class
  local p = c.specs[group]
  if type(p) ~= "table" then p = NewProfile(c, group); c.specs[group] = p end
  p.specName, p.specTab = specName, tab
  local changed = (PF.activeKey ~= key) or (PF.activeGroup ~= group)
  PF.activeKey, PF.activeGroup = key, group
  PF.ActivateProfile(p)
  return changed
end

----------------------------------------------------------------------
-- Copiar configuraciones (clonar / cargar)
----------------------------------------------------------------------
-- Copia hud + fx + sound de "src" al perfil activo (mantiene el estado de bloqueo)
local function ApplyInto(src)
  local p = PF.profile
  if not p or type(src) ~= "table" then return false end
  p.hud = DeepCopy(src.hud or {})
  p.bhud = DeepCopy(src.bhud or {})
  p.fx = DeepCopy(src.fx or {})
  p.sound = DeepCopy(src.sound or {})
  p.rot = DeepCopy(src.rot or {})
  p.combo = DeepCopy(src.combo or {})
  PF.ActivateProfile(p)
  return true
end

-- Listado de perfiles de la cuenta (excluye el activo): { {key=, group=, label=}, ... }
function PF.ListProfiles()
  local list = {}
  for key, c in pairs(DB.chars) do
    if type(c) == "table" and type(c.specs) == "table" then
      local cls = (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[c.class or ""]) or c.class or "?"
      for group, p in pairs(c.specs) do
        if type(p) == "table" and not (key == PF.activeKey and group == PF.activeGroup) then
          list[#list + 1] = {
            key = key, group = group,
            label = PF.T("cloneLabel", key, cls, group, p.specName or "?"),
          }
        end
      end
    end
  end
  table.sort(list, function(a, b)
    if a.key ~= b.key then return a.key < b.key end
    return a.group < b.group
  end)
  return list
end

-- Clonar: copia la configuración de OTRO personaje / rama de la cuenta al perfil activo
function PF.CloneProfile(key, group)
  local c = DB.chars[key]
  local src = c and c.specs and c.specs[group]
  if ApplyInto(src) then
    PF.Msg(PF.T("cloned", key, group))
    return true
  end
  return false
end

-- Perfiles guardados a mano (Guardar / Cargar), compartidos por toda la cuenta
function PF.SavePreset(name)
  name = strtrim(name or "")
  if name == "" or not PF.profile then return false end
  local _, class = UnitClass("player")
  DB.presets[name] = {
    hud = DeepCopy(PF.profile.hud), bhud = DeepCopy(PF.profile.bhud), fx = DeepCopy(PF.profile.fx),
    sound = DeepCopy(PF.profile.sound), rot = DeepCopy(PF.profile.rot),
    combo = DeepCopy(PF.profile.combo), class = class,
  }
  PF.Msg(PF.T("presetSaved", name))
  return true
end

function PF.LoadPreset(name)
  if ApplyInto(DB.presets[name]) then
    PF.Msg(PF.T("presetLoaded", name))
    return true
  end
  return false
end

function PF.DeletePreset(name)
  if DB.presets[name] then
    DB.presets[name] = nil
    PF.Msg(PF.T("presetDeleted", name))
  end
end

function PF.ListPresets()
  local list = {}
  for name in pairs(DB.presets) do list[#list + 1] = name end
  table.sort(list)
  return list
end

----------------------------------------------------------------------
-- Inicialización (la llama Core.lua en PLAYER_LOGIN, antes de crear el HUD)
----------------------------------------------------------------------
function PF.Profiles_Init(db)
  DB = db
  if type(DB.chars) ~= "table" then DB.chars = {} end
  if type(DB.presets) ~= "table" then DB.presets = {} end
  -- Config global de versiones anteriores: se guarda una vez como semilla de los perfiles nuevos
  if type(DB.legacy) ~= "table" then
    DB.legacy = { hud = DeepCopy(DB.hud or {}), fx = {}, sound = {} }
  end
  PF.LoadActiveProfile()

  -- La rama puede no estar disponible justo en PLAYER_LOGIN: se revisa al entrar al mundo
  -- y cada vez que cambian los talentos / la rama activa.
  local f = CreateFrame("Frame")
  f:RegisterEvent("PLAYER_ENTERING_WORLD")
  f:RegisterEvent("PLAYER_TALENT_UPDATE")
  f:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
  f:SetScript("OnEvent", function(_, event)
    if not DB then return end
    local group = PF.GetSpecInfo()
    if group ~= PF.activeGroup then
      PF.LoadActiveProfile()
      local p = PF.profile
      PF.Msg(PF.T("profileSwitched", PF.activeKey, PF.activeGroup, p and p.specName or "?"))
    elseif PF.profile then
      -- misma rama: solo se refresca el nombre de la especialización (cambio de talentos)
      local _, tab, name = PF.GetSpecInfo()
      PF.profile.specName, PF.profile.specTab = name, tab
      if PF.RefreshConfig then PF.RefreshConfig() end
    end
  end)
end
