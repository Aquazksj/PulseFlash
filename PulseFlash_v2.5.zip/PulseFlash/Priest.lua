-- PulseFlash: Sacerdote (Sombras; Smite si aún no tienes la forma) - 3.3.5a
local CF = PulseFlash
local Aura, Dot, First = CF.Aura, CF.Dot, CF.First

local function IsShadow(c, N)
  return (c.spec == 3) or (Aura("player", N.Shadowform) ~= nil)
end

local function evaluate(c, add, N)
  local shadowform = Aura("player", N.Shadowform)
  local shadow = (c.spec == 3) or shadowform

  local swp = Aura("target", N.ShadowWordPain, true, true)

  if shadow then
    if c.worth then
      Dot(add, c, N.VampiricTouch, Aura("target", N.VampiricTouch, true, true))
      Dot(add, c, N.ShadowWordPain, swp)
      Dot(add, c, N.DevouringPlague, Aura("target", N.DevouringPlague, true, true))
    end
    add(N.MindBlast, 1)
    if c.hp < 0.25 then add(N.ShadowWordDeath, 1) end
    if c.combat and c.manaPct < 0.5 then add(N.Shadowfiend, 2) end
  else
    -- Sin Forma de las Sombras (leveling / otras ramas): Smite como relleno
    if c.worth then Dot(add, c, N.ShadowWordPain, swp) end
    if not Aura("target", N.HolyFire, true, true) then add(N.HolyFire, 1) end
    add(N.Penance, 1)
    add(N.MindBlast, 1)
  end

  -- Interrupción / defensivos / utilidad (verde)
  if (UnitCastingInfo("target") or UnitChannelInfo("target"))
     and IsSpellInRange(N.Silence, "target") == 1 then
    add(N.Silence, 3)
  end
  if c.combat then
    if c.php < 0.60 and not Aura("player", N.WeakenedSoul, true) then add(N.PowerWordShield, 3) end
    if c.php < 0.35 then add(N.Dispersion, 3) end
    if c.php < 0.30 then add(N.PsychicScream, 3) end
  end
end

-- Relleno infinito: Tortura mental (Sombras) / Latigazo de las Sombras... o Aplastar si aún no la tienes
local function filler(c, N)
  if IsShadow(c, N) then return First(N.MindFlay, N.Smite) end
  return First(N.Smite, N.MindBlast)
end

CF.Register("PRIEST", {
  ids = {
    Smite = 585,             HolyFire = 14914,        ShadowWordPain = 589,
    MindBlast = 8092,        MindFlay = 15407,        VampiricTouch = 34914,
    DevouringPlague = 2944,  ShadowWordDeath = 32379, Penance = 47540,
    PowerWordShield = 17,    InnerFire = 588,         Shadowform = 15473,
    PsychicScream = 8122,    Dispersion = 47585,      WeakenedSoul = 6788,
    Silence = 15487,         Shadowfiend = 34433,
  },
  evaluate = evaluate,
  filler = filler,
})
