-- PulseFlash: Paladín (Reprensión; la misma lista sirve para leveling) - 3.3.5a
local CF = PulseFlash
local Aura, Known, Proc, First = CF.Aura, CF.Known, CF.Proc, CF.First

local function evaluate(c, add, N)
  -- 1) Procs: El arte de la guerra -> Exorcismo instantáneo
  Proc(add, N.ArtOfWar, N.Exorcism)

  -- 2) Rotación (CDs y rematar)
  add(N.JudgementOfWisdom, 1)
  add(N.JudgementOfLight, 1)
  add(N.CrusaderStrike, 1)
  add(N.DivineStorm, 1)
  if c.hp < 0.20 then add(N.HammerOfWrath, 1) end
  add(N.Consecration, 1)
  if not Known(N.CrusaderStrike) then add(N.Exorcism, 1) end

  -- Cooldowns / maná (cola)
  if c.combat then
    add(N.AvengingWrath, 2)
    if c.manaPct < 0.50 then add(N.DivinePlea, 2) end
  end

  -- Interrupción / defensivos (verde)
  if (UnitCastingInfo("target") or UnitChannelInfo("target"))
     and IsSpellInRange(N.HammerOfJustice, "target") == 1 then
    add(N.HammerOfJustice, 3)
  end
  if c.combat then
    if c.php < 0.40 then add(N.DivineProtection, 3) end
    if c.php < 0.15 then add(N.DivineShield, 3) end
  end
end

-- Relleno infinito: Golpe del cruzado (o Juicio / Consagración / Sello según nivel)
local function filler(c, N)
  return First(N.CrusaderStrike, N.JudgementOfWisdom, N.JudgementOfLight,
               N.Consecration, N.SealOfRighteousness)
end

CF.Register("PALADIN", {
  ids = {
    CrusaderStrike = 35395, DivineStorm = 53385,     JudgementOfWisdom = 53408,
    JudgementOfLight = 20271, Consecration = 26573,  Exorcism = 879,
    HammerOfWrath = 24275,  AvengingWrath = 31884,   DivinePlea = 54428,
    HammerOfJustice = 853,  DivineProtection = 498,  DivineShield = 642,
    SealOfCommand = 20375,  SealOfVengeance = 31801, SealOfCorruption = 53736,
    SealOfRighteousness = 21084, SealOfWisdom = 20166, SealOfLight = 20165,
    SealOfJustice = 20164,
    SanctityAura = 20218, RetributionAura = 7294, DevotionAura = 465,
    ConcentrationAura = 19746, FireResistanceAura = 19891,
    FrostResistanceAura = 19888, ShadowResistanceAura = 19876,
    -- proc (buff)
    ArtOfWar = 59578,
  },
  evaluate = evaluate,
  filler = filler,
})
