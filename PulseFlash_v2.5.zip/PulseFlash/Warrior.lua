-- PulseFlash: Guerrero (Armas / Furia) - 3.3.5a
-- Las posturas se respetan solas: IsUsableSpell devuelve falso en la postura equivocada
-- y esa habilidad se salta; además se recomienda la postura de más daño.
local CF = PulseFlash
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

local function evaluate(c, add, N)
  local spec = c.spec

  -- 1) Procs
  Proc(add, N.TasteForBlood, N.Overpower)       -- Sabor a sangre
  Proc(add, N.SuddenDeath, N.Execute)           -- Muerte súbita
  Proc(add, N.Bloodsurge, N.Slam)               -- ¡Empalar! (Oleada de sangre)
  add(N.VictoryRush, 1)                         -- solo es usable tras una muerte

  -- Ejecutar
  if c.hp < 0.20 then add(N.Execute, 1) end

  -- 2) Mantenimiento de DoT
  if c.worth then Dot(add, c, N.Rend, Aura("target", N.Rend, true, true)) end

  -- 3) Rotación por rama
  if spec == 2 then            -- Furia
    add(N.Bloodthirst, 1)
    add(N.Whirlwind, 1)
  else                         -- Armas / sin especialización
    add(N.MortalStrike, 1)
    add(N.Overpower, 1)
    add(N.Whirlwind, 1)
  end
  if c.rage >= 50 then add(N.HeroicStrike, 1) end   -- volcado de ira

  -- Cooldowns y generación de ira (cola)
  if c.combat then
    if c.rage < 20 then add(N.Bloodrage, 2) end
    add(N.Recklessness, 2)
    add(N.DeathWish, 2)
    add(N.Bladestorm, 2)
  end

  -- Interrupción / defensivos (verde)
  if (UnitCastingInfo("target") or UnitChannelInfo("target"))
     and IsSpellInRange(N.Pummel, "target") == 1 then
    add(N.Pummel, 3)
  end
  if c.combat and c.php < 0.35 then add(N.EnragedRegeneration, 3) end
end

-- Relleno infinito: Empalar (Armas) / Golpe heroico (Furia y leveling)
local function filler(c, N)
  if c.spec == 1 then return First(N.Slam, N.HeroicStrike) end
  return First(N.HeroicStrike, N.Slam)
end

CF.Register("WARRIOR", {
  ids = {
    HeroicStrike = 78,   MortalStrike = 12294,  Bloodthirst = 23881,
    Whirlwind = 1680,    Slam = 1464,           Execute = 5308,
    Rend = 772,          Overpower = 7384,      VictoryRush = 34428,
    Bloodrage = 2687,    Recklessness = 1719,   DeathWish = 12292,
    Bladestorm = 46924,  Pummel = 6552,         EnragedRegeneration = 55694,
    BattleStance = 2457, DefensiveStance = 71,  BerserkerStance = 2458,
    BattleShout = 6673,  CommandingShout = 469,
    -- procs (buffs)
    TasteForBlood = 60503, SuddenDeath = 52437, Bloodsurge = 46916,
  },
  evaluate = evaluate,
  filler = filler,
})
