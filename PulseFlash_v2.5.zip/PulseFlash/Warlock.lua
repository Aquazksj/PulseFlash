-- PulseFlash: Brujo (Aflicción / Demonología / Destrucción) - 3.3.5a
--
-- Particularidades de este módulo:
--   * Transfusión de vida (Glifo): el buff de poder de hechizo se mantiene SIEMPRE activo
--     (upkeep, prioridad 1). Constantes LIFETAP_MIN_HP / LIFETAP_REFRESH.
--   * Modo ICC/Banda (/pf icc, DB.icc): la maldición principal pasa de Maldición de agonía
--     a Maldición de apocalipsis (MainCurse). Apagado por defecto.
--   * Armadura vil y piedra de hechizo: ya no están aquí; las muestra el HUD de buffos (BuffHUD.lua).
local CF = PulseFlash
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

local eradSince = nil      -- desde cuándo está activa esta racha del proc de Erradicación

-- Transfusión de vida (Life Tap) con el Glifo de Transfusión de vida: el buff de poder de
-- hechizo (+% de tu Espíritu) debe estar activo SIEMPRE. Solo se exige si el glifo está
-- puesto (o si el buff ya se vio alguna vez), para no insistir si no tienes el glifo.
local ltGlyph, ltGlyphAt, ltSeen = false, 0, false
local LIFETAP_MIN_HP = 0.40      -- no sugerirlo si tu vida está por debajo de este %
local LIFETAP_REFRESH = 2.0      -- se renueva si le quedan <= 2 s (nunca se queda sin buff)

local function HasLifeTapGlyph(N)
  local now = GetTime()
  if now - ltGlyphAt < 2 then return ltGlyph end
  ltGlyphAt = now
  ltGlyph = false
  local lt = N.LifeTap
  if lt and GetNumGlyphSockets and GetGlyphSocketInfo then
    for i = 1, GetNumGlyphSockets() do
      local enabled, _, glyphSpellID = GetGlyphSocketInfo(i)
      if enabled and glyphSpellID then
        local gname = GetSpellInfo(glyphSpellID)
        if gname and gname:find(lt, 1, true) then ltGlyph = true; break end
      end
    end
  end
  return ltGlyph
end

-- Mantenimiento: se evalúa también SIN objetivo (armadura y piedra: ahora en BuffHUD.lua)
local function upkeep(c, add, N)
  -- Erradicación: se anota cuándo empezó la racha del proc
  if Aura("player", N.Eradication) then
    if not eradSince then eradSince = GetTime() end
  else
    eradSince = nil
  end

  -- Transfusión de vida: buff de SP siempre activo (prioridad 1 dorada cuando falta o va a acabarse)
  if Known(N.LifeTap) then
    local ltLeft = Aura("player", N.LifeTap)
    if ltLeft then ltSeen = true end
    if (ltSeen or HasLifeTapGlyph(N)) and (not ltLeft or ltLeft <= LIFETAP_REFRESH)
       and c.php > LIFETAP_MIN_HP and not CF.Pending(N.LifeTap) then
      add(N.LifeTap, 1)
    end
  end
end

-- Maldición principal según el modo (/pf icc):
--   estándar        -> Maldición de agonía
--   modo ICC/Banda  -> Maldición de apocalipsis (si aún no la conoces, se mantiene Agonía)
local function MainCurse(N)
  if CF.db.icc and Known(N.CurseOfDoom) then return N.CurseOfDoom end
  return N.CurseOfAgony
end

local function evaluate(c, add, N)
  local spec, hp = c.spec, c.hp
  local execute = (hp <= 0.25)           -- fase de ejecución: Drenar alma

  -- Maná: Sacar vida cuando se acaba (si tu vida lo permite)
  if c.manaPct < 0.15 and c.php > 0.5 then add(N.LifeTap, 1) end

  -- 1) Procs (prioridad inmediata)
  Proc(add, N.ShadowTrance, N.ShadowBolt)
  Proc(add, N.Backlash, spec == 3 and N.Incinerate or N.ShadowBolt)
  if hp < 0.35 then Proc(add, N.Decimation, N.SoulFire) end
  Proc(add, N.MoltenCore, N.Incinerate)

  -- Erradicación: si Corrupción se aplicó ANTES de que saltara el proc, reaplicarla
  -- para que la nueva aplicación aproveche el aumento de celeridad
  if eradSince and c.worth then
    local cLeft, _, cDur, cExp = Aura("target", N.Corruption, true, true)
    if cLeft and cDur and cExp and cDur > 0 and cExp > 0
       and (cExp - cDur) < (eradSince - 0.2) and c.casting ~= N.Corruption and not CF.Pending(N.Corruption) then
      add(N.Corruption, 1)
    end
  end

  -- 2) Mantenimiento de DoTs / debuffs
  if c.worth then
    local imm = Aura("target", N.Immolate, true, true)
    local corr = Aura("target", N.Corruption, true, true)
    local curse = MainCurse(N)
    local curseLeft = Aura("target", curse, true, true)
    -- Apocalipsis (60 s de recarga = 60 s de duración): solo se lanza si NO está puesta,
    -- porque recastearla antes de que termine cancelaría su golpe final
    if curse == N.CurseOfDoom and curseLeft then curseLeft = 9999 end
    if spec == 1 then            -- Aflicción
      Dot(add, c, N.Haunt, Aura("target", N.Haunt, true, true))
      Dot(add, c, N.UnstableAffliction, Aura("target", N.UnstableAffliction, true, true))
      Dot(add, c, N.Corruption, corr)
      Dot(add, c, curse, curseLeft)
    elseif spec == 3 then        -- Destrucción
      Dot(add, c, N.Immolate, imm)
      if imm then add(N.Conflagrate, 1) end
      add(N.ChaosBolt, 1)
      Dot(add, c, N.Corruption, corr)
    elseif spec == 2 then        -- Demonología
      Dot(add, c, N.Corruption, corr)
      Dot(add, c, N.Immolate, imm)
      Dot(add, c, curse, curseLeft)
    else                         -- sin especialización (leveling)
      Dot(add, c, N.Immolate, imm)
      Dot(add, c, N.Corruption, corr)
      Dot(add, c, curse, curseLeft)
    end
  end

  -- Aflicción: con el objetivo al 25% de vida o menos, Drenar alma (también en jefes)
  if spec == 1 and execute then add(N.DrainSoul, 1) end

  -- Cooldowns ofensivos (cola)
  if c.combat and spec == 2 then add(N.Metamorphosis, 2) end

  -- Defensivo (verde)
  if c.combat and c.php < 0.35 then add(N.DeathCoil, 3) end
end

-- Relleno infinito: Descarga de las sombras (Incinerar en Destrucción; Drenar alma al ejecutar)
local function filler(c, N)
  if c.spec == 1 and c.hp <= 0.25 and Known(N.DrainSoul) then return N.DrainSoul end
  if c.spec == 3 then return First(N.Incinerate, N.ShadowBolt) end
  return First(N.ShadowBolt, N.Incinerate)
end

CF.Register("WARLOCK", {
  ids = {
    ShadowBolt = 686,   Immolate = 348,          Corruption = 172,
    CurseOfAgony = 980, CurseOfDoom = 603, UnstableAffliction = 30108, Haunt = 48181,
    Conflagrate = 17962, ChaosBolt = 50796,      Incinerate = 29722,
    SoulFire = 6353,    DrainSoul = 1120,        LifeTap = 1454,
    Metamorphosis = 47241, DeathCoil = 6789,
    FelArmor = 28176,   DemonArmor = 706,        DemonSkin = 687,
    CreateSpellstone = 2362,
    -- procs (buffs)
    ShadowTrance = 17941, Backlash = 34936, Decimation = 63167, MoltenCore = 47383,
    Eradication = 64371,
  },
  upkeep = upkeep,
  evaluate = evaluate,
  filler = filler,
})
