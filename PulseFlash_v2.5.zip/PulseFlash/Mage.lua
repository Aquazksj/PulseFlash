-- PulseFlash: Mago (Arcano / Fuego / Escarcha) - 3.3.5a
local CF = PulseFlash
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

local function evaluate(c, add, N)
  local spec = c.spec

  -- 1) Procs
  Proc(add, N.HotStreak, N.Pyroblast)                         -- Racha ardiente: Piroexplosión instantánea
  Proc(add, N.MissileBarrage, N.ArcaneMissiles)               -- Descarga de misiles
  if Aura("player", N.FingersOfFrost) then                    -- Dedos de escarcha
    add(N.DeepFreeze, 1)
    add(N.IceLance, 1)
  end
  Proc(add, N.BrainFreeze, Known(N.FrostfireBolt) and N.FrostfireBolt or N.Fireball)

  -- 2) Mantenimiento de DoTs
  if c.worth then
    Dot(add, c, N.LivingBomb, Aura("target", N.LivingBomb, true, true))
  end

  -- Cooldowns ofensivos (cola)
  if c.combat then
    if spec == 1 then add(N.ArcanePower, 2) end
    if spec == 2 then add(N.Combustion, 2) end
    if spec == 3 then add(N.IcyVeins, 2) end
    add(N.MirrorImage, 2)
  end

  -- Interrupción / defensivos / utilidad (verde)
  if (UnitCastingInfo("target") or UnitChannelInfo("target"))
     and IsSpellInRange(N.Counterspell, "target") == 1 then
    add(N.Counterspell, 3)
  end
  if c.combat then
    if c.php < 0.20 then add(N.IceBlock, 3) end
    if c.manaPct < 0.20 then add(N.Evocation, 3) end
  end
end

-- Relleno infinito según la rama
local function filler(c, N)
  if c.spec == 1 then return First(N.ArcaneBlast, N.Fireball, N.Frostbolt) end
  if c.spec == 2 then return First(N.Fireball, N.Frostbolt) end
  return First(N.Frostbolt, N.Fireball)
end

CF.Register("MAGE", {
  ids = {
    Fireball = 133,       Frostbolt = 116,       ArcaneBlast = 30451,
    ArcaneMissiles = 5143, Pyroblast = 11366,    LivingBomb = 44457,
    FrostfireBolt = 44614, IceLance = 30455,     DeepFreeze = 44572,
    Combustion = 11129,   IcyVeins = 12472,      MirrorImage = 55342,
    ArcanePower = 12042,  Counterspell = 2139,   IceBlock = 45438,
    Evocation = 12051,    MoltenArmor = 30482,   MageArmor = 6117,
    IceArmor = 7302,      FrostArmor = 168,
    -- procs (buffs)
    HotStreak = 48108, MissileBarrage = 44401, FingersOfFrost = 44544, BrainFreeze = 57761,
  },
  evaluate = evaluate,
  filler = filler,
})
