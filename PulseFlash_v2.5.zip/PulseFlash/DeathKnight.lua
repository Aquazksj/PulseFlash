-- PulseFlash: Caballero de la Muerte (Escarcha / Profano / Sangre DPS) - 3.3.5a
-- (el DK empieza en el nivel 55; las runas y el poder rúnico los controla IsUsableSpell)
local CF = PulseFlash
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

local function evaluate(c, add, N)
  local spec = c.spec

  -- 1) Procs
  Proc(add, N.KillingMachine, Known(N.Obliterate) and N.Obliterate or N.FrostStrike)
  Proc(add, N.Rime, N.HowlingBlast)                           -- Rime (Niebla helada)

  -- 2) Mantenimiento de enfermedades
  if c.worth then
    Dot(add, c, N.IcyTouch, Aura("target", N.FrostFever, true, true))
    Dot(add, c, N.PlagueStrike, Aura("target", N.BloodPlague, true, true))
  end

  -- 3) Rotación por rama (lo que no sea ejecutable por runas/poder rúnico se salta)
  if spec == 2 then            -- Escarcha
    add(N.Obliterate, 1)
    add(N.BloodStrike, 1)
    add(N.HowlingBlast, 1)
    add(N.FrostStrike, 1)
    add(N.DeathCoil, 1)
    if c.combat then add(N.UnbreakableArmor, 2) end
  elseif spec == 3 then        -- Profano
    add(N.ScourgeStrike, 1)
    add(N.BloodStrike, 1)
    add(N.DeathCoil, 1)
    if c.combat then add(N.SummonGargoyle, 2) end
  elseif spec == 1 then        -- Sangre DPS
    add(N.HeartStrike, 1)
    add(N.BloodStrike, 1)
    add(N.DeathStrike, 1)
    add(N.DeathCoil, 1)
    if c.combat then add(N.DancingRuneWeapon, 2) end
  else                         -- sin especialización
    add(N.ScourgeStrike, 1)
    add(N.Obliterate, 1)
    add(N.BloodStrike, 1)
    add(N.DeathCoil, 1)
  end
  if c.combat then add(N.EmpowerRuneWeapon, 2) end

  -- Interrupción / defensivos (verde)
  if UnitCastingInfo("target") or UnitChannelInfo("target") then
    if IsSpellInRange(N.MindFreeze, "target") == 1 then add(N.MindFreeze, 3)
    elseif IsSpellInRange(N.Strangulate, "target") == 1 then add(N.Strangulate, 3) end
  end
  if c.combat then
    if c.php < 0.40 then add(N.IceboundFortitude, 3) end
    if c.php < 0.50 then add(N.AntiMagicShell, 3) end
  end
end

-- Relleno infinito según la rama
local function filler(c, N)
  if c.spec == 2 then return First(N.FrostStrike, N.DeathCoil, N.BloodStrike) end
  if c.spec == 3 then return First(N.DeathCoil, N.ScourgeStrike, N.BloodStrike) end
  if c.spec == 1 then return First(N.HeartStrike, N.BloodStrike, N.DeathCoil) end
  return First(N.BloodStrike, N.DeathCoil)
end

CF.Register("DEATHKNIGHT", {
  ids = {
    IcyTouch = 45477,      PlagueStrike = 45462,    BloodStrike = 45902,
    DeathCoil = 47541,     Obliterate = 49020,      FrostStrike = 49143,
    HowlingBlast = 49184,  ScourgeStrike = 55090,   DeathStrike = 49998,
    HeartStrike = 55050,   UnbreakableArmor = 51271, EmpowerRuneWeapon = 47568,
    SummonGargoyle = 49206, DancingRuneWeapon = 49028,
    MindFreeze = 47528,    Strangulate = 47476,     IceboundFortitude = 48792,
    AntiMagicShell = 48707,
    BloodPresence = 48266, UnholyPresence = 48265, HornOfWinter = 57330,
    -- debuffs de enfermedad y procs (buffs)
    FrostFever = 55095, BloodPlague = 55078, KillingMachine = 51124, Rime = 59052,
  },
  evaluate = evaluate,
  filler = filler,
})
