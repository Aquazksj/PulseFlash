-- PulseFlash: Cazador (Bestias / Puntería / Supervivencia) - 3.3.5a
local CF = PulseFlash
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

local function evaluate(c, add, N)
  local spec = c.spec

  -- 1) Procs: Cargar y apuntar
  Proc(add, N.LockAndLoad, spec == 3 and N.ExplosiveShot or N.ArcaneShot)

  -- Rematar
  if c.hp < 0.20 then add(N.KillShot, 1) end

  -- 2) Mantenimiento de DoTs / debuffs
  if c.worth then
    Dot(add, c, N.SerpentSting, Aura("target", N.SerpentSting, true, true))
    if spec == 3 then Dot(add, c, N.BlackArrow, Aura("target", N.BlackArrow, true, true)) end
  end

  -- 3) Rotación por rama (lo que no sea ejecutable se salta)
  if spec == 3 then            -- Supervivencia
    add(N.ExplosiveShot, 1)
  elseif spec == 2 then        -- Puntería
    add(N.ChimeraShot, 1)
    add(N.AimedShot, 1)
  elseif spec == 1 then        -- Bestias
    add(N.KillCommand, 1)
  end
  add(N.ArcaneShot, 1)
  if CF.db.aoe then add(N.MultiShot, 1) end

  -- Cooldowns y marca (cola)
  if c.worth and not Aura("target", N.HuntersMark, true) then add(N.HuntersMark, 2) end
  if c.combat then
    add(N.RapidFire, 2)
    if spec == 1 then add(N.BestialWrath, 2) end
  end

  -- Interrupción / defensivos (verde)
  if (UnitCastingInfo("target") or UnitChannelInfo("target"))
     and IsSpellInRange(N.SilencingShot, "target") == 1 then
    add(N.SilencingShot, 3)
  end
  if c.combat and c.php < 0.30 then add(N.Deterrence, 3) end
end

-- Relleno infinito: Disparo firme (antes del 62: Disparo arcano / Ataque de Raptor)
local function filler(c, N)
  return First(N.SteadyShot, N.ArcaneShot, N.RaptorStrike)
end

CF.Register("HUNTER", {
  ids = {
    SteadyShot = 56641,  ArcaneShot = 3044,    AimedShot = 19434,
    MultiShot = 2643,    SerpentSting = 1978,  ChimeraShot = 53209,
    ExplosiveShot = 53301, BlackArrow = 3674,  KillShot = 53351,
    KillCommand = 34026, RaptorStrike = 2973,  HuntersMark = 1130,
    RapidFire = 3045,    BestialWrath = 19574, SilencingShot = 34490,
    Deterrence = 19263,
    AspectViper = 34074, AspectHawk = 13165,   AspectDragonhawk = 61847,
    -- proc (buff)
    LockAndLoad = 56343,
  },
  evaluate = evaluate,
  filler = filler,
})
