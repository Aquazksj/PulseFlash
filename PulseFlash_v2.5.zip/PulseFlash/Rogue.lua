-- PulseFlash: Pícaro (Asesinato / Combate / Sutileza) - 3.3.5a
--
-- MODO DE ROTACIÓN (menú -> Rotación, o /pf modo):
--   NORMAL ....... siempre se recomienda la primera habilidad que puedas lanzar YA. Si te falta
--                  energía para Mutilar / Puñalada trapera, brilla Golpe siniestro (que cuesta menos).
--   MÁXIMO DAÑO .. (prueba) dos cambios, ambos con cuenta atrás en el HUD:
--     1) ESPERAR LA MEJOR HABILIDAD: si solo faltan <= 2 s de energía para Mutilar (Asesinato, con dos
--        dagas) o Puñalada trapera (solo Sutileza), se espera en vez de gastar esa energía en un
--        Golpe siniestro. Mutilar da 2 PC por 60 de energía: más daño y más PC por energía que
--        Golpe siniestro. Puñalada trapera pega más por energía pero da 1 PC por 60, por eso solo
--        se espera por ella en Sutileza y no en Combate.
--     2) ACUMULAR ENERGÍA PARA REFRESCAR: si Rebanar y Cortar (o Ruptura) vence en pocos segundos y
--        gastar ahora la energía te dejaría sin la necesaria para refrescarlo a tiempo, se espera.
local CF = PulseFlash
local Aura, Known, Dot, First = CF.Aura, CF.Known, CF.Dot, CF.First

-- Nombre localizado de la subclase "Dagas"
local DAGGER = {
  enUS = "Daggers", enGB = "Daggers", esES = "Dagas", esMX = "Dagas",
  frFR = "Dagues", deDE = "Dolche", ptBR = "Adagas", ruRU = "Кинжалы",
  zhCN = "匕首", zhTW = "匕首", koKR = "단검",
}

local mhDagger, ohDagger = false, false
local lastPoisonMsg = 0
local ctcTalent = false          -- ¿tienes Cut to the Chase? (Envenom renueva Golpe rápido y Corte)

-- Segundos que le faltan a un cooldown (0 si está listo o solo tiene el GCD)
local function CDLeft(spell)
  if not spell then return 0 end
  local s, d = GetSpellCooldown(spell)
  if s and s > 0 and d and d > 1.6 then return math.max(0, s + d - GetTime()) end
  return 0
end

local function CheckWeapons()
  local wanted = DAGGER[GetLocale()]
  local function isDagger(slot)
    local link = GetInventoryItemLink("player", slot)
    if not link then return false end
    if not wanted then return true end
    return select(7, GetItemInfo(link)) == wanted
  end
  mhDagger, ohDagger = isDagger(16), isDagger(17)
end

local function RefreshTalents()
  ctcTalent = CF.HasTalent(CF.N.CutToTheChase)
end

-- GetWeaponEnchantInfo con la firma de 8 valores (ver Core.lua)
local WeaponEnchants = CF.WeaponEnchants

local function PoisonCheck(c)
  if not CF.db.poison or c.level < 20 or c.combat or UnitIsDeadOrGhost("player") then return end
  if GetTime() - lastPoisonMsg < 90 then return end
  local hasMH, mhExp, _, _, hasOH, ohExp = WeaponEnchants()
  local needMH = (not hasMH) or (mhExp and mhExp < 120000)
  local needOH = OffhandHasWeapon() and ((not hasOH) or (ohExp and ohExp < 120000))
  if needMH or needOH then
    lastPoisonMsg = GetTime()
    CF.Msg(CF.T("poisonsMissing"))
  end
end

local function InStealth(N)
  return Aura("player", N.Stealth) or Aura("player", N.Vanish) or Aura("player", N.ShadowDance)
end

local function evaluate(c, add, N)
  local cp, energy, lvl, spec = c.cp, c.energy, c.level, c.spec
  local behind = mhDagger and c.behind
  -- Modo máximo daño: regeneración de energía estimada (Estimulación la duplica)
  local maxMode = CF.db and CF.db.rot and CF.db.rot.max
  local regen = Aura("player", N.AdrenalineRush) and 20 or 10

  local dance = Aura("player", N.ShadowDance)

  -- Apertura desde sigilo / Esfumarse (no Baile de sombras): lo que no sea ejecutable se salta.
  -- Emboscada (daga) y Garrote exigen estar DETRÁS; Puñalo bajo no sirve contra jefes (inmunes al aturdimiento).
  if InStealth(N) and not dance then
    if spec == 3 and cp == 0 then add(N.Premeditation, 2) end
    if behind then add(N.Ambush, 1) end
    if spec == 1 and mhDagger and ohDagger then add(N.Mutilate, 1) end
    if c.behind then add(N.Garrote, 1) end
    if not c.boss then add(N.CheapShot, 1) end
    add(N.SinisterStrike, 1)
    return
  end

  local sndLeft = Aura("player", N.SliceAndDice)
  local ruptLeft = Aura("target", N.Rupture, true, true)
  local bleed = ruptLeft or Aura("target", N.Garrote, true, true)
  local hfbLeft = Aura("player", N.HungerForBlood)
  local hemoLeft = Aura("target", N.Hemorrhage, true)
  local dpUp = Aura("target", N.DeadlyPoison, true, true, true)

  local finishCP = (lvl >= 60 and 5) or (lvl >= 30 and 4) or 3
  if spec == 1 and finishCP > 4 then finishCP = 4 end
  local finish = cp >= finishCP or (cp >= 2 and c.hp < 0.15 and not c.boss)
  local envenom = (spec == 1 and dpUp and Known(N.Envenom)) and N.Envenom or nil

  -- Mantenimiento (falta o expira en < 2.5 s -> dorado)
  -- Con Cut to the Chase, Envenom ya renueva Golpe rápido y Corte: no se gasta un PC en recastearlo
  -- mientras siga activo y haya Envenom listo.
  if cp >= 1 and not (ctcTalent and envenom and finish and sndLeft) then
    Dot(add, c, N.SliceAndDice, sndLeft, 6)
  end
  if bleed then Dot(add, c, N.HungerForBlood, hfbLeft, 8) end
  if c.worth and finish then
    if spec == 1 then
      if Known(N.HungerForBlood) and not bleed then add(N.Rupture, 1) end
    else
      Dot(add, c, N.Rupture, ruptLeft)
    end
  end

  -- MÁXIMO DAÑO: acumular energía para refrescar Rebanar y Cortar / Ruptura a tiempo. Lo que se
  -- gastaría ahora es el remate (si toca) o el generador que se lanzaría.
  local pooled = false
  if maxMode and not dance then
    local gen = (spec == 1 and mhDagger and ohDagger and Known(N.Mutilate) and N.Mutilate)
                or (behind and Known(N.Backstab) and N.Backstab) or N.SinisterStrike
    local spendCost = CF.Cost(finish and (envenom or N.Eviscerate) or gen)
    local function Pool(spell, left, needCP)
      if pooled or not spell or not left or cp < needCP or not Known(spell) then return end
      local t = left - 2.0                       -- Dot() refresca a los 2 s restantes
      if t <= 0 or t > CF.POOL_MAX_T then return end
      if not CF.CanSpend(spendCost, CF.Cost(spell), t, regen) then
        pooled = add(spell, 1, t)
      end
    end
    Pool(N.SliceAndDice, sndLeft, 1)
    if c.worth and spec ~= 1 then Pool(N.Rupture, ruptLeft, finishCP) end
  end

  -- Remate (en máximo daño, si solo falta energía se muestra la cuenta atrás)
  if finish then
    if envenom then add(envenom, 1, maxMode and CF.HoldEta(envenom, regen) or nil) end
    add(N.Eviscerate, 1, maxMode and not envenom and CF.HoldEta(N.Eviscerate, regen) or nil)
  end

  -- Generadores (con 5 PC no se generan más: se espera al remate)
  local capped = cp >= 5 and Known(N.Eviscerate)
  if not capped then
    -- Baile de sombras: solo valen las habilidades de sigilo -> Emboscada (detrás) y Garrote
    if dance then
      if behind then add(N.Ambush, 1) end
      if not bleed then add(N.Garrote, 1) end
    end
    if CF.db.aoe then add(N.FanOfKnives, 1) end
    -- Generador "mejor" (espera en modo máximo daño): solo el primero que se añade puede esperar
    local held = false
    local function build(spell, preferred)
      local hold = (maxMode and preferred and not held) and CF.HoldEta(spell, regen) or nil
      if add(spell, 1, hold) and hold then held = true end
    end
    if spec == 1 and mhDagger and ohDagger then build(N.Mutilate, true) end
    if spec == 3 and ((not hemoLeft or hemoLeft < 3) or not behind) then add(N.Hemorrhage, 1) end
    if behind then build(N.Backstab, spec == 3) end   -- si no estás detrás se salta
    add(N.SinisterStrike, 1)
    add(N.Hemorrhage, 1)
  end

  -- Cooldowns ofensivos (cola)
  -- Combate: se agrupan los cooldowns en este orden (Icy Veins): Danza de cuchillas -> Juerga de
  -- matanza -> Estimulación. Blade Flurry también es +20% de velocidad en un solo objetivo.
  if c.combat then
    if spec == 1 and cp >= 4 then add(N.ColdBlood, 2) end
    local bf = Aura("player", N.BladeFlurry)
    local ar = Aura("player", N.AdrenalineRush)
    if (spec == 2 or CF.db.aoe) and not bf then add(N.BladeFlurry, 2) end
    -- Juerga: con energía baja, Golpe rápido y Corte con >= 3 s, sin Estimulación activa (se desperdicia
    -- energía) y tras la Danza de cuchillas (activa o en cooldown)
    local bfDone = (not Known(N.BladeFlurry)) or bf or CDLeft(N.BladeFlurry) > 0
    if energy < 40 and sndLeft and sndLeft >= 3 and not ar and bfDone then add(N.KillingSpree, 2) end
    -- Estimulación: después de la Juerga (o directamente si no la tienes)
    if (not Known(N.KillingSpree)) or CDLeft(N.KillingSpree) > 0 then add(N.AdrenalineRush, 2) end
    if spec == 3 and energy >= 60 and not dance then add(N.ShadowDance, 2) end
  end

  -- Interrupción / defensivos (verde)
  if (UnitCastingInfo("target") or UnitChannelInfo("target"))
     and IsSpellInRange(N.Kick, "target") == 1 then
    add(N.Kick, 3)
  end
  if c.combat then
    if c.php < 0.50 then add(N.Evasion, 3) end
    if c.php < 0.35 then add(N.CloakOfShadows, 3) end
    if c.php < 0.20 then add(N.Vanish, 3) end
  end
end

-- Relleno infinito: Golpe siniestro (con 5 PC, el remate; desde sigilo, la apertura)
local function filler(c, N)
  if InStealth(N) then
    if c.behind then
      if mhDagger and Known(N.Ambush) then return N.Ambush end
      if Known(N.Garrote) then return N.Garrote end
    end
    return First((not c.boss) and N.CheapShot or nil, N.SinisterStrike)
  end
  if c.cp >= 5 and Known(N.Eviscerate) then
    if c.spec == 1 and Known(N.Envenom) and Aura("target", N.DeadlyPoison, true, true, true) then
      return N.Envenom
    end
    return N.Eviscerate
  end
  return First(N.SinisterStrike)
end

CF.Register("ROGUE", {
  ids = {
    SinisterStrike = 1752,  Backstab = 53,        Eviscerate = 2098,
    SliceAndDice = 5171,    Rupture = 1943,       Mutilate = 1329,
    Envenom = 32645,        Hemorrhage = 16511,   HungerForBlood = 51662,
    Garrote = 703,          Ambush = 8676,        CheapShot = 1833,
    ColdBlood = 14177,      BladeFlurry = 13877,  AdrenalineRush = 13750,
    KillingSpree = 51690,   ShadowDance = 51713,  Premeditation = 14183,
    Kick = 1766,            Vanish = 1856,        Stealth = 1784,
    DeadlyPoison = 2823,    FanOfKnives = 51723,  Evasion = 5277,
    CloakOfShadows = 31224, CutToTheChase = 51669,
  },
  -- Habilidades que exigen estar DETRÁS del objetivo (3.3.5): no se recomiendan de frente
  positional = { "Backstab", "Ambush", "Garrote" },
  init = function() CheckWeapons(); RefreshTalents() end,
  onEquipment = function() CheckWeapons(); RefreshTalents() end,
  slow = function(c) CheckWeapons(); RefreshTalents(); PoisonCheck(c) end,
  evaluate = evaluate,
  filler = filler,
})
