--[[
  PulseFlash - Update.lua  (WoW 3.3.5a)
  AVISO DE NUEVA VERSIÓN dentro del juego, por CHAT, para todos los jugadores del reino.

  Un addon de WoW no puede acceder a internet ni actualizarse solo, así que el aviso funciona
  como el de DBM / BigWigs: los jugadores con la versión nueva se la comunican por mensajes de
  addon (invisibles) a los que tienen una versión antigua.

    * CANAL PROPIO: al entrar, el addon se une a un canal de chat oculto (CHANNEL) que usan solo
      los jugadores de PulseFlash. Así el aviso llega a TODOS, estén o no en hermandad / grupo.
      Sus avisos de "entraste al canal" se ocultan y no se escribe nada en él.
    * También se envía por hermandad, grupo / banda y campo de batalla.
    * Si recibes una versión MÁS NUEVA que la tuya: mensaje en el chat con el enlace de descarga.
      La versión nueva queda guardada, así que el mensaje se repite al entrar al juego, cambiar
      de personaje o hacer /reload, hasta que actualices. Una vez por sesión y versión.
    * Si recibes una versión MÁS ANTIGUA, vuelves a emitir la tuya por el mismo medio (con
      límite de frecuencia) para que el que acaba de entrar se entere.
    * RECORDATORIO POR FECHA (independiente de otros jugadores): si esta versión tiene 10 días o
      más desde su fecha de publicación (PF.BUILD_DATE), cada 10 días el addon recuerda por chat
      que conviene revisar GitHub / CurseForge. Funciona aunque no haya ningún otro usuario.
    * NOVEDADES: al entrar por primera vez con una versión nueva se anuncian por chat (cl_*).
    * No hay susurros, ni ventanas, ni comando para desactivarlo.

  LIMITACIÓN: el aviso llega mientras haya conectado, en el mismo reino, al menos un jugador con
  la versión nueva. El enlace se publica aquí; cada jugador debe descargarla él mismo.

  ANTES DE PUBLICAR: comprueba PF.URL_GITHUB / PF.URL_CURSE (más abajo) y, en CADA release, pon en PF.BUILD_DATE la fecha de publicación (AAAA-MM-DD).
  La versión se lee del TOC (## Version), así que solo hay que subirla ahí en cada release.
]]
local PF = PulseFlash

----------------------------------------------------------------------
-- Configuración (edita estos valores)
----------------------------------------------------------------------
PF.URL_GITHUB = "https://github.com/Aquazksj/PulseFlash-v2.4/releases/tag/MaxDPS"   -- descarga en GitHub
PF.URL_CURSE  = "https://www.curseforge.com/wow/addons/pulseflash-v2-4"            -- página de CurseForge

PF.BUILD_DATE = "2026-10-16"         -- fecha de publicación de ESTA versión (AAAA-MM-DD): actualízala en cada release
local AGE_DAYS = 10                  -- días desde la publicación (y entre recordatorios) para avisar

local PREFIX = "PulseFlash"          -- prefijo de los mensajes de addon (máx. 16 caracteres)
local CHANNEL = "PulseFlashUpd"      -- canal oculto compartido por todos los usuarios del addon
local SEND_COOLDOWN = 30             -- segundos mínimos entre envíos al mismo medio
local LOGIN_DELAY = 6                -- segundos tras entrar al mundo antes del primer aviso / envío
local JOIN_TRIES = 15                -- intentos (1 por segundo) de esperar a que el canal esté listo

local DB
local myVersion = "0"
local lastSent = {}                  -- [medio] = instante del último envío
local sessionShown = "0"             -- última versión de la que ya avisamos en esta sesión
local pending = {}                   -- [medio] = instante en que responderé a una versión antigua
local REPLY_MIN, REPLY_MAX = 1, 8    -- retraso aleatorio (s) antes de responder

----------------------------------------------------------------------
-- Versiones: "2.5" / "2.5.1" -> comparación numérica por tramos
----------------------------------------------------------------------
local function Parse(v)
  local t = {}
  for n in tostring(v or ""):gmatch("(%d+)") do t[#t + 1] = tonumber(n) end
  return t
end

-- 1 si a > b | -1 si a < b | 0 si iguales
local function Compare(a, b)
  local pa, pb = Parse(a), Parse(b)
  for i = 1, math.max(#pa, #pb) do
    local x, y = pa[i] or 0, pb[i] or 0
    if x > y then return 1 elseif x < y then return -1 end
  end
  return 0
end
PF.CompareVersions = Compare

-- Solo se aceptan versiones con forma "2", "2.5" o "2.5.1" (nada de texto arbitrario)
local function ValidVersion(v)
  return type(v) == "string" and #v <= 12 and v:match("^%d+%.?%d*%.?%d*$") ~= nil
end

----------------------------------------------------------------------
-- Envío de mi versión
----------------------------------------------------------------------
local function ChannelId()
  local id = GetChannelName(CHANNEL)
  return (id and id > 0) and id or nil
end

-- medio: "GUILD" | "PARTY" | "RAID" | "BATTLEGROUND" | "CHANNEL"
local function Send(medium)
  local now = GetTime()
  if lastSent[medium] and now - lastSent[medium] < SEND_COOLDOWN then return end
  local msg = "V:" .. myVersion
  if medium == "CHANNEL" then
    local id = ChannelId()
    if not id then return end
    lastSent[medium] = now
    SendAddonMessage(PREFIX, msg, "CHANNEL", id)
  else
    lastSent[medium] = now
    SendAddonMessage(PREFIX, msg, medium)
  end
end

local function Broadcast()
  Send("CHANNEL")
  if IsInGuild and IsInGuild() then Send("GUILD") end
  local _, instType = IsInInstance()
  if instType == "pvp" then
    Send("BATTLEGROUND")
  elseif GetNumRaidMembers and GetNumRaidMembers() > 0 then
    Send("RAID")
  elseif GetNumPartyMembers and GetNumPartyMembers() > 0 then
    Send("PARTY")
  end
end

----------------------------------------------------------------------
-- Aviso por chat
----------------------------------------------------------------------
local function Notify(newVersion)
  sessionShown = newVersion
  PF.Msg(PF.T("upd_chat", myVersion, newVersion, PF.URL_GITHUB))
  PF.Msg(PF.T("upd_curse", PF.URL_CURSE))
end

-- Se recibió la versión `v` de otro jugador por el medio `medium`
local function OnVersion(v, medium)
  if not DB or not ValidVersion(v) then return end
  local c = Compare(v, myVersion)
  if c > 0 then
    if Compare(v, DB.update.newest or "0") > 0 then DB.update.newest = v end
    if Compare(v, sessionShown) > 0 then Notify(v) end
    pending[medium] = nil                            -- ya hay alguien con versión nueva hablando
  elseif c < 0 then
    -- Tiene una versión más antigua: respondo con la mía tras un retraso aleatorio, y solo si
    -- nadie más (con versión nueva) responde antes, para no inundar el canal
    if not pending[medium] then
      pending[medium] = GetTime() + REPLY_MIN + math.random() * (REPLY_MAX - REPLY_MIN)
    end
  else
    pending[medium] = nil                            -- otro con mi misma versión ya respondió
  end
end

----------------------------------------------------------------------
-- Novedades de la versión: se anuncian UNA vez por chat al entrar con una versión nueva instalada.
-- Los textos están en Locale.lua (cl_title, cl_1 ... cl_N): actualízalos en cada release.
----------------------------------------------------------------------
local CHANGELOG_LINES = 5
local function ShowChangelog()
  if DB.update.seenVersion == myVersion then return end
  DB.update.seenVersion = myVersion
  PF.Msg(PF.T("cl_title", myVersion))
  for i = 1, CHANGELOG_LINES do PF.Msg(PF.T("cl_" .. i)) end
end

----------------------------------------------------------------------
-- Recordatorio por fecha: no depende de que haya otros usuarios
----------------------------------------------------------------------
local function AgeReminder()
  local y, m, d = tostring(PF.BUILD_DATE):match("^(%d+)-(%d+)-(%d+)$")
  if not y then return end
  local built = time({ year = tonumber(y), month = tonumber(m), day = tonumber(d), hour = 12 })
  local now = time()
  if not built or not now then return end
  local days = math.floor((now - built) / 86400)
  if days < AGE_DAYS then return end
  local last = DB.update.lastAgeNotice
  if last and last <= now and (now - last) < AGE_DAYS * 86400 then return end
  DB.update.lastAgeNotice = now
  PF.Msg(PF.T("upd_age", myVersion, days, PF.URL_GITHUB))
  PF.Msg(PF.T("upd_curse", PF.URL_CURSE))
end

----------------------------------------------------------------------
-- Oculta los avisos de sistema del canal (entrar / salir) para que no ensucien el chat
----------------------------------------------------------------------
local function HideChannelNotices(_, _, ...)
  for i = 1, select("#", ...) do
    local a = select(i, ...)
    if type(a) == "string" and a:find(CHANNEL, 1, true) then return true end
  end
  return false
end

----------------------------------------------------------------------
-- Comando: /pf version (versión instalada y enlaces; no desactiva nada)
----------------------------------------------------------------------
function PF.VersionCommand()
  PF.Msg(PF.T("upd_version", myVersion))
  local n = DB and DB.update and DB.update.newest
  if n and Compare(n, myVersion) > 0 then
    PF.Msg(PF.T("upd_chat", myVersion, n, PF.URL_GITHUB))
  else
    PF.Msg(PF.T("upd_latest"))
  end
  PF.Msg("GitHub: " .. PF.URL_GITHUB)
  PF.Msg("CurseForge: " .. PF.URL_CURSE)
end

----------------------------------------------------------------------
-- Inicialización (la llama Core.lua en PLAYER_LOGIN: entrar, cambiar de personaje y /reload)
----------------------------------------------------------------------
function PF.Update_Init()
  DB = PF.db
  myVersion = (GetAddOnMetadata and GetAddOnMetadata("PulseFlash", "Version")) or "0"
  PF.version = myVersion
  DB.updateCheck = nil                              -- ajuste antiguo: el aviso ya no se puede apagar
  if type(DB.update) ~= "table" then DB.update = {} end
  DB.update.shown, DB.update.popupFor = nil, nil
  -- Si ya actualizaste a (o por encima de) la versión guardada, se borra el aviso pendiente
  if DB.update.newest and Compare(DB.update.newest, myVersion) <= 0 then
    DB.update.newest = nil
  end

  if ChatFrame_AddMessageEventFilter then
    ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL_NOTICE", HideChannelNotices)
    ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL_NOTICE_USER", HideChannelNotices)
    ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL_JOIN", HideChannelNotices)
    ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL_LEAVE", HideChannelNotices)
  end

  local f = CreateFrame("Frame")
  f:RegisterEvent("CHAT_MSG_ADDON")
  f:RegisterEvent("PARTY_MEMBERS_CHANGED")
  f:RegisterEvent("RAID_ROSTER_UPDATE")
  f:SetScript("OnEvent", function(_, event, prefix, message, medium, sender)
    if event == "CHAT_MSG_ADDON" then
      if prefix ~= PREFIX or sender == UnitName("player") then return end
      local v = message and message:match("^V:(.+)$")
      if v then OnVersion(v, medium) end
    else
      Send(GetNumRaidMembers() > 0 and "RAID" or "PARTY")       -- cambió el grupo / banda
    end
  end)

  -- Secuencia al entrar: aviso de la versión ya conocida -> unirse al canal -> enviar mi versión
  local timer, step, tries, tick = 0, 0, 0, 0
  f:SetScript("OnUpdate", function(_, dt)
    -- Respuestas pendientes a jugadores con versión antigua
    if next(pending) then
      local now = GetTime()
      for medium, at in pairs(pending) do
        if now >= at then pending[medium] = nil; Send(medium) end
      end
    end
    if step >= 3 then return end
    timer = timer + dt
    if step == 0 then
      if timer < LOGIN_DELAY then return end
      step = 1
      ShowChangelog()
      local n = DB.update.newest
      if n and Compare(n, myVersion) > 0 then
        Notify(n)                                      -- ya sé que hay una versión nueva
      else
        AgeReminder()                                  -- si no, recordatorio por antigüedad
      end
      JoinChannelByName(CHANNEL)
      tick = 0
    elseif step == 1 then
      tick = tick + dt
      if tick < 1 then return end
      tick = 0
      tries = tries + 1
      if ChannelId() then
        step = 3
        Broadcast()
      elseif tries >= JOIN_TRIES then
        step = 3
        Broadcast()                                            -- sin canal: al menos hermandad / grupo
      end
    end
  end)
end
