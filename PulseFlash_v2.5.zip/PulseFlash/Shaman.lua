-- PulseFlash: Chamán (Elemental / Mejora) - 3.3.5a
local CF = PulseFlash
local Aura, Known, Dot, Proc, First = CF.Aura, CF.Known, CF.Dot, CF.Proc, CF.First

local function evaluate(c, add, N)
  local spec = c.spec
  local fs = Aura("target", N.FlameShock, true, true)

  if spec == 2 then
    -- Mejora (cuerpo a cuerpo)
    Proc(add, N.MaelstromWeapon, N.LightningBolt, 5)        -- 5 cargas: Descarga instantánea
    if c.worth then Dot(add, c, N.FlameShock, fs) end
    add(N.Stormstrike, 1)
    add(N.LavaLash, 1)
    add(N.EarthShock, 1)
    if CF.db.aoe then add(N.ChainLightning, 1) end
    if c.combat then add(N.FeralSpirit, 2) end
  else
    -- Elemental / sin especialización (leveling): a distancia
    if c.worth then Dot(add, c, N.FlameShock, fs) end
    if fs and c.casting ~= N.LavaBurst then add(N.LavaBurst, 1) end
    if spec == 1 or CF.db.aoe then add(N.ChainLightning, 1) end
    if c.combat then add(N.ElementalMastery, 2) end
  end

  -- Interrupción / defensivos / utilidad (verde)
  if UnitCastingInfo("target") or UnitChannelInfo("target") then
    local kick = Known(N.WindShear) and N.WindShear or N.EarthShock
    if IsSpellInRange(kick, "target") == 1 then add(kick, 3) end
  end
  if c.combat then
    if c.php < 0.50 or c.manaPct < 0.25 then add(N.ShamanisticRage, 3) end
    if c.manaPct < 0.25 then add(N.Thunderstorm, 3) end
  end
end

-- Relleno infinito: Descarga de relámpagos
local function filler(c, N)
  return First(N.LightningBolt)
end

CF.Register("SHAMAN", {
  ids = {
    LightningBolt = 403,     ChainLightning = 421,     FlameShock = 8050,
    EarthShock = 8042,       LavaBurst = 51505,        Stormstrike = 17364,
    LavaLash = 60103,        LightningShield = 324,    WaterShield = 52127,
    WindShear = 57994,       ShamanisticRage = 30823,  FeralSpirit = 51533,
    ElementalMastery = 16166, Thunderstorm = 51490,
    MaelstromWeapon = 53817,   -- buff (proc)
    WindfuryWeapon = 8232, FlametongueWeapon = 8024, RockbiterWeapon = 8017,
  },
  evaluate = evaluate,
  filler = filler,
})
